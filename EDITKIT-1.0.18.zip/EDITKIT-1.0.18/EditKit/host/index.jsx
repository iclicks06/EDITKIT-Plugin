// ============================================================
// EditKit combined host script
// AlignIt functions + EaseIt functions (easeit_*, _ae_*,
// EaseItTH helpers) in one ExtendScript context, since a CEP
// extension only allows one host script.
// ============================================================

// ---------- AlignIt ----------
/**
 * ALIGN & ANCHOR PANEL ULTRA - Host Script
 * Versión con funcionalidades avanzadas de productividad
 */

// ============================================================================
// CONFIGURACIÓN GLOBAL
// ============================================================================

var SCRIPT_NAME = "AlignIt";

var MODE = {
    ALIGN: "align",
    ANCHOR: "anchor"
};

var DIRECTION = {
    LEFT: "left",
    RIGHT: "right",
    TOP: "top",
    BOTTOM: "bottom",
    CENTER_H: "centerH",
    CENTER_V: "centerV",
    TOP_LEFT: "topLeft",
    TOP_RIGHT: "topRight",
    BOTTOM_LEFT: "bottomLeft",
    BOTTOM_RIGHT: "bottomRight",
    CENTER: "center"
};

// ============================================================================
// UTILIDADES BÁSICAS
// ============================================================================

function getLayerContentBounds(layer, time) {
    try {
        if (layer instanceof CameraLayer || layer instanceof LightLayer) {
            return null;
        }
        var rect = layer.sourceRectAtTime(time, false);
        return {
            left: rect.left,
            top: rect.top,
            width: rect.width,
            height: rect.height
        };
    } catch (e) {
        return null;
    }
}

function localToComp(layer, localPoint, time) {
    var anchorPoint = layer.anchorPoint.valueAtTime(time, false);
    var position = layer.position.valueAtTime(time, false);
    var scale = layer.scale.valueAtTime(time, false);
    var rotation = layer.rotation.valueAtTime(time, false);
    
    var x = (localPoint[0] - anchorPoint[0]) * (scale[0] / 100);
    var y = (localPoint[1] - anchorPoint[1]) * (scale[1] / 100);
    
    var rad = rotation * Math.PI / 180;
    var cos = Math.cos(rad);
    var sin = Math.sin(rad);
    
    var rotX = x * cos - y * sin;
    var rotY = x * sin + y * cos;
    
    var compX = rotX + position[0];
    var compY = rotY + position[1];
    
    return [compX, compY];
}

function getCompBounds(layer, bounds, time) {
    var topLeft = [bounds.left, bounds.top];
    var topRight = [bounds.left + bounds.width, bounds.top];
    var bottomLeft = [bounds.left, bounds.top + bounds.height];
    var bottomRight = [bounds.left + bounds.width, bounds.top + bounds.height];
    
    var tl = localToComp(layer, topLeft, time);
    var tr = localToComp(layer, topRight, time);
    var bl = localToComp(layer, bottomLeft, time);
    var br = localToComp(layer, bottomRight, time);
    
    var allX = [tl[0], tr[0], bl[0], br[0]];
    var allY = [tl[1], tr[1], bl[1], br[1]];
    
    var left = Math.min.apply(null, allX);
    var right = Math.max.apply(null, allX);
    var top = Math.min.apply(null, allY);
    var bottom = Math.max.apply(null, allY);
    
    return {
        left: left,
        right: right,
        top: top,
        bottom: bottom,
        centerX: (left + right) / 2,
        centerY: (top + bottom) / 2,
        width: right - left,
        height: bottom - top
    };
}

function getSelectionBounds(layers, time) {
    var minLeft = Infinity;
    var maxRight = -Infinity;
    var minTop = Infinity;
    var maxBottom = -Infinity;
    
    for (var i = 0; i < layers.length; i++) {
        var bounds = getLayerContentBounds(layers[i], time);
        if (!bounds) continue;
        
        var compBounds = getCompBounds(layers[i], bounds, time);
        
        if (compBounds.left < minLeft) minLeft = compBounds.left;
        if (compBounds.right > maxRight) maxRight = compBounds.right;
        if (compBounds.top < minTop) minTop = compBounds.top;
        if (compBounds.bottom > maxBottom) maxBottom = compBounds.bottom;
    }
    
    return {
        left: minLeft,
        right: maxRight,
        top: minTop,
        bottom: maxBottom,
        centerX: (minLeft + maxRight) / 2,
        centerY: (minTop + maxBottom) / 2,
        width: maxRight - minLeft,
        height: maxBottom - minTop
    };
}

// ============================================================================
// ALINEACIÓN Y ANCHOR
// ============================================================================

function alignLayer(layer, direction, targetBounds, time, padding) {
    var bounds = getLayerContentBounds(layer, time);
    if (!bounds) return;
    
    var compBounds = getCompBounds(layer, bounds, time);
    var position = layer.position.valueAtTime(time, false);
    
    var offsetX = 0;
    var offsetY = 0;
    
    switch (direction) {
        case DIRECTION.LEFT:
            offsetX = (targetBounds.left + padding) - compBounds.left;
            break;
        case DIRECTION.RIGHT:
            offsetX = (targetBounds.right - padding) - compBounds.right;
            break;
        case DIRECTION.TOP:
            offsetY = (targetBounds.top + padding) - compBounds.top;
            break;
        case DIRECTION.BOTTOM:
            offsetY = (targetBounds.bottom - padding) - compBounds.bottom;
            break;
        case DIRECTION.CENTER_H:
            offsetX = targetBounds.centerX - compBounds.centerX;
            break;
        case DIRECTION.CENTER_V:
            offsetY = targetBounds.centerY - compBounds.centerY;
            break;
        case DIRECTION.TOP_LEFT:
            offsetX = (targetBounds.left + padding) - compBounds.left;
            offsetY = (targetBounds.top + padding) - compBounds.top;
            break;
        case DIRECTION.TOP_RIGHT:
            offsetX = (targetBounds.right - padding) - compBounds.right;
            offsetY = (targetBounds.top + padding) - compBounds.top;
            break;
        case DIRECTION.BOTTOM_LEFT:
            offsetX = (targetBounds.left + padding) - compBounds.left;
            offsetY = (targetBounds.bottom - padding) - compBounds.bottom;
            break;
        case DIRECTION.BOTTOM_RIGHT:
            offsetX = (targetBounds.right - padding) - compBounds.right;
            offsetY = (targetBounds.bottom - padding) - compBounds.bottom;
            break;
    }
    
    var newPosition = [
        position[0] + offsetX,
        position[1] + offsetY
    ];
    
    if (layer.threeDLayer && position.length === 3) {
        newPosition.push(position[2]);
    }
    
    if (layer.position.numKeys > 0) {
        layer.position.setValueAtTime(time, newPosition);
    } else {
        layer.position.setValue(newPosition);
    }
}

function moveAnchorPoint(layer, direction, time) {
    var bounds = getLayerContentBounds(layer, time);
    if (!bounds) return;
    
    var anchorPoint = layer.anchorPoint.valueAtTime(time, false);
    var position = layer.position.valueAtTime(time, false);
    var scale = layer.scale.valueAtTime(time, false);
    var rotation = layer.rotation.valueAtTime(time, false);
    
    var newAnchorX = anchorPoint[0];
    var newAnchorY = anchorPoint[1];
    
    switch (direction) {
        case DIRECTION.LEFT:
            newAnchorX = bounds.left;
            break;
        case DIRECTION.RIGHT:
            newAnchorX = bounds.left + bounds.width;
            break;
        case DIRECTION.TOP:
            newAnchorY = bounds.top;
            break;
        case DIRECTION.BOTTOM:
            newAnchorY = bounds.top + bounds.height;
            break;
        case DIRECTION.CENTER_H:
            newAnchorX = bounds.left + (bounds.width / 2);
            break;
        case DIRECTION.CENTER_V:
            newAnchorY = bounds.top + (bounds.height / 2);
            break;
        case DIRECTION.TOP_LEFT:
            newAnchorX = bounds.left;
            newAnchorY = bounds.top;
            break;
        case DIRECTION.TOP_RIGHT:
            newAnchorX = bounds.left + bounds.width;
            newAnchorY = bounds.top;
            break;
        case DIRECTION.BOTTOM_LEFT:
            newAnchorX = bounds.left;
            newAnchorY = bounds.top + bounds.height;
            break;
        case DIRECTION.BOTTOM_RIGHT:
            newAnchorX = bounds.left + bounds.width;
            newAnchorY = bounds.top + bounds.height;
            break;
    }
    
    var deltaAnchorX = newAnchorX - anchorPoint[0];
    var deltaAnchorY = newAnchorY - anchorPoint[1];
    
    var scaleX = scale[0] / 100;
    var scaleY = scale[1] / 100;
    
    var rad = rotation * Math.PI / 180;
    var cos = Math.cos(rad);
    var sin = Math.sin(rad);
    
    var scaledX = deltaAnchorX * scaleX;
    var scaledY = deltaAnchorY * scaleY;
    
    var deltaPosX = scaledX * cos - scaledY * sin;
    var deltaPosY = scaledX * sin + scaledY * cos;
    
    var newAnchor = [newAnchorX, newAnchorY];
    var newPosition = [
        position[0] + deltaPosX,
        position[1] + deltaPosY
    ];
    
    if (layer.threeDLayer) {
        if (anchorPoint.length === 3) {
            newAnchor.push(anchorPoint[2]);
        }
        if (position.length === 3) {
            newPosition.push(position[2]);
        }
    }
    
    if (layer.anchorPoint.numKeys > 0) {
        layer.anchorPoint.setValueAtTime(time, newAnchor);
    } else {
        layer.anchorPoint.setValue(newAnchor);
    }
    
    if (layer.position.numKeys > 0) {
        layer.position.setValueAtTime(time, newPosition);
    } else {
        layer.position.setValue(newPosition);
    }
}

// ============================================================================
// QUICK ACTIONS
// ============================================================================

function quickCenterBoth() {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) {
        return "Error: No hay composición activa";
    }
    
    var selectedLayers = comp.selectedLayers;
    if (selectedLayers.length === 0) {
        return "Error: No hay capas seleccionadas";
    }
    
    app.beginUndoGroup(SCRIPT_NAME + " - Centro Total");
    
    try {
        var time = comp.time;
        var targetBounds = {
            centerX: comp.width / 2,
            centerY: comp.height / 2
        };
        
        for (var i = 0; i < selectedLayers.length; i++) {
            var layer = selectedLayers[i];
            
            // Centrar posición
            alignLayer(layer, DIRECTION.CENTER_H, {centerX: targetBounds.centerX}, time, 0);
            alignLayer(layer, DIRECTION.CENTER_V, {centerY: targetBounds.centerY}, time, 0);
            
            // Centrar anchor
            moveAnchorPoint(layer, DIRECTION.CENTER_H, time);
            moveAnchorPoint(layer, DIRECTION.CENTER_V, time);
        }
        
        return "OK";
    } catch (e) {
        return "Error: " + e.toString();
    } finally {
        app.endUndoGroup();
    }
}

function quickMatchSize() {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) {
        return "Error: No hay composición activa";
    }
    
    var selectedLayers = comp.selectedLayers;
    if (selectedLayers.length < 2) {
        return "Error: Necesitas seleccionar al menos 2 capas";
    }
    
    app.beginUndoGroup(SCRIPT_NAME + " - Match Size");
    
    try {
        var time = comp.time;
        var firstLayer = selectedLayers[0];
        var firstBounds = getLayerContentBounds(firstLayer, time);
        
        if (!firstBounds) {
            return "Error: No se puede obtener tamaño de la primera capa";
        }
        
        var firstCompBounds = getCompBounds(firstLayer, firstBounds, time);
        var targetWidth = firstCompBounds.width;
        var targetHeight = firstCompBounds.height;
        
        for (var i = 1; i < selectedLayers.length; i++) {
            var layer = selectedLayers[i];
            var bounds = getLayerContentBounds(layer, time);
            
            if (!bounds) continue;
            
            var compBounds = getCompBounds(layer, bounds, time);
            var currentScale = layer.scale.valueAtTime(time, false);
            
            var scaleX = (targetWidth / compBounds.width) * currentScale[0];
            var scaleY = (targetHeight / compBounds.height) * currentScale[1];
            
            var newScale = [scaleX, scaleY];
            if (currentScale.length === 3) {
                newScale.push(currentScale[2]);
            }
            
            if (layer.scale.numKeys > 0) {
                layer.scale.setValueAtTime(time, newScale);
            } else {
                layer.scale.setValue(newScale);
            }
        }
        
        return "OK";
    } catch (e) {
        return "Error: " + e.toString();
    } finally {
        app.endUndoGroup();
    }
}

function quickStack(direction, spacing) {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) {
        return "Error: No hay composición activa";
    }
    
    var selectedLayers = comp.selectedLayers;
    if (selectedLayers.length < 2) {
        return "Error: Necesitas seleccionar al menos 2 capas";
    }
    
    app.beginUndoGroup(SCRIPT_NAME + " - Stack " + direction);
    
    try {
        var time = comp.time;
        var layersWithBounds = [];
        
        for (var i = 0; i < selectedLayers.length; i++) {
            var layer = selectedLayers[i];
            var bounds = getLayerContentBounds(layer, time);
            if (!bounds) continue;
            
            var compBounds = getCompBounds(layer, bounds, time);
            layersWithBounds.push({
                layer: layer,
                bounds: compBounds,
                index: layer.index
            });
        }
        
        // Ordenar por índice (orden en timeline)
        layersWithBounds.sort(function(a, b) {
            return a.index - b.index;
        });
        
        var currentPos = 0;
        
        for (var i = 0; i < layersWithBounds.length; i++) {
            var item = layersWithBounds[i];
            var layer = item.layer;
            var bounds = item.bounds;
            var position = layer.position.valueAtTime(time, false);
            
            if (i === 0) {
                // Primera capa mantiene su posición
                if (direction === "vertical") {
                    currentPos = bounds.bottom;
                } else {
                    currentPos = bounds.right;
                }
            } else {
                // Calcular nueva posición
                var offset = 0;
                
                if (direction === "vertical") {
                    var targetTop = currentPos + spacing;
                    offset = targetTop - bounds.top;
                    var newPosition = [position[0], position[1] + offset];
                    
                    if (layer.threeDLayer && position.length === 3) {
                        newPosition.push(position[2]);
                    }
                    
                    if (layer.position.numKeys > 0) {
                        layer.position.setValueAtTime(time, newPosition);
                    } else {
                        layer.position.setValue(newPosition);
                    }
                    
                    currentPos = targetTop + bounds.height;
                } else {
                    var targetLeft = currentPos + spacing;
                    offset = targetLeft - bounds.left;
                    var newPosition = [position[0] + offset, position[1]];
                    
                    if (layer.threeDLayer && position.length === 3) {
                        newPosition.push(position[2]);
                    }
                    
                    if (layer.position.numKeys > 0) {
                        layer.position.setValueAtTime(time, newPosition);
                    } else {
                        layer.position.setValue(newPosition);
                    }
                    
                    currentPos = targetLeft + bounds.width;
                }
            }
        }
        
        return "OK";
    } catch (e) {
        return "Error: " + e.toString();
    } finally {
        app.endUndoGroup();
    }
}

function quickFlip(direction) {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) {
        return "Error: No hay composición activa";
    }
    
    var selectedLayers = comp.selectedLayers;
    if (selectedLayers.length === 0) {
        return "Error: No hay capas seleccionadas";
    }
    
    app.beginUndoGroup(SCRIPT_NAME + " - Flip " + direction);
    
    try {
        var time = comp.time;
        
        for (var i = 0; i < selectedLayers.length; i++) {
            var layer = selectedLayers[i];
            var scale = layer.scale.valueAtTime(time, false);
            
            var newScale;
            if (direction === "horizontal") {
                newScale = [-scale[0], scale[1]];
            } else {
                newScale = [scale[0], -scale[1]];
            }
            
            if (scale.length === 3) {
                newScale.push(scale[2]);
            }
            
            if (layer.scale.numKeys > 0) {
                layer.scale.setValueAtTime(time, newScale);
            } else {
                layer.scale.setValue(newScale);
            }
        }
        
        return "OK";
    } catch (e) {
        return "Error: " + e.toString();
    } finally {
        app.endUndoGroup();
    }
}

// ============================================================================
// COPY TRANSFORM
// ============================================================================

function copyTransform(transformType) {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) {
        return "Error: No hay composición activa";
    }
    
    var selectedLayers = comp.selectedLayers;
    if (selectedLayers.length < 2) {
        return "Error: Necesitas seleccionar al menos 2 capas";
    }
    
    app.beginUndoGroup(SCRIPT_NAME + " - Copy " + transformType);
    
    try {
        var time = comp.time;
        var sourceLayer = selectedLayers[0];
        var sourceValue;
        
        switch(transformType) {
            case "copyPosition":
                sourceValue = sourceLayer.position.valueAtTime(time, false);
                break;
            case "copyAnchor":
                sourceValue = sourceLayer.anchorPoint.valueAtTime(time, false);
                break;
            case "copyScale":
                sourceValue = sourceLayer.scale.valueAtTime(time, false);
                break;
            default:
                return "Error: Tipo de transform no válido";
        }
        
        for (var i = 1; i < selectedLayers.length; i++) {
            var targetLayer = selectedLayers[i];
            var property;
            
            switch(transformType) {
                case "copyPosition":
                    property = targetLayer.position;
                    break;
                case "copyAnchor":
                    property = targetLayer.anchorPoint;
                    break;
                case "copyScale":
                    property = targetLayer.scale;
                    break;
            }
            
            if (property.numKeys > 0) {
                property.setValueAtTime(time, sourceValue);
            } else {
                property.setValue(sourceValue);
            }
        }
        
        return "OK";
    } catch (e) {
        return "Error: " + e.toString();
    } finally {
        app.endUndoGroup();
    }
}

// ============================================================================
// DISTRIBUTE LAYERS
// ============================================================================

function distributeLayersEvenly(direction) {
    var comp = app.project.activeItem;
    
    if (!comp || !(comp instanceof CompItem)) {
        return "Error: No hay composición activa";
    }
    
    var selectedLayers = comp.selectedLayers;
    
    if (selectedLayers.length < 3) {
        return "Error: Necesitas al menos 3 capas";
    }
    
    app.beginUndoGroup(SCRIPT_NAME + " - Distribute " + direction);
    
    try {
        var time = comp.time;
        var layersWithBounds = [];
        
        for (var i = 0; i < selectedLayers.length; i++) {
            var layer = selectedLayers[i];
            var bounds = getLayerContentBounds(layer, time);
            if (!bounds) continue;
            
            var compBounds = getCompBounds(layer, bounds, time);
            
            layersWithBounds.push({
                layer: layer,
                bounds: compBounds
            });
        }
        
        if (layersWithBounds.length < 3) {
            return "Error: No hay suficientes capas válidas";
        }
        
        if (direction === "horizontal") {
            layersWithBounds.sort(function(a, b) {
                return a.bounds.centerX - b.bounds.centerX;
            });
        } else {
            layersWithBounds.sort(function(a, b) {
                return a.bounds.centerY - b.bounds.centerY;
            });
        }
        
        var first = layersWithBounds[0];
        var last = layersWithBounds[layersWithBounds.length - 1];
        
        var totalSpace = direction === "horizontal" 
            ? (last.bounds.centerX - first.bounds.centerX)
            : (last.bounds.centerY - first.bounds.centerY);
        
        var spacing = totalSpace / (layersWithBounds.length - 1);
        
        for (var i = 1; i < layersWithBounds.length - 1; i++) {
            var item = layersWithBounds[i];
            var layer = item.layer;
            var bounds = item.bounds;
            var position = layer.position.valueAtTime(time, false);
            
            var targetCenter = direction === "horizontal"
                ? first.bounds.centerX + (spacing * i)
                : first.bounds.centerY + (spacing * i);
            
            var currentCenter = direction === "horizontal" ? bounds.centerX : bounds.centerY;
            var offset = targetCenter - currentCenter;
            
            var newPosition = direction === "horizontal"
                ? [position[0] + offset, position[1]]
                : [position[0], position[1] + offset];
            
            if (layer.threeDLayer && position.length === 3) {
                newPosition.push(position[2]);
            }
            
            if (layer.position.numKeys > 0) {
                layer.position.setValueAtTime(time, newPosition);
            } else {
                layer.position.setValue(newPosition);
            }
        }
        
        return "OK";
        
    } catch (e) {
        return "Error: " + e.toString();
    } finally {
        app.endUndoGroup();
    }
}

// ============================================================================
// FUNCIÓN PRINCIPAL - ALIGNMENT
// ============================================================================

function executeAlignment(direction, mode, doubleDuty, target, padding) {
    var comp = app.project.activeItem;
    
    if (!comp || !(comp instanceof CompItem)) {
        return "Error: No hay composición activa";
    }
    
    var selectedLayers = comp.selectedLayers;
    
    if (selectedLayers.length === 0) {
        return "Error: No hay capas seleccionadas";
    }
    
    app.beginUndoGroup(SCRIPT_NAME + " - " + direction);
    
    try {
        var time = comp.time;
        padding = padding || 0;
        
        var targetBounds;
        
        if (target === "selection" && selectedLayers.length > 1) {
            targetBounds = getSelectionBounds(selectedLayers, time);
        } else {
            targetBounds = {
                left: 0,
                right: comp.width,
                top: 0,
                bottom: comp.height,
                centerX: comp.width / 2,
                centerY: comp.height / 2,
                width: comp.width,
                height: comp.height
            };
        }
        
        for (var i = 0; i < selectedLayers.length; i++) {
            var layer = selectedLayers[i];
            
            if (direction === DIRECTION.CENTER || direction === "center") {
                if (mode === MODE.ALIGN || doubleDuty) {
                    alignLayer(layer, DIRECTION.CENTER_H, targetBounds, time, padding);
                    alignLayer(layer, DIRECTION.CENTER_V, targetBounds, time, padding);
                }
                if (mode === MODE.ANCHOR || doubleDuty) {
                    moveAnchorPoint(layer, DIRECTION.CENTER_H, time);
                    moveAnchorPoint(layer, DIRECTION.CENTER_V, time);
                }
            } else {
                if (mode === MODE.ALIGN || doubleDuty) {
                    alignLayer(layer, direction, targetBounds, time, padding);
                }
                if (mode === MODE.ANCHOR || doubleDuty) {
                    moveAnchorPoint(layer, direction, time);
                }
            }
        }
        
        return "OK";
        
    } catch (e) {
        return "Error: " + e.toString();
    } finally {
        app.endUndoGroup();
    }
}
// ---------- EaseIt ----------
// =============================================================
// EaseIt - Premiere Pro ExtendScript Host
// Applies custom easing curves to clip keyframes by "baking":
// Premiere's scripting API exposes addKey / setValueAtKey /
// setInterpolationTypeAtKey but NOT custom bezier handles, so we
// sample the curve per-frame and write dense linear keyframes.
// NOTE: host runs a pre-ES5 engine -> no trim/map/indexOf/JSON/let/=>.
// =============================================================

// ------- JSON POLYFILL -------
if (typeof JSON === 'undefined') { JSON = {}; }
if (typeof JSON.parse !== 'function') {
    JSON.parse = function (str) { return eval('(' + str + ')'); };
}
if (typeof JSON.stringify !== 'function') {
    JSON.stringify = function (val) {
        if (val === null || typeof val === 'undefined') return 'null';
        if (typeof val === 'number' || typeof val === 'boolean') return String(val);
        if (typeof val === 'string') {
            return '"' + val.replace(/\\/g, '\\\\').replace(/"/g, '\\"')
                            .replace(/\n/g, '\\n').replace(/\r/g, '\\r') + '"';
        }
        if (val instanceof Array) {
            var items = [];
            for (var i = 0; i < val.length; i++) items.push(JSON.stringify(val[i]));
            return '[' + items.join(',') + ']';
        }
        if (typeof val === 'object') {
            var pairs = [];
            for (var k in val) {
                if (val.hasOwnProperty(k)) pairs.push('"' + k + '":' + JSON.stringify(val[k]));
            }
            return '{' + pairs.join(',') + '}';
        }
        return 'null';
    };
}

// ------- ES3 HELPERS -------
var TICKS_PER_SECOND = 254016000000; // Premiere fixed tick rate

function _trim(s) { return String(s).replace(/^\s+|\s+$/g, ''); }
function _containsCI(hay, needle) {
    return String(hay).toLowerCase().indexOf(String(needle).toLowerCase()) >= 0;
}
function _isArr(v) { return v !== null && typeof v === 'object' && typeof v.length === 'number'; }

function _collToArray(coll) {
    var out = [];
    if (!coll) return out;
    var n = null;
    if (typeof coll.numItems === 'number') n = coll.numItems;
    else if (typeof coll.length === 'number') n = coll.length;
    if (n === null) return out;
    for (var i = 0; i < n; i++) { try { out.push(coll[i]); } catch (e) {} }
    return out;
}

// ------- CUBIC BEZIER (CSS-style: implicit endpoints 0,0 and 1,1) -------
function _bezX(s, x1, x2) { var c = 1 - s; return 3 * c * c * s * x1 + 3 * c * s * s * x2 + s * s * s; }
function _bezY(s, y1, y2) { var c = 1 - s; return 3 * c * c * s * y1 + 3 * c * s * s * y2 + s * s * s; }
function _solveBez(x, x1, y1, x2, y2) {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    var lo = 0, hi = 1, s = x, xs;
    for (var i = 0; i < 40; i++) {
        xs = _bezX(s, x1, x2);
        if (Math.abs(xs - x) < 0.000005) break;
        if (xs < x) lo = s; else hi = s;
        s = (lo + hi) / 2;
    }
    return _bezY(s, y1, y2);
}

// formula easings (must match client FN exactly) — for baked Elastic/Bounce presets
var _TAU = 2 * Math.PI;
function _bounceOut(t) {
    var n1 = 7.5625, d1 = 2.75;
    if (t < 1 / d1) return n1 * t * t;
    if (t < 2 / d1) { t -= 1.5 / d1; return n1 * t * t + 0.75; }
    if (t < 2.5 / d1) { t -= 2.25 / d1; return n1 * t * t + 0.9375; }
    t -= 2.625 / d1; return n1 * t * t + 0.984375;
}
var HOST_FN = {
    elasticOut: function (t) { if (t <= 0) return 0; if (t >= 1) return 1; var p = 0.3, s = p / 4; return Math.pow(2, -10 * t) * Math.sin((t - s) * _TAU / p) + 1; },
    elasticIn: function (t) { if (t <= 0) return 0; if (t >= 1) return 1; var p = 0.3, s = p / 4; return -(Math.pow(2, 10 * (t - 1)) * Math.sin((t - 1 - s) * _TAU / p)); },
    elasticInOut: function (t) { if (t <= 0) return 0; if (t >= 1) return 1; var p = 0.45, s = p / 4; t *= 2; if (t < 1) return -0.5 * (Math.pow(2, 10 * (t - 1)) * Math.sin((t - 1 - s) * _TAU / p)); return Math.pow(2, -10 * (t - 1)) * Math.sin((t - 1 - s) * _TAU / p) * 0.5 + 1; },
    bounceOut: function (t) { return _bounceOut(t); },
    bounceIn: function (t) { return 1 - _bounceOut(1 - t); },
    bounceInOut: function (t) { return t < 0.5 ? (1 - _bounceOut(1 - 2 * t)) / 2 : (1 + _bounceOut(2 * t - 1)) / 2; }
};

// multi-point path eval (segments: [p0x,p0y,c1x,c1y,c2x,c2y,p3x,p3y]) — must match client
function _cubicAt(t, a, b, c, d) { var u = 1 - t; return u * u * u * a + 3 * u * u * t * b + 3 * u * t * t * c + t * t * t * d; }
function _solveSeg(x, s) {
    if (x <= s[0]) return s[1];
    if (x >= s[6]) return s[7];
    var lo = 0, hi = 1, t = 0.5, xs;
    for (var i = 0; i < 40; i++) { xs = _cubicAt(t, s[0], s[2], s[4], s[6]); if (Math.abs(xs - x) < 0.000005) break; if (xs < x) lo = t; else hi = t; t = (lo + hi) / 2; }
    return _cubicAt(t, s[1], s[3], s[5], s[7]);
}
function _solvePath(x, segs) {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    for (var i = 0; i < segs.length; i++) { if (x >= segs[i][0] && x <= segs[i][6]) return _solveSeg(x, segs[i]); }
    return 1;
}
// x positions (0..1) for the FEW keyframes a formula easing needs: endpoints + local extrema
function _formulaKeyXs(fn) {
    var N = 240, xs = [0], prevD = null, prevX = 0;
    for (var i = 1; i < N; i++) {
        var x = i / N, h = 0.5 / N;
        var d = fn(Math.min(1, x + h)) - fn(Math.max(0, x - h));
        if (prevD !== null && ((prevD > 0 && d <= 0) || (prevD < 0 && d >= 0)) && (x - prevX) > 0.012) { xs.push(x); prevX = x; }
        prevD = d;
    }
    xs.push(1);
    return xs;
}

function _lerpVal(v0, v1, t) {
    if (_isArr(v0) && _isArr(v1)) {
        var r = [], n = Math.min(v0.length, v1.length);
        for (var i = 0; i < n; i++) r.push(Number(v0[i]) + (Number(v1[i]) - Number(v0[i])) * t);
        return r;
    }
    return Number(v0) + (Number(v1) - Number(v0)) * t;
}

// ------- SEQUENCE / CLIP / PARAM LOOKUP -------
function _getSeq() {
    var seq = app.project ? app.project.activeSequence : null;
    return seq || null;
}

function _fpsOf(seq) {
    // timebase = ticks per frame (string)
    try {
        var tpf = Number(seq.timebase);
        if (tpf && tpf > 0) return TICKS_PER_SECOND / tpf;
    } catch (e) {}
    try {
        var fr = seq.getSettings().videoFrameRate; // Time object (ticks)
        var t = (fr && fr.ticks !== undefined) ? Number(fr.ticks) : Number(fr);
        if (t && t > 0) return TICKS_PER_SECOND / t;
    } catch (e2) {}
    return 30; // safe fallback
}

function _getSelectedClip(seq) {
    // Preferred: sequence selection
    try {
        if (seq.getSelection) {
            var sel = _collToArray(seq.getSelection());
            for (var i = 0; i < sel.length; i++) {
                if (sel[i] && sel[i].components) return sel[i];
            }
        }
    } catch (e) {}
    // Fallback: scan video tracks for a selected clip
    try {
        var vt = seq.videoTracks;
        var nT = vt.numTracks;
        for (var t = 0; t < nT; t++) {
            var clips = vt[t].clips;
            var nC = clips.numItems;
            for (var c = 0; c < nC; c++) {
                var clip = clips[c];
                try { if (clip.isSelected && clip.isSelected()) return clip; } catch (e2) {}
            }
        }
    } catch (e3) {}
    return null;
}

// Map UI property -> { component displayName contains, param displayName }
var PROP_MAP = {
    "Position":     { comp: "Motion",  param: "Position",     dims: 2 },
    "Scale":        { comp: "Motion",  param: "Scale",        dims: 1 },
    "Rotation":     { comp: "Motion",  param: "Rotation",     dims: 1 },
    "Anchor Point": { comp: "Motion",  param: "Anchor Point", dims: 2 },
    "Opacity":      { comp: "Opacity", param: "Opacity",      dims: 1 }
};

/* Premiere LOCALISES displayName. The table above is English, so on a Spanish
   install "Movimiento" never equals "Motion" and every standard property fails
   with "Could not find 'Position' on this clip" — the panel looks broken in
   every language Adobe ships but one.
   Spanish is transcribed from a real Spanish Premiere; the rest are the usual
   Adobe translations and are best-effort. A wrong entry costs nothing: it
   simply never matches, and the English name is always tried first. */
var PROP_ALIASES = {
    "Motion":       ["motion", "movimiento", "mouvement", "bewegung", "movimento",
                     "beweging", "ruch", "hareket", "動き", "モーション",
                     "运动", "運動", "движение"],
    "Opacity":      ["opacity", "opacidad", "opacité", "deckkraft", "opacidade",
                     "opacità", "dekking", "krycie", "opaklık", "不透明度",
                     "불투명도", "непрозрачность"],
    "Position":     ["position", "posición", "posicion", "posição", "posizione",
                     "positie", "pozycja", "konum", "位置", "位置",
                     "위치", "положение", "позиция"],
    "Scale":        ["scale", "escala", "échelle", "echelle", "skalierung",
                     "scala", "schaal", "skala", "ölçek", "スケール",
                     "缩放", "縮放", "비율", "масштаб"],
    "Rotation":     ["rotation", "rotación", "rotacion", "rotação", "rotazione",
                     "drehung", "rotatie", "obrót", "döndürme", "回転",
                     "旋转", "旋轉", "회전", "поворот"],
    "Anchor Point": ["anchor point", "punto de anclaje", "point d'ancrage", "ankerpunkt",
                     "ponto de ancoragem", "punto di ancoraggio", "ankerpunt",
                     "punkt zaczepienia", "sabitleme noktası", "アンカーポイント",
                     "锚点", "錨點", "기준점", "точка привязки"]
};

// Does this localised displayName mean `canonical`? Exact match against the
// alias list; falls back to the canonical name itself for anything unlisted.
function _isName(displayName, canonical) {
    var low = String(displayName === null || typeof displayName === 'undefined' ? "" : displayName).toLowerCase();
    if (!low) return false;
    if (low === String(canonical).toLowerCase()) return true;
    var list = PROP_ALIASES[canonical];
    if (!list) return false;
    for (var i = 0; i < list.length; i++) { if (low === list[i]) return true; }
    return false;
}

function _isFiniteNum(n) { return typeof n === 'number' && !isNaN(n) && isFinite(n); }
// Dimensionality of a live value read (custom effect params have no PROP_MAP entry,
// so their dims come from the value itself: array length, else scalar).
function _dimsOfVal(v) { return _isArr(v) ? v.length : 1; }
// A value is safe to bake only if it matches the property's dimensionality with
// real finite numbers. This is what stops a misread point from writing (0,0).
function _validValue(v, dims) {
    if (dims >= 2) {
        if (!_isArr(v) || v.length < dims) return false;
        for (var i = 0; i < dims; i++) { if (!_isFiniteNum(Number(v[i]))) return false; }
        return true;
    }
    if (_isArr(v)) return v.length >= 1 && _isFiniteNum(Number(v[0]));
    return _isFiniteNum(Number(v));
}

function _findComponent(clip, compName) {
    var comps = _collToArray(clip.components);
    var i, dn;
    // exact name or a known translation of it
    for (i = 0; i < comps.length; i++) {
        dn = "";
        try { dn = comps[i].displayName; } catch (e) {}
        if (_isName(dn, compName)) return comps[i];
    }
    // last resort: the old substring match, for names no table knows
    for (i = 0; i < comps.length; i++) {
        dn = "";
        try { dn = comps[i].displayName; } catch (e2) {}
        if (_containsCI(dn, compName)) return comps[i];
    }
    return null;
}

function _findParam(component, paramName) {
    var params = _collToArray(component.properties);
    // exact name or a known translation first (avoid "Scale Width" when asking "Scale")
    for (var i = 0; i < params.length; i++) {
        var dn = "";
        try { dn = params[i].displayName; } catch (e) {}
        if (_isName(dn, paramName)) return params[i];
    }
    for (var j = 0; j < params.length; j++) {
        var dn2 = "";
        try { dn2 = params[j].displayName; } catch (e2) {}
        if (_containsCI(dn2, paramName)) return params[j];
    }
    return null;
}

function _findParamExact(component, paramName) {
    var params = _collToArray(component.properties);
    for (var i = 0; i < params.length; i++) {
        var dn = "";
        try { dn = params[i].displayName; } catch (e) {}
        // an exact reference stored by the panel wins; otherwise a translation
        if (String(dn).toLowerCase() === String(paramName).toLowerCase()) return params[i];
    }
    for (var j = 0; j < params.length; j++) {
        var dn2 = "";
        try { dn2 = params[j].displayName; } catch (e2) {}
        if (_isName(dn2, paramName)) return params[j];
    }
    return null;
}
// Resolve an EXPLICIT effect-param reference from the panel's custom list:
// ref = { comp: "<effect displayName>", compIdx: <n-th same-named instance>, param: "<param displayName>" }.
// Exact displayName matches only — a rename/removal must fail loudly, never grab a lookalike.
function _resolveParamRef(clip, ref) {
    if (!ref || !ref.comp || !ref.param) return null;
    var want = 0;
    try { want = Math.max(0, Math.floor(Number(ref.compIdx) || 0)); } catch (e) {}
    var comps = _collToArray(clip.components);
    var idx = 0;
    for (var i = 0; i < comps.length; i++) {
        var dn = "";
        try { dn = String(comps[i].displayName); } catch (e2) {}
        if (dn.toLowerCase() !== String(ref.comp).toLowerCase()) continue;
        if (idx === want) return _findParamExact(comps[i], ref.param);
        idx++;
    }
    return null;
}

// Resolve a UI property to a clip param. An explicit ref (custom effect param picked
// from the panel's scan) wins outright. Otherwise the 5 standard props: the intrinsic
// component (Motion/Opacity) first, then any "Transform" effect on the clip — it
// carries its own Position/Scale/Rotation/Anchor Point/Opacity and users animate those
// instead of Motion (previously unsupported). Whichever candidate actually has >=2
// keyframes wins, so the easing lands on the keyframes the user is looking at.
/* Names of the properties on this clip that actually carry an animation, for
   error messages. Premiere reports localised names, which is exactly what the
   user sees in Effect Controls, so they are quotable as-is. */
function _keyedParamHint(clip) {
    var out = [];
    try {
        var comps = _collToArray(clip.components);
        for (var i = 0; i < comps.length && out.length < 6; i++) {
            var cn = ""; try { cn = String(comps[i].displayName); } catch (e1) {}
            var params = _collToArray(comps[i].properties);
            for (var j = 0; j < params.length && out.length < 6; j++) {
                var pn = ""; try { pn = String(params[j].displayName); } catch (e2) {}
                var kc = 0; try { kc = _getKeyTimes(params[j]).length; } catch (e3) {}
                if (kc >= 2 && pn) out.push(cn ? (cn + " > " + pn) : pn);
            }
        }
    } catch (e4) {}
    if (!out.length) return "";
    return " Con keyframes en este clip: " + out.join(", ") + ".";
}
function _resolveParam(clip, uiProp, ref) {
    if (ref && ref.comp && ref.param) return _resolveParamRef(clip, ref);
    var map = PROP_MAP[uiProp];
    if (!map) return null;
    var cands = [];
    var fixed = _findComponent(clip, map.comp);
    if (fixed) { var fp = _findParam(fixed, map.param); if (fp) cands.push(fp); }
    var comps = _collToArray(clip.components);
    for (var i = 0; i < comps.length; i++) {
        var dn = "";
        try { dn = String(comps[i].displayName); } catch (e) {}
        if (!_containsCI(dn, "Transform")) continue;
        // Transform's Scale is split into Scale Height/Width (Height drives Uniform Scale)
        var names = (uiProp === "Scale") ? ["Scale", "Scale Height", "Scale Width"] : [map.param];
        for (var nIdx = 0; nIdx < names.length; nIdx++) {
            var p2 = _findParamExact(comps[i], names[nIdx]);
            if (p2) cands.push(p2);
        }
    }
    for (var c = 0; c < cands.length; c++) {
        var kc = 0;
        try { kc = _getKeyTimes(cands[c]).length; } catch (e2) {}
        if (kc >= 2) return cands[c];
    }

    /* Still nothing animated in the usual places. A graphic keyframed through
       the Essential Graphics panel puts its Position inside the graphics
       component's own transform, not in the clip's Motion, so asking for
       "Position" found the clip's — which has no keyframes at all. Sweep every
       component for a property of the same name that does carry an animation.
       Only reached when the normal candidates came up empty, and only accepted
       when it actually has keyframes, so it can never hijack a real target. */
    for (var g = 0; g < comps.length; g++) {
        var gp = _collToArray(comps[g].properties);
        for (var q = 0; q < gp.length; q++) {
            var qn = "";
            try { qn = String(gp[q].displayName); } catch (e3) {}
            if (!_isName(qn, map.param)) continue;
            var kq = 0;
            try { kq = _getKeyTimes(gp[q]).length; } catch (e4) {}
            if (kq >= 2) return gp[q];
        }
    }

    if (!cands.length) return null;
    return cands[0];
}

// Every KEYFRAMED, numeric, keyframe-capable param on the clip beyond the standard 5 —
// the panel merges these into the "Apply to" dropdown so ANY effect param can be eased
// (Blurriness, Crop edges, Lumetri sliders, third-party effects…). Only params the user
// has already keyframed are listed (easing needs keyframes anyway, and it keeps the menu
// out of Lumetri's ~60-param flood). compIdx disambiguates duplicate effect instances.
function _customParamList(clip) {
    var out = [];
    var comps = _collToArray(clip.components);
    var seen = {}; // lowercased comp name -> instances seen so far
    for (var i = 0; i < comps.length; i++) {
        var dn = "";
        try { dn = String(comps[i].displayName); } catch (e1) {}
        if (!dn) continue;
        var low = dn.toLowerCase();
        var idx = seen[low] || 0;
        seen[low] = idx + 1;
        // exact names only — an effect merely CONTAINING "Motion" must not be skipped
        var isMotion = _isName(dn, "Motion"), isOpac = _isName(dn, "Opacity");
        var params = _collToArray(comps[i].properties);
        for (var j = 0; j < params.length; j++) {
            var pn = "";
            try { pn = String(params[j].displayName); } catch (e2) {}
            if (!pn) continue;
            // the standard dropdown entries already cover these
            if (isMotion && (_isName(pn, "Position") || _isName(pn, "Scale") ||
                             _isName(pn, "Rotation") || _isName(pn, "Anchor Point"))) continue;
            if (isOpac && _isName(pn, "Opacity")) continue;
            var sup = false;
            try { sup = !!params[j].areKeyframesSupported(); } catch (e3) {}
            if (!sup) continue;
            var kc = 0;
            try { kc = _getKeyTimes(params[j]).length; } catch (e4) {}
            if (kc < 1) continue;
            var v = null;
            try { v = params[j].getValue(); } catch (e5) {}
            if (v === null || typeof v === 'undefined') { // some params only answer at a key
                try { var ko = _keyObjs(params[j]); if (ko.length) v = params[j].getValueAtKey(ko[0]); } catch (e6) {}
            }
            if (typeof v === 'boolean') continue; // checkboxes can't be eased
            var dims = _dimsOfVal(v);
            if (!_validValue(v, dims)) continue;  // non-numeric (text/media/color-wheel) params
            out.push({ comp: dn, compIdx: idx, param: pn, dims: dims, keys: kc });
        }
    }
    return out;
}

// seconds from a Time object (or a raw number/ticks fallback)
function _secOf(t) {
    if (t === null || typeof t === 'undefined') return null;
    if (typeof t === 'object' && t.seconds !== undefined) return Number(t.seconds);
    var n = Number(t);
    if (isNaN(n)) return null;
    if (n > 100000) return n / TICKS_PER_SECOND; // looks like ticks
    return n;
}

// Build a Premiere Time object at the given seconds. CRITICAL: the keyframe
// value methods (getValueAtKey/addKey/setValueAtKey/setInterpolationTypeAtKey)
// require a Time OBJECT, not a number — passing a number returns null.
function _mkTime(sec) {
    var t = new Time();
    t.seconds = sec;
    return t;
}

// getKeys() returns an array of Time OBJECTS; keep them as objects (sorted).
function _keyObjs(param) {
    var out = [];
    var raw;
    try { raw = param.getKeys(); } catch (e) { return out; }
    if (raw === null || typeof raw === 'undefined' || raw === 0) return out;
    if (typeof raw === 'string') {
        // legacy: comma-separated numbers -> rebuild Time objects
        var parts = raw.split(',');
        for (var i = 0; i < parts.length; i++) {
            var s = _secOf(_trim(parts[i]));
            if (s !== null) out.push(_mkTime(s));
        }
    } else {
        out = _collToArray(raw);
    }
    out.sort(function (a, b) { return (_secOf(a) || 0) - (_secOf(b) || 0); });
    return out;
}

// seconds array (used for keyframe COUNT and display)
function _getKeyTimes(param) {
    var objs = _keyObjs(param), out = [];
    for (var i = 0; i < objs.length; i++) { var s = _secOf(objs[i]); if (s !== null) out.push(s); }
    return out;
}

// Snap caller-supplied anchor times (seconds) to the nearest real key Time object
// (within ~1.5 frames), sorted + deduped. Keeps re-bakes locked to the originals.
function _snapAnchorObjs(keyObjs, providedSecs, fps) {
    var eps = 1.5 / fps;
    var out = [];
    for (var i = 0; i < providedSecs.length; i++) {
        var a = Number(providedSecs[i]);
        var best = null, bestD = eps;
        for (var j = 0; j < keyObjs.length; j++) {
            var d = Math.abs(_secOf(keyObjs[j]) - a);
            if (d < bestD) { bestD = d; best = keyObjs[j]; }
        }
        if (best !== null) out.push(best);
    }
    out.sort(function (x, y) { return _secOf(x) - _secOf(y); });
    var dd = [];
    for (var k = 0; k < out.length; k++) {
        if (k === 0 || Math.abs(_secOf(out[k]) - _secOf(dd[dd.length - 1])) > 0.0001) dd.push(out[k]);
    }
    return dd;
}

function _nearAnySec(s, anchorSecs, eps) {
    for (var i = 0; i < anchorSecs.length; i++) { if (Math.abs(s - anchorSecs[i]) <= eps) return true; }
    return false;
}
function _keyObjNearest(keyObjs, sec) {
    var best = null, bd = 1e12;
    for (var i = 0; i < keyObjs.length; i++) { var d = Math.abs(_secOf(keyObjs[i]) - sec); if (d < bd) { bd = d; best = keyObjs[i]; } }
    return best;
}

// =============================================================
// AFTER EFFECTS IMPLEMENTATION
// One ZXP serves both apps; the host script self-detects which it is in.
// `CompItem` is a global only inside After Effects.
// =============================================================
var IS_AE = (typeof CompItem !== 'undefined');

var AE_PROP = {
    "Position":     "ADBE Position",
    "Scale":        "ADBE Scale",
    "Rotation":     "ADBE Rotate Z",
    "Anchor Point": "ADBE Anchor Point",
    "Opacity":      "ADBE Opacity"
};

function _aeComp() {
    var it = app.project ? app.project.activeItem : null;
    return (it && it instanceof CompItem) ? it : null;
}
function _aeLayer(comp) {
    if (!comp) return null;
    var sel = comp.selectedLayers;
    return (sel && sel.length > 0) ? sel[0] : null;
}
function _aeResolve(layer, uiName) {
    try {
        var tg = layer.property("ADBE Transform Group");
        if (tg) { var p = tg.property(AE_PROP[uiName]); if (p) return p; }
    } catch (e) {}
    try { return layer.property(uiName) || null; } catch (e2) { return null; }
}
// Times of the user's SELECTED keyframes on this property (AE exposes this; PR doesn't).
function _aeSelectedTimes(prop) {
    var out = [];
    try {
        var sk = prop.selectedKeys;
        if (sk && sk.length) { for (var i = 0; i < sk.length; i++) out.push(prop.keyTime(sk[i])); out.sort(function (a, b) { return a - b; }); }
    } catch (e) {}
    return out;
}
// Capas seleccionadas que tienen al menos una propiedad con 2 o más keyframes
// seleccionados, cada una con su selección ya capturada: [{ layer, R }].
function _aeKeyedLayers(comp) {
    var out = [], sel = [];
    try { sel = comp.selectedLayers || []; } catch (e) { sel = []; }
    for (var i = 0; i < sel.length; i++) {
        var R = _aeResolveSelection(sel[i], {}, false);
        if (R && R.targets && R.targets.length) out.push({ layer: sel[i], R: R });
    }
    return out;
}
// Grupos de deshacer que se pueden anidar: aplicar en varias capas llama a las
// funciones de una capa, y todo tiene que quedar en UN solo Ctrl+Z.
var _AE_UNDO_DEPTH = 0;
function _aeUndoBegin(name) { if (_AE_UNDO_DEPTH++ === 0) app.beginUndoGroup(name); }
function _aeUndoEnd() { if (_AE_UNDO_DEPTH > 0 && --_AE_UNDO_DEPTH === 0) app.endUndoGroup(); }
function _aeSelCount(prop) { try { var sk = prop.selectedKeys; return (sk && sk.length) ? sk.length : 0; } catch (e) { return 0; } }
// Rich error text: name + message + the line number AE reports (and file when present).
function _aeErr(e) {
    var s;
    try { s = (e && e.name) ? (e.name + ": " + e.message) : ("" + e); } catch (x) { s = "" + e; }
    try { if (e && (e.line || e.line === 0)) s += " [line " + e.line + "]"; } catch (x2) {}
    try { if (e && e.fileName) { var f = String(e.fileName); var sl = Math.max(f.lastIndexOf("/"), f.lastIndexOf("\\")); if (sl >= 0) f = f.substr(sl + 1); s += " (" + f + ")"; } } catch (x3) {}
    return s;
}

// ---------- backdrop image picker ----------
// The panel's own <input type="file"> is unreliable across CEP versions (some
// builds never open the dialog at all), and it would hand back a multi-megabyte
// data URL for a GIF. File.openDialog is always there when we're really inside
// AE/Premiere, and returns a path the panel can point CSS straight at. The
// panel falls back to the HTML input if this isn't reachable.
function editkit_pickBackdropImage() {
    try {
        var isWin = false;
        try { isWin = String($.os).toLowerCase().indexOf("win") !== -1; } catch (eOS) {}
        // The filter argument is a Windows-style mask string on Windows and a
        // different beast on macOS, so only pass it where it's understood.
        var f = isWin
            ? File.openDialog("Elegir imagen de fondo", "Imágenes:*.png;*.jpg;*.jpeg;*.gif;*.webp;*.bmp")
            : File.openDialog("Elegir imagen de fondo");
        if (!f) return JSON.stringify({ success: false, canceled: true });
        return JSON.stringify({ success: true, path: f.fsName });
    } catch (e) {
        return JSON.stringify({ success: false, error: _aeErr(e) });
    }
}

// The same reliable host picker for the independent EaseIt / AlignIt work
// areas. Video is deliberately opt-in in the panel UI, but once enabled it
// uses a narrow format filter here rather than accepting arbitrary files.
function editkit_pickWorkMedia(kind) {
    try {
        kind = String(kind || "image").toLowerCase();
        var video = kind === "video";
        var isWin = false;
        try { isWin = String($.os).toLowerCase().indexOf("win") !== -1; } catch (eOS) {}
        var title = video ? "Elegir video para el recuadro" : "Elegir imagen para el recuadro";
        var filter = video
            ? "Videos:*.mp4;*.m4v;*.webm;*.ogv;*.ogg"
            : "Imágenes:*.png;*.jpg;*.jpeg;*.gif;*.webp;*.bmp";
        var f = isWin ? File.openDialog(title, filter) : File.openDialog(title);
        if (!f) return JSON.stringify({ success: false, canceled: true });
        return JSON.stringify({ success: true, path: f.fsName });
    } catch (e) {
        return JSON.stringify({ success: false, error: _aeErr(e) });
    }
}

// ---------- preset import / export (File dialogs; AE & PR both have the File API) ----------
/* File.saveDialog does not receive a suggested file name. On Windows that can
   leave the name field empty after the user chooses the destination folder;
   some host versions then return the folder itself as if it were a File and
   nothing is written. Starting from a File gives the native dialog a real name
   and directory, while the checks below make sure success is never reported
   until the file was actually created. */
function _easeitSaveText(jsonStr, ext, title, baseName) {
    ext = String(ext || "json").replace(/^\.+/, "").toLowerCase();
    baseName = String(baseName || "EaseIt Presets");

    var start = null, f = null;
    try { start = new File(Folder.myDocuments.fsName + "/" + baseName + "." + ext); } catch (eStart) {}
    try {
        f = start && start.saveDlg ? start.saveDlg(title) : File.saveDialog(title);
    } catch (eDialog) {
        f = File.saveDialog(title);
    }
    if (!f) return JSON.stringify({ success: false, canceled: true });

    var suffix = "." + ext;
    var name = String(f.name || "").toLowerCase();
    if (name.slice(name.length - suffix.length) !== suffix) f = new File(f.fsName + suffix);

    f.encoding = "UTF-8";
    if (!f.open("w")) return JSON.stringify({ success: false, error: "Could not open file for writing" });

    var wrote = false, closed = false;
    try { wrote = f.write(String(jsonStr)); } catch (eWrite) {
        try { f.close(); } catch (eCloseAfterWrite) {}
        return JSON.stringify({ success: false, error: _aeErr(eWrite) });
    }
    try { closed = f.close(); } catch (eClose) {
        return JSON.stringify({ success: false, error: _aeErr(eClose) });
    }
    if (wrote === false || closed === false || !f.exists) {
        return JSON.stringify({ success: false, error: "Could not write the exported file" });
    }
    return JSON.stringify({ success: true, path: f.fsName });
}

function easeit_exportPresets(jsonStr) {
    try {
        return _easeitSaveText(jsonStr, "json", "Export EaseIt presets", "EaseIt Presets");
    } catch (e) { return JSON.stringify({ success: false, error: _aeErr(e) }); }
}
// Export a preset library under a chosen extension. easeit_exportPresets forces
// .json; the library format is meant to be handed to other ease plugins, so it
// needs to keep whatever extension the panel asks for (.easeit today).
function easeit_exportLibrary(jsonStr, ext) {
    try {
        ext = String(ext || "easeit").replace(/^\.+/, "");
        return _easeitSaveText(jsonStr, ext, "Export EaseIt library", "EaseIt Library");
    } catch (e) { return JSON.stringify({ success: false, error: _aeErr(e) }); }
}
function easeit_importPresets() {
    try {
        var f = File.openDialog("Import EaseIt presets");
        if (!f) return JSON.stringify({ success: false, canceled: true });
        f.encoding = "UTF-8";
        if (!f.open("r")) return JSON.stringify({ success: false, error: "Could not open file for reading" });
        var s = f.read(); f.close();
        // the name travels too: importing into a NEW library names it after the file
        var fname = "";
        try { fname = String(f.displayName || f.name || ""); } catch (eN) {}
        return JSON.stringify({ success: true, data: s, file: fname });
    } catch (e) { return JSON.stringify({ success: false, error: _aeErr(e) }); }
}
// Walk the WHOLE layer property tree and return every leaf property with >=2 selected
// keyframes — so EaseIt works on Trim Paths, effects, masks, text animators, etc., not just
// Transform. (Separated Position X/Y are leaves and get picked up here too.)
function _aeSelectedProps(layer) {
    var out = [];
    function walk(g) {
        var n = 0; try { n = g.numProperties; } catch (e) { n = 0; }
        for (var i = 1; i <= n; i++) {
            var p = null; try { p = g.property(i); } catch (e) { p = null; }
            if (!p) continue;
            var isGroup = false;
            try { isGroup = (p.propertyType !== PropertyType.PROPERTY); } catch (e) { isGroup = false; }
            if (isGroup) { walk(p); }
            else {
                try {
                    var cv = false; try { cv = !!p.canVaryOverTime; } catch (e2) {}
                    if (cv && p.selectedKeys && p.selectedKeys.length >= 2) out.push(p);
                } catch (e3) {}
            }
        }
    }
    try { walk(layer); } catch (e) {}
    return out;
}
// Resolve what to ease: honor the Position-overshoot "separate dimensions" special case,
// else ease every leaf property the user selected keyframes on.
// Returns {targets, perTimes, separated} | {needSeparate:true} | {error}.
function _aeResolveSelection(layer, opts, overshoot) {
    var posP = _aeResolve(layer, "Position");
    var posSep = false; try { posSep = posP && (posP.dimensionsSeparated === true); } catch (e) {}
    var posSel = posP ? (_aeSelCount(posP) >= 2) : false;
    var posSpatial = false; try { posSpatial = posP && !!posP.isSpatial; } catch (e) {}
    if (overshoot && posP && posSel && posSpatial && !posSep) {
        if (!opts.confirmSeparate) return { needSeparate: true };
        var captured = _aeSelectedTimes(posP);          // capture BEFORE separating (selection drops)
        try { posP.dimensionsSeparated = true; } catch (e) {}
        var subs = _aeTargets(layer, "Position");
        var pt = []; for (var i = 0; i < subs.length; i++) pt.push(captured.slice());
        return { targets: subs, perTimes: pt, separated: true };
    }
    var sel = _aeSelectedProps(layer);
    if (!sel.length) return { error: "Select 2 or more keyframes in the timeline first." };
    var perTimes = [];
    for (var j = 0; j < sel.length; j++) perTimes.push(_aeSelectedTimes(sel[j]));
    return { targets: sel, perTimes: perTimes, separated: !!posSep };
}
// Keep the user's selection on `times` after an apply. Live auto-apply mutates keyframes
// (insert/remove), which otherwise drifts the selection to a subset and narrows the span.
function _aeReselect(prop, times, eps) {
    var nk = 0; try { nk = prop.numKeys; } catch (e) { return; }
    for (var ki = 1; ki <= nk; ki++) {
        var kt; try { kt = prop.keyTime(ki); } catch (e) { continue; }
        try { prop.setSelectedAtKey(ki, _nearAnySec(kt, times, eps)); } catch (e2) {}
    }
}

// Properties to actually operate on for a UI name. Position may be split into
// X/Y(/Z) ("Separate Dimensions") — then we return those instead of the combined.
function _aeTargets(layer, uiName) {
    var p = _aeResolve(layer, uiName);
    if (!p) return [];
    if (uiName === "Position") {
        var sep = false; try { sep = (p.dimensionsSeparated === true); } catch (e) {}
        if (sep) {
            var out = [];
            try {
                var tg = layer.property("ADBE Transform Group");
                var names = ["ADBE Position_0", "ADBE Position_1", "ADBE Position_2"];
                for (var i = 0; i < names.length; i++) {
                    try { var dp = tg.property(names[i]); if (dp && dp.canVaryOverTime) out.push(dp); } catch (e2) {}
                }
            } catch (e3) {}
            if (out.length) return out;
        }
    }
    return [p];
}

function _ae_getClipInfo() {
    try {
        var comp = _aeComp();
        if (!comp) return JSON.stringify({ success: false, error: "No active composition" });
        var layer = _aeLayer(comp);
        if (!layer) return JSON.stringify({ success: false, error: "No layer selected in the comp" });
        var props = {};
        for (var key in AE_PROP) {
            if (!AE_PROP.hasOwnProperty(key)) continue;
            var info = { supported: false, keyCount: 0 };
            var tg = _aeTargets(layer, key);
            if (tg.length) {
                try { info.supported = !!tg[0].canVaryOverTime; } catch (e) { info.supported = true; }
                try { info.keyCount = tg[0].numKeys; } catch (e2) {}
            }
            props[key] = info;
        }
        // report the selection across ANY property (Trim Paths, effects, transform, …)
        var selProps = [], keyed = _aeKeyedLayers(comp), selCount = 0, selName = null;
        for (var kl = 0; kl < keyed.length; kl++) selProps = selProps.concat(keyed[kl].R.targets);
        if (!selProps.length) selProps = _aeSelectedProps(layer);
        if (selProps.length) { selName = ""; try { selName = selProps[0].name; } catch (e3) {} if (selProps.length > 1) selName = selProps.length + " properties"; for (var si = 0; si < selProps.length; si++) { var n = _aeSelCount(selProps[si]); if (n > selCount) selCount = n; } }
        var posSep = false; try { var pp = _aeResolve(layer, "Position"); if (pp) posSep = (pp.dimensionsSeparated === true); } catch (ePS) {}
        return JSON.stringify({ success: true, clip: layer.name, fps: comp.frameRate, props: props, selProp: selName, selCount: selCount, posSeparated: posSep });
    } catch (e) {
        return JSON.stringify({ success: false, error: _aeErr(e) });
    }
}

function _aeEase(speed, influence) {
    var inf = Math.max(0.1, Math.min(100, influence));
    if (isNaN(speed) || !isFinite(speed)) speed = 0;
    return new KeyframeEase(speed, inf);
}
function _neutralEases(n) { var a = []; for (var i = 0; i < n; i++) a.push(new KeyframeEase(0, 0.1)); return a; }
function _vecDist(a, b) {
    if (!_isArr(a)) return Math.abs(Number(b) - Number(a));
    var s = 0, n = Math.min(a.length, b.length);
    for (var i = 0; i < n; i++) { var d = Number(b[i]) - Number(a[i]); s += d * d; }
    return Math.sqrt(s);
}
function _aeKeyIndexNear(prop, t) {
    var best = 0, bd = 1e12;
    for (var i = 1; i <= prop.numKeys; i++) { var d = Math.abs(prop.keyTime(i) - t); if (d < bd) { bd = d; best = i; } }
    return best;
}
function _aeKeyIn(prop, i, n) { try { var e = prop.keyInTemporalEase(i); if (e && e.length) return e; } catch (er) {} return _neutralEases(n); }
function _aeKeyOut(prop, i, n) { try { var e = prop.keyOutTemporalEase(i); if (e && e.length) return e; } catch (er) {} return _neutralEases(n); }

// Apply temporal ease from a single cubic-bezier to ONE property's keyframes.
// If `pair` ([tA,tB]) is given, only the segment bracketing it is eased (and the
// neighboring keys' other-side ease is preserved); otherwise every segment is eased.
function _ae_easeProp(prop, x1, y1, x2, y2, pair) {
    var nk = prop.numKeys;
    if (nk < 2) return;
    var isSpatial = false; try { isSpatial = !!prop.isSpatial; } catch (e) {}
    var n; if (isSpatial) { n = 1; } else { var pv = prop.value; n = _isArr(pv) ? pv.length : 1; }
    // speed must use the SAME clamped influence so the ease handle lands exactly on the
    // bezier handle (otherwise a near-vertical handle, x1~0, overshoots hugely in AE).
    var infOut = Math.max(0.1, Math.min(100, x1 * 100));
    var infIn = Math.max(0.1, Math.min(100, (1 - x2) * 100));
    var sOut = y1 / (infOut / 100);
    var sIn = (1 - y2) / (infIn / 100);

    function segEases(s) {
        var tA = prop.keyTime(s), tB = prop.keyTime(s + 1), dt = tB - tA; if (dt <= 0) dt = 1e-6;
        var vA = prop.keyValue(s), vB = prop.keyValue(s + 1), outArr = [], inArr = [];
        if (isSpatial) {
            var base = _vecDist(vA, vB) / dt;
            outArr.push(_aeEase(base * sOut, infOut)); inArr.push(_aeEase(base * sIn, infIn));
        } else {
            for (var d = 0; d < n; d++) {
                var dv = (_isArr(vB) ? Number(vB[d]) : Number(vB)) - (_isArr(vA) ? Number(vA[d]) : Number(vA));
                var b = dv / dt;
                outArr.push(_aeEase(b * sOut, infOut)); inArr.push(_aeEase(b * sIn, infIn));
            }
        }
        return { out: outArr, ind: inArr };
    }

    if (pair) {
        var iA = _aeKeyIndexNear(prop, pair[0]);
        if (iA < 1 || iA >= nk) return;
        var e = segEases(iA);
        try { prop.setInterpolationTypeAtKey(iA, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER); } catch (e1) {}
        try { prop.setTemporalEaseAtKey(iA, _aeKeyIn(prop, iA, n), e.out); } catch (e2) {}
        try { prop.setInterpolationTypeAtKey(iA + 1, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER); } catch (e3) {}
        try { prop.setTemporalEaseAtKey(iA + 1, e.ind, _aeKeyOut(prop, iA + 1, n)); } catch (e4) {}
        return;
    }

    var inE = {}, outE = {};
    for (var s = 1; s < nk; s++) { var ee = segEases(s); outE[s] = ee.out; inE[s + 1] = ee.ind; }
    for (var k = 1; k <= nk; k++) {
        try { prop.setInterpolationTypeAtKey(k, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER); } catch (e5) {}
        try { prop.setTemporalEaseAtKey(k, inE[k] || _neutralEases(n), outE[k] || _neutralEases(n)); } catch (e6) {}
    }
}

// AE-native easing for a single cubic-bezier (no baking). For an overshooting
// curve on spatial Position, auto-separate XY so each axis can overshoot natively.
function _ae_nativeEase(comp, layer, opts, seg, pre) {
    var fps = comp.frameRate, eps = 0.5 / fps;
    var x1 = seg[2], y1 = seg[3], x2 = seg[4], y2 = seg[5];
    if (opts.reverse) { var rx1 = 1 - x2, ry1 = 1 - y2, rx2 = 1 - x1, ry2 = 1 - y1; x1 = rx1; y1 = ry1; x2 = rx2; y2 = ry2; }
    var overshoot = (y1 < -0.0001 || y1 > 1.0001 || y2 < -0.0001 || y2 > 1.0001);

    _aeUndoBegin("EaseIt: ease");
    try {
        // Ease EVERY property the user selected keyframes on (Trim Paths, effects, transform…),
        // each over its own selected span. Position overshoot triggers dimension-separation.
        var R = pre || _aeResolveSelection(layer, opts, overshoot);
        if (R.needSeparate) { _aeUndoEnd(); return JSON.stringify({ success: false, needSeparate: true }); }
        if (R.error) { _aeUndoEnd(); return JSON.stringify({ success: false, error: R.error }); }
        var targets = R.targets, perTimes = R.perTimes, eachPair = !!opts.eachPair;
        var nKeys = 0, propName = "", anchors = [];
        for (var ti = 0; ti < targets.length; ti++) {
            var prop = targets[ti], times = perTimes[ti];
            if (!times || times.length < 2) continue;
            var t0 = times[0], t1 = times[times.length - 1]; if (t1 - t0 <= 0) continue;
            if (!anchors.length) anchors = [t0, t1];
            if (eachPair && times.length > 2) {
                // keep all selected keys, strip only UNSELECTED interior, ease each adjacent pair
                for (var rk = prop.numKeys; rk >= 1; rk--) { var rkt = prop.keyTime(rk); if (rkt > t0 + eps && rkt < t1 - eps && !_nearAnySec(rkt, times, eps)) { try { prop.removeKey(rk); } catch (eR) {} } }
                for (var s = 0; s < times.length - 1; s++) { _ae_easeProp(prop, x1, y1, x2, y2, [times[s], times[s + 1]]); }
                _aeReselect(prop, times, eps);
                nKeys = times.length;
            } else {
                // collapse: strip EVERY interior key, ease between the two endpoints
                for (var rk2 = prop.numKeys; rk2 >= 1; rk2--) { var rkt2 = prop.keyTime(rk2); if (rkt2 > t0 + eps && rkt2 < t1 - eps) { try { prop.removeKey(rk2); } catch (eR2) {} } }
                _ae_easeProp(prop, x1, y1, x2, y2, [t0, t1]);
                _aeReselect(prop, [t0, t1], eps);
                nKeys = 2;
            }
            try { propName = prop.name; } catch (ePN) {}
        }
        _aeUndoEnd();
        var label = targets.length > 1 ? (targets.length + " properties") : propName;
        return JSON.stringify({ success: true, prop: label, mode: "native", separated: R.separated, keyframes: nKeys, keysAdded: 0, segments: 1, reBake: false, anchorsUsed: anchors, fps: fps });
    } catch (eMain) {
        _aeUndoEnd();
        return JSON.stringify({ success: false, error: _aeErr(eMain) });
    }
}

// Multi-point graph in AE: each interior node becomes a real keyframe inside the
// original t0..t1 span, and each segment gets native temporal ease. It stays ONE
// animation (the original pair) — just with more detail. No dense baking.
function _ae_multiPointEase(comp, layer, opts, segs, pre) {
    var fps = comp.frameRate, eps = 0.5 / fps;
    _aeUndoBegin("EaseIt: ease");
    try {
        var R = pre || _aeResolveSelection(layer, opts, false); // multi-point never overshoot-separates
        if (R.error) { _aeUndoEnd(); return JSON.stringify({ success: false, error: R.error }); }
        var targets = R.targets, perTimes = R.perTimes;
        // node boundaries in normalized graph space: (0,0), interior..., (1,1)
        var nodes = [{ x: segs[0][0], y: segs[0][1] }];
        for (var i = 0; i < segs.length; i++) nodes.push({ x: segs[i][6], y: segs[i][7] });
        var propName = "", anchors = [];
        for (var ti = 0; ti < targets.length; ti++) {
            var prop = targets[ti], times = perTimes[ti];
            if (!times || times.length < 2) continue;
            var t0 = times[0], t1 = times[times.length - 1], span = t1 - t0; if (span <= 0) continue;
            if (!anchors.length) anchors = [t0, t1];
            var v0 = prop.valueAtTime(t0, false), v1 = prop.valueAtTime(t1, false);
            // If the node count matches the selected-keyframe count, this is a Read -> Apply
            // round-trip: each interior node corresponds to a REAL keyframe the user selected,
            // not a synthetic path point. Capture its actual value before we delete anything,
            // so re-applying restores it exactly instead of flattening it onto the straight
            // v0->v1 line (which corrupted any keyframe whose value wasn't collinear with the
            // span's endpoints — e.g. a detour/bounce — into a generic in-between value).
            var origVals = null;
            if (nodes.length === times.length) {
                origVals = [];
                for (var oi = 0; oi < times.length; oi++) origVals.push(prop.valueAtTime(times[oi], false));
            }
            for (var rk = prop.numKeys; rk >= 1; rk--) { var kt = prop.keyTime(rk); if (kt > t0 + eps && kt < t1 - eps) { try { prop.removeKey(rk); } catch (eR) {} } }
            for (var ni = 1; ni < nodes.length - 1; ni++) { var nt = t0 + nodes[ni].x * span; if (nt <= t0 + eps || nt >= t1 - eps) continue; var val = origVals ? origVals[ni] : _lerpVal(v0, v1, nodes[ni].y); try { prop.setValueAtTime(nt, val); } catch (eIns) {} }
            for (var si = 0; si < segs.length; si++) {
                var sg = segs[si], ax = sg[0], ay = sg[1], bx = sg[6], by = sg[7];
                var dxn = (bx - ax) || 1e-6, dyn = by - ay;
                var nx1 = (sg[2] - ax) / dxn, nx2 = (sg[4] - ax) / dxn;
                var ny1 = dyn !== 0 ? (sg[3] - ay) / dyn : 0;
                var ny2 = dyn !== 0 ? (sg[5] - ay) / dyn : 1;
                _ae_easeProp(prop, nx1, ny1, nx2, ny2, [t0 + ax * span, t0 + bx * span]);
            }
            _aeReselect(prop, [t0, t1], eps); // keep the original span selected (live auto-apply)
            try { propName = prop.name; } catch (ePN) {}
        }
        _aeUndoEnd();
        var label = targets.length > 1 ? (targets.length + " properties") : propName;
        return JSON.stringify({ success: true, prop: label, mode: "native-multi", keyframes: nodes.length, keysAdded: nodes.length - 2, segments: 1, reBake: false, anchorsUsed: anchors, fps: fps });
    } catch (eMain) {
        _aeUndoEnd();
        return JSON.stringify({ success: false, error: _aeErr(eMain) });
    }
}

// Elastic/Bounce in AE: don't bake every frame — place a keyframe only at each curve
// extremum (the bounce/oscillation points) and smooth between. A handful of keyframes.
function _ae_formulaEase(comp, layer, opts, fn, pre) {
    var fps = comp.frameRate, eps = 0.5 / fps;
    _aeUndoBegin("EaseIt: ease");
    try {
        var R = pre || _aeResolveSelection(layer, opts, false);
        if (R.error) { _aeUndoEnd(); return JSON.stringify({ success: false, error: R.error }); }
        var targets = R.targets, perTimes = R.perTimes;
        var reverse = !!opts.reverse;
        function ev(x) { return reverse ? (1 - fn(1 - x)) : fn(x); }
        var xs = _formulaKeyXs(ev); // endpoints + extrema only
        var added = 0, propName = "", anchors = [];
        for (var ti = 0; ti < targets.length; ti++) {
            var prop = targets[ti], times = perTimes[ti];
            if (!times || times.length < 2) continue;
            var t0 = times[0], t1 = times[times.length - 1], sp = t1 - t0; if (sp <= 0) continue;
            if (!anchors.length) anchors = [t0, t1];
            var v0 = prop.valueAtTime(t0, false), v1 = prop.valueAtTime(t1, false);
            for (var rk = prop.numKeys; rk >= 1; rk--) { var ktp = prop.keyTime(rk); if (ktp > t0 + eps && ktp < t1 - eps) { try { prop.removeKey(rk); } catch (e) {} } }
            for (var i = 0; i < xs.length; i++) {
                var x = xs[i]; if (x <= 0.0001 || x >= 0.9999) continue;
                try { prop.setValueAtTime(t0 + x * sp, _lerpVal(v0, v1, ev(x))); added++; } catch (e) {}
            }
            // match each keyframe's ease to the formula velocity: sharp at bounce contacts
            // (non-zero slope both sides), smooth at apexes (slope ~0). Influence 33.33%
            // approximates the parabolic arcs.
            var isSpat = false; try { isSpat = !!prop.isSpatial; } catch (e) {}
            var nDim = isSpat ? 1 : (_isArr(prop.value) ? prop.value.length : 1);
            var dvMag = isSpat ? _vecDist(v0, v1) : 0;
            for (var li = 1; li <= prop.numKeys; li++) {
                var lt = prop.keyTime(li);
                if (lt < t0 - eps || lt > t1 + eps) continue;
                var xk = (lt - t0) / sp; if (xk < 0) xk = 0; if (xk > 1) xk = 1;
                var hh = 0.004;
                var sb = (ev(xk) - ev(Math.max(0, xk - hh))) / hh;
                var sa = (ev(Math.min(1, xk + hh)) - ev(xk)) / hh;
                if (xk <= 0.0001) sb = sa;
                if (xk >= 0.9999) sa = sb;
                var inArr = [], outArr = [];
                for (var d = 0; d < nDim; d++) {
                    var dv = isSpat ? dvMag : ((_isArr(v1) ? Number(v1[d]) : Number(v1)) - (_isArr(v0) ? Number(v0[d]) : Number(v0)));
                    var inSp = (dv / sp) * sb, outSp = (dv / sp) * sa;
                    if (isSpat) { inSp = Math.abs(inSp); outSp = Math.abs(outSp); }
                    inArr.push(new KeyframeEase(inSp, 33.33));
                    outArr.push(new KeyframeEase(outSp, 33.33));
                }
                try { prop.setInterpolationTypeAtKey(li, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER); } catch (e) {}
                try { prop.setTemporalEaseAtKey(li, inArr, outArr); } catch (e) {}
            }
            _aeReselect(prop, [t0, t1], eps); // keep the original span selected (live auto-apply)
            try { propName = prop.name; } catch (ePN) {}
        }
        _aeUndoEnd();
        var label = targets.length > 1 ? (targets.length + " properties") : propName;
        return JSON.stringify({ success: true, prop: label, mode: "formula", keysAdded: added, keyframes: xs.length, segments: 1, reBake: false, anchorsUsed: anchors, fps: fps });
    } catch (eMain) { _aeUndoEnd(); return JSON.stringify({ success: false, error: _aeErr(eMain) }); }
}

// Aplica en TODAS las capas seleccionadas que tengan keyframes seleccionados, no solo
// en la primera. Antes se usaba comp.selectedLayers[0] y el resto se ignoraba.
//
// El orden importa: en After Effects, escribir un keyframe suelta la selección de
// toda la composición. Si se aplicara capa por capa leyendo la selección sobre la
// marcha, la segunda capa ya no tendría nada seleccionado. Por eso primero se
// captura la selección de todas, luego se escribe, y al final se vuelve a marcar.
function _ae_applyEasing(opts) {
    var comp = _aeComp();
    if (!comp) return JSON.stringify({ success: false, error: "No active composition" });
    var layer = _aeLayer(comp);
    if (!layer) return JSON.stringify({ success: false, error: "No layer selected in the comp" });

    // Eases whatever property(ies) the user selected keyframes on — resolved inside each fn.
    // Elastic/Bounce -> few keyframes at extrema. Single cubic -> native ease.
    // Multi-point graph -> interior nodes become real keyframes. (None bake every frame.)
    var _isFormula = (opts.kind === "fn" && opts.fn && HOST_FN[opts.fn]);
    var _isPath = (opts.kind === "path" && opts.segs && opts.segs.length >= 1);
    if (!_isFormula && !_isPath) return JSON.stringify({ success: false, error: "Nothing to apply — build a curve first." });

    function one(L, pre) {
        if (_isFormula) return _ae_formulaEase(comp, L, opts, HOST_FN[opts.fn], pre);
        if (opts.segs.length === 1) return _ae_nativeEase(comp, L, opts, opts.segs[0], pre);
        return _ae_multiPointEase(comp, L, opts, opts.segs, pre);
    }

    var jobs = _aeKeyedLayers(comp);
    // Una sola capa (o ninguna con keyframes): el camino de siempre, con sus mensajes.
    if (jobs.length < 2) return one(jobs.length ? jobs[0].layer : layer, null);

    // Rebase en Posición: se decide para todas antes de tocar ninguna.
    var nativeOne = _isPath && opts.segs.length === 1;
    var sg = nativeOne ? opts.segs[0] : null;
    var overshoot = nativeOne && (sg[3] < -0.0001 || sg[3] > 1.0001 || sg[5] < -0.0001 || sg[5] > 1.0001);
    var j, needSep = false;
    if (overshoot) {
        for (j = 0; j < jobs.length; j++) {
            var posP = _aeResolve(jobs[j].layer, "Position");
            if (!posP) continue;
            var sep = false; try { sep = (posP.dimensionsSeparated === true); } catch (e1) {}
            var spat = false; try { spat = !!posP.isSpatial; } catch (e2) {}
            if (spat && !sep && _aeSelCount(posP) >= 2) { jobs[j].posP = posP; jobs[j].posTimes = _aeSelectedTimes(posP); needSep = true; }
        }
        if (needSep && !opts.confirmSeparate) return JSON.stringify({ success: false, needSeparate: true });
    }

    _aeUndoBegin("EaseIt: ease");
    try {
        // Separar dimensiones con los tiempos ya capturados (separar también suelta la selección).
        for (j = 0; j < jobs.length; j++) {
            if (!jobs[j].posP) continue;
            try { jobs[j].posP.dimensionsSeparated = true; } catch (e3) {}
            var subs = _aeTargets(jobs[j].layer, "Position"), pt = [];
            for (var q = 0; q < subs.length; q++) pt.push(jobs[j].posTimes.slice());
            jobs[j].R = { targets: subs, perTimes: pt, separated: true };
        }

        var first = null, firstErr = null, nProps = 0, added = 0, sepAny = false;
        for (j = 0; j < jobs.length; j++) {
            var r = null;
            try { r = JSON.parse(one(jobs[j].layer, jobs[j].R)); } catch (e4) { r = null; }
            if (!r || !r.success) { if (!firstErr && r) firstErr = r; continue; }
            if (!first) first = r;
            nProps += jobs[j].R.targets.length;
            added += Number(r.keysAdded) || 0;
            if (r.separated) sepAny = true;
        }

        // Volver a marcar lo que el usuario tenía seleccionado en cada capa, para que
        // la aplicación en vivo siga funcionando sobre todas.
        var eps = 0.5 / comp.frameRate, keepAll = nativeOne && !!opts.eachPair;
        for (j = 0; j < jobs.length; j++) {
            var R = jobs[j].R;
            for (var t = 0; t < R.targets.length; t++) {
                var tm = R.perTimes[t];
                if (!tm || tm.length < 2) continue;
                _aeReselect(R.targets[t], (keepAll && tm.length > 2) ? tm : [tm[0], tm[tm.length - 1]], eps);
            }
        }
        _aeUndoEnd();

        if (!first) return JSON.stringify(firstErr || { success: false, error: "Select 2 or more keyframes in the timeline first." });
        first.prop = nProps > 1 ? (nProps + " properties") : first.prop;
        first.keysAdded = added;
        first.separated = sepAny;
        first.layers = jobs.length;
        return JSON.stringify(first);
    } catch (eMain) {
        _aeUndoEnd();
        return JSON.stringify({ success: false, error: _aeErr(eMain) });
    }
}

function _ae_revertEasing(opts) {
    var comp = _aeComp();
    if (!comp) return JSON.stringify({ success: false, error: "No active composition" });
    var layer = _aeLayer(comp);
    if (!layer) return JSON.stringify({ success: false, error: "No layer selected in the comp" });
    // revert whatever properties are selected, on every selected layer; the times are
    // captured for all of them before anything is removed
    var jobs = _aeKeyedLayers(comp), work = [];
    for (var jl = 0; jl < jobs.length; jl++) {
        var R = jobs[jl].R;
        for (var jt = 0; jt < R.targets.length; jt++) work.push({ prop: R.targets[jt], times: R.perTimes[jt] });
    }
    if (!work.length) return JSON.stringify({ success: false, error: "Select 2 or more keyframes to revert." });

    var fps = comp.frameRate, eps = 0.5 / fps, removed = 0, propName = "";
    _aeUndoBegin("EaseIt: revert");
    try {
        for (var ti = 0; ti < work.length; ti++) {
            var prop = work[ti].prop;
            var times = work[ti].times;
            if (!times || times.length < 2) continue;
            var rA = times[0], rB = times[times.length - 1];
            // remove baked keys strictly between the pair...
            for (var k = prop.numKeys; k >= 1; k--) {
                var kt = prop.keyTime(k);
                if (kt > rA + eps && kt < rB - eps) { try { prop.removeKey(k); removed++; } catch (e) {} }
            }
            // ...and clear native ease on the pair endpoints (set them Linear)
            var iA = _aeKeyIndexNear(prop, rA), iB = _aeKeyIndexNear(prop, rB);
            try { if (iA >= 1) prop.setInterpolationTypeAtKey(iA, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR); } catch (eLa) {}
            try { if (iB >= 1) prop.setInterpolationTypeAtKey(iB, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR); } catch (eLb) {}
            try { propName = prop.name; } catch (ePN) {}
        }
    } catch (eMain) { _aeUndoEnd(); return JSON.stringify({ success: false, error: _aeErr(eMain) }); }
    _aeUndoEnd();
    return JSON.stringify({ success: true, prop: (work.length > 1 ? (work.length + " properties") : propName), removed: removed });
}

// Read the selected keyframes' existing temporal ease back into a cubic-bezier
// (inverse of the apply mapping). AE only — Premiere exposes no ease to read.
// Read 3+ selected keyframes as ONE multi-point graph: each selected key becomes a node
// at its normalized time/value, and each segment's temporal ease becomes the node handles.
// Exact inverse of _ae_easeProp: influence -> handle x, speed*x*dt/dv -> handle y (per
// segment, in segment-local space, then mapped into the global 0..1 graph).
function _ae_readPath(prop, selT) {
    var idx = [], last = -1, i;
    for (i = 0; i < selT.length; i++) {
        var k = _aeKeyIndexNear(prop, selT[i]);
        if (k > last) { idx.push(k); last = k; }
    }
    if (idx.length < 3) return null; // duplicates collapsed it — let the pair read handle it
    var isSpatial = false; try { isSpatial = !!prop.isSpatial; } catch (e) {}
    var t0 = prop.keyTime(idx[0]), tN = prop.keyTime(idx[idx.length - 1]), span = tN - t0;
    if (span <= 0) return JSON.stringify({ success: false, error: "Zero-length selection." });
    var v0 = prop.keyValue(idx[0]), vN = prop.keyValue(idx[idx.length - 1]);

    function sc(v) { return _isArr(v) ? Number(v[0]) : Number(v); }
    // graph y of a key value: scalar fraction of the overall change; for spatial values
    // the projection onto the start->end line (the inverse of apply's _lerpVal placement)
    function yOf(v) {
        if (isSpatial && _isArr(v) && _isArr(v0) && _isArr(vN)) {
            var num = 0, den = 0, n = Math.min(v.length, v0.length, vN.length);
            for (var d = 0; d < n; d++) { var e2 = Number(vN[d]) - Number(v0[d]); num += (Number(v[d]) - Number(v0[d])) * e2; den += e2 * e2; }
            return den < 1e-12 ? 0 : num / den;
        }
        var DV = sc(vN) - sc(v0);
        return Math.abs(DV) < 1e-12 ? 0 : (sc(v) - sc(v0)) / DV;
    }

    var nodes = [], j;
    for (j = 0; j < idx.length; j++) {
        var y = (j === 0) ? 0 : (j === idx.length - 1 ? 1 : yOf(prop.keyValue(idx[j])));
        nodes.push({ x: (prop.keyTime(idx[j]) - t0) / span, y: y, hl: null, hr: null });
    }
    for (j = 0; j < idx.length - 1; j++) {
        var a = nodes[j], b = nodes[j + 1], iA = idx[j], iB = idx[j + 1];
        var dt = prop.keyTime(iB) - prop.keyTime(iA); if (dt <= 0) dt = 1e-6;
        var dv = isSpatial ? _vecDist(prop.keyValue(iA), prop.keyValue(iB)) : (sc(prop.keyValue(iB)) - sc(prop.keyValue(iA)));
        if (Math.abs(dv) < 1e-9) dv = (dv < 0 ? -1e-9 : 1e-9);
        var outE = null, inE = null;
        try { outE = prop.keyOutTemporalEase(iA)[0]; } catch (e3) {}
        try { inE = prop.keyInTemporalEase(iB)[0]; } catch (e4) {}
        var lx1 = 1 / 3, ly1 = 1 / 3, lx2 = 2 / 3, ly2 = 2 / 3; // linear fallback per segment
        if (outE) { lx1 = Math.max(0, Math.min(1, outE.influence / 100)); ly1 = outE.speed * lx1 * dt / dv; }
        if (inE) { lx2 = Math.max(0, Math.min(1, 1 - inE.influence / 100)); ly2 = 1 - (inE.speed * (1 - lx2) * dt / dv); }
        var dx = b.x - a.x, dy = b.y - a.y;
        a.hr = [a.x + lx1 * dx, a.y + ly1 * dy];
        b.hl = [a.x + lx2 * dx, a.y + ly2 * dy];
    }
    var rpn = ""; try { rpn = prop.name; } catch (e5) {}
    return JSON.stringify({ success: true, prop: rpn, nodes: nodes, points: nodes.length });
}

function _ae_readEasing(opts) {
    var comp = _aeComp();
    if (!comp) return JSON.stringify({ success: false, error: "No active composition" });
    var layer = _aeLayer(comp);
    if (!layer) return JSON.stringify({ success: false, error: "No layer selected in the comp" });
    var targets = _aeSelectedProps(layer); // read whatever property is selected
    if (!targets.length) return JSON.stringify({ success: false, error: "Select 2 or more keyframes to read." });
    var prop = targets[0];

    var fps = comp.frameRate, eps = 0.5 / fps;
    var selT = _aeSelectedTimes(prop);
    if (selT.length < 2) return JSON.stringify({ success: false, error: "Select 2 or more keyframes to read." });
    // 3+ selected keys -> read the whole selection as one multi-point graph
    if (selT.length > 2) { var multi = _ae_readPath(prop, selT); if (multi) return multi; }
    var pair = [selT[0], selT[1]];
    var iA = _aeKeyIndexNear(prop, pair[0]), iB = _aeKeyIndexNear(prop, pair[1]);
    if (iB <= iA) return JSON.stringify({ success: false, error: "Select a keyframe pair at different times." });
    var dt = prop.keyTime(iB) - prop.keyTime(iA);
    if (dt <= 0) return JSON.stringify({ success: false, error: "Zero-length segment." });

    var isSpatial = false; try { isSpatial = !!prop.isSpatial; } catch (e) {}
    var vA = prop.keyValue(iA), vB = prop.keyValue(iB);
    var dv = isSpatial ? _vecDist(vA, vB) : ((_isArr(vB) ? Number(vB[0]) : Number(vB)) - (_isArr(vA) ? Number(vA[0]) : Number(vA)));
    if (Math.abs(dv) < 1e-9) dv = (dv < 0 ? -1e-9 : 1e-9);

    var outE, inE;
    try { outE = prop.keyOutTemporalEase(iA)[0]; } catch (e1) {}
    try { inE = prop.keyInTemporalEase(iB)[0]; } catch (e2) {}
    if (!outE || !inE) return JSON.stringify({ success: false, error: "These keyframes have no readable ease." });

    var x1 = Math.max(0, Math.min(1, outE.influence / 100));
    var y1 = outE.speed * x1 * dt / dv;
    var x2 = Math.max(0, Math.min(1, 1 - inE.influence / 100));
    var y2 = 1 - (inE.speed * (1 - x2) * dt / dv);
    var rpn = ""; try { rpn = prop.name; } catch (e) {}
    return JSON.stringify({ success: true, prop: rpn, curve: [x1, y1, x2, y2] });
}

// =============================================================
// PUBLIC API
// =============================================================

// Lightweight context for the panel: selected clip + per-property keyframe counts
function easeit_getClipInfo() {
    if (IS_AE) return _ae_getClipInfo();
    try {
        var seq = _getSeq();
        if (!seq) return JSON.stringify({ success: false, error: "No active sequence" });
        var clip = _getSelectedClip(seq);
        if (!clip) return JSON.stringify({ success: false, error: "No clip selected in the timeline" });

        var name = "";
        try { name = clip.name; } catch (e) {}

        var props = {};
        for (var key in PROP_MAP) {
            if (!PROP_MAP.hasOwnProperty(key)) continue;
            var info = { supported: false, keyCount: 0 };
            var p = _resolveParam(clip, key);
            if (p) {
                try { info.supported = !!p.areKeyframesSupported(); } catch (e2) { info.supported = true; }
                info.keyCount = _getKeyTimes(p).length;
            }
            props[key] = info;
        }

        // keyframed effect params beyond the standard 5 (panel adds them to "Apply to")
        var custom = [];
        try { custom = _customParamList(clip); } catch (eCP) {}

        return JSON.stringify({
            success: true,
            clip: name,
            fps: _fpsOf(seq),
            props: props,
            custom: custom
        });
    } catch (e) {
        return JSON.stringify({ success: false, error: _aeErr(e) });
    }
}

// Premiere: the 2 keyframes bracketing the playhead. Keyframe times are CLIP-relative but
// getPlayerPosition() is SEQUENCE-relative, so map the playhead into clip time first.
function _prPairAroundPlayhead(seq, clip, keyObjs) {
    if (keyObjs.length < 2) return keyObjs.slice();
    var ph = null;
    try { ph = _secOf(seq.getPlayerPosition()) - _secOf(clip.start) + _secOf(clip.inPoint); } catch (e) {}
    if (ph === null) return [keyObjs[0], keyObjs[1]];
    for (var i = 0; i < keyObjs.length - 1; i++) {
        var a = _secOf(keyObjs[i]), b = _secOf(keyObjs[i + 1]);
        if (ph >= a - 1e-6 && ph <= b + 1e-6) return [keyObjs[i], keyObjs[i + 1]];
    }
    if (ph < _secOf(keyObjs[0])) return [keyObjs[0], keyObjs[1]];
    return [keyObjs[keyObjs.length - 2], keyObjs[keyObjs.length - 1]];
}

// Bake an easing curve onto the keyframe pair around the playhead.
// opts = { prop, x1, y1, x2, y2, density (frame step >=1), reverse }
function easeit_applyEasing(jsonStr) {
    if (IS_AE) { try { return _ae_applyEasing(JSON.parse(jsonStr)); } catch (e) { return JSON.stringify({ success: false, error: _aeErr(e) }); } }
    try {
        var opts = JSON.parse(jsonStr);
        var seq = _getSeq();
        if (!seq) return JSON.stringify({ success: false, error: "No active sequence" });
        var clip = _getSelectedClip(seq);
        if (!clip) return JSON.stringify({ success: false, error: "No clip selected in the timeline" });

        var param = _resolveParam(clip, opts.prop, opts.propRef);
        if (!param) return JSON.stringify({ success: false, error: "Could not find '" + opts.prop + "' on this clip" });

        try { if (!param.areKeyframesSupported()) return JSON.stringify({ success: false, error: "'" + opts.prop + "' does not support keyframes" }); } catch (eK) {}

        var fps = _fpsOf(seq);
        var frameDur = 1 / fps;

        var keyObjs = _keyObjs(param); // Time objects
        if (keyObjs.length < 2) return JSON.stringify({ success: false, error: "Need at least 2 keyframes on '" + opts.prop + "'. Found " + keyObjs.length + "." + _keyedParamHint(clip) });

        try { if (!param.isTimeVarying()) param.setTimeVarying(true); } catch (eT) {}

        // Premiere = one animation (designed for 2 keyframes). Anchors are the real
        // keyframes; on a re-bake the panel sends the recorded anchor seconds, which we
        // snap back to real keys so the baked keys in between can be cleared and redone.
        // Premiere has no keyframe selection — ease the 2 keyframes AROUND THE PLAYHEAD.
        var anchorObjs = _prPairAroundPlayhead(seq, clip, keyObjs);
        var reBake = (opts.anchors && opts.anchors.length >= 2);
        if (anchorObjs.length < 2) return JSON.stringify({ success: false, error: "Need 2 keyframes around the playhead on '" + opts.prop + "'." });

        // ---- SAFETY GATE ----
        // Read + validate each anchor value (passing the real Time OBJECT) BEFORE
        // mutating anything, so a bad read can never overwrite keyframes with junk.
        // Custom effect params have no PROP_MAP entry — their dims come from the
        // first real value read (0 = not derived yet).
        var dims = PROP_MAP[opts.prop] ? PROP_MAP[opts.prop].dims : 0;
        var segData = [];
        for (var i = 0; i < anchorObjs.length - 1; i++) {
            var o0 = anchorObjs[i], o1 = anchorObjs[i + 1];
            var s0 = _secOf(o0), s1 = _secOf(o1);
            if (s1 - s0 <= 0) continue;
            var rv0 = param.getValueAtKey(o0);
            var rv1 = param.getValueAtKey(o1);
            if (!dims) dims = _dimsOfVal(rv0);
            if (!_validValue(rv0, dims) || !_validValue(rv1, dims)) {
                return JSON.stringify({
                    success: false,
                    error: "Aborted — nothing changed. Premiere returned an unreadable " + opts.prop +
                           " value, so EaseIt refused to write keyframes. Click the EASING badge and send me the dump.",
                    readType: (_isArr(rv0) ? "array[" + rv0.length + "]" : typeof rv0),
                    readSample: String(rv0).slice(0, 60),
                    expectedDims: dims
                });
            }
            segData.push({ o0: o0, o1: o1, s0: s0, s1: s1, v0: rv0, v1: rv1 });
        }
        if (segData.length === 0) return JSON.stringify({ success: false, error: "No bakeable segments (keyframes are adjacent or zero-length)." });

        var anchorSecs = [];
        for (var a = 0; a < anchorObjs.length; a++) anchorSecs.push(_secOf(anchorObjs[a]));

        // Now safe to mutate. On a re-bake, clear the old baked keys (everything that
        // isn't one of the anchors) so the new curve replaces it cleanly.
        // remove only baked keys STRICTLY between the chosen pair (keep all other keyframes)
        var eps = 0.5 / fps;
        var spanLo = anchorSecs[0], spanHi = anchorSecs[anchorSecs.length - 1];
        for (var r = 0; r < keyObjs.length; r++) {
            var ks = _secOf(keyObjs[r]);
            if (ks > spanLo + eps && ks < spanHi - eps) { try { param.removeKey(keyObjs[r]); } catch (eR) {} }
        }

        var x1 = Number(opts.x1), y1 = Number(opts.y1), x2 = Number(opts.x2), y2 = Number(opts.y2);
        var reverse = !!opts.reverse;
        var step = Math.max(1, Math.round(Number(opts.density) || 1));
        var useFn = (opts.kind === "fn" && opts.fn && HOST_FN[opts.fn]) ? HOST_FN[opts.fn] : null;
        var segs = (opts.kind === "path" && opts.segs && opts.segs.length) ? opts.segs : null;
        var added = 0, segments = 0;
        var KF_LINEAR = 0;

        for (var sg = 0; sg < segData.length; sg++) {
            var seg = segData[sg];
            var span = seg.s1 - seg.s0;
            var nFrames = Math.round(span * fps);
            if (nFrames >= 2) {
                for (var f = 1; f < nFrames; f += step) {
                    var ts = seg.s0 + f * frameDur;
                    if (ts >= seg.s1) break;
                    var xN = (ts - seg.s0) / span;
                    var prog;
                    if (useFn) prog = reverse ? (1 - useFn(1 - xN)) : useFn(xN);
                    else if (segs) prog = reverse ? (1 - _solvePath(1 - xN, segs)) : _solvePath(xN, segs);
                    else prog = reverse ? (1 - _solveBez(1 - xN, x1, y1, x2, y2)) : _solveBez(xN, x1, y1, x2, y2);
                    var val = _lerpVal(seg.v0, seg.v1, prog);
                    if (!_validValue(val, dims)) continue; // never write garbage
                    var tObj = _mkTime(ts);
                    param.addKey(tObj);
                    param.setValueAtKey(tObj, val, true);
                    try { param.setInterpolationTypeAtKey(tObj, KF_LINEAR, true); } catch (eI) {}
                    added++;
                }
            }
            // endpoints linear so the baked ramp reads cleanly
            try { param.setInterpolationTypeAtKey(seg.o0, KF_LINEAR, true); } catch (e0) {}
            try { param.setInterpolationTypeAtKey(seg.o1, KF_LINEAR, true); } catch (e1) {}
            segments++;
        }

        return JSON.stringify({
            success: true,
            prop: opts.prop,
            segments: segments,
            keysAdded: added,
            reBake: reBake,
            anchorsUsed: anchorSecs,
            fps: fps
        });
    } catch (e) {
        return JSON.stringify({ success: false, error: _aeErr(e) });
    }
}

// Reliable "undo": strip baked keys and leave only the original anchor keyframes.
// (Premiere's native Ctrl+Z doesn't integrate with CEP keyframe ops, so this is
// the deterministic way to revert.) opts = { prop, anchors? }
function easeit_revertEasing(jsonStr) {
    if (IS_AE) { try { return _ae_revertEasing(JSON.parse(jsonStr)); } catch (e) { return JSON.stringify({ success: false, error: _aeErr(e) }); } }
    try {
        var opts = JSON.parse(jsonStr);
        var seq = _getSeq();
        if (!seq) return JSON.stringify({ success: false, error: "No active sequence" });
        var clip = _getSelectedClip(seq);
        if (!clip) return JSON.stringify({ success: false, error: "No clip selected in the timeline" });
        var param = _resolveParam(clip, opts.prop, opts.propRef);
        if (!param) return JSON.stringify({ success: false, error: "Could not find '" + opts.prop + "' on this clip" });

        var fps = _fpsOf(seq);
        var keyObjs = _keyObjs(param);
        if (keyObjs.length < 2) return JSON.stringify({ success: true, prop: opts.prop, removed: 0 });

        // One animation: keep the original anchors, strip all baked keys between them.
        var anchorSecs = [];
        if (opts.anchors && opts.anchors.length >= 2) {
            var snapped = _snapAnchorObjs(keyObjs, opts.anchors, fps);
            for (var a = 0; a < snapped.length; a++) anchorSecs.push(_secOf(snapped[a]));
        }
        if (anchorSecs.length < 2) anchorSecs = [_secOf(keyObjs[0]), _secOf(keyObjs[keyObjs.length - 1])];
        var eps = 0.5 / fps, removed = 0;
        for (var r = 0; r < keyObjs.length; r++) {
            if (!_nearAnySec(_secOf(keyObjs[r]), anchorSecs, eps)) {
                try { param.removeKey(keyObjs[r]); removed++; } catch (eR) {}
            }
        }
        return JSON.stringify({ success: true, prop: opts.prop, removed: removed });
    } catch (e) {
        return JSON.stringify({ success: false, error: _aeErr(e) });
    }
}

function easeit_readEasing(jsonStr) {
    if (IS_AE) { try { return _ae_readEasing(JSON.parse(jsonStr)); } catch (e) { return JSON.stringify({ success: false, error: _aeErr(e) }); } }
    return JSON.stringify({ success: false, error: "Reading easing back isn't available in Premiere (no ease API)." });
}

// =============================================================
// TRUE HANDLES (Premiere only) — real bezier-handle easing with
// NO baking, via project-file surgery. The scripting API cannot
// set handle velocity/influence, but the .prproj XML stores them
// per keyframe (decoded 2026-07-03, research/handle-easing/):
//   ticks,value,mode,?,inVel,inInfl,outVel,outInfl  (mode 5 = bezier)
// Host side only PREPARES: it tags the target pair with a unique
// marker keyframe, saves, and hands exact ticks to the panel. The
// panel Node.js side does the gunzip -> rewrite -> gzip while the
// project is closed, then the host reopens it.
// =============================================================

function _ticksOf(t) {
    // exact tick string when available; else derive from seconds
    try { if (t && t.ticks !== undefined && t.ticks !== null) return String(t.ticks); } catch (e) {}
    var s = _secOf(t);
    if (s === null) return null;
    return String(Math.round(s * TICKS_PER_SECOND));
}

function _projPath() {
    var p = "";
    try { p = String(app.project.path || ""); } catch (e) {}
    return p;
}

// Capability probe so the panel can grey the toggle out with a reason.
function easeit_th_support() {
    if (IS_AE) return JSON.stringify({ success: false, error: "True Handles is Premiere-only (AE has a native ease API)." });
    var rep = { success: true };
    rep.path = _projPath();
    rep.isPrproj = /\.prproj$/i.test(rep.path);
    rep.canSave = false; rep.canClose = false; rep.canOpen = false;
    try { rep.canSave = (typeof app.project.save === 'function'); } catch (e1) {}
    try { rep.canClose = (typeof app.project.closeDocument === 'function'); } catch (e2) {}
    try { rep.canOpen = (typeof app.openDocument === 'function'); } catch (e3) {}
    rep.supported = !!(rep.path && rep.isPrproj && rep.canSave && rep.canClose && rep.canOpen);
    if (!rep.supported) {
        if (!rep.path) rep.error = "Save your project first — True Handles edits the .prproj file.";
        else if (!rep.isPrproj) rep.error = "True Handles needs a plain .prproj project (Productions/team projects not supported yet).";
        else rep.error = "This Premiere version is missing save/close/open scripting support.";
    }
    return JSON.stringify(rep);
}

// Prepare the surgery: locate the playhead pair on the chosen param, validate its
// values, insert a MARKER keyframe between them (unique tick -> uniquely identifies
// this param XML block even if another clip has an identical animation), save.
// opts = { prop }
function easeit_th_prep(jsonStr) {
    if (IS_AE) return JSON.stringify({ success: false, error: "True Handles is Premiere-only." });
    try {
        var opts = JSON.parse(jsonStr);
        var path = _projPath();
        if (!path) return JSON.stringify({ success: false, error: "Save your project first — True Handles edits the .prproj file." });
        if (!/\.prproj$/i.test(path)) return JSON.stringify({ success: false, error: "True Handles needs a plain .prproj project." });

        var seq = _getSeq();
        if (!seq) return JSON.stringify({ success: false, error: "No active sequence" });
        var clip = _getSelectedClip(seq);
        if (!clip) return JSON.stringify({ success: false, error: "No clip selected in the timeline" });
        var param = _resolveParam(clip, opts.prop, opts.propRef);
        if (!param) return JSON.stringify({ success: false, error: "Could not find '" + opts.prop + "' on this clip" });

        var keyObjs = _keyObjs(param);
        if (keyObjs.length < 2) return JSON.stringify({ success: false, error: "Need at least 2 keyframes on '" + opts.prop + "'. Found " + keyObjs.length + "." + _keyedParamHint(clip) });

        var pair = _prPairAroundPlayhead(seq, clip, keyObjs);
        if (pair.length < 2) return JSON.stringify({ success: false, error: "Need 2 keyframes around the playhead on '" + opts.prop + "'." });
        var oA = pair[0], oB = pair[1];
        var sA = _secOf(oA), sB = _secOf(oB);
        if (sB - sA <= 0) return JSON.stringify({ success: false, error: "Zero-length keyframe pair." });

        // ---- SAFETY GATE: read + validate BEFORE touching anything ----
        var vA = param.getValueAtKey(oA), vB = param.getValueAtKey(oB);
        var dims = PROP_MAP[opts.prop] ? PROP_MAP[opts.prop].dims : _dimsOfVal(vA);
        if (!_validValue(vA, dims) || !_validValue(vB, dims)) {
            return JSON.stringify({ success: false, error: "Aborted — unreadable " + opts.prop + " value; nothing was changed." });
        }
        // The surgery rewrites the scalar and x:y point record shapes it has decoded;
        // higher-dim params bake instead (the panel pre-gates this — backstop only).
        if (!PROP_MAP[opts.prop] && dims > 2) {
            return JSON.stringify({ success: false, error: "True Handles supports 1D and 2D parameters — '" + opts.prop + "' has " + dims + ". Turn True Handles off to bake this one." });
        }

        // ---- MARKER keyframe: off-frame-grid tick between the pair. Frame-aligned
        // keys sit on multiples of the timebase (~8.5e9 ticks), so a mid-span time
        // nudged by a 0.137-frame offset cannot collide with a real keyframe. ----
        var markerSec = sA + (sB - sA) * 0.5 + (1 / _fpsOf(seq)) * 0.137;
        if (markerSec >= sB) markerSec = (sA + sB) / 2;
        var mObj = _mkTime(markerSec);
        var frac = (markerSec - sA) / (sB - sA);
        param.addKey(mObj);
        param.setValueAtKey(mObj, _lerpVal(vA, vB, frac), true);

        // re-scan to capture the EXACT tick strings Premiere assigned
        var after = _keyObjs(param);
        var mKey = _keyObjNearest(after, markerSec);
        var aKey = _keyObjNearest(after, sA);
        var bKey = _keyObjNearest(after, sB);
        var tickA = _ticksOf(aKey), tickB = _ticksOf(bKey), tickM = _ticksOf(mKey);
        if (!tickA || !tickB || !tickM) {
            try { param.removeKey(mKey); } catch (eRm) {}
            return JSON.stringify({ success: false, error: "Could not read exact keyframe ticks; nothing was changed." });
        }

        // persist everything to disk so the XML matches what we just measured.
        // If save throws, remove our marker key again — never leave residue.
        try { app.project.save(); }
        catch (eSv) {
            try { param.removeKey(mKey); } catch (x) {}
            return JSON.stringify({ success: false, error: "Could not save the project: " + _aeErr(eSv) });
        }

        // Sequence identity — the reopen can come back with the timeline panel closed
        // (a fresh temp path has no UI state), so the panel refocuses it afterwards.
        var seqId = "", seqName = "";
        try { seqId = String(seq.sequenceID || ""); } catch (eSq) {}
        try { seqName = String(seq.name || ""); } catch (eSn) {}

        /* Where this clip sits, so it can be found again after the reopen.
           Kept on $.global rather than returned: it has to survive the project
           closing and opening, and the ExtendScript engine belongs to the app,
           not to the project. Position beats identity — Premiere hands back a
           whole new object graph — and beats the name alone, which two clips
           can share. */
        try {
            $.global.__easeit_reselect = {
                seqId: seqId, seqName: seqName,
                name: String(clip.name || ""),
                startTicks: String(clip.start.ticks)
            };
        } catch (eRs) {}

        return JSON.stringify({
            success: true,
            projPath: path,
            paramName: String(param.displayName),
            clipName: String(clip.name || ""),
            dims: dims,
            tickA: tickA, tickB: tickB, tickMarker: tickM,
            secA: sA, secB: sB, secMarker: markerSec,
            valueA: vA, valueB: vB,
            fps: _fpsOf(seq),
            seqId: seqId, seqName: seqName
        });
    } catch (e) {
        return JSON.stringify({ success: false, error: _aeErr(e) });
    }
}

// Close the project so the panel can rewrite the file. Project was saved in prep.
function easeit_th_close() {
    if (IS_AE) return JSON.stringify({ success: false, error: "Premiere-only." });
    try {
        if (typeof app.project.closeDocument !== 'function') {
            return JSON.stringify({ success: false, error: "closeDocument() not available in this Premiere version." });
        }
        // closeDocument(saveFirst, promptIfDirty): (0,0) = don't save, don't prompt.
        // The project was already saved in prep, so there are no unsaved changes —
        // but pass the flags anyway so a "save changes?" modal can never block us.
        try { app.project.closeDocument(0, 0); }
        catch (e1) { app.project.closeDocument(); }
        return JSON.stringify({ success: true });
    } catch (e) { return JSON.stringify({ success: false, error: _aeErr(e) }); }
}

// Reopen after surgery. Extra args suppress convert/locate/warning dialogs where
// the running version supports them (older builds just ignore the extras). If the
// first attempt lands while Premiere is still tearing the old project down, wait
// briefly and retry once.
function _tryOpen(path) {
    var ok = false;
    try { ok = app.openDocument(path, 1, 1, 1); }
    catch (e1) { try { ok = app.openDocument(path); } catch (e2) { ok = false; } }
    return ok;
}
function easeit_th_open(jsonStr) {
    if (IS_AE) return JSON.stringify({ success: false, error: "Premiere-only." });
    try {
        var opts = JSON.parse(jsonStr);
        var ok = _tryOpen(opts.path);
        if (ok === false || ok === null || typeof ok === 'undefined') {
            try { $.sleep(700); } catch (eS) {}
            ok = _tryOpen(opts.path);
        }
        return JSON.stringify({ success: (ok !== false && ok !== null && typeof ok !== 'undefined'), reopened: String(ok) });
    } catch (e) { return JSON.stringify({ success: false, error: _aeErr(e) }); }
}

/* The reopen returns the project with nothing selected, so the clip that was
   just eased has to be hunted down again by hand. This puts the selection back
   where it was. Runs after the sequence is refocused, so activeSequence is
   already the right one. */
function easeit_th_reselect() {
    if (IS_AE) return JSON.stringify({ success: false, error: "Premiere-only." });
    try {
        var want = null;
        try { want = $.global.__easeit_reselect; } catch (e0) {}
        if (!want) return JSON.stringify({ success: false, error: "nothing to reselect" });

        var seq = app.project ? app.project.activeSequence : null;
        if (!seq) return JSON.stringify({ success: false, error: "no active sequence" });

        var vt = seq.videoTracks, nT = vt.numTracks;
        for (var t = 0; t < nT; t++) {
            var clips = vt[t].clips, nC = clips.numItems;
            for (var c = 0; c < nC; c++) {
                var cl = clips[c];
                var st = ""; try { st = String(cl.start.ticks); } catch (e1) {}
                if (st !== String(want.startTicks)) continue;
                var nm = ""; try { nm = String(cl.name || ""); } catch (e2) {}
                if (want.name && nm !== want.name) continue;
                if (typeof cl.setSelected !== "function") {
                    return JSON.stringify({ success: false, error: "setSelected() not available in this Premiere version" });
                }
                cl.setSelected(true, true);
                try { $.global.__easeit_reselect = null; } catch (e3) {}
                return JSON.stringify({ success: true, clip: nm, track: t });
            }
        }
        return JSON.stringify({ success: false, error: "clip not found after reopen" });
    } catch (e) { return JSON.stringify({ success: false, error: _aeErr(e) }); }
}

// After the True Handles reopen, the project can come back with the TIMELINE PANEL
// CLOSED (the fresh temp path has no per-path UI state), which both annoys the user
// and leaves activeSequence null (breaking verify AND the next prep). Re-open/focus
// the sequence that was active when we started. opts = { seqId, seqName }
function easeit_th_focusSeq(jsonStr) {
    if (IS_AE) return JSON.stringify({ success: false, error: "Premiere-only." });
    try {
        var opts = JSON.parse(jsonStr);
        var seqs = app.project ? app.project.sequences : null;
        var n = seqs ? Number(seqs.numSequences) : 0;
        if (!n) return JSON.stringify({ success: false, error: "no sequences in project" });
        var target = null, i, sid;
        if (opts.seqId) { // exact id first
            for (i = 0; i < n; i++) {
                sid = ""; try { sid = String(seqs[i].sequenceID || ""); } catch (e1) {}
                if (sid === String(opts.seqId)) { target = seqs[i]; break; }
            }
        }
        if (!target && opts.seqName) { // then name
            for (i = 0; i < n; i++) {
                var nm = ""; try { nm = String(seqs[i].name || ""); } catch (e2) {}
                if (nm === String(opts.seqName)) { target = seqs[i]; break; }
            }
        }
        if (!target) target = seqs[0]; // any open timeline beats none
        var how = "";
        try { if (typeof app.project.openSequence === "function") { if (app.project.openSequence(target.sequenceID)) how = "openSequence"; } } catch (e3) {}
        if (!how) { try { app.project.activeSequence = target; how = "activeSequence"; } catch (e4) {} }
        var active = false;
        try { active = !!(app.project.activeSequence && String(app.project.activeSequence.sequenceID) === String(target.sequenceID)); } catch (e5) {}
        return JSON.stringify({ success: true, how: how, active: active });
    } catch (e) { return JSON.stringify({ success: false, error: _aeErr(e) }); }
}

// After a True Handles reopen, verify the project ON SCREEN matches the eased file:
// scan the active sequence for a keyframe at the unique marker tick. Surgery removes
// the marker, so markerPresent=true means Premiere loaded a STALE (pre-surgery) copy
// (diagnostic for the reopen path). Selection-independent (scans all clips/params).
function easeit_th_verify(jsonStr) {
    if (IS_AE) return JSON.stringify({ success: false, error: "Premiere-only." });
    try {
        var opts = JSON.parse(jsonStr);
        var markerTicks = Number(opts.tickMarker);
        var seq = _getSeq();
        if (!seq) return JSON.stringify({ success: false, error: "no active sequence" });
        var markerPresent = false, scanned = 0;
        var vt = seq.videoTracks, nT = vt.numTracks, t, c, i, j, k;
        for (t = 0; t < nT && !markerPresent; t++) {
            var clips = vt[t].clips, nC = clips.numItems;
            for (c = 0; c < nC && !markerPresent; c++) {
                var comps = _collToArray(clips[c].components);
                for (i = 0; i < comps.length && !markerPresent; i++) {
                    var params = _collToArray(comps[i].properties);
                    for (j = 0; j < params.length && !markerPresent; j++) {
                        var keyObjs = _keyObjs(params[j]);
                        if (keyObjs.length === 0) continue;
                        scanned++;
                        for (k = 0; k < keyObjs.length; k++) {
                            var tk = _ticksOf(keyObjs[k]);
                            if (tk && Math.abs(Number(tk) - markerTicks) < 100000) { markerPresent = true; break; }
                        }
                    }
                }
            }
        }
        return JSON.stringify({ success: true, markerPresent: markerPresent, paramsScanned: scanned });
    } catch (e) { return JSON.stringify({ success: false, error: _aeErr(e) }); }
}

// Save the currently-open project to a path (used by the cache-bust reopen: after
// opening a fresh temp copy, saveAs back to the user's canonical filename). The
// canonical path is deleted just before this, so there's no overwrite prompt.
function easeit_th_saveAs(jsonStr) {
    if (IS_AE) return JSON.stringify({ success: false, error: "Premiere-only." });
    try {
        var opts = JSON.parse(jsonStr);
        if (!app.project) return JSON.stringify({ success: false, error: "no project open" });
        if (typeof app.project.saveAs !== 'function') return JSON.stringify({ success: false, error: "saveAs() not available in this Premiere version." });
        app.project.saveAs(opts.path);
        return JSON.stringify({ success: true, path: String(app.project.path || "") });
    } catch (e) { return JSON.stringify({ success: false, error: _aeErr(e) }); }
}

// =============================================================
// EDITKIT TOOLS — After Effects
//
// Todo lo que este bloque expone al panel sigue tres reglas:
//
//   1. Una acción, un deshacer. Cada función abre y cierra su propio grupo
//      con un nombre legible en el historial, y lo cierra también cuando
//      revienta a mitad.
//   2. Los errores viajan como código, no como frase. El panel los traduce;
//      así el mismo host sirve en español y en inglés sin duplicar textos.
//   3. El motor de scripts es pre-ES5: nada de map, indexOf, trim, let ni
//      funciones flecha. Se escribe como está escrito el resto del archivo.
// =============================================================

// ------- utilidades comunes -------

function _ekJ(o) { return JSON.stringify(o); }
function _ekBad(code, detail) {
    var o = { ok: false, code: code };
    if (detail) o.detail = String(detail);
    return _ekJ(o);
}
function _ekGood(extra) {
    var o = { ok: true };
    if (extra) { for (var k in extra) { if (extra.hasOwnProperty(k)) o[k] = extra[k]; } }
    return _ekJ(o);
}

function _ekComp() {
    var c = null;
    try { c = app.project.activeItem; } catch (e) { c = null; }
    if (!c || !(c instanceof CompItem)) return null;
    return c;
}

function _ekSel(comp) {
    var s = [];
    try { s = comp.selectedLayers; } catch (e) { s = []; }
    return s;
}

function _ekRound(n, d) {
    var f = Math.pow(10, d || 0);
    return Math.round(n * f) / f;
}

// Cuántas dimensiones tiene el valor de una propiedad (1 para escalares).
function _ekDims(prop) {
    var v = null;
    try { v = prop.value; } catch (e) { return 1; }
    return _isArr(v) ? v.length : 1;
}

// Recorre TODO el árbol de la capa y devuelve las propiedades hoja que
// cumplan el filtro. Es el mismo recorrido que usa EaseIt, pero abierto:
// aquí hace falta con un solo keyframe, o con expresión y ninguno.
function _ekWalk(layer, test) {
    var out = [];
    function walk(g) {
        var n = 0;
        try { n = g.numProperties; } catch (e) { n = 0; }
        for (var i = 1; i <= n; i++) {
            var p = null;
            try { p = g.property(i); } catch (e2) { p = null; }
            if (!p) continue;
            var isGroup = false;
            try { isGroup = (p.propertyType !== PropertyType.PROPERTY); } catch (e3) { isGroup = false; }
            if (isGroup) { walk(p); continue; }
            try { if (test(p)) out.push(p); } catch (e4) {}
        }
    }
    try { walk(layer); } catch (e) {}
    return out;
}

// Propiedades con al menos `min` keyframes seleccionados.
function _ekSelKeyProps(layer, min) {
    return _ekWalk(layer, function (p) {
        var cv = false;
        try { cv = !!p.canVaryOverTime; } catch (e) { return false; }
        if (!cv) return false;
        var sk = null;
        try { sk = p.selectedKeys; } catch (e2) { return false; }
        return !!(sk && sk.length >= min);
    });
}

// Propiedades donde se puede escribir una expresión.
function _ekExprProps(layer, onlyWithExpr) {
    return _ekWalk(layer, function (p) {
        var can = false;
        try { can = !!p.canSetExpression; } catch (e) { return false; }
        if (!can) return false;
        if (!onlyWithExpr) return true;
        var ex = "";
        try { ex = p.expression || ""; } catch (e2) { ex = ""; }
        return _trim(ex) !== "";
    });
}

// Propiedades marcadas por el usuario en la línea de tiempo (con o sin keys).
function _ekSelProps(layer) {
    var out = [];
    try {
        var sp = layer.selectedProperties;
        for (var i = 0; i < sp.length; i++) {
            var p = sp[i];
            var isProp = false;
            try { isProp = (p.propertyType === PropertyType.PROPERTY); } catch (e) { isProp = false; }
            if (isProp) out.push(p);
        }
    } catch (e2) {}
    return out;
}

// El punto de anclaje de una capa en coordenadas de composición. Pasa por
// toComp, así que respeta toda la cadena de padres — a diferencia del
// medidor que usa la alineación, que solo mira la capa.
function _ekWorldPt(layer, localPt, time) {
    try { return layer.toComp(localPt, time); } catch (e) { return null; }
}

// Límites reales de un grupo de capas en la composición, con padres incluidos.
function _ekWorldBounds(layers, time) {
    var minX = null, maxX = null, minY = null, maxY = null;
    for (var i = 0; i < layers.length; i++) {
        var L = layers[i];
        var r = null;
        try {
            if (L instanceof CameraLayer || L instanceof LightLayer) continue;
            r = L.sourceRectAtTime(time, false);
        } catch (e) { r = null; }
        if (!r || !isFinite(r.width) || !isFinite(r.height)) continue;
        var pts = [
            [r.left, r.top],
            [r.left + r.width, r.top],
            [r.left, r.top + r.height],
            [r.left + r.width, r.top + r.height]
        ];
        for (var k = 0; k < 4; k++) {
            var w = _ekWorldPt(L, pts[k], time);
            if (!w) continue;
            if (minX === null || w[0] < minX) minX = w[0];
            if (maxX === null || w[0] > maxX) maxX = w[0];
            if (minY === null || w[1] < minY) minY = w[1];
            if (maxY === null || w[1] > maxY) maxY = w[1];
        }
    }
    if (minX === null) return null;
    return {
        left: minX, right: maxX, top: minY, bottom: maxY,
        width: maxX - minX, height: maxY - minY,
        centerX: (minX + maxX) / 2, centerY: (minY + maxY) / 2
    };
}

// =============================================================
// A — TIEMPO Y KEYFRAMES
// =============================================================

/* Mover un keyframe en el tiempo no se puede: keyTime es de solo lectura.
   Hay que leerlo entero —valor, tipo de interpolación, eases temporales,
   tangentes espaciales, roving— borrarlo y volver a escribirlo en el sitio
   nuevo. Este lector y su escritor son la base de A2 y A3, y el punto donde
   se pierde información si se hace a la ligera. */
function _ekReadKey(prop, i) {
    var k = { t: prop.keyTime(i), v: prop.keyValue(i) };
    try { k.inI = prop.keyInInterpolationType(i); } catch (e) { k.inI = null; }
    try { k.outI = prop.keyOutInterpolationType(i); } catch (e) { k.outI = null; }
    try { k.inE = prop.keyInTemporalEase(i); } catch (e) { k.inE = null; }
    try { k.outE = prop.keyOutTemporalEase(i); } catch (e) { k.outE = null; }
    try { k.tAuto = prop.keyTemporalAutoBezier(i); } catch (e) { k.tAuto = false; }
    try { k.tCont = prop.keyTemporalContinuous(i); } catch (e) { k.tCont = false; }
    var spatial = false;
    try { spatial = !!prop.isSpatial; } catch (e) { spatial = false; }
    k.spatial = spatial;
    if (spatial) {
        try { k.inS = prop.keyInSpatialTangent(i); } catch (e) { k.inS = null; }
        try { k.outS = prop.keyOutSpatialTangent(i); } catch (e) { k.outS = null; }
        try { k.sAuto = prop.keySpatialAutoBezier(i); } catch (e) { k.sAuto = false; }
        try { k.sCont = prop.keySpatialContinuous(i); } catch (e) { k.sCont = false; }
        try { k.rove = prop.keyRoving(i); } catch (e) { k.rove = false; }
    }
    return k;
}

/* ESCRIBIR KEYFRAMES EN OTRO TIEMPO, SIN PERDER LAS CURVAS

   Esto se hacia en una sola pasada: crear el keyframe y vestirlo —tipo de
   interpolacion, tangentes, eases— antes de pasar al siguiente. Funciona
   mientras los tiempos nuevos vayan hacia delante y no haya nada detras, que
   es el caso de desplazar y de estirar. Y falla en los dos que se acaban de
   anadir, por dos motivos distintos y los dos del mismo origen: UN EASE NO ES
   UNA PROPIEDAD DEL KEYFRAME, ES UNA PROPIEDAD DEL TRAMO QUE HAY A SU LADO.

     · Al invertir, el primer keyframe que se escribe es el que va al final, y
       en ese momento la propiedad esta vacia. Escribirle un ease a un
       keyframe que esta solo no tiene a que agarrarse: After Effects no lo
       guarda, y esa curva se pierde. Por eso la animacion invertida salia
       "cortada a la mitad" — el ultimo keyframe se quedaba con la velocidad
       que le calculo el programa en lugar de con la de su pareja.

     · Al copiar invertido, los keyframes nuevos se meten ENTRE los que ya
       habia. Cada uno parte un tramo en dos, y la influencia es un porcentaje
       del tramo: partir el tramo cambia lo que valia el ease de los vecinos
       que ya se habian escrito. Por eso la copia salia aplanada.

   La solucion es la misma para los dos: dos pasadas. Primero se crean TODOS
   los keyframes —solo el valor— y de menor a mayor tiempo. Despues, con la
   fila ya completa y ningun tramo por partir, se les pone a cada uno su tipo,
   sus tangentes y sus eases.

   `sp` reescala la velocidad de los eases. La influencia es un porcentaje y no
   cambia al estirar el tiempo, pero la velocidad va en unidades por segundo:
   si no se divide por el factor, la curva se deforma. */

// El indice del keyframe que esta EXACTAMENTE en ese tiempo. Se compara por
// igualdad porque el tiempo viene de keyTime(), leido del propio programa, y
// no de una cuenta nuestra que podria caer entre dos cuadros.
function _aeKeyIndexAt(prop, t) {
    var n = 0;
    try { n = prop.numKeys; } catch (e) { return 0; }
    for (var i = 1; i <= n; i++) {
        var kt;
        try { kt = prop.keyTime(i); } catch (e2) { continue; }
        if (Math.abs(kt - t) < 1e-7) return i;
    }
    return 0;
}

/* Pasada 1: el keyframe, con su valor y nada mas. Devuelve el tiempo REAL al
   que fue a parar —After Effects lo ajusta al cuadro mas cercano— para poder
   volver a encontrarlo en la segunda pasada aunque los indices se hayan
   movido al crear los demas. */
function _ekPlaceKey(prop, k, newT) {
    try { prop.setValueAtTime(newT, k.v); } catch (e) { return null; }
    var i = -1;
    try { i = _aeKeyIndexNear(prop, newT); } catch (e2) { i = -1; }
    if (i < 1) return null;
    try { return prop.keyTime(i); } catch (e3) { return null; }
}

// Pasada 2: todo lo demas.
function _ekStyleKey(prop, k, atT, sp) {
    var i = _aeKeyIndexAt(prop, atT);
    if (i < 1) return;

    if (k.inI !== null && k.outI !== null) {
        try { prop.setInterpolationTypeAtKey(i, k.inI, k.outI); } catch (e) {}
    }
    if (k.spatial) {
        try { if (k.inS) prop.setSpatialTangentsAtKey(i, k.inS, k.outS); } catch (e2) {}
        try { prop.setSpatialAutoBezierAtKey(i, k.sAuto); } catch (e3) {}
        try { prop.setSpatialContinuousAtKey(i, k.sCont); } catch (e4) {}
        try { prop.setRovingAtKey(i, k.rove); } catch (e5) {}
    }

    /* Las dos banderas ANTES de los eases, no despues. Encender
       temporalAutoBezier hace que After Effects se calcule los eases por su
       cuenta: puesta detras, borraba lo que se acababa de escribir. */
    try { prop.setTemporalAutoBezierAtKey(i, k.tAuto); } catch (e6) {}
    try { prop.setTemporalContinuousAtKey(i, k.tCont); } catch (e7) {}

    /* Y un keyframe que era automatico se queda automatico: sus eases son los
       que calcula el programa, escribirlos a mano solo serviria para apagarle
       lo que lo hacia automatico. */
    if (!k.tAuto && k.inE && k.outE) {
        var scale = (sp && sp > 0) ? sp : 1;
        var a = [], b = [], n;
        for (n = 0; n < k.inE.length; n++) a.push(new KeyframeEase(k.inE[n].speed / scale, k.inE[n].influence));
        for (n = 0; n < k.outE.length; n++) b.push(new KeyframeEase(k.outE[n].speed / scale, k.outE[n].influence));
        try { prop.setTemporalEaseAtKey(i, a, b); } catch (e8) {}
    }
}

/* Las dos pasadas, que es lo unico que llaman los de fuera.

   El orden de creacion es de menor a mayor tiempo SIEMPRE, aunque la lista
   venga al reves —que es justo lo que pasa al invertir—. Asi cada keyframe
   nuevo se anade detras del anterior en lugar de meterse en medio. */
function _ekWriteKeys(prop, keys, news, sp, flip) {
    var order = [], i;
    for (i = 0; i < keys.length; i++) order.push(i);
    order.sort(function (a, b) { return news[a] - news[b]; });

    var placed = [];
    for (i = 0; i < order.length; i++) {
        var j = order[i];
        var k = flip ? _ekFlipKey(keys[j]) : keys[j];
        var t = _ekPlaceKey(prop, k, news[j]);
        if (t === null) continue;
        placed.push({ k: k, t: t });
    }
    for (i = 0; i < placed.length; i++) {
        _ekStyleKey(prop, placed[i].k, placed[i].t, sp);
    }
    return placed;
}

/* Un keyframe visto del reves.

   Invertir el tiempo no es solo cambiar de sitio los keyframes: lo que entraba
   ahora sale. Si no se cambian de lado la interpolacion y los eases, una
   entrada suave se queda como entrada suave en el lado que ahora es la salida,
   y la animacion invertida no es la de antes al reves — es otra.

   Las tangentes espaciales se cambian de lado pero NO se invierten de signo:
   son la posicion de la manija respecto al keyframe, y la manija sigue
   estando donde estaba; lo unico que cambia es cual de las dos es la de
   entrada. */
function _ekFlipEase(arr, spatial) {
    if (!arr) return arr;
    /* Al invertir el tiempo el valor se recorre al reves, asi que la
       velocidad —que es cuanto cambia el valor por segundo— cambia de signo.
       Menos en las propiedades espaciales: ahi After Effects no da un signo,
       da la magnitud en pixeles por segundo, y una magnitud negativa no
       existe. Sin esta distincion, invertir una opacidad o una escala salia al
       reves de como tenia que salir, y una posicion no se podia invertir. */
    if (spatial) return arr;
    var out = [];
    for (var i = 0; i < arr.length; i++) {
        var sp = 0, inf = 16.666666;
        try { sp = arr[i].speed; } catch (e) {}
        try { inf = arr[i].influence; } catch (e2) {}
        out.push(new KeyframeEase(-sp, inf));
    }
    return out;
}

function _ekFlipKey(k) {
    var f = { t: k.t, v: k.v, spatial: k.spatial };
    f.inI = k.outI; f.outI = k.inI;
    f.inE = _ekFlipEase(k.outE, k.spatial);
    f.outE = _ekFlipEase(k.inE, k.spatial);
    f.tAuto = k.tAuto; f.tCont = k.tCont;
    if (k.spatial) {
        f.inS = k.outS; f.outS = k.inS;
        f.sAuto = k.sAuto; f.sCont = k.sCont; f.rove = k.rove;
    }
    return f;
}

// =============================================================
// EASECOPY — COPIAR CURVAS Y VALORES POR SEPARADO
// =============================================================

/* El portapapeles es deliberadamente interno. CEP no necesita leer ni
   escribir el portapapeles de Windows y, por tanto, tampoco depende del foco
   de After Effects. Se conserva mientras siga vivo el motor ExtendScript de
   EDITKIT. */
var _ekEaseCopyClipboard = null;

function _ekEaseCopyPackEase(arr) {
    var out = [];
    if (!arr) return out;
    for (var i = 0; i < arr.length; i++) {
        var speed = 0, influence = 16.666666;
        try { speed = Number(arr[i].speed); } catch (e) { speed = 0; }
        try { influence = Number(arr[i].influence); } catch (e2) { influence = 16.666666; }
        if (!isFinite(speed)) speed = 0;
        if (!isFinite(influence)) influence = 16.666666;
        out.push({ speed: speed, influence: influence });
    }
    return out;
}

function _ekEaseCopyValue(v) {
    if (!_isArr(v)) return v;
    var out = [];
    for (var i = 0; i < v.length; i++) out.push(v[i]);
    return out;
}

function _ekEaseCopySelected(comp) {
    var out = [], layers = _ekSel(comp), i, j, k;
    layers.sort(function (a, b) {
        var ai = 0, bi = 0;
        try { ai = a.index; } catch (e) {}
        try { bi = b.index; } catch (e2) {}
        return ai - bi;
    });
    for (i = 0; i < layers.length; i++) {
        var props = _ekSelKeyProps(layers[i], 1);
        for (j = 0; j < props.length; j++) {
            var sk = null, idx = [];
            try { sk = props[j].selectedKeys; } catch (e3) { sk = null; }
            if (!sk) continue;
            for (k = 0; k < sk.length; k++) idx.push(sk[k]);
            idx.sort(function (a, b) { return a - b; });
            for (k = 0; k < idx.length; k++) out.push({ prop: props[j], index: idx[k] });
        }
    }
    return out;
}

function _ekEaseCopyEaseCount(prop, index, spatial) {
    var n = 0, arr = null;
    try { arr = prop.keyOutTemporalEase(index); } catch (e) { arr = null; }
    if (arr && arr.length) n = arr.length;
    if (!n) {
        try { arr = prop.keyInTemporalEase(index); } catch (e2) { arr = null; }
        if (arr && arr.length) n = arr.length;
    }
    if (!n) n = spatial ? 1 : _ekDims(prop);
    return Math.max(1, n);
}

function _ekEaseCopySegmentVelocity(prop, a, b, n, spatial) {
    if (a < 1 || b < 1) return null;
    var ta, tb, va, vb;
    try {
        ta = prop.keyTime(a); tb = prop.keyTime(b);
        va = prop.keyValue(a); vb = prop.keyValue(b);
    } catch (e) { return null; }
    var dt = tb - ta;
    if (!isFinite(dt) || Math.abs(dt) < 1e-8) return null;
    if (spatial) return [_vecDist(va, vb) / Math.abs(dt)];
    var out = [];
    for (var d = 0; d < n; d++) {
        var av = _isArr(va) ? Number(va[Math.min(d, va.length - 1)]) : Number(va);
        var bv = _isArr(vb) ? Number(vb[Math.min(d, vb.length - 1)]) : Number(vb);
        var speed = (bv - av) / dt;
        out.push(isFinite(speed) ? speed : 0);
    }
    return out;
}

function _ekEaseCopyBase(prop, index, n, spatial, incoming) {
    var count = 0;
    try { count = prop.numKeys; } catch (e) { count = 0; }
    var base = incoming ? _ekEaseCopySegmentVelocity(prop, index - 1, index, n, spatial) :
        _ekEaseCopySegmentVelocity(prop, index, index + 1, n, spatial);
    if (base) return base;
    /* El lado exterior del primer/ultimo keyframe no participa en la curva.
       Usar el tramo que si existe evita que una propiedad equivalente pierda
       su escala solo porque la seleccion incluye un extremo. */
    if (incoming && index < count) return _ekEaseCopySegmentVelocity(prop, index, index + 1, n, spatial);
    if (!incoming && index > 1) return _ekEaseCopySegmentVelocity(prop, index - 1, index, n, spatial);
    return null;
}

function _ekEaseCopyRead(prop, index) {
    var k = _ekReadKey(prop, index), spatial = !!k.spatial;
    var n = _ekEaseCopyEaseCount(prop, index, spatial), valueType = null;
    try { valueType = prop.propertyValueType; } catch (e) { valueType = null; }
    return {
        value: _ekEaseCopyValue(k.v), valueType: valueType,
        spatial: spatial, dims: _ekDims(prop),
        inI: k.inI, outI: k.outI,
        inE: _ekEaseCopyPackEase(k.inE), outE: _ekEaseCopyPackEase(k.outE),
        inBase: _ekEaseCopyBase(prop, index, n, spatial, true),
        outBase: _ekEaseCopyBase(prop, index, n, spatial, false)
    };
}

function _ekEaseCopyCompatible(source, target) {
    var targetType = null, targetValue = null;
    try { targetType = target.prop.propertyValueType; } catch (e) { return false; }
    if (String(targetType) !== String(source.valueType)) return false;
    try { targetValue = target.prop.keyValue(target.index); } catch (e2) { return false; }
    if (_isArr(source.value) !== _isArr(targetValue)) return false;
    if (_isArr(source.value) && source.value.length !== targetValue.length) return false;
    return true;
}

function _ekEaseCopyScaledEase(sourceEase, sourceBase, targetBase, n, targetSpatial) {
    var out = [];
    sourceEase = sourceEase || [];
    for (var d = 0; d < n; d++) {
        var item = sourceEase.length ? sourceEase[Math.min(d, sourceEase.length - 1)] : { speed: 0, influence: 16.666666 };
        var sb = sourceBase && sourceBase.length ? Number(sourceBase[Math.min(d, sourceBase.length - 1)]) : 0;
        var tb = targetBase && targetBase.length ? Number(targetBase[Math.min(d, targetBase.length - 1)]) : 0;
        var speed = Number(item.speed);
        if (isFinite(sb) && Math.abs(sb) > 1e-8 && isFinite(tb)) speed = (speed / sb) * tb;
        if (!isFinite(speed)) speed = 0;
        if (targetSpatial) speed = Math.abs(speed);
        out.push(_aeEase(speed, Number(item.influence)));
    }
    return out;
}

function _ekEaseCopyPassVelocity(inEase, outEase, inBase, outBase, spatial) {
    var n = Math.min(inEase.length, outEase.length);
    for (var d = 0; d < n; d++) {
        var ib = inBase && inBase.length ? Number(inBase[Math.min(d, inBase.length - 1)]) : 0;
        var ob = outBase && outBase.length ? Number(outBase[Math.min(d, outBase.length - 1)]) : 0;
        /* En un cambio real de direccion no existe una sola velocidad escalar
           que atraviese el keyframe. En ese caso se respetan ambos lados. */
        if (!spatial && ib * ob < 0) continue;
        var shared = (Number(inEase[d].speed) + Number(outEase[d].speed)) / 2;
        inEase[d] = _aeEase(shared, inEase[d].influence);
        outEase[d] = _aeEase(shared, outEase[d].influence);
    }
}

function easeit_easeCopyCapture() {
    try {
        var comp = _ekComp();
        if (!comp) return _ekBad("needComp");
        var selected = _ekEaseCopySelected(comp);
        if (!selected.length) return _ekBad("needKeys");
        var keys = [];
        for (var i = 0; i < selected.length; i++) keys.push(_ekEaseCopyRead(selected[i].prop, selected[i].index));
        _ekEaseCopyClipboard = { keys: keys };
        return _ekGood({ count: keys.length });
    } catch (e) { return _ekBad("captureFailed", e.toString()); }
}

function _ekEaseCopyValidateTargets() {
    var comp = _ekComp();
    if (!comp) return { error: "needComp" };
    if (!_ekEaseCopyClipboard || !_ekEaseCopyClipboard.keys || !_ekEaseCopyClipboard.keys.length) return { error: "clipboardEmpty" };
    var targets = _ekEaseCopySelected(comp), sourceCount = _ekEaseCopyClipboard.keys.length;
    if (!targets.length) return { error: "needKeys" };
    if (targets.length % sourceCount !== 0) return { error: "countMismatch", detail: sourceCount + ":" + targets.length };
    return { comp: comp, targets: targets, sourceCount: sourceCount };
}

function easeit_easeCopyPasteEase(passThrough) {
    var state = _ekEaseCopyValidateTargets();
    if (state.error) return _ekBad(state.error, state.detail);
    var continuous = passThrough === true || String(passThrough) === "true";
    var changed = 0, failed = 0;
    _aeUndoBegin("EaseCopy - Paste easing");
    try {
        for (var i = 0; i < state.targets.length; i++) {
            var target = state.targets[i], source = _ekEaseCopyClipboard.keys[i % state.sourceCount];
            var prop = target.prop, index = target.index, spatial = false, count = 0;
            try { spatial = !!prop.isSpatial; count = prop.numKeys; } catch (e0) { failed++; continue; }
            var n = _ekEaseCopyEaseCount(prop, index, spatial);
            var inBase = _ekEaseCopyBase(prop, index, n, spatial, true);
            var outBase = _ekEaseCopyBase(prop, index, n, spatial, false);
            var inEase = _ekEaseCopyScaledEase(source.inE, source.inBase, inBase, n, spatial);
            var outEase = _ekEaseCopyScaledEase(source.outE, source.outBase, outBase, n, spatial);
            if (continuous && index > 1 && index < count) _ekEaseCopyPassVelocity(inEase, outEase, inBase, outBase, spatial);
            try {
                if (source.inI !== null && source.outI !== null) prop.setInterpolationTypeAtKey(index, source.inI, source.outI);
                prop.setTemporalAutoBezierAtKey(index, false);
                prop.setTemporalContinuousAtKey(index, false);
                var hold = false;
                try { hold = source.inI === KeyframeInterpolationType.HOLD || source.outI === KeyframeInterpolationType.HOLD; } catch (e1) { hold = false; }
                if (!hold) prop.setTemporalEaseAtKey(index, inEase, outEase);
                if (continuous && index > 1 && index < count) {
                    try { prop.setTemporalContinuousAtKey(index, true); } catch (e2) {}
                }
                changed++;
            } catch (e3) { failed++; }
        }
    } catch (e4) { failed++; }
    finally { _aeUndoEnd(); }
    if (!changed) return _ekBad("pasteFailed");
    return _ekGood({ count: changed, failed: failed, sourceCount: state.sourceCount });
}

function easeit_easeCopyPasteValue() {
    var state = _ekEaseCopyValidateTargets();
    if (state.error) return _ekBad(state.error, state.detail);
    var i;
    for (i = 0; i < state.targets.length; i++) {
        if (!_ekEaseCopyCompatible(_ekEaseCopyClipboard.keys[i % state.sourceCount], state.targets[i])) {
            return _ekBad("valueMismatch");
        }
    }
    var changed = 0, failed = 0;
    _aeUndoBegin("EaseCopy - Paste values");
    try {
        for (i = 0; i < state.targets.length; i++) {
            var target = state.targets[i], source = _ekEaseCopyClipboard.keys[i % state.sourceCount];
            var before = null, time = null;
            try {
                before = _ekReadKey(target.prop, target.index);
                time = target.prop.keyTime(target.index);
                target.prop.setValueAtKey(target.index, _ekEaseCopyValue(source.value));
                _ekStyleKey(target.prop, before, time, 1);
                changed++;
            } catch (e) { failed++; }
        }
    } catch (e2) { failed++; }
    finally { _aeUndoEnd(); }
    if (!changed) return _ekBad("pasteFailed");
    return _ekGood({ count: changed, failed: failed, sourceCount: state.sourceCount });
}

/* LEER LA SELECCION DE TODAS LAS PROPIEDADES ANTES DE TOCAR NINGUNA

   Escribir un keyframe cambia la seleccion de la linea de tiempo ENTERA: After
   Effects deja marcado lo que acaba de crear y suelta todo lo demas, este donde
   este. Con una sola propiedad eso no se nota —se lee, se escribe y se acabo—.
   Con varias, la primera se llevaba por delante la seleccion de las otras, y
   cada una de las siguientes llegaba a su turno, preguntaba que keyframes tenia
   marcados, no encontraba ninguno y se iba sin hacer nada.

   Eso es lo que se veia al elegir keyframes de posicion Y de escala e invertir:
   se invertia una propiedad y las demas se quedaban como estaban.

   Asi que los indices se leen de una vez, al principio, y luego cada propiedad
   trabaja con los suyos en lugar de volver a preguntar. Los indices siguen
   valiendo mientras se escribe: anadir o quitar keyframes en una propiedad no
   cambia los de otra.

   Es la misma leccion que la de los eases, un piso mas arriba: leer entero
   antes de escribir nada. */
function _ekSnapSel(props) {
    var out = [], i, j;
    for (i = 0; i < props.length; i++) {
        var sk = null;
        try { sk = props[i].selectedKeys; } catch (e) { sk = null; }
        var idx = [];
        if (sk) { for (j = 0; j < sk.length; j++) idx.push(sk[j]); }
        out.push(idx);
    }
    return out;
}

// Los tiempos de esos indices, en orden. Sustituye a volver a leer la
// seleccion cuando ya se ha escrito algo en otra propiedad.
function _ekTimesAt(prop, idx) {
    var out = [];
    if (!idx) return out;
    for (var i = 0; i < idx.length; i++) {
        try { out.push(prop.keyTime(idx[i])); } catch (e) {}
    }
    out.sort(function (a, b) { return a - b; });
    return out;
}

/* El tramo que ocupan TODAS las propiedades juntas, no cada una por su lado.

   Es la diferencia entre invertir una animacion y romperla. Si la posicion va
   del segundo 0 al 1 y la escala del 0.2 al 0.8, darle la vuelta a cada una
   dentro de su propio tramo deja las dos invertidas pero ya no coordinadas.
   Con un tramo comun, todo gira alrededor del mismo eje y lo que pasaba antes
   sigue pasando antes. */
function _ekSelSpan(props, snap) {
    var lo = null, hi = null, i, j;
    for (i = 0; i < props.length; i++) {
        var times = [];
        try {
            times = snap ? _ekTimesAt(props[i], snap[i]) : _aeSelectedTimes(props[i]);
        } catch (e) { times = []; }
        for (j = 0; j < times.length; j++) {
            if (lo === null || times[j] < lo) lo = times[j];
            if (hi === null || times[j] > hi) hi = times[j];
        }
    }
    if (lo === null) return null;
    return { lo: lo, hi: hi };
}

// Marca todos los keyframes de una propiedad. Es el atajo para "no hay nada
// seleccionado, asi que va todo".
function _ekSelectAllKeys(prop) {
    var n = 0;
    try { n = prop.numKeys; } catch (e) { return 0; }
    for (var i = 1; i <= n; i++) {
        try { prop.setSelectedAtKey(i, true); } catch (e2) {}
    }
    return n;
}

/* Las propiedades con keyframes de las capas marcadas, seleccionados o no.

   Se usa como respaldo: quien elige una capa entera y pide invertir el tiempo
   esta pidiendo invertir su animacion, no que no pase nada porque no toco
   ningun rombo en la linea de tiempo. */
function _ekGatherAnyKeys(comp) {
    var layers = _ekSel(comp), out = [], i, j;
    for (i = 0; i < layers.length; i++) {
        var props = _ekWalk(layers[i], function (p) {
            var n = 0;
            try { n = p.numKeys; } catch (e) { return false; }
            return n > 0;
        });
        for (j = 0; j < props.length; j++) out.push(props[j]);
    }
    return out;
}

/* Las propiedades sobre las que trabajan las dos funciones de invertir: las
   que tengan keyframes seleccionados y, si no hay ninguno, todas las de las
   capas marcadas.

   Devuelve las propiedades Y los indices ya leidos, no solo las propiedades.
   Quien lo llama va a escribir keyframes, y en cuanto escriba el primero la
   seleccion de la linea de tiempo deja de ser la que era —ver la nota de
   _ekSnapSel—. Leerla aqui, de una vez y antes de nada, es lo unico que
   garantiza que las propiedades segunda y tercera reciban lo suyo.

   En el camino de respaldo ni siquiera hace falta preguntar: si van todos los
   keyframes, los indices son 1..n. Se marcan igualmente en la linea de tiempo
   para que el usuario vea sobre que se trabajo. */
function _ekKeyWorkset(comp) {
    var props = _ekGatherSelKeys(comp, 1), i;
    if (props.length) return { props: props, snap: _ekSnapSel(props) };

    props = _ekGatherAnyKeys(comp);
    var snap = [];
    for (i = 0; i < props.length; i++) {
        var n = _ekSelectAllKeys(props[i]);
        var idx = [];
        for (var j = 1; j <= n; j++) idx.push(j);
        snap.push(idx);
    }
    return { props: props, snap: snap };
}

/* DEVOLVER LA SELECCION, AL FINAL Y DE UNA VEZ

   La otra mitad del mismo problema. Cada propiedad dejaba marcados sus
   keyframes nuevos nada mas escribirlos, y eso funciona con una sola: con
   varias, el primer keyframe que escribe la propiedad siguiente suelta lo que
   se acaba de marcar en la anterior, y al terminar solo quedaba marcada la
   ultima. Se nota sobre todo al copiar invertido, donde lo que queda marcado
   es justamente la copia que el usuario va a arrastrar.

   Asi que se marca despues, cuando ya no queda nada por escribir. Cada entrada
   es una propiedad y los tiempos que le tocan: lo que coincida se marca y lo
   demas se suelta. */
function _ekReselectKeys(keep) {
    var eps = 1e-5;
    for (var i = 0; i < keep.length; i++) {
        var prop = keep[i].p, times = keep[i].t, n = 0;
        try { n = prop.numKeys; } catch (e) { continue; }
        for (var ki = 1; ki <= n; ki++) {
            var kt, hit = false;
            try { kt = prop.keyTime(ki); } catch (e2) { continue; }
            for (var m = 0; m < times.length; m++) {
                if (Math.abs(kt - times[m]) < eps) { hit = true; break; }
            }
            try { prop.setSelectedAtKey(ki, hit); } catch (e3) {}
        }
    }
}

/* Reescribe en el tiempo los keyframes seleccionados de una propiedad.
   `mapT` recibe el tiempo viejo y devuelve el nuevo. Se borra de arriba abajo
   —al quitar el índice 3 el 4 pasa a ser 3— y se escribe después, ya con la
   lista entera leída, para que dos keyframes que se cruzan no se pisen. */
function _ekRetimeProp(prop, mapT, sp, minT, flip, idx, keep) {
    /* `idx` son los indices leidos antes de empezar a escribir. Se le pasan
       siempre que haya mas de una propiedad en juego; ver la nota de
       _ekSnapSel. Sin ellos se pregunta, que sigue valiendo para quien llama
       con una sola. */
    var sk = idx || null;
    if (!sk) {
        try { sk = prop.selectedKeys; } catch (e) { return 0; }
    }
    if (!sk || !sk.length) return 0;

    var keys = [], i;
    for (i = 0; i < sk.length; i++) {
        try { keys.push(_ekReadKey(prop, sk[i])); } catch (e2) {}
    }
    if (!keys.length) return 0;

    // Un keyframe en tiempo negativo no existe: si el reparto se sale por la
    // izquierda se aborta la propiedad entera en lugar de recortarla, que
    // dejaría la animación distinta sin avisar.
    var news = [];
    for (i = 0; i < keys.length; i++) {
        var nt = mapT(keys[i].t);
        if (!isFinite(nt) || nt < (minT === null || typeof minT === "undefined" ? 0 : minT) - 1e-6) return -1;
        news.push(nt);
    }

    var idx = [];
    for (i = 0; i < sk.length; i++) idx.push(sk[i]);
    idx.sort(function (a, b) { return b - a; });
    for (i = 0; i < idx.length; i++) {
        try { prop.removeKey(idx[i]); } catch (e3) {}
    }

    try { _ekWriteKeys(prop, keys, news, sp, flip); } catch (e4) {}

    /* La seleccion se devuelve donde estaba, para poder encadenar otra
       operacion sin volver a marcar nada en la linea de tiempo. Con `keep` se
       apunta para el final; sin el —una sola propiedad— se hace aqui mismo. */
    if (keep) keep.push({ p: prop, t: news });
    else { try { _ekReselectKeys([{ p: prop, t: news }]); } catch (e5) {} }

    return keys.length;
}

/* Recolecta las propiedades con keyframes seleccionados en todas las capas
   marcadas. Devuelve también el total, que es lo que el panel enseña. */
function _ekGatherSelKeys(comp, min) {
    var layers = _ekSel(comp), out = [], i, j;
    for (i = 0; i < layers.length; i++) {
        var props = _ekSelKeyProps(layers[i], min);
        for (j = 0; j < props.length; j++) out.push(props[j]);
    }
    return out;
}

// ------- A2 · estirar o encoger la animación -------
function ek_timeScale(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { return _ekBad("badArg"); }
    var factor = Number(o.factor);
    if (!isFinite(factor) || factor <= 0) return _ekBad("badFactor");

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var props = _ekGatherSelKeys(comp, 2);
    if (!props.length) return _ekBad("needTwoKeys");

    // Igual que al invertir: la seleccion entera, antes de escribir nada.
    var snap = _ekSnapSel(props);

    app.beginUndoGroup("EDITKIT: escalar tiempo ×" + _ekRound(factor, 3));
    try {
        var moved = 0, clipped = 0, keep = [];
        for (var i = 0; i < props.length; i++) {
            var p = props[i];
            var times = _ekTimesAt(p, snap[i]);
            if (times.length < 2) continue;

            // El ancla decide qué se queda quieto. Con el cursor de tiempo
            // fuera del tramo el resultado sigue siendo válido: el tramo se
            // aleja o se acerca al cursor, que es justo lo que se pide al
            // escribir un factor con el cursor puesto a propósito.
            var anchor;
            if (o.anchor === "last") anchor = times[times.length - 1];
            else if (o.anchor === "playhead") anchor = comp.time;
            else anchor = times[0];

            var n = _ekRetimeProp(p, (function (a, f) {
                return function (t) { return a + (t - a) * f; };
            })(anchor, factor), factor, 0, false, snap[i], keep);

            if (n < 0) clipped++;
            else moved += n;
        }
        _ekReselectKeys(keep);
        if (!moved && clipped) return _ekBad("wouldGoNegative");
        return _ekGood({ keys: moved, skipped: clipped });
    } catch (e2) {
        return _ekBad("hostErr", _aeErr(e2));
    } finally {
        app.endUndoGroup();
    }
}

// ------- A3 · desplazar N fotogramas -------
function ek_timeShift(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { return _ekBad("badArg"); }
    var frames = Number(o.frames);
    if (!isFinite(frames) || frames === 0) return _ekBad("badArg");

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var props = _ekGatherSelKeys(comp, 1);
    if (!props.length) return _ekBad("needKeys");

    var dt = frames / comp.frameRate;
    var snap = _ekSnapSel(props);

    app.beginUndoGroup("EDITKIT: desplazar " + frames + " f");
    try {
        var moved = 0, clipped = 0, keep = [];
        for (var i = 0; i < props.length; i++) {
            // Sin reescalar velocidades: desplazar no cambia la duración, así
            // que los eases se copian tal cual.
            var n = _ekRetimeProp(props[i], (function (d) {
                return function (t) { return t + d; };
            })(dt), 1, 0, false, snap[i], keep);
            if (n < 0) clipped++; else moved += n;
        }
        _ekReselectKeys(keep);
        if (!moved && clipped) return _ekBad("wouldGoNegative");
        return _ekGood({ keys: moved, skipped: clipped });
    } catch (e2) {
        return _ekBad("hostErr", _aeErr(e2));
    } finally {
        app.endUndoGroup();
    }
}

/* ------- A3b · invertir el tiempo de los keyframes -------

   Dos funciones que comparten casi todo y se diferencian en una cosa: una
   mueve lo que hay y la otra deja una copia.

   INVERTIR. Los keyframes se reflejan alrededor del centro de su propio
   tramo: el primero pasa a estar donde estaba el ultimo, el ultimo donde
   estaba el primero, y los del medio a la distancia que les toca. Con dos
   keyframes es un intercambio; con diez es el mismo espejo. Los valores no se
   tocan —siguen pegados a su keyframe— y las curvas se cambian de lado, que es
   lo que hace que la animacion invertida sea de verdad la de antes al reves.

   COPIAR E INVERTIR. Lo mismo, pero sin quitar nada: la copia se escribe a
   partir del cursor de tiempo y en orden contrario, y queda seleccionada para
   poder moverla de sitio sin volver a buscarla. Es la ida y la vuelta de un
   movimiento, que a mano son diez minutos de copiar, pegar y cuadrar a ojo.

   Las dos miran primero los keyframes seleccionados. Si no hay ninguno, toman
   todos los de las capas marcadas: quien elige una capa entera y pide invertir
   su tiempo no esta pidiendo que no pase nada.
   ------- */
function ek_reverseKeys(jsonStr) {
    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    if (!_ekSel(comp).length) return _ekBad("noSel");

    var ws = _ekKeyWorkset(comp);
    var props = ws.props, snap = ws.snap;
    if (!props.length) return _ekBad("needKeys");

    var span = _ekSelSpan(props, snap);
    if (!span || (span.hi - span.lo) <= 1e-9) return _ekBad("needTwoKeys");

    app.beginUndoGroup("EDITKIT: invertir el tiempo de los keyframes");
    try {
        var sum = span.lo + span.hi;
        var moved = 0, clipped = 0, keep = [];
        for (var i = 0; i < props.length; i++) {
            // Sin reescalar velocidades: el tramo mide lo mismo, solo se lee
            // del otro lado.
            var n = _ekRetimeProp(props[i], function (t) { return sum - t; }, 1, 0, true, snap[i], keep);
            if (n < 0) clipped++; else moved += n;
        }
        _ekReselectKeys(keep);
        if (!moved && clipped) return _ekBad("wouldGoNegative");
        if (!moved) return _ekBad("needKeys");
        return _ekGood({ keys: moved, skipped: clipped });
    } catch (e) {
        return _ekBad("hostErr", _aeErr(e));
    } finally {
        app.endUndoGroup();
    }
}

/* Escribe la copia invertida de los keyframes seleccionados de una propiedad.
   No borra nada: lo que habia se queda donde estaba. */
function _ekStampReverse(prop, hi, at, idx, keep) {
    var sk = idx || null;
    if (!sk) {
        try { sk = prop.selectedKeys; } catch (e) { return 0; }
    }
    if (!sk || !sk.length) return 0;

    var keys = [], i;
    for (i = 0; i < sk.length; i++) {
        try { keys.push(_ekReadKey(prop, sk[i])); } catch (e2) {}
    }
    if (!keys.length) return 0;

    var news = [];
    for (i = 0; i < keys.length; i++) {
        var nt = at + (hi - keys[i].t);
        if (!isFinite(nt) || nt < -1e-6) return -1;
        news.push(nt);
    }

    try { _ekWriteKeys(prop, keys, news, 1, true); } catch (e5) {}

    /* La copia es lo que queda marcado y el original se suelta — pero al
       final, no ahora: ver _ekReselectKeys. */
    if (keep) keep.push({ p: prop, t: news });
    else { try { _ekReselectKeys([{ p: prop, t: news }]); } catch (e6) {} }

    return keys.length;
}

function ek_reverseKeysCopy(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    if (!_ekSel(comp).length) return _ekBad("noSel");

    var ws = _ekKeyWorkset(comp);
    var props = ws.props, snap = ws.snap;
    if (!props.length) return _ekBad("needKeys");

    var span = _ekSelSpan(props, snap);
    if (!span) return _ekBad("needKeys");

    var at = Number(o.at);
    if (!isFinite(at)) at = comp.time;

    app.beginUndoGroup("EDITKIT: copiar los keyframes invertidos");
    try {
        var made = 0, clipped = 0, keep = [];
        for (var i = 0; i < props.length; i++) {
            var n = _ekStampReverse(props[i], span.hi, at, snap[i], keep);
            if (n < 0) clipped++; else made += n;
        }
        _ekReselectKeys(keep);
        if (!made && clipped) return _ekBad("wouldGoNegative");
        if (!made) return _ekBad("needKeys");
        return _ekGood({ keys: made, skipped: clipped, at: _ekRound(at, 4) });
    } catch (e) {
        return _ekBad("hostErr", _aeErr(e));
    } finally {
        app.endUndoGroup();
    }
}

// ------- A4 · retención, lineal o suave -------
function ek_setInterp(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { return _ekBad("badArg"); }
    var kind = String(o.kind || "");

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var props = _ekGatherSelKeys(comp, 1);
    if (!props.length) return _ekBad("needKeys");

    var names = { hold: "retención", linear: "lineal", ease: "suavizado", easeIn: "suavizar entrada", easeOut: "suavizar salida" };
    var snap = _ekSnapSel(props);

    app.beginUndoGroup("EDITKIT: " + (names[kind] || kind));
    try {
        var done = 0;
        for (var i = 0; i < props.length; i++) {
            var p = props[i];
            var sk = snap[i];
            if (!sk || !sk.length) continue;

            for (var j = 0; j < sk.length; j++) {
                var k = sk[j];
                try {
                    if (kind === "hold") {
                        // La retención de After Effects es la salida: la
                        // entrada se deja como esté para no aplanar la llegada
                        // del keyframe anterior.
                        p.setInterpolationTypeAtKey(k, p.keyInInterpolationType(k), KeyframeInterpolationType.HOLD);
                    } else if (kind === "linear") {
                        p.setInterpolationTypeAtKey(k, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
                    } else {
                        var dims = 1;
                        try { var ce = p.keyInTemporalEase(k); dims = (ce && ce.length) ? ce.length : 1; } catch (e3) { dims = 1; }

                        var soft = [], flat = [], d;
                        // 33,33 % es la influencia que aplica el propio
                        // programa con F9. Se usa la misma para que un
                        // keyframe hecho aquí y otro hecho con el atajo sean
                        // indistinguibles.
                        for (d = 0; d < dims; d++) soft.push(new KeyframeEase(0, 33.3333));
                        for (d = 0; d < dims; d++) flat.push(new KeyframeEase(0, 0.1));

                        var inT = KeyframeInterpolationType.BEZIER, outT = KeyframeInterpolationType.BEZIER;
                        p.setInterpolationTypeAtKey(k, inT, outT);

                        if (kind === "easeIn") p.setTemporalEaseAtKey(k, soft, flat);
                        else if (kind === "easeOut") p.setTemporalEaseAtKey(k, flat, soft);
                        else p.setTemporalEaseAtKey(k, soft, soft);
                    }
                    done++;
                } catch (e4) {}
            }
        }
        if (!done) return _ekBad("needKeys");
        return _ekGood({ keys: done });
    } catch (e5) {
        return _ekBad("hostErr", _aeErr(e5));
    } finally {
        app.endUndoGroup();
    }
}

// ------- A5 · convertir expresión en keyframes -------
function ek_bakeExpression(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { o = {}; }
    var range = String(o.range || "layer");

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var layers = _ekSel(comp);
    if (!layers.length) return _ekBad("noSel");

    var fps = comp.frameRate, fd = 1 / fps;

    // Reunir el trabajo antes de tocar nada: si el tramo pedido es absurdo
    // conviene decirlo antes de haber escrito la mitad.
    var jobs = [], i, j;
    for (i = 0; i < layers.length; i++) {
        var L = layers[i];
        var props = _ekExprProps(L, true);
        if (!props.length) continue;

        var t0, t1;
        if (range === "work") { t0 = comp.workAreaStart; t1 = comp.workAreaStart + comp.workAreaDuration; }
        else if (range === "comp") { t0 = 0; t1 = comp.duration; }
        else { t0 = L.inPoint; t1 = L.outPoint; }
        if (t1 <= t0) continue;

        for (j = 0; j < props.length; j++) jobs.push({ p: props[j], t0: t0, t1: t1 });
    }
    if (!jobs.length) return _ekBad("noExpr");

    var total = 0;
    for (i = 0; i < jobs.length; i++) total += Math.round((jobs[i].t1 - jobs[i].t0) * fps) + 1;
    if (total > 60000) return _ekBad("tooManyFrames", total);

    app.beginUndoGroup("EDITKIT: expresión a keyframes");
    try {
        var written = 0;
        for (i = 0; i < jobs.length; i++) {
            var p = jobs[i].p;
            var a = jobs[i].t0, b = jobs[i].t1;
            var n = Math.round((b - a) * fps);

            // Muestrear primero, escribir después. Escribir un keyframe con la
            // expresión todavía activa cambia lo que devuelve la muestra
            // siguiente, y el resultado deja de parecerse al original.
            var samples = [];
            for (j = 0; j <= n; j++) {
                var t = a + j * fd;
                if (t > b) t = b;
                var v = null;
                try { v = p.valueAtTime(t, false); } catch (eS) { v = null; }
                if (v === null) continue;
                samples.push({ t: t, v: v });
            }
            if (samples.length < 2) continue;

            try { p.expressionEnabled = false; } catch (eD) {}
            try { p.expression = ""; } catch (eD2) {}

            for (var rk = p.numKeys; rk >= 1; rk--) { try { p.removeKey(rk); } catch (eR) {} }
            for (j = 0; j < samples.length; j++) {
                try { p.setValueAtTime(samples[j].t, samples[j].v); written++; } catch (eW) {}
            }
            for (var li = 1; li <= p.numKeys; li++) {
                try { p.setInterpolationTypeAtKey(li, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR); } catch (eL) {}
            }
        }
        if (!written) return _ekBad("noExpr");
        return _ekGood({ keys: written });
    } catch (e2) {
        return _ekBad("hostErr", _aeErr(e2));
    } finally {
        app.endUndoGroup();
    }
}

// ------- A6 · saltar de keyframe en keyframe -------
function ek_gotoKey(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { o = {}; }
    var dir = String(o.dir || "next");

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var layers = _ekSel(comp);
    if (!layers.length) return _ekBad("noSel");

    /* Qué keyframes cuentan: los de las propiedades que el usuario tenga
       marcadas, y si no marcó ninguna, los de todas las de la capa. Así el
       salto sigue la intención sin obligar a abrir la propiedad. */
    var times = [], i, j, k;
    for (i = 0; i < layers.length; i++) {
        var props = _ekSelProps(layers[i]);
        if (!props.length) {
            props = _ekWalk(layers[i], function (p) {
                var n = 0;
                try { n = p.numKeys; } catch (e2) { return false; }
                return n > 0;
            });
        }
        for (j = 0; j < props.length; j++) {
            var nk = 0;
            try { nk = props[j].numKeys; } catch (e3) { nk = 0; }
            for (k = 1; k <= nk; k++) {
                var t;
                try { t = props[j].keyTime(k); } catch (e4) { continue; }
                var dup = false;
                for (var m = 0; m < times.length; m++) { if (Math.abs(times[m] - t) < 1e-6) { dup = true; break; } }
                if (!dup) times.push(t);
            }
        }
    }
    if (!times.length) return _ekBad("noKeys");
    times.sort(function (a, b) { return a - b; });

    var eps = 0.5 / comp.frameRate, now = comp.time, target = null;
    if (dir === "first") target = times[0];
    else if (dir === "last") target = times[times.length - 1];
    else if (dir === "prev") {
        for (i = times.length - 1; i >= 0; i--) { if (times[i] < now - eps) { target = times[i]; break; } }
    } else {
        for (i = 0; i < times.length; i++) { if (times[i] > now + eps) { target = times[i]; break; } }
    }
    if (target === null) return _ekBad("noMoreKeys");

    try { comp.time = target; } catch (e5) { return _ekBad("hostErr", _aeErr(e5)); }
    return _ekGood({ time: _ekRound(target, 4), frame: Math.round(target * comp.frameRate) });
}

// =============================================================
// B — CAPAS, JERARQUÍA Y COMPOSICIÓN
// =============================================================

// ------- B1 · nulo padre en el centro -------
/* DONDE NACE EL NULO

   Medir la selección es lo que decide el sitio, y medirla puede salir mal por
   media docena de motivos que no son culpa del usuario: una capa de audio, una
   de cámara, una forma vacía, una a la que `sourceRectAtTime` no le contesta.
   Antes bastaba con que una sola no se dejara medir para que la función se
   rindiera entera y no creara nada.

   Ahora hay tres intentos, de mejor a peor, y solo se rinde si fallan los
   tres — que es tanto como decir que no se rinde:

     1. el rectángulo real de lo que ocupan las capas en pantalla;
     2. si no, el promedio de sus puntos de anclaje llevados a la composición,
        que no es el centro visual pero está dentro de la selección;
     3. y si tampoco, el centro de la composición.

   Un nulo en un sitio aproximado se arrastra en dos segundos. Un nulo que no
   llega a existir no se arregla. */
function _ekNullSpot(layers, at, comp, t) {
    var i, w;

    if (at === "anchor") {
        try {
            w = _ekWorldPt(layers[0], layers[0].anchorPoint.valueAtTime(t, false), t);
            if (w) return { x: w[0], y: w[1], how: "anchor" };
        } catch (e) {}
    }

    var b = null;
    try { b = _ekWorldBounds(layers, t); } catch (e2) { b = null; }
    if (b && isFinite(b.centerX) && isFinite(b.centerY)) {
        return { x: b.centerX, y: b.centerY, how: "bounds" };
    }

    // Segundo intento: los anclajes, que existen aunque el rectángulo no.
    var sx = 0, sy = 0, n = 0;
    for (i = 0; i < layers.length; i++) {
        try {
            var ap = layers[i].anchorPoint.valueAtTime(t, false);
            w = _ekWorldPt(layers[i], ap, t);
            if (!w || !isFinite(w[0]) || !isFinite(w[1])) continue;
            sx += w[0]; sy += w[1]; n++;
        } catch (e3) {}
    }
    if (n) return { x: sx / n, y: sy / n, how: "anchors" };

    // Tercero: el centro de la composición. Siempre se puede.
    try {
        return { x: comp.width / 2, y: comp.height / 2, how: "comp" };
    } catch (e4) {}
    return null;
}

/* EL NOMBRE DEL NULO

   After Effects da un nombre al metraje solido y otro, independiente, a la
   capa que lo usa. Renombrar solo la capa permite que varias terminen con el
   mismo nombre y deja el elemento del proyecto como "Null 1".

   El siguiente numero libre se busca en los dos sitios donde el nombre debe
   ser unico: todas las capas de la composicion y todos los elementos del
   proyecto. La comparacion no distingue mayusculas para que "NULO 1" y
   "Nulo 1" cuenten como el mismo nombre. */
function _ekNullNameTaken(comp, candidate) {
    var wanted = String(candidate || "").toLowerCase();
    var i, current;

    try {
        for (i = 1; i <= comp.numLayers; i++) {
            current = String(comp.layer(i).name || "").toLowerCase();
            if (current === wanted) return true;
        }
    } catch (eLayers) {}

    try {
        if (app.project) {
            for (i = 1; i <= app.project.numItems; i++) {
                current = String(app.project.item(i).name || "").toLowerCase();
                if (current === wanted) return true;
            }
        }
    } catch (eItems) {}

    return false;
}

function _ekNextNullName(comp, base) {
    base = String(base || "NULO").replace(/^\s+|\s+$/g, "");
    if (!base) base = "NULO";

    var number = 1;
    var candidate = base + " " + number;
    while (_ekNullNameTaken(comp, candidate)) {
        number++;
        candidate = base + " " + number;
    }
    return candidate;
}

function ek_parentNull(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { o = {}; }
    var at = String(o.at || "center");

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    /* Sin nada elegido no se rinde: hace un nulo en el centro de la
       composicion y ya esta. "Nulo padre" sin capas es "dame un nulo", que es
       una peticion perfectamente razonable y el motivo por el que mucha gente
       pulsa ese boton. */
    var layers = _ekSel(comp);

    app.beginUndoGroup("EDITKIT: nulo padre");
    try {
        var t = comp.time, i;

        /* La capa más alta de la selección se guarda como OBJETO, no como
           índice. Se guardaba como número, y `addNull` mete el nulo arriba del
           todo y corre un puesto a todas las demás: el índice apuntaba ya a la
           capa de al lado, y cuando la selección estaba arriba del todo
           apuntaba al propio nulo recién creado. Una referencia no se
           descoloca. */
        var top = null, any3D = false;
        for (i = 0; i < layers.length; i++) {
            try { if (layers[i].threeDLayer) any3D = true; } catch (e2) {}
            try { if (!top || layers[i].index < top.index) top = layers[i]; } catch (e3) {}
        }

        var spot = layers.length
            ? _ekNullSpot(layers, at, comp, t)
            : { x: comp.width / 2, y: comp.height / 2, how: "comp" };
        if (!spot) return _ekBad("cantMeasure");

        /* Se decide antes de addNull porque esa llamada crea a la vez la capa
           y su fuente en el panel Proyecto. */
        var nullName = _ekNextNullName(comp, o.name);
        var nul = null;
        try { nul = comp.layers.addNull(comp.duration); } catch (eN) { nul = null; }
        if (!nul) return _ekBad("cantAddNull");

        try { nul.name = nullName; } catch (eNm) {}
        try { if (nul.source) nul.source.name = nullName; } catch (eSrcNm) {}
        try { nul.label = 9; } catch (eL) {}

        /* CUANTO DURA EL NULO

           De fabrica, toda la composicion: un nulo es un pivote y estorba tan
           poco que da igual. Con `span: true` —Control y clic— dura lo que dura
           lo que cuelga de el, de la entrada mas temprana a la salida mas
           tardia. Eso importa cuando el nulo va a viajar dentro de una
           precomposicion o cuando la linea de tiempo esta llena y una barra que
           cruza la comp entera es una barra de mas.

           El arranque se mueve con la entrada para que la fuente del nulo
           empiece donde empieza la capa: si se dejara en cero, la entrada no
           podria adelantarse mas alla de donde arranca su material. */
        var span = null;
        if (o.span) span = _ekTimeSpan(layers);
        if (span) {
            try { nul.startTime = span.lo; } catch (eS1) {}
            try { nul.inPoint = span.lo; } catch (eS2) {}
            try { nul.outPoint = span.hi; } catch (eS3) {}
        } else {
            try { nul.startTime = 0; } catch (eS) {}
        }

        /* Primero 3D y después el anclaje y la posición: al pasar a 3D esas
           dos propiedades cambian de tamaño, y escribirlas antes es escribir
           en algo que va a cambiar de forma. */
        if (any3D) { try { nul.threeDLayer = true; } catch (e3D) {} }

        // El nulo nace de 100×100 con el anclaje en la esquina. Moverlo al
        // centro es lo que hace que rote sobre sí mismo, que es para lo que
        // se crea.
        try { nul.anchorPoint.setValue(any3D ? [50, 50, 0] : [50, 50]); }
        catch (eA) { try { nul.anchorPoint.setValue([50, 50]); } catch (eA2) {} }

        try { nul.position.setValue(any3D ? [spot.x, spot.y, 0] : [spot.x, spot.y]); }
        catch (eP) { try { nul.position.setValue([spot.x, spot.y]); } catch (eP2) {} }

        // Justo encima de la más alta de la selección. Si esa resulta ser el
        // propio nulo —no puede, pero por si acaso— se queda donde está.
        try { if (top && top !== nul) nul.moveBefore(top); } catch (eM) {}

        /* Solo se emparenta lo que está suelto o colgado de fuera de la
           selección. Reasignar el padre de una capa que ya cuelga de otra
           seleccionada destruiría la jerarquía que el usuario montó, y eso no
           es lo que pidió al pulsar el botón. */
        var linked = 0, failed = 0;
        for (i = 0; i < layers.length; i++) {
            var L = layers[i], par = null;
            try { par = L.parent; } catch (e4) { par = null; }
            var parentInSel = false;
            if (par) {
                for (var j = 0; j < layers.length; j++) { if (layers[j] === par) { parentInSel = true; break; } }
            }
            if (parentInSel) continue;
            try { L.parent = nul; linked++; } catch (e5) { failed++; }
        }

        try {
            for (i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false;
            nul.selected = true;
        } catch (e6) {}

        return _ekGood({
            linked: linked, failed: failed, how: spot.how, name: nul.name,
            trimmed: !!span,
            inPoint: span ? _ekRound(span.lo, 4) : 0,
            outPoint: span ? _ekRound(span.hi, 4) : _ekRound(comp.duration, 4)
        });
    } catch (e7) {
        return _ekBad("hostErr", _aeErr(e7));
    } finally {
        app.endUndoGroup();
    }
}

// ------- B2 · desemparentar sin que se mueva -------

/* La transformación que una capa acaba teniendo en pantalla se lee sin
   álgebra: se pregunta al propio programa dónde caen tres puntos de la capa
   —el anclaje y dos a cien píxeles— y de ahí salen posición, giro y escala.
   Es exacto porque quien resuelve la cadena de padres es After Effects, no
   este archivo, y sirve igual con dos padres que con seis. */
function _ekProbe(layer, t) {
    var a = null;
    try { a = layer.anchorPoint.valueAtTime(t, false); } catch (e) { return null; }
    var ax = a[0], ay = a[1];
    var p0 = _ekWorldPt(layer, [ax, ay], t);
    var px = _ekWorldPt(layer, [ax + 100, ay], t);
    var py = _ekWorldPt(layer, [ax, ay + 100], t);
    if (!p0 || !px || !py) return null;

    var vx = [px[0] - p0[0], px[1] - p0[1]];
    var vy = [py[0] - p0[0], py[1] - p0[1]];
    var lx = Math.sqrt(vx[0] * vx[0] + vx[1] * vx[1]) / 100;
    var ly = Math.sqrt(vy[0] * vy[0] + vy[1] * vy[1]) / 100;
    var rot = Math.atan2(vx[1], vx[0]) * 180 / Math.PI;

    // El producto cruzado en negativo significa que la cadena de padres
    // incluye un volteo; se traslada al signo de la escala vertical.
    var cross = vx[0] * vy[1] - vx[1] * vy[0];
    if (cross < 0) ly = -ly;

    // Si los dos ejes dejan de ser perpendiculares hay cizalla, y una capa de
    // After Effects no sabe representarla con posición, giro y escala. Se
    // avisa en lugar de entregar algo parecido.
    var dot = vx[0] * vy[0] + vx[1] * vy[1];
    var skew = Math.abs(dot) / Math.max(1e-6, (lx * 100) * (Math.abs(ly) * 100));

    return { pos: [p0[0], p0[1]], rot: rot, scale: [lx * 100, ly * 100], skew: skew };
}

// Momentos en los que hay que medir: los keyframes de la propia capa y los de
// toda su ascendencia. Entre dos de ellos la transformación heredada no cambia
// de forma, así que muestrear ahí basta.
function _ekChainTimes(layer) {
    var times = [], seen = 0;
    var names = ["Anchor Point", "Position", "Scale", "Rotation", "X Rotation", "Y Rotation", "Z Rotation", "Orientation"];
    var L = layer;
    while (L && seen < 32) {
        for (var i = 0; i < names.length; i++) {
            var p = null;
            try { p = L.transform.property(names[i]); } catch (e) { p = null; }
            if (!p) continue;
            var nk = 0;
            try { nk = p.numKeys; } catch (e2) { nk = 0; }
            for (var k = 1; k <= nk; k++) {
                var t;
                try { t = p.keyTime(k); } catch (e3) { continue; }
                var dup = false;
                for (var m = 0; m < times.length; m++) { if (Math.abs(times[m] - t) < 1e-6) { dup = true; break; } }
                if (!dup) times.push(t);
            }
        }
        try { L = L.parent; } catch (e4) { L = null; }
        seen++;
    }
    times.sort(function (a, b) { return a - b; });
    return times;
}

/* Suelta una capa de su padre dejandola exactamente donde estaba.

   Es el nucleo que ya usaba B2 y ahora comparten los dos sitios que lo
   necesitan: desemparentar a mano, y sacar las capas de una precomposicion.
   Devuelve el aviso que corresponda —o null— en lugar de ensenarlo, porque
   quien llama sabe si vale la pena contarlo. */
function _ekFreeToWorld(layer, comp) {
    var is3D = false;
    try { is3D = !!layer.threeDLayer; } catch (e) {}
    if (is3D) {
        /* En 3D la orientacion no se deduce de dos puntos: hacen falta tres
           ejes y un orden de rotacion. Se deja el desemparentado del programa,
           que resuelve bien el caso estatico, y se avisa. */
        try { layer.parent = null; } catch (e2) {}
        return "only2D";
    }

    var times = _ekChainTimes(layer);
    var warn = null;

    if (!times.length) {
        var s = _ekProbe(layer, comp.time);
        if (!s) return null;
        if (s.skew > 0.02) warn = "skew";
        try { layer.parent = null; } catch (e3) {}
        try { layer.transform.position.setValue(s.pos); } catch (e4) {}
        try { layer.transform.rotation.setValue(s.rot); } catch (e5) {}
        try { layer.transform.scale.setValue(s.scale); } catch (e6) {}
        return warn;
    }

    // Con animacion hay que medir en cada momento en el que algo de la cadena
    // cambia, y volver a escribirlo como keyframes propios.
    var samples = [], j;
    for (j = 0; j < times.length; j++) {
        var sm = _ekProbe(layer, times[j]);
        if (!sm) continue;
        if (sm.skew > 0.02) warn = "skew";
        samples.push({ t: times[j], s: sm });
    }
    if (!samples.length) return warn;

    try { layer.parent = null; } catch (e7) {}

    var pp = layer.transform.position, rp = layer.transform.rotation, sp = layer.transform.scale;
    var rk;
    for (rk = pp.numKeys; rk >= 1; rk--) { try { pp.removeKey(rk); } catch (e8) {} }
    for (rk = rp.numKeys; rk >= 1; rk--) { try { rp.removeKey(rk); } catch (e9) {} }
    for (rk = sp.numKeys; rk >= 1; rk--) { try { sp.removeKey(rk); } catch (eA) {} }

    if (samples.length === 1) {
        try { pp.setValue(samples[0].s.pos); } catch (eB) {}
        try { rp.setValue(samples[0].s.rot); } catch (eC) {}
        try { sp.setValue(samples[0].s.scale); } catch (eD) {}
    } else {
        for (j = 0; j < samples.length; j++) {
            try { pp.setValueAtTime(samples[j].t, samples[j].s.pos); } catch (eE) {}
            try { rp.setValueAtTime(samples[j].t, samples[j].s.rot); } catch (eF) {}
            try { sp.setValueAtTime(samples[j].t, samples[j].s.scale); } catch (eG) {}
        }
        warn = warn || "resampled";
    }
    return warn;
}

/* Una capa de precomposicion "neutra" es la que no aporta transformacion: lo
   que este en (x, y) dentro se ve en (x, y) fuera. Es exactamente lo que deja
   el Pre-componer de After Effects, asi que es el caso de casi todo el mundo, y
   reconocerlo permite sacar las capas sin tocarles ni un valor.

   La cuenta es corta: la capa coloca a sus hijas en
   posicion + giro·escala·(punto - anclaje), asi que sin giro, a escala 100 y
   con la posicion justo encima del anclaje, la suma es cero. */
function _ekNeutralHost(layer) {
    function still(p) {
        var n = 0;
        try { n = p.numKeys; } catch (e) { return false; }
        if (n > 0) return false;
        var x = null;
        try { x = p.expressionEnabled; } catch (e2) { x = false; }
        return !x;
    }
    try {
        var t = layer.transform;
        var ap = t.property("Anchor Point"), po = t.property("Position");
        var sc = t.property("Scale"), ro = t.property("Rotation");
        if (!still(ap) || !still(po) || !still(sc)) return false;
        if (ro && !still(ro)) return false;

        var a = ap.value, p = po.value, s = sc.value;
        if (Math.abs(a[0] - p[0]) > 0.001 || Math.abs(a[1] - p[1]) > 0.001) return false;
        if (a.length > 2 && p.length > 2 && Math.abs(a[2] - p[2]) > 0.001) return false;
        if (Math.abs(s[0] - 100) > 0.001 || Math.abs(s[1] - 100) > 0.001) return false;
        if (s.length > 2 && Math.abs(s[2] - 100) > 0.001) return false;
        if (ro && Math.abs(ro.value) > 0.001) return false;

        // En 3D quedan las otras dos rotaciones y la orientacion.
        var is3D = false;
        try { is3D = !!layer.threeDLayer; } catch (e3) {}
        if (is3D) {
            var names = ["X Rotation", "Y Rotation", "Z Rotation", "Orientation"];
            for (var i = 0; i < names.length; i++) {
                var q = null;
                try { q = t.property(names[i]); } catch (e4) { q = null; }
                if (!q) continue;
                if (!still(q)) return false;
                var v = q.value;
                if (v instanceof Array) {
                    for (var k = 0; k < v.length; k++) { if (Math.abs(v[k]) > 0.001) return false; }
                } else if (Math.abs(v) > 0.001) return false;
            }
        }
        return true;
    } catch (e5) { return false; }
}

// Nadie seleccionado. copyToComp se comporta como un pegado: sin seleccion deja
// la copia arriba del todo, y con algo seleccionado la mete justo encima de
// eso. Deseleccionar antes de cada copia es lo que hace que se sepa donde cae.
function _ekDeselect(comp) {
    for (var i = 1; i <= comp.numLayers; i++) {
        try { comp.layer(i).selected = false; } catch (e) {}
    }
}

/* Quitar la seleccion de capa no basta en After Effects: los keyframes y las
   propiedades que se copiaron pueden seguir seleccionados por dentro. En ese
   estado, el comando Pegar ignora la nueva capa y vuelve a pegar en el origen.
   Limpiamos ambas selecciones antes de elegir cada destino. */
function _ekClearDeepSelection(comp) {
    for (var li = 1; li <= comp.numLayers; li++) {
        var layer = null, props = [];
        try { layer = comp.layer(li); } catch (e0) { layer = null; }
        if (!layer) continue;

        try { props = layer.selectedProperties || []; } catch (e1) { props = []; }
        for (var pi = 0; pi < props.length; pi++) {
            var p = props[pi], keys = [];
            try { keys = p.selectedKeys || []; } catch (e2) { keys = []; }
            for (var ki = 0; ki < keys.length; ki++) {
                try { p.setSelectedAtKey(keys[ki], false); } catch (e3) {}
            }
            try { p.selected = false; } catch (e4) {}
        }
        try { layer.selected = false; } catch (e5) {}
    }
}

// Una ruta portable desde la capa hasta una propiedad. Guardar solo el nombre
// no sirve con dos efectos iguales; guardar solo el indice no sirve si el
// destino no tiene exactamente el mismo orden. Al resolver se prueban ambos.
function _ekPropertyAddress(prop) {
    var out = [], p = prop, guard = 0;
    while (p && guard++ < 40) {
        var depth = 0, mn = "", ix = 0, ord = 1, par = null;
        try { depth = p.propertyDepth; } catch (e0) { depth = 0; }
        if (depth <= 0) break;
        try { mn = p.matchName || p.name || ""; } catch (e1) { mn = ""; }
        try { ix = p.propertyIndex || 0; } catch (e2) { ix = 0; }
        try { par = p.parentProperty; } catch (e3) { par = null; }
        if (par && mn && ix > 1) {
            ord = 0;
            for (var si = 1; si <= ix; si++) {
                var sibling = null, sm = "";
                try { sibling = par.property(si); } catch (e4) { sibling = null; }
                if (!sibling) continue;
                try { sm = sibling.matchName || sibling.name || ""; } catch (e5) { sm = ""; }
                if (sm === mn) ord++;
            }
            if (ord < 1) ord = 1;
        }
        out.unshift({ matchName: mn, index: ix, ordinal: ord });
        p = par;
    }
    return out;
}

function _ekResolvePropertyAddress(layer, address, create) {
    var cur = layer;
    for (var i = 0; i < address.length; i++) {
        var step = address[i], next = null, gotName = "", matches = [];
        if (step.index > 0) {
            try { next = cur.property(step.index); } catch (e0) { next = null; }
            if (next) {
                try { gotName = next.matchName || next.name || ""; } catch (e1) { gotName = ""; }
                if (step.matchName && gotName !== step.matchName) next = null;
            }
        }
        if (!next && step.matchName) {
            var n = 0;
            try { n = cur.numProperties || 0; } catch (e2) { n = 0; }
            for (var mi = 1; mi <= n; mi++) {
                var candidate = null, cm = "";
                try { candidate = cur.property(mi); } catch (e3) { candidate = null; }
                if (!candidate) continue;
                try { cm = candidate.matchName || candidate.name || ""; } catch (e4) { cm = ""; }
                if (cm === step.matchName) matches.push(candidate);
            }
            next = matches[(step.ordinal || 1) - 1] || null;
            while (!next && create && matches.length < (step.ordinal || 1)) {
                var can = false, made = null;
                try { can = !!cur.canAddProperty(step.matchName); } catch (e5) { can = false; }
                if (!can) break;
                try { made = cur.addProperty(step.matchName); } catch (e6) { made = null; }
                if (!made) break;
                matches.push(made);
                next = matches[(step.ordinal || 1) - 1] || null;
            }
        }
        if (!next) return null;
        cur = next;
    }
    return cur;
}

/* Animator Properties es un grupo dinamico especial: una propiedad como
   Opacity o Tracking existe en el origen porque fue añadida por el usuario,
   pero no aparece en el destino hasta llamar addProperty directamente sobre
   ese grupo. Algunas versiones de AE responden false a canAddProperty durante
   una resolución generica, aunque addProperty por matchName sí funcione. */
function _ekEnsureTextAnimatorProperty(layer, address) {
    var animatorAt = -1, propsAt = -1, i;
    for (i = 0; i < address.length; i++) {
        if (address[i].matchName === "ADBE Text Animator") animatorAt = i;
        if (address[i].matchName === "ADBE Text Animator Properties") propsAt = i;
    }
    if (animatorAt < 0 || propsAt !== animatorAt + 1 || propsAt >= address.length - 1) return null;

    var animator = _ekResolvePropertyAddress(layer, address.slice(0, animatorAt + 1), true);
    if (!animator) return null;
    // Volver a resolver tras cualquier alta de Animator: el grupo indexado
    // puede haber invalidado el objeto devuelto en la primera pasada.
    animator = _ekResolvePropertyAddress(layer, address.slice(0, animatorAt + 1), false) || animator;

    var animatorProps = null;
    try { animatorProps = animator.property("ADBE Text Animator Properties"); } catch (e0) { animatorProps = null; }
    if (!animatorProps) return null;

    var leafStep = address[address.length - 1], leaf = null, got = "";
    // No probar antes con property() ni numProperties: Animator Properties
    // publica todo su esquema (mas de cien miembros virtuales) aunque ninguno
    // se haya añadido a la linea de tiempo. addProperty es la operacion que
    // materializa la hoja; para una propiedad ya añadida AE devuelve la misma.
    try { leaf = animatorProps.addProperty(leafStep.matchName); } catch (e1) { leaf = null; }
    if (!leaf) {
        try { leaf = animatorProps.property(leafStep.matchName); } catch (e2) { leaf = null; }
    }
    if (!leaf) return null;
    try { got = leaf.matchName || ""; } catch (e3) { got = ""; }
    return (!leafStep.matchName || got === leafStep.matchName) ? leaf : null;
}

/* Resolver una hoja dinamica de Animator Properties exige enumerar los hijos
   reales. property(matchName) puede devolver un miembro virtual del esquema:
   acepta llamadas, pero no aparece en la linea de tiempo y sus valores se
   pierden. Esta prueba se usa tanto al crear como al escribir la captura. */
function _ekIsTextAnimatorLeafAddress(address) {
    var animatorAt = -1, propsAt = -1;
    for (var i = 0; i < address.length; i++) {
        if (address[i].matchName === "ADBE Text Animator") animatorAt = i;
        if (address[i].matchName === "ADBE Text Animator Properties") propsAt = i;
    }
    return animatorAt >= 0 && propsAt === animatorAt + 1 && propsAt < address.length - 1;
}

function _ekConcreteTextAnimatorProperty(layer, address, create) {
    if (!_ekIsTextAnimatorLeafAddress(address)) return null;
    if (create) return _ekEnsureTextAnimatorProperty(layer, address);
    var propsAt = -1, i;
    for (i = 0; i < address.length; i++) {
        if (address[i].matchName === "ADBE Text Animator Properties") { propsAt = i; break; }
    }
    if (propsAt < 0) return null;

    var group = _ekResolvePropertyAddress(layer, address.slice(0, propsAt + 1), !!create);
    if (!group) return null;
    var leafStep = address[address.length - 1], n = 0;
    try { n = group.numProperties || 0; } catch (e0) { n = 0; }
    for (i = 1; i <= n; i++) {
        var p = null, mn = "";
        try { p = group.property(i); mn = p ? (p.matchName || "") : ""; } catch (e1) { p = null; }
        if (p && mn === leafStep.matchName) return p;
    }
    return null;
}

function _ekPasteFitProperty(layer, address, create) {
    if (_ekIsTextAnimatorLeafAddress(address)) {
        return _ekConcreteTextAnimatorProperty(layer, address, create);
    }
    return create ? _ekEnsurePropertyAddress(layer, address) : _ekResolvePropertyAddress(layer, address, false);
}

/* Los grupos indexados de texto y efectos pueden reconstruirse al añadir un
   hijo. Una sola resolución puede crear el animador pero quedarse sin una
   referencia válida a su propiedad interna. Reintentar desde la capa hace
   que cada pasada trabaje con el árbol nuevo y estable. */
function _ekEnsurePropertyAddress(layer, address) {
    var prop = null;
    for (var attempt = 0; attempt < 4; attempt++) {
        prop = _ekResolvePropertyAddress(layer, address, false);
        if (prop) return prop;
        _ekResolvePropertyAddress(layer, address, true);
    }
    prop = _ekResolvePropertyAddress(layer, address, false);
    if (prop) return prop;
    return _ekEnsureTextAnimatorProperty(layer, address);
}

// Los grupos indexados (efectos y animadores de texto) deben pegarse sobre la
// capa. Si intentamos precrear y seleccionar sus hojas, AE reconstruye el
// grupo durante el proceso y puede duplicar propiedades en el primer miembro.
function _ekAddressNeedsLayerPaste(address) {
    for (var i = 0; i < address.length; i++) {
        var mn = String(address[i].matchName || "");
        if (mn === "ADBE Effect Parade" || mn === "ADBE Text Animators") return true;
    }
    return false;
}

function _ekClipboardPathNeedsLayerPaste(path) {
    for (var i = 0; i < path.length; i++) {
        var n = _ekClipNorm(path[i]).replace(/\s*#\d+$/, "");
        if (n === "effects" || n === "efectos" || n === "animators" || n === "animadores") return true;
    }
    return false;
}

/* El portapapeles de AE no revela que propiedad contiene, pero al copiar deja
   seleccionadas las propiedades de origen. Las fotografiamos antes de limpiar
   la seleccion y usamos esas mismas rutas en cada destino. Primero se prefieren
   propiedades con keyframes seleccionados; si AE ya solto los rombos, se usan
   las propiedades hoja que aun sigan marcadas. */
function _ekPastePropertyHints(comp) {
    var keyed = [], selected = [], seenKeyed = {}, seenSelected = {};
    for (var li = 1; li <= comp.numLayers; li++) {
        var layer = null, props = [];
        try { layer = comp.layer(li); } catch (e0) { layer = null; }
        if (!layer) continue;
        try { props = layer.selectedProperties || []; } catch (e1) { props = []; }
        for (var pi = 0; pi < props.length; pi++) {
            var p = props[pi], sk = [], canKeys = false, addr = [], id = "";
            try { sk = p.selectedKeys || []; canKeys = true; } catch (e2) { canKeys = false; }
            if (!canKeys) continue; // grupos completos se pegan sobre la capa
            addr = _ekPropertyAddress(p);
            if (!addr.length) continue;
            try { id = _ekPropPath(p); } catch (e3) { id = String(pi); }
            if (sk.length) {
                if (!seenKeyed[id]) { seenKeyed[id] = true; keyed.push(addr); }
            } else if (!seenSelected[id]) {
                seenSelected[id] = true;
                selected.push(addr);
            }
        }
    }
    return keyed.length ? keyed : selected;
}

// Rutas publicadas por After Effects en el formato de texto de su
// portapapeles. Las lineas de valores comienzan por Frame o por un numero;
// las demas lineas del cuerpo son rutas de propiedades separadas por tabs.
function _ekClipboardPropertyPaths(text) {
    text = String(text || "");
    if (text.indexOf("Adobe After Effects") < 0 || text.indexOf("Keyframe Data") < 0) return [];
    var lines = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
    var out = [], body = false;
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i], clean = _trim(line);
        if (clean === "Layer") { body = true; continue; }
        if (!body || !clean) continue;
        if (/^End of Keyframe Data/i.test(clean)) break;

        var raw = line.split("\t"), parts = [];
        for (var j = 0; j < raw.length; j++) {
            var bit = _trim(raw[j]);
            if (bit) parts.push(bit);
        }
        if (!parts.length) continue;
        if (/^Frame$/i.test(parts[0]) || /^[-+]?\d+(?:[.,]\d+)?$/.test(parts[0])) continue;
        out.push(parts);
    }
    return out;
}

function _ekClipNorm(value) {
    return _trim(String(value || "")).toLowerCase().replace(/\s+/g, " ");
}

function _ekClipboardAlias(token, parent) {
    var n = _ekClipNorm(token).replace(/\s*#\d+$/, "");
    var pm = "";
    try { pm = parent.matchName || ""; } catch (e0) { pm = ""; }

    if (n === "transform" || n === "transformar") return "ADBE Transform Group";
    if (n === "effects" || n === "efectos") return "ADBE Effect Parade";
    if (n === "text" || n === "texto") return "ADBE Text Properties";
    if (n === "animators" || n === "animadores") return "ADBE Text Animators";
    if (n === "animator" || n === "animador") return "ADBE Text Animator";
    if (n === "selectors" || n === "selectores") return "ADBE Text Selectors";
    if (n === "range selector" || n === "selector de rango") return "ADBE Text Selector";
    if (n === "properties" || n === "propiedades") return "ADBE Text Animator Properties";
    if (n === "source text" || n === "texto de origen") return "ADBE Text Document";

    if (pm === "ADBE Transform Group") {
        if (n === "anchor point" || n === "punto de anclaje") return "ADBE Anchor Point";
        if (n === "position" || n === "posicion" || n === "posición") return "ADBE Position";
        if (n === "scale" || n === "escala") return "ADBE Scale";
        if (n === "rotation" || n === "rotacion" || n === "rotación") return "ADBE Rotate Z";
        if (n === "opacity" || n === "opacidad") return "ADBE Opacity";
        if (n === "orientation" || n === "orientacion" || n === "orientación") return "ADBE Orientation";
        if (n === "x rotation" || n === "rotacion x" || n === "rotación x") return "ADBE Rotate X";
        if (n === "y rotation" || n === "rotacion y" || n === "rotación y") return "ADBE Rotate Y";
        if (n === "z rotation" || n === "rotacion z" || n === "rotación z") return "ADBE Rotate Z";
    }
    if (pm === "ADBE Text Selector") {
        if (n === "start" || n === "inicio") return "ADBE Text Percent Start";
        if (n === "end" || n === "fin") return "ADBE Text Percent End";
        if (n === "offset" || n === "desplazamiento") return "ADBE Text Percent Offset";
    }
    if (pm === "ADBE Text Animator Properties") {
        if (n === "tracking amount" || n === "cantidad de tracking") return "ADBE Text Tracking Amount";
        if (n === "anchor point" || n === "punto de anclaje") return "ADBE Text Anchor Point 3D";
        if (n === "position" || n === "posicion" || n === "posición") return "ADBE Text Position 3D";
        if (n === "scale" || n === "escala") return "ADBE Text Scale 3D";
        if (n === "rotation" || n === "rotacion" || n === "rotación") return "ADBE Text Rotation";
        if (n === "opacity" || n === "opacidad") return "ADBE Text Opacity";
    }
    return "";
}

function _ekClipboardChild(parent, token, create) {
    var direct = null, alias = _ekClipboardAlias(token, parent), ordinal = 0;
    var om = String(token || "").match(/#(\d+)\s*$/);
    if (om) ordinal = parseInt(om[1], 10) || 0;

    try { direct = parent.property(token); } catch (e0) { direct = null; }
    if (direct && !ordinal) return direct;

    var base = _ekClipNorm(token).replace(/\s*#\d+$/, "");
    var matches = [], count = 0;
    try { count = parent.numProperties || 0; } catch (e1) { count = 0; }
    for (var i = 1; i <= count; i++) {
        var p = null, name = "", mn = "", candidate = "";
        try { p = parent.property(i); } catch (e2) { p = null; }
        if (!p) continue;
        try { name = p.name || ""; mn = p.matchName || ""; } catch (e3) {}
        candidate = _ekClipNorm(name);
        if (ordinal) candidate = candidate.replace(/\s*#?\d+$/, "");
        if ((alias && mn === alias) || candidate === base || _ekClipNorm(mn) === base) matches.push(p);
    }
    if (matches.length) return matches[(ordinal > 0 ? ordinal - 1 : 0)] || matches[0];

    if (!create) return null;
    var addName = alias || String(token || "").replace(/\s*#\d+$/, "");
    if (!addName) return null;
    var wanted = ordinal > 0 ? ordinal : 1;
    while (matches.length < wanted) {
        var can = false, made = null;
        try { can = !!parent.canAddProperty(addName); } catch (e4) { can = false; }
        if (!can) break;
        try { made = parent.addProperty(addName); } catch (e5) { made = null; }
        if (!made) break;
        matches.push(made);
    }
    return matches[wanted - 1] || matches[0] || null;
}

function _ekResolveClipboardPath(layer, path, create) {
    var cur = layer;
    for (var i = 0; i < path.length; i++) {
        cur = _ekClipboardChild(cur, path[i], create);
        if (!cur) return null;
    }
    return cur;
}

var _ekPasteFitCapture = null;

/* Captura fiable cuando CEP no puede leer el texto del portapapeles. Se hace
   con el propio comando Copiar de AE y se guardan, aparte, las rutas internas
   de las propiedades. No se serializan valores ni curvas: el portapapeles
   nativo conserva toda la interpolacion, tangentes y datos espaciales. */
function _ekPasteFitSelection(comp) {
    var layers = _ekSel(comp), addresses = [], groups = 0, count = 0, seen = {};
    for (var li = 0; li < layers.length; li++) {
        var props = [];
        try { props = layers[li].selectedProperties || []; } catch (e0) { props = []; }
        for (var pi = 0; pi < props.length; pi++) {
            var p = props[pi], keys = [], leaf = false, addr = [], id = "";
            try { keys = p.selectedKeys || []; leaf = true; } catch (e1) { leaf = false; }
            if (leaf) {
                addr = _ekPropertyAddress(p);
                if (!addr.length) continue;
                try { id = _ekPropPath(p); } catch (e2) { id = String(li) + ":" + String(pi); }
                if (!seen[id]) { seen[id] = true; addresses.push(addr); count++; }
            } else if (!leaf) {
                groups++;
            }
        }
    }
    return { addresses: addresses, groups: groups, count: count + groups };
}

function _ekEffectCount(layer) {
    var parade = null, n = 0;
    try { parade = layer.property("ADBE Effect Parade"); } catch (e0) { parade = null; }
    if (!parade) return 0;
    try { n = parade.numProperties || 0; } catch (e1) { n = 0; }
    return n;
}

// Y su pareja: dejar marcadas exactamente esas capas y ninguna mas. Lo que se
// toma prestado se devuelve.
function _ekReselect(comp, layers) {
    _ekDeselect(comp);
    for (var i = 0; i < layers.length; i++) {
        try { layers[i].selected = true; } catch (e) {}
    }
}

function ek_unparentKeep(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var layers = _ekSel(comp);
    if (!layers.length) return _ekBad("noSel");

    var work = [], i;
    for (i = 0; i < layers.length; i++) {
        var par = null;
        try { par = layers[i].parent; } catch (e2) { par = null; }
        if (par) work.push(layers[i]);
    }
    if (!work.length) return _ekBad("noParent");

    app.beginUndoGroup("EDITKIT: desemparentar");
    try {
        var done = 0, warn = null;
        for (i = 0; i < work.length; i++) {
            // El trabajo de verdad esta en _ekFreeToWorld, que comparte con
            // sacar una precomposicion: las dos cosas son lo mismo —despegar
            // una capa de su padre sin que se mueva— y tenerlo escrito dos
            // veces era pedir que una de las dos se quedara atras.
            var w = _ekFreeToWorld(work[i], comp);
            if (w && !warn) warn = w;
            done++;
        }
        if (!done) return _ekBad("noParent");
        return _ekGood({ layers: done, warn: warn });
    } catch (eZ) {
        return _ekBad("hostErr", _aeErr(eZ));
    } finally {
        app.endUndoGroup();
    }
}

// ------- B3 · ajustar la composición al contenido -------
function ek_compToContent(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { o = {}; }
    var margin = Number(o.margin);
    if (!isFinite(margin) || margin < 0) margin = 0;

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");

    // Con selección se recorta a lo seleccionado; sin ella, a todo lo que se
    // vea. Es la lectura natural del gesto y evita tener que explicarlo.
    var pool = _ekSel(comp), i;
    if (!pool.length) {
        pool = [];
        for (i = 1; i <= comp.numLayers; i++) {
            var L = comp.layer(i);
            var on = true;
            try { on = !!L.enabled; } catch (e2) { on = true; }
            if (on) pool.push(L);
        }
    }
    if (!pool.length) return _ekBad("noLayers");

    var t = comp.time;
    var b = _ekWorldBounds(pool, t);
    if (!b || !isFinite(b.width) || !isFinite(b.height)) return _ekBad("cantMeasure");

    var newW = Math.round(b.width + margin * 2);
    var newH = Math.round(b.height + margin * 2);
    if (newW < 4) newW = 4;
    if (newH < 4) newH = 4;
    if (newW > 30000 || newH > 30000) return _ekBad("tooBig");

    var dx = Math.round(b.left - margin);
    var dy = Math.round(b.top - margin);

    app.beginUndoGroup("EDITKIT: comp al contenido");
    try {
        var moved = 0;
        for (i = 1; i <= comp.numLayers; i++) {
            var Ly = comp.layer(i);

            // Solo se mueve lo que cuelga de nada: las capas con padre siguen
            // al suyo, y desplazarlas también las movería el doble.
            var par = null;
            try { par = Ly.parent; } catch (e3) { par = null; }
            if (par) continue;

            var pp = null;
            try { pp = Ly.transform.property("Position"); } catch (e4) { pp = null; }
            if (!pp) continue;

            var expr = "";
            try { expr = pp.expressionEnabled ? (pp.expression || "") : ""; } catch (e5) { expr = ""; }
            if (_trim(expr) !== "") continue;   // con expresión no se toca: la escribió el usuario

            var sep = false;
            try { sep = !!pp.dimensionsSeparated; } catch (e6) { sep = false; }
            if (sep) {
                var px = Ly.transform.property("X Position"), py = Ly.transform.property("Y Position");
                _ekOffsetScalar(px, -dx);
                _ekOffsetScalar(py, -dy);
                moved++;
                continue;
            }

            if (pp.numKeys > 0) {
                for (var k = 1; k <= pp.numKeys; k++) {
                    var v = pp.keyValue(k), nv = v.slice();
                    nv[0] = v[0] - dx; nv[1] = v[1] - dy;
                    try { pp.setValueAtKey(k, nv); } catch (e7) {}
                }
            } else {
                var v2 = pp.value, nv2 = v2.slice();
                nv2[0] = v2[0] - dx; nv2[1] = v2[1] - dy;
                try { pp.setValue(nv2); } catch (e8) {}
            }
            moved++;
        }

        comp.width = newW;
        comp.height = newH;

        return _ekGood({ width: newW, height: newH, layers: moved });
    } catch (e9) {
        return _ekBad("hostErr", _aeErr(e9));
    } finally {
        app.endUndoGroup();
    }
}

function _ekOffsetScalar(prop, d) {
    if (!prop) return;
    try {
        if (prop.numKeys > 0) {
            for (var k = 1; k <= prop.numKeys; k++) prop.setValueAtKey(k, prop.keyValue(k) + d);
        } else {
            prop.setValue(prop.value + d);
        }
    } catch (e) {}
}

// ------- B4 · sacar un precomp a la composición padre -------

/* La mas delicada de la lista, y la unica que puede estropear el proyecto de
   alguien.

   Deshace un Pre-componer: devuelve las capas a la composicion que contiene la
   precomposicion, en su orden, con sus tiempos, y quita la capa que las tenia
   dentro.

   La transformacion se resuelve por dos caminos segun lo que haga esa capa:

     · No aporta nada —posicion encima del anclaje, escala 100, sin giro y sin
       animacion, que es justo lo que deja el Pre-componer de After Effects—:
       las copias salen tal cual, sin tocarles un solo valor. Es el caso de casi
       todo el mundo y el unico exacto por definicion.

     · Aporta algo: las copias se cuelgan de ella, que reproduce su
       transformacion con exactitud —animacion incluida—, y despues se mide
       donde acaba cada una en pantalla y se le escribe eso como valores
       propios. Asi la capa se puede quitar sin que nada se mueva.

   Lo que ninguno de los dos sabe reproducir —efectos, mascaras, modo de fusion,
   opacidad, remapeo de tiempo, estiramiento— se comprueba antes y detiene la
   operacion, salvo que el panel confirme que se asume la perdida. */
function ek_extractPrecomp(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var layers = _ekSel(comp);
    if (layers.length !== 1) return _ekBad("needOnePrecomp");

    var host = layers[0], src = null;
    try { src = host.source; } catch (e2) { src = null; }
    if (!src || !(src instanceof CompItem)) return _ekBad("notPrecomp");
    if (src === comp) return _ekBad("notPrecomp");
    if (src.numLayers < 1) return _ekBad("emptyPrecomp");

    // Lo que este camino no sabe reproducir.
    var issues = [];
    try { if (host.timeRemapEnabled) issues.push("timeRemap"); } catch (e3) {}
    try { if (Math.abs(host.stretch - 100) > 0.001) issues.push("stretch"); } catch (e4) {}
    try { if (host.effect && host.effect.numProperties > 0) issues.push("effects"); } catch (e5) {}
    try { if (host.mask && host.mask.numProperties > 0) issues.push("masks"); } catch (e6) {}
    try { if (host.blendingMode !== BlendingMode.NORMAL) issues.push("blend"); } catch (e7) {}
    try { if (host.trackMatteType && host.trackMatteType !== TrackMatteType.NO_TRACK_MATTE) issues.push("matte"); } catch (e8) {}
    try { if (host.collapseTransformation) issues.push("collapse"); } catch (e9) {}
    try {
        var op = host.transform.property("Opacity");
        if (op.numKeys > 0 || Math.abs(op.value - 100) > 0.001) issues.push("opacity");
    } catch (eA) {}
    try { if (Math.abs(src.frameRate - comp.frameRate) > 0.001) issues.push("fps"); } catch (eB) {}

    /* Si la capa aporta transformacion hay que hornearla en cada capa que sale,
       y eso a una capa 3D no se le puede hacer con exactitud: la orientacion no
       sale de medir dos puntos. Se avisa antes en lugar de dejarlo torcido. */
    var neutral = _ekNeutralHost(host);
    if (!neutral) {
        for (var q = 1; q <= src.numLayers; q++) {
            var is3 = false;
            try { is3 = !!src.layer(q).threeDLayer; } catch (eC) {}
            if (is3) { issues.push("threeD"); break; }
        }
    }

    if (issues.length && !o.force) return _ekJ({ ok: false, code: "precompRisky", issues: issues });

    var anchor = null;
    try {
        var ap = host.transform.property("Anchor Point");
        if (ap.numKeys > 0) return _ekBad("anchorAnimated");
        anchor = ap.value;
    } catch (eD) { return _ekBad("cantMeasure"); }

    app.beginUndoGroup("EDITKIT: sacar precomposición");
    try {
        var offset = host.startTime;
        var lo = host.inPoint, hi = host.outPoint;
        var n = src.numLayers;
        var i, j;

        /* 1. Las copias.

           De abajo arriba y deseleccionando antes de cada una, para que
           copyToComp deje cada copia arriba del todo y comp.layer(1) sea
           siempre la recien llegada. Este era el fallo de antes: con la capa de
           precomposicion seleccionada, las copias caian JUSTO ENCIMA DE ELLA y
           no arriba, asi que comp.layer(1) devolvia una capa que no era la que
           se acababa de copiar. Todo lo que venia despues —el orden, los
           tiempos, el emparentado— se le aplicaba a la capa equivocada, y el
           resultado salia con los nombres al reves de sus barras. */
        var made = [];
        for (i = 0; i < n; i++) made.push(null);

        var ok = 0;
        for (i = n; i >= 1; i--) {
            _ekDeselect(comp);
            var was = comp.numLayers;
            try { src.layer(i).copyToComp(comp); } catch (eE) { continue; }
            if (comp.numLayers !== was + 1) continue;
            made[i - 1] = comp.layer(1);
            ok++;
        }
        if (!ok) return _ekBad("hostErr", "copyToComp");

        /* 2. El orden, escrito a mano y no confiado a como caigan las copias.

           moveBefore deja la capa justo encima de la otra, asi que recorriendo
           las copias de arriba abajo y mandandolas todas encima de la capa de
           precomposicion, quedan en su orden y en el sitio que ocupaba ella.
           Las que estuvieran por encima o por debajo en la composicion no se
           mueven: es lo que faltaba para que sacar un precomp no reordenara el
           resto del proyecto. */
        for (i = 0; i < n; i++) {
            if (made[i]) { try { made[i].moveBefore(host); } catch (eF) {} }
        }

        // De hijo original a copia, para rehacer las jerarquias internas.
        function copyOf(srcLayer) {
            for (var m = 1; m <= n; m++) {
                if (src.layer(m) === srcLayer) return made[m - 1];
            }
            return null;
        }

        /* 3. Emparentado y tiempos.

           Las que colgaban de otra de dentro siguen colgando de su copia: esa
           relacion es del usuario y no tiene por que perderse. Las que no
           colgaban de nadie son las que hay que despegar de la precomposicion,
           y solo ellas. */
        var roots = [];
        for (i = 0; i < n; i++) {
            var nw = made[i];
            if (!nw) continue;
            var og = src.layer(i + 1);

            var ogParent = null;
            try { ogParent = og.parent; } catch (eG) { ogParent = null; }
            var mapped = ogParent ? copyOf(ogParent) : null;

            if (mapped) {
                /* setParentWithJump y no `parent =`: al asignar el padre de la
                   forma normal, After Effects recalcula la transformacion para
                   que la capa no se mueva, y eso es justo lo contrario de lo
                   que hace falta aqui. Los valores copiados ya estan escritos
                   en el sistema de coordenadas de la precomposicion; lo que se
                   quiere es que pasen a leerse en el espacio del padre sin
                   tocarlos. */
                try { nw.setParentWithJump(mapped); } catch (eH) {}
            } else if (!neutral) {
                /* La capa aporta transformacion. Se cuelga de ella —que la
                   reproduce exacta, animacion incluida— y mas abajo se hornea y
                   se suelta. Antes hay que corregir el origen: dentro de la
                   precomposicion las coordenadas salen de su esquina superior
                   izquierda, y en el espacio del padre salen de su anclaje. */
                _ekShiftPosition(nw, -anchor[0], -anchor[1]);
                try { nw.setParentWithJump(host); } catch (eI) {}
                roots.push(nw);
            }
            /* Y si la capa es neutra no hay nada que hacer: lo que estaba en
               (x, y) dentro se ve en (x, y) fuera, que es justo lo que deja el
               Pre-componer de After Effects. Ni se cuelga ni se hornea. */

            try { nw.startTime = og.startTime + offset; } catch (eJ) {}
            try {
                var ip = og.inPoint + offset, op2 = og.outPoint + offset;
                if (ip < lo) ip = lo;
                if (op2 > hi) op2 = hi;
                if (op2 > ip) { nw.inPoint = ip; nw.outPoint = op2; }
            } catch (eK) {}
        }

        /* 4. Hornear y soltar.

           Antes la capa de precomposicion se quedaba apagada haciendo de padre:
           era exacto y se deshacia solo, pero dejaba en la composicion una capa
           que el usuario no habia pedido y que no entendia por que seguia ahi.
           Ahora se mide donde acaba cada capa suelta en pantalla y se le
           escribe eso como valores propios, y la capa se va. */
        var warn = null;
        for (i = 0; i < roots.length; i++) {
            var w = _ekFreeToWorld(roots[i], comp);
            if (w && !warn) warn = w;
        }

        try { host.remove(); } catch (eL) {}

        /* Si esa composicion ya no se usa en ningun sitio, se dice. No se borra
           del proyecto: puede que el usuario la quiera para otra cosa, y una
           composicion que desaparece sola del panel de proyecto es de las cosas
           que asustan. */
        var orphan = false;
        try { orphan = (src.usedIn.length === 0); } catch (eM) { orphan = false; }

        return _ekGood({ layers: ok, issues: issues, warn: warn, orphan: orphan, name: src.name });
    } catch (eZ) {
        return _ekBad("hostErr", _aeErr(eZ));
    } finally {
        app.endUndoGroup();
    }
}

// Desplaza la posición de una capa, con o sin keyframes, y con las
// dimensiones separadas o juntas.
function _ekShiftPosition(layer, dx, dy) {
    var pp = null;
    try { pp = layer.transform.property("Position"); } catch (e) { return; }
    if (!pp) return;
    var sep = false;
    try { sep = !!pp.dimensionsSeparated; } catch (e2) {}
    if (sep) {
        _ekOffsetScalar(layer.transform.property("X Position"), dx);
        _ekOffsetScalar(layer.transform.property("Y Position"), dy);
        return;
    }
    try {
        if (pp.numKeys > 0) {
            for (var k = 1; k <= pp.numKeys; k++) {
                var v = pp.keyValue(k), nv = v.slice();
                nv[0] = v[0] + dx; nv[1] = v[1] + dy;
                pp.setValueAtKey(k, nv);
            }
        } else {
            var v2 = pp.value, nv2 = v2.slice();
            nv2[0] = v2[0] + dx; nv2[1] = v2[1] + dy;
            pp.setValue(nv2);
        }
    } catch (e3) {}
}

// =============================================================
// C — EXPRESIONES EN UN CLIC
//
// Todas se escriben con los parámetros arriba y en una línea propia, para que
// quien abra la propiedad pueda cambiar un número sin leer el resto. Es la
// diferencia entre dejar una herramienta y dejar una caja negra.
// =============================================================

function _ekEsc(s) { return String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"'); }

// Vector literal del tamaño que pida la propiedad: [0, 0] o [0, 0, 0].
function _ekZeroVec(n) {
    var a = [];
    for (var i = 0; i < n; i++) a.push("0");
    return n <= 1 ? "0" : "[" + a.join(", ") + "]";
}

function _ekExprText(kind, o, dims, layerName) {
    var L = [];
    if (kind === "wiggle") {
        var freq = Number(o.freq); if (!isFinite(freq)) freq = 3;
        var amp = Number(o.amp); if (!isFinite(amp)) amp = 30;
        L.push("// EditKit · Vibración");
        L.push("freq = " + freq + ";   // veces por segundo");
        L.push("amp  = " + amp + ";   // cuánto se aparta");
        L.push("seedRandom(index, true);");
        L.push("w = wiggle(freq, amp);");
        if (dims >= 2 && o.axis === "x") L.push(dims === 3 ? "[w[0], value[1], value[2]]" : "[w[0], value[1]]");
        else if (dims >= 2 && o.axis === "y") L.push(dims === 3 ? "[value[0], w[1], value[2]]" : "[value[0], w[1]]");
        else L.push("w");
        return L.join("\n");
    }
    if (kind === "loop") {
        var mode = String(o.mode || "cycle");
        var fn = (o.dir === "in") ? "loopIn" : "loopOut";
        L.push("// EditKit · Bucle");
        L.push('modo = "' + mode + '";   // cycle · pingpong · offset · continue');
        L.push("ciclos = " + (Number(o.cycles) || 0) + ";   // 0 = todos los keyframes");
        L.push(fn + "(modo, ciclos)");
        return L.join("\n");
    }
    if (kind === "inertia") {
        var amp2 = Number(o.amp); if (!isFinite(amp2)) amp2 = 0.08;
        var f2 = Number(o.freq); if (!isFinite(f2)) f2 = 2.5;
        var dec = Number(o.decay); if (!isFinite(dec)) dec = 6;
        L.push("// EditKit · Inercia después del último keyframe");
        L.push("amp   = " + amp2 + ";   // cuánto se pasa de largo");
        L.push("freq  = " + f2 + ";   // rebotes por segundo");
        L.push("decay = " + dec + ";   // cuánto tarda en pararse");
        L.push("n = 0;");
        L.push("if (numKeys > 0) { n = nearestKey(time).index; if (key(n).time > time) n--; }");
        L.push("if (n == 0) { value } else {");
        L.push("  t = time - key(n).time;");
        L.push("  v = velocityAtTime(key(n).time - thisComp.frameDuration / 10);");
        L.push("  value + v * amp * Math.sin(freq * t * 2 * Math.PI) / Math.exp(decay * t);");
        L.push("}");
        return L.join("\n");
    }
    if (kind === "autofade") {
        var fi = Number(o.fadeIn); if (!isFinite(fi) || fi < 0) fi = 0.5;
        var fo = Number(o.fadeOut); if (!isFinite(fo) || fo < 0) fo = 0.5;
        L.push("// EditKit · Entrada y salida automáticas");
        L.push("entrada = " + fi + ";   // segundos");
        L.push("salida  = " + fo + ";   // segundos");
        L.push("a = entrada > 0 ? linear(time, inPoint, inPoint + entrada, 0, value) : value;");
        L.push("b = salida  > 0 ? linear(time, outPoint - salida, outPoint, value, 0) : value;");
        L.push("Math.min(a, b)");
        return L.join("\n");
    }
    if (kind === "follow") {
        L.push("// EditKit · Seguir a otra capa");
        L.push("desfase = " + _ekZeroVec(dims) + ";");
        L.push('objetivo = thisComp.layer("' + _ekEsc(layerName) + '");');
        L.push("p = objetivo.toComp(objetivo.anchorPoint);");
        L.push("if (hasParent) p = parent.fromComp(p);");
        L.push("p + desfase");
        return L.join("\n");
    }
    return "";
}

/* Sobre qué propiedades se escribe: las que el usuario tenga marcadas en la
   línea de tiempo, y si no marcó ninguna, la que la expresión da por supuesta.
   Marcar una propiedad es más barato que elegirla en un desplegable, y deja
   la decisión donde ya está mirando. */
function _ekExprTargets(layer, fallbackName, forced) {
    /* Con `forced` no se mira lo que el usuario tenga marcado. Hay dos
       expresiones que solo tienen sentido en una propiedad concreta: seguir a
       otra capa devuelve un punto y la entrada automatica devuelve un
       porcentaje, y escribirlas en Escala porque estaba abierta no seria
       respetar la seleccion, seria romper la capa. */
    var p = null;
    if (forced) {
        try { p = layer.transform.property(fallbackName); } catch (e0) { p = null; }
        return p ? [p] : [];
    }
    var sel = _ekSelProps(layer), out = [], i;
    for (i = 0; i < sel.length; i++) {
        var can = false;
        try { can = !!sel[i].canSetExpression; } catch (e) { can = false; }
        if (can) out.push(sel[i]);
    }
    if (out.length) return out;
    try { p = layer.transform.property(fallbackName); } catch (e2) { p = null; }
    return p ? [p] : [];
}

function ek_expression(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { return _ekBad("badArg"); }
    var kind = String(o.kind || "");

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var layers = _ekSel(comp);
    if (!layers.length) return _ekBad("noSel");

    var titles = {
        wiggle: "vibración", loop: "bucle", inertia: "inercia",
        autofade: "entrada y salida", seed: "desincronizar", follow: "seguir capa"
    };

    // Seguir a otra capa necesita a quién seguir: la primera seleccionada es
    // la referencia, igual que en igualar tamaño.
    var refName = null, followers = layers;
    if (kind === "follow") {
        if (layers.length < 2) return _ekBad("needTwoLayers");
        refName = layers[0].name;
        followers = [];
        for (var f = 1; f < layers.length; f++) followers.push(layers[f]);
    }

    app.beginUndoGroup("EDITKIT: " + (titles[kind] || kind));
    try {
        var done = 0, i, j;

        if (kind === "seed") {
            /* Desincronizar no escribe una expresión nueva: le pone una línea
               delante a la que ya hay. Sin expresión previa no hay nada que
               desincronizar, y decirlo es más útil que dejar un value suelto. */
            for (i = 0; i < layers.length; i++) {
                var props = _ekExprProps(layers[i], true);
                for (j = 0; j < props.length; j++) {
                    var cur = "";
                    try { cur = props[j].expression || ""; } catch (e2) { cur = ""; }
                    if (cur.indexOf("seedRandom(") >= 0) continue;
                    try {
                        props[j].expression = "seedRandom(index, true);   // EditKit · desincronizado\n" + cur;
                        done++;
                    } catch (e3) {}
                }
            }
            if (!done) return _ekBad("noExpr");
            return _ekGood({ props: done });
        }

        var fallback = (kind === "autofade") ? "Opacity" : "Position";
        var forced = (kind === "autofade" || kind === "follow");
        for (i = 0; i < followers.length; i++) {
            var targets = _ekExprTargets(followers[i], fallback, forced);

            for (j = 0; j < targets.length; j++) {
                var p = targets[j];
                var txt = _ekExprText(kind, o, _ekDims(p), refName);
                if (!txt) continue;
                try {
                    p.expression = txt;
                    p.expressionEnabled = true;
                    done++;
                } catch (e4) {}
            }
        }
        if (!done) return _ekBad("noWritableProp");
        return _ekGood({ props: done });
    } catch (e5) {
        return _ekBad("hostErr", _aeErr(e5));
    } finally {
        app.endUndoGroup();
    }
}

// Quitar la expresión de lo seleccionado — el par de cualquier botón que la ponga.
function ek_clearExpression() {
    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var layers = _ekSel(comp);
    if (!layers.length) return _ekBad("noSel");

    app.beginUndoGroup("EDITKIT: quitar expresión");
    try {
        var done = 0;
        for (var i = 0; i < layers.length; i++) {
            var sel = _ekSelProps(layers[i]);
            var props = sel.length ? sel : _ekExprProps(layers[i], true);
            for (var j = 0; j < props.length; j++) {
                var ex = "";
                try { ex = props[j].expression || ""; } catch (e) { ex = ""; }
                if (_trim(ex) === "") continue;
                try { props[j].expression = ""; done++; } catch (e2) {}
            }
        }
        if (!done) return _ekBad("noExpr");
        return _ekGood({ props: done });
    } catch (e3) {
        return _ekBad("hostErr", _aeErr(e3));
    } finally {
        app.endUndoGroup();
    }
}

// =============================================================
// D — FORMAS Y TEXTO
// =============================================================

// ------- D1 · extremos y uniones de trazo -------
function ek_strokeStyle(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { return _ekBad("badArg"); }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var layers = _ekSel(comp);
    if (!layers.length) return _ekBad("noSel");

    var cap = Number(o.cap), join = Number(o.join);
    var miter = Number(o.miter);

    app.beginUndoGroup("EDITKIT: trazo");
    try {
        var touched = 0;

        // Los trazos viven a cualquier profundidad dentro de Contenido, así
        // que se busca por matchName y no por posición.
        function walkVec(g) {
            var n = 0;
            try { n = g.numProperties; } catch (e2) { return; }
            for (var i = 1; i <= n; i++) {
                var p = null;
                try { p = g.property(i); } catch (e3) { continue; }
                if (!p) continue;
                var mn = "";
                try { mn = p.matchName || ""; } catch (e4) { mn = ""; }

                if (mn === "ADBE Vector Graphic - Stroke") {
                    if (isFinite(cap) && cap > 0) { try { p.property("ADBE Vector Stroke Line Cap").setValue(cap); } catch (e5) {} }
                    if (isFinite(join) && join > 0) { try { p.property("ADBE Vector Stroke Line Join").setValue(join); } catch (e6) {} }
                    if (isFinite(miter) && miter > 0) { try { p.property("ADBE Vector Stroke Miter Limit").setValue(miter); } catch (e7) {} }
                    touched++;
                    continue;
                }
                var isGroup = false;
                try { isGroup = (p.propertyType !== PropertyType.PROPERTY); } catch (e8) { isGroup = false; }
                if (isGroup) walkVec(p);
            }
        }

        for (var k = 0; k < layers.length; k++) {
            var root = null;
            try { root = layers[k].property("ADBE Root Vectors Group"); } catch (e9) { root = null; }
            if (root) walkVec(root);
        }

        if (!touched) return _ekBad("noStrokes");
        return _ekGood({ strokes: touched });
    } catch (eA) {
        return _ekBad("hostErr", _aeErr(eA));
    } finally {
        app.endUndoGroup();
    }
}

// ------- D2 · separar texto en capas -------

/* Medir texto desde un script solo se puede de una forma: escribirlo en una
   capa y preguntar por su rectángulo. sourceRectAtTime descarta los espacios
   del final, así que se mide con un carácter centinela pegado y se le resta
   su propio ancho. No es exacto al píxel con fuentes muy ligadas, pero deja
   las partes donde estaban en lugar de amontonarlas en el origen. */
function _ekTextWidth(probe, str, t) {
    if (str === "") return 0;
    var d = probe.sourceText.value;
    d.text = str + "|";
    probe.sourceText.setValue(d);
    var w1 = probe.sourceRectAtTime(t, false).width;
    d = probe.sourceText.value;
    d.text = "|";
    probe.sourceText.setValue(d);
    var w0 = probe.sourceRectAtTime(t, false).width;
    return w1 - w0;
}

/* Un texto con keyframes o expresion no admite setValue. Como la regla y las
   piezas son copias de trabajo, se les quita: lo que interesa de ellas es el
   estilo, no la animacion del original, que se queda en la capa apagada. */
function _ekFreeText(layer) {
    try {
        var st = layer.sourceText;
        try { st.expression = ""; } catch (e) {}
        for (var k = st.numKeys; k >= 1; k--) { try { st.removeKey(k); } catch (e2) {} }
    } catch (e3) {}
}

function _ekSplitWords(line) {
    var out = [], cur = "";
    for (var i = 0; i < line.length; i++) {
        var ch = line.charAt(i);
        if (ch === " " || ch === "\t") {
            if (cur !== "") { out.push(cur); cur = ""; }
        } else cur += ch;
    }
    if (cur !== "") out.push(cur);
    return out;
}

function ek_splitText(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { o = {}; }
    var mode = String(o.mode || "char");

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var layers = _ekSel(comp), i, j;
    if (!layers.length) return _ekBad("noSel");

    var texts = [];
    for (i = 0; i < layers.length; i++) {
        var isText = false;
        try { isText = (layers[i] instanceof TextLayer); } catch (e2) { isText = false; }
        if (isText) texts.push(layers[i]);
    }
    if (!texts.length) return _ekBad("noTextLayer");

    app.beginUndoGroup("EDITKIT: separar texto");
    try {
        var t = comp.time, made = 0;

        for (i = 0; i < texts.length; i++) {
            var src = texts[i];
            var doc = src.sourceText.valueAtTime(t, false);
            var full = String(doc.text);
            if (_trim(full) === "") continue;

            var just = 0;
            try { just = doc.justification; } catch (e3) { just = 0; }

            var leading = 0;
            try { leading = doc.autoLeading ? (doc.fontSize * 1.2) : doc.leading; } catch (e4) { leading = 0; }
            if (!isFinite(leading) || leading <= 0) { try { leading = doc.fontSize * 1.2; } catch (e5) { leading = 0; } }

            // Las líneas del propio texto, respetando los dos tipos de salto.
            var raw = full.replace(/\r\n/g, "\r").replace(/\n/g, "\r");
            var lines = raw.split("\r");

            // Una copia apagada hace de regla: se le cambia el texto muchas
            // veces para medir y se borra al terminar.
            var probe = src.duplicate();
            probe.enabled = false;
            probe.name = "· regla ·";
            _ekFreeText(probe);

            var pieces = [];   // {text, dx, dy}
            for (j = 0; j < lines.length; j++) {
                var line = lines[j];
                var dy = j * leading;

                if (mode === "line") {
                    if (_trim(line) === "") continue;
                    pieces.push({ text: line, dx: 0, dy: dy });
                    continue;
                }

                var parts = (mode === "word") ? _ekSplitWords(line) : line.split("");
                var lineW = _ekTextWidth(probe, line, t);
                var cursor = 0, prefix = "";

                for (var k = 0; k < parts.length; k++) {
                    var part = parts[k];
                    if (mode === "char" && part === " ") { prefix += part; continue; }

                    // Ancho hasta aquí y ancho de la pieza: con eso se sabe
                    // dónde empieza y cuánto ocupa, que es lo que hace falta
                    // para las tres alineaciones.
                    if (mode === "word") {
                        var upto = line.substr(0, _ekIndexOfFrom(line, part, cursor));
                        prefix = upto;
                        cursor = prefix.length + part.length;
                    }
                    var before = _ekTextWidth(probe, prefix, t);
                    var pw = _ekTextWidth(probe, part, t);

                    var dx;
                    if (just === ParagraphJustification.RIGHT_JUSTIFY) dx = -(lineW - before - pw);
                    else if (just === ParagraphJustification.CENTER_JUSTIFY) dx = -lineW / 2 + before + pw / 2;
                    else dx = before;

                    pieces.push({ text: part, dx: dx, dy: dy });
                    if (mode === "char") prefix += part;
                }
            }

            try { probe.remove(); } catch (e6) {}
            if (!pieces.length) continue;

            /* Hacia delante y no al reves: cada duplicado nace justo encima
               del original, asi que creando en orden de lectura la pila queda
               en orden de lectura. */
            for (j = 0; j < pieces.length; j++) {
                var nw = src.duplicate();
                _ekFreeText(nw);
                var nd = nw.sourceText.value;
                nd.text = pieces[j].text;
                nw.sourceText.setValue(nd);
                nw.name = _ekLayerName(pieces[j].text);
                _ekShiftPosition(nw, pieces[j].dx, pieces[j].dy);
                nw.enabled = true;
                made++;
            }

            // El original se apaga en lugar de borrarse: si el reparto no
            // convence, se enciende y se tiran las piezas.
            try { src.enabled = false; } catch (e7) {}
            try { src.name = src.name + " · origen"; } catch (e8) {}
        }

        if (!made) return _ekBad("noTextLayer");
        return _ekGood({ layers: made });
    } catch (e9) {
        return _ekBad("hostErr", _aeErr(e9));
    } finally {
        app.endUndoGroup();
    }
}

function _ekIndexOfFrom(hay, needle, from) {
    var n = String(hay), m = String(needle);
    for (var i = from; i <= n.length - m.length; i++) {
        if (n.substr(i, m.length) === m) return i;
    }
    return from;
}

function _ekLayerName(s) {
    var n = _trim(String(s));
    if (n === "") return "·";
    if (n.length > 28) n = n.substr(0, 28);
    return n;
}

// ------- D3 · caja detrás del texto -------
function ek_textBox(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { o = {}; }
    var padX = Number(o.padX); if (!isFinite(padX)) padX = 24;
    var padY = Number(o.padY); if (!isFinite(padY)) padY = 14;
    var radius = Number(o.radius); if (!isFinite(radius) || radius < 0) radius = 0;
    var rgb = _isArr(o.color) ? o.color : [0.09, 0.09, 0.09];

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var layers = _ekSel(comp);
    if (!layers.length) return _ekBad("noSel");

    var target = null;
    for (var i = 0; i < layers.length; i++) {
        var isText = false;
        try { isText = (layers[i] instanceof TextLayer); } catch (e2) { isText = false; }
        if (isText) { target = layers[i]; break; }
    }
    if (!target) return _ekBad("noTextLayer");

    app.beginUndoGroup("EDITKIT: caja de texto");
    try {
        var shape = comp.layers.addShape();
        shape.name = "Caja · " + _ekLayerName(target.name);
        shape.moveAfter(target);

        var nm = _ekEsc(target.name);
        var contents = shape.property("ADBE Root Vectors Group");
        var grp = contents.addProperty("ADBE Vector Group");
        var vecs = grp.property("ADBE Vectors Group");
        var rect = vecs.addProperty("ADBE Vector Shape - Rect");
        var fill = vecs.addProperty("ADBE Vector Graphic - Fill");

        try { fill.property("ADBE Vector Fill Color").setValue([rgb[0], rgb[1], rgb[2], 1]); } catch (e3) {}
        try { rect.property("ADBE Vector Rect Roundness").setValue(radius); } catch (e4) {}

        /* La caja se cuelga del texto y se pone en su origen. A partir de ahí
           las coordenadas que devuelve sourceRectAtTime —que salen del punto
           de anclaje del texto— valen tal cual, sin convertir nada. */
        var sizeExpr = [
            "// EditKit · Caja detrás del texto",
            "margenX = " + padX + ";",
            "margenY = " + padY + ";",
            'r = thisComp.layer("' + nm + '").sourceRectAtTime(time, false);',
            "[r.width + margenX * 2, r.height + margenY * 2]"
        ].join("\n");
        var posExpr = [
            "// EditKit · Caja detrás del texto",
            'r = thisComp.layer("' + nm + '").sourceRectAtTime(time, false);',
            "[r.left + r.width / 2, r.top + r.height / 2]"
        ].join("\n");

        try { rect.property("ADBE Vector Rect Size").expression = sizeExpr; } catch (e5) {}
        try { rect.property("ADBE Vector Rect Position").expression = posExpr; } catch (e6) {}

        /* El espacio del padre nace en su punto de anclaje, pero el
           rectangulo que devuelve sourceRectAtTime se mide desde el origen de
           la capa de texto. Si el usuario movio el anclaje, las dos cosas
           dejan de coincidir: esta expresion mantiene la caja pegada al texto
           aunque el anclaje cambie despues. */
        try { shape.transform.property("Anchor Point").setValue([0, 0]); } catch (e7) {}
        try {
            shape.transform.property("Position").expression = [
                "// EditKit · Caja detras del texto",
                'a = thisComp.layer("' + nm + '").anchorPoint;',
                "[-a[0], -a[1]]"
            ].join("\n");
        } catch (e8) {}
        try { shape.setParentWithJump(target); } catch (e9) { try { shape.parent = target; } catch (eA) {} }

        try { shape.startTime = target.startTime; shape.inPoint = target.inPoint; shape.outPoint = target.outPoint; } catch (eB) {}

        return _ekGood({ name: shape.name });
    } catch (eC) {
        return _ekBad("hostErr", _aeErr(eC));
    } finally {
        app.endUndoGroup();
    }
}

// =============================================================
// E — ENTREGA E ITERACIÓN
// =============================================================

// Escala y recoloca una propiedad de posición respecto a dos centros.
function _ekReframePos(prop, oc, nc, k) {
    function map(v) {
        var nv = v.slice();
        nv[0] = nc[0] + (v[0] - oc[0]) * k;
        nv[1] = nc[1] + (v[1] - oc[1]) * k;
        return nv;
    }
    try {
        if (prop.numKeys > 0) {
            for (var i = 1; i <= prop.numKeys; i++) prop.setValueAtKey(i, map(prop.keyValue(i)));
        } else {
            prop.setValue(map(prop.value));
        }
    } catch (e) {}
}

function _ekScaleProp(prop, k) {
    function map(v) {
        var nv = v.slice();
        for (var i = 0; i < nv.length && i < 2; i++) nv[i] = v[i] * k;
        return nv;
    }
    try {
        if (prop.numKeys > 0) {
            for (var i = 1; i <= prop.numKeys; i++) prop.setValueAtKey(i, map(prop.keyValue(i)));
        } else {
            prop.setValue(map(prop.value));
        }
    } catch (e) {}
}

// ------- E1 · clonar la composicion activa y sus fuentes editables -------

function _ekCloneLookup(pairs, source) {
    for (var i = 0; i < pairs.length; i++) {
        if (pairs[i].source === source || (source.id && pairs[i].source.id === source.id)) {
            return pairs[i].copy;
        }
    }
    return null;
}

function _ekCloneName(source) {
    var base = source.name + " - Clone", name = base, n = 2, taken = true;
    while (taken) {
        taken = false;
        for (var i = 1; i <= app.project.numItems; i++) {
            if (app.project.item(i).name === name) { taken = true; break; }
        }
        if (taken) { name = base + " " + n; n++; }
    }
    return name;
}

function _ekCloneRegister(source, copy, pairs, state) {
    state.created.push(copy);
    pairs.push({ source: source, copy: copy });
    try { copy.parentFolder = source.parentFolder; } catch (e) {}
    copy.name = _ekCloneName(source);
    return copy;
}

/* Los solidos son FootageItem editables: siempre reciben un origen propio.
   El metraje importado solo se reimporta si el usuario lo pide. La copia
   comparte el archivo del disco, pero es un elemento distinto del proyecto. */
function _ekCloneFootage(source, compCopy, state) {
    var existing = _ekCloneLookup(state.footage, source);
    if (existing) return existing;
    for (var i = 0; i < state.skippedSources.length; i++) {
        if (state.skippedSources[i] === source ||
            (source.id && state.skippedSources[i].id === source.id)) return source;
    }

    var main = null, color = null;
    try { main = source.mainSource; color = main.color; } catch (e) { color = null; }
    if (color && color.length >= 3) {
        var duration = source.duration;
        if (!isFinite(duration) || duration < 0.01) duration = compCopy.duration;
        var temporary = compCopy.layers.addSolid(color, source.name,
            source.width, source.height, source.pixelAspect, duration);
        var solidCopy = temporary.source;
        _ekCloneRegister(source, solidCopy, state.footage, state);
        temporary.remove();
        return solidCopy;
    }
    if (!state.duplicateFootage) return source;

    var file = null;
    try { file = source.file; } catch (e3) { file = null; }
    if (!file || !file.exists) {
        state.skipped++;
        state.skippedSources.push(source);
        return source;
    }
    var copy = null;
    try {
        var options = new ImportOptions(file);
        var isStill = true;
        try { isStill = !!main.isStill; } catch (e4) {}
        if (!isStill && /\.(png|jpe?g|tiff?|tga|exr|dpx|bmp|psd)$/i.test(file.name)) {
            options.sequence = true;
        }
        copy = app.project.importFile(options);
    } catch (e5) {
        state.skipped++;
        state.skippedSources.push(source);
        return source;
    }
    _ekCloneRegister(source, copy, state.footage, state);
    try { copy.mainSource.conformFrameRate = main.conformFrameRate; } catch (e6) {}
    try { copy.mainSource.alphaMode = main.alphaMode; } catch (e7) {}
    try { copy.mainSource.premulColor = main.premulColor; } catch (e8) {}
    try { copy.mainSource.invertAlpha = main.invertAlpha; } catch (e9) {}
    try { copy.mainSource.fieldSeparationType = main.fieldSeparationType; } catch (e10) {}
    try { copy.mainSource.loop = main.loop; } catch (e11) {}
    return copy;
}

/* Registrar antes de bajar al arbol evita duplicar dos veces una precomp
   reutilizada y tambien impide un bucle si hay referencias circulares. */
function _ekCloneCompSource(source, state) {
    var existing = _ekCloneLookup(state.comps, source);
    if (existing) return existing;
    var copy = source.duplicate();
    _ekCloneRegister(source, copy, state.comps, state);

    for (var j = 1; j <= source.numLayers; j++) {
        var nested = null;
        try { nested = source.layer(j).source; } catch (e) { nested = null; }
        if (!nested) continue;
        if (nested instanceof CompItem) {
            copy.layer(j).replaceSource(_ekCloneCompSource(nested, state), false);
        } else if (nested instanceof FootageItem) {
            var footageCopy = _ekCloneFootage(nested, copy, state);
            if (footageCopy !== nested) copy.layer(j).replaceSource(footageCopy, false);
        }
    }
    return copy;
}

function _ekCloneRelinkExpression(expr, state) {
    return expr.replace(/\b(comp|footage)\s*\(\s*(["'])([^"']*)\2\s*\)/g,
        function (full, kind, quote, name) {
            var pairs = kind === "comp" ? state.comps : state.footage;
            for (var i = 0; i < pairs.length; i++) {
                if (pairs[i].source.name === name) {
                    var newName = pairs[i].copy.name.replace(/\\/g, "\\\\");
                    newName = newName.replace(quote === '"' ? /"/g : /'/g, "\\" + quote);
                    return kind + "(" + quote + newName + quote + ")";
                }
            }
            return full;
        });
}

function _ekCloneRelinkAll(state) {
    for (var i = 0; i < state.comps.length; i++) {
        var comp = state.comps[i].copy;
        for (var j = 1; j <= comp.numLayers; j++) {
            var props = _ekExprProps(comp.layer(j), true);
            for (var k = 0; k < props.length; k++) {
                var before = props[k].expression;
                var after = _ekCloneRelinkExpression(before, state);
                if (after !== before) props[k].expression = after;
            }
        }
    }
}

function _ekCloneFolder(state) {
    var project = app.project, root = project.rootFolder;
    for (var i = 1; i <= project.numItems; i++) {
        var item = project.item(i);
        if (!(item instanceof FolderItem)) continue;
        if (item.name !== "QuickIt - Duplicados" && item.name !== "QuickIt - Duplicates") continue;
        var parent = item.parentFolder;
        if (parent === root || (parent && root && parent.id === root.id)) return item;
    }
    var name = state.lang === "en" ? "QuickIt - Duplicates" : "QuickIt - Duplicados";
    var folder = project.items.addFolder(name);
    state.created.push(folder);
    return folder;
}

function ek_cloneComp(jsonStr) {
    var options;
    try { options = JSON.parse(jsonStr || "{}"); } catch (e) { return _ekBad("badArg"); }
    if (!options || typeof options !== "object") return _ekBad("badArg");
    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var state = { comps: [], footage: [], created: [], duplicateFootage: options.duplicateFootage === true,
        skipped: 0, skippedSources: [], lang: options.lang === "en" ? "en" : "es" };

    app.beginUndoGroup("EDITKIT: clonar composicion");
    try {
        var root = _ekCloneCompSource(comp, state);
        _ekCloneRelinkAll(state);
        var folder = _ekCloneFolder(state);
        for (var n = 0; n < state.comps.length; n++) state.comps[n].copy.parentFolder = folder;
        try { root.openInViewer(); } catch (e2) {}
        return _ekGood({ comps: state.comps.length, skipped: state.skipped, name: root.name,
            folder: folder.name });
    } catch (e3) {
        // El grupo de deshacer no revierte automaticamente un fallo a mitad.
        // Se crearon padres antes que hijos: se retiran en ese mismo orden.
        for (var i = 0; i < state.created.length; i++) {
            try { state.created[i].remove(); } catch (e4) {}
        }
        return _ekBad("hostErr", _aeErr(e3));
    } finally {
        app.endUndoGroup();
    }
}

// ------- E1b · organizador seguro del panel Proyecto -------
function _ekOrganizerAtRoot(item, root) {
    if (!item || !root) return false;
    var parent = null;
    try { parent = item.parentFolder; } catch (e) { return false; }
    return parent === root || (parent && parent.id === root.id);
}

function _ekOrganizerFolder(project, marker, names, parent, created) {
    for (var i = 1; i <= project.numItems; i++) {
        var item = project.item(i);
        if (!(item instanceof FolderItem) || !_ekOrganizerAtRoot(item, parent)) continue;
        var comment = "";
        try { comment = String(item.comment || ""); } catch (e) {}
        if (comment === marker) return item;
        for (var n = 0; n < names.length; n++) {
            if (item.name !== names[n]) continue;
            if (!comment) try { item.comment = marker; } catch (e2) {}
            return item;
        }
    }
    var folder = project.items.addFolder(names[0]);
    folder.parentFolder = parent;
    try { folder.comment = marker; } catch (e3) {}
    created.push(folder);
    return folder;
}

function _ekOrganizerExt(item) {
    var name = "";
    try { name = item.file ? item.file.name : item.name; } catch (e) { name = item.name || ""; }
    var match = String(name || "").toLowerCase().match(/\.([a-z0-9]+)$/);
    return match ? match[1] : "";
}

function _ekOrganizerKind(item, precomps) {
    if (item instanceof CompItem) return precomps[item.id] ? "precomps" : "comps";
    if (!(item instanceof FootageItem)) return "other";
    try { if (item.footageMissing) return "missing"; } catch (e) {}
    try {
        if (typeof SolidSource !== "undefined" && item.mainSource instanceof SolidSource) return "solids";
    } catch (e2) {}
    var ext = _ekOrganizerExt(item);
    if (/^(wav|mp3|aif|aiff|m4a|aac|flac|ogg|wma)$/.test(ext)) return "audio";
    try { if (item.hasAudio && !item.hasVideo) return "audio"; } catch (e3) {}
    try { if (item.mainSource && item.mainSource.isStill) return "images"; } catch (e4) {}
    if (/^(jpg|jpeg|png|gif|webp|tif|tiff|bmp|exr|dpx|psd|ai|svg|heic)$/.test(ext)) return "images";
    try { if (item.hasVideo) return "video"; } catch (e5) {}
    if (/^(mov|mp4|m4v|avi|mxf|mpg|mpeg|mts|m2ts|webm|wmv|r3d|braw)$/.test(ext)) return "video";
    return "other";
}

function ek_organizeProject(jsonStr) {
    var options;
    try { options = JSON.parse(jsonStr || "{}"); } catch (e) { return _ekBad("badArg"); }
    var project = app.project;
    if (!project) return _ekBad("noProject");
    var lang = options && options.lang === "en" ? "en" : "es";
    var root = project.rootFolder, created = [], moved = [], loose = [], precomps = {};
    var names = lang === "en" ? {
        root: "QuickIt - Organized", comps: "01 - Main Comps", precomps: "02 - Precomps",
        video: "03 - Video", images: "04 - Images", audio: "05 - Audio",
        solids: "06 - Solids", missing: "07 - Missing", other: "08 - Other"
    } : {
        root: "QuickIt - Organizado", comps: "01 - Composiciones", precomps: "02 - Precomposiciones",
        video: "03 - Video", images: "04 - Imágenes", audio: "05 - Audio",
        solids: "06 - Sólidos", missing: "07 - Faltantes", other: "08 - Otros"
    };
    var alternateRoot = lang === "en" ? "QuickIt - Organizado" : "QuickIt - Organized";
    var keys = ["comps", "precomps", "video", "images", "audio", "solids", "missing", "other"];

    app.beginUndoGroup("EDITKIT: organizar proyecto");
    try {
        var i, j, item, source;
        // Se inspeccionan todas las composiciones, incluso las que ya viven en
        // carpetas, solo para distinguir una precomp de una composicion raiz.
        for (i = 1; i <= project.numItems; i++) {
            item = project.item(i);
            if (!(item instanceof CompItem)) continue;
            for (j = 1; j <= item.numLayers; j++) {
                try { source = item.layer(j).source; } catch (e2) { source = null; }
                if (source instanceof CompItem) precomps[source.id] = true;
            }
        }
        // Solo entran elementos sueltos del nivel principal. Las carpetas del
        // usuario y todo lo que contienen quedan fuera por construccion.
        for (i = 1; i <= project.numItems; i++) {
            item = project.item(i);
            if (item instanceof FolderItem || !_ekOrganizerAtRoot(item, root)) continue;
            loose.push(item);
        }
        if (!loose.length) return _ekGood({ moved: 0, folders: 0 });

        var organizer = _ekOrganizerFolder(project, "EditKit:project-organizer:root",
            [names.root, alternateRoot], root, created);
        var buckets = {}, folders = {}, kind;
        for (i = 0; i < keys.length; i++) buckets[keys[i]] = [];
        for (i = 0; i < loose.length; i++) buckets[_ekOrganizerKind(loose[i], precomps)].push(loose[i]);

        for (i = 0; i < keys.length; i++) {
            kind = keys[i];
            if (!buckets[kind].length) continue;
            folders[kind] = _ekOrganizerFolder(project, "EditKit:project-organizer:" + kind,
                [names[kind]], organizer, created);
            for (j = 0; j < buckets[kind].length; j++) {
                item = buckets[kind][j];
                moved.push({ item: item, parent: item.parentFolder });
                item.parentFolder = folders[kind];
            }
        }
        return _ekGood({ moved: moved.length, folders: created.length, folder: organizer.name });
    } catch (e3) {
        for (var m = moved.length - 1; m >= 0; m--) {
            try { moved[m].item.parentFolder = moved[m].parent; } catch (e4) {}
        }
        for (var c = created.length - 1; c >= 0; c--) {
            try { created[c].remove(); } catch (e5) {}
        }
        return _ekBad("hostErr", _aeErr(e3));
    } finally {
        app.endUndoGroup();
    }
}

// ------- E2 · versiones de formato -------
function ek_formatVersion(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { return _ekBad("badArg"); }
    var W = Math.round(Number(o.w)), H = Math.round(Number(o.h));
    if (!isFinite(W) || !isFinite(H) || W < 4 || H < 4 || W > 30000 || H > 30000) return _ekBad("badArg");
    var mode = String(o.mode || "fit");

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    if (comp.width === W && comp.height === H) return _ekBad("sameFormat");

    app.beginUndoGroup("EDITKIT: versión " + W + "×" + H);
    try {
        var dup = comp.duplicate();
        dup.name = comp.name + " · " + W + "×" + H;
        dup.width = W;
        dup.height = H;

        var oc = [comp.width / 2, comp.height / 2];
        var nc = [W / 2, H / 2];

        /* Encajar toma el lado que más aprieta y llenar el que menos: la misma
           decisión que se toma a ojo al reencuadrar, escrita una vez. Mover
           deja los tamaños en paz y solo recoloca, que es lo que se quiere
           cuando cada capa ya está pensada para su formato. */
        var k = 1;
        if (mode === "fit") k = Math.min(W / comp.width, H / comp.height);
        else if (mode === "fill") k = Math.max(W / comp.width, H / comp.height);

        var moved = 0;
        for (var i = 1; i <= dup.numLayers; i++) {
            var L = dup.layer(i);
            try { if (L instanceof CameraLayer || L instanceof LightLayer) continue; } catch (e2) {}

            var par = null;
            try { par = L.parent; } catch (e3) { par = null; }
            if (par) continue;

            var pp = null, sp = null;
            try { pp = L.transform.property("Position"); } catch (e4) { pp = null; }
            try { sp = L.transform.property("Scale"); } catch (e5) { sp = null; }
            if (!pp) continue;

            var hasExpr = false;
            try { hasExpr = pp.expressionEnabled && _trim(pp.expression || "") !== ""; } catch (e6) {}
            if (!hasExpr) _ekReframePos(pp, oc, nc, k);
            if (sp && mode !== "move") {
                var sExpr = false;
                try { sExpr = sp.expressionEnabled && _trim(sp.expression || "") !== ""; } catch (e7) {}
                if (!sExpr) _ekScaleProp(sp, k);
            }
            moved++;
        }

        try { dup.openInViewer(); } catch (e8) {}
        return _ekGood({ name: dup.name, layers: moved });
    } catch (e9) {
        return _ekBad("hostErr", _aeErr(e9));
    } finally {
        app.endUndoGroup();
    }
}

// ------- E3 · a la cola de render, y fotograma suelto -------

function ek_addToQueue(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");

    app.beginUndoGroup("EDITKIT: a la cola de render");
    try {
        var it = app.project.renderQueue.items.add(comp);
        if (o.render) { try { it.applyTemplate(String(o.render)); } catch (e2) {} }

        var om = it.outputModule(1);
        if (o.output) { try { om.applyTemplate(String(o.output)); } catch (e3) {} }

        var folder = _trim(String(o.folder || ""));
        if (folder !== "") {
            var f = new Folder(folder);
            if (f.exists) {
                try { om.file = new File(f.fsName + "/" + comp.name); } catch (e4) {}
            }
        }
        return _ekGood({ name: comp.name });
    } catch (e5) {
        return _ekBad("hostErr", _aeErr(e5));
    } finally {
        app.endUndoGroup();
    }
}

function ek_saveFrame(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (e) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");

    try {
        var name = comp.name.replace(/[\\\/:*?"<>|]/g, "_") + "_" + Math.round(comp.time * comp.frameRate) + ".png";
        var file = null;
        var folder = _trim(String(o.folder || ""));

        if (folder !== "") {
            var fo = new Folder(folder);
            if (fo.exists) file = new File(fo.fsName + "/" + name);
        }
        // Sin carpeta guardada se pregunta, en vez de decidir por el usuario
        // dónde deja las cosas.
        if (!file) {
            file = File.saveDialog("Guardar fotograma", "PNG:*.png");
            if (!file) return _ekJ({ ok: false, code: "canceled" });
        }
        comp.saveFrameToPng(comp.time, file);
        return _ekGood({ path: file.fsName });
    } catch (e2) {
        return _ekBad("hostErr", _aeErr(e2));
    }
}

// ------- E4 · consolidar audio y devolver stems a la linea de tiempo -------

function _ekAudioSafeName(name) {
    var s = String(name || "audio").replace(/[\\\/:*?"<>|]/g, "_");
    s = _trim(s);
    return s === "" ? "audio" : s;
}

function _ekAudioTemplate(om) {
    var names = null, audioOnly = "", wavFallback = "";
    try { names = om.templates; } catch (e) { names = null; }
    if (!names) return "";
    for (var i = 0; i < names.length; i++) {
        var original = String(names[i]);
        var low = original.toLowerCase();
        // WAV conserva un nombre estable en las instalaciones localizadas de
        // After Effects y garantiza que la extensión final sea realmente .wav.
        if (low === "wav") return original;
        if (!wavFallback && (low.indexOf("wav") !== -1 || low.indexOf("waveform") !== -1)) {
            wavFallback = original;
        }
        if (low === "audio only" || low === "solo audio" || low === "sólo audio") audioOnly = original;
        if (low.indexOf("audio") !== -1 &&
            (low.indexOf("only") !== -1 || low.indexOf("solo") !== -1 || low.indexOf("sólo") !== -1)) {
            audioOnly = original;
        }
    }
    return wavFallback || audioOnly;
}

function _ekAudioUniqueFile(folder, base) {
    var file = new File(folder.fsName + "/" + base + ".wav");
    var n = 2;
    while (file.exists && n < 10000) {
        file = new File(folder.fsName + "/" + base + "_" + n + ".wav");
        n++;
    }
    return file;
}

function _ekAudioCompById(id) {
    var wanted = parseInt(id, 10);
    if (!isFinite(wanted)) return null;
    try {
        if (app.project.itemByID) {
            var direct = app.project.itemByID(wanted);
            if (direct && direct instanceof CompItem) return direct;
        }
    } catch (e) {}
    for (var i = 1; i <= app.project.numItems; i++) {
        var item = null;
        try { item = app.project.item(i); } catch (e2) { item = null; }
        try { if (item && item.id === wanted && item instanceof CompItem) return item; } catch (e3) {}
    }
    return null;
}

function _ekAudioProjectFolder() {
    var name = "QuickIt - Audio";
    for (var i = 1; i <= app.project.numItems; i++) {
        var item = null;
        try { item = app.project.item(i); } catch (e) { item = null; }
        try {
            if (item && item instanceof FolderItem && item.parentFolder === app.project.rootFolder && item.name === name) return item;
        } catch (e2) {}
    }
    try { return app.project.items.addFolder(name); } catch (e3) { return null; }
}

function ek_audioConsolidate(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var selected = _ekSel(comp);
    if (!selected.length) return _ekBad("noSel");

    var start = comp.duration, end = 0, selectedIndices = {}, audible = 0;
    for (var s = 0; s < selected.length; s++) {
        var sourceLayer = selected[s];
        selectedIndices[sourceLayer.index] = true;
        try { if (sourceLayer.inPoint < start) start = sourceLayer.inPoint; } catch (eB) {}
        try { if (sourceLayer.outPoint > end) end = sourceLayer.outPoint; } catch (eC) {}
        try { if (sourceLayer.hasAudio && sourceLayer.audioEnabled) audible++; } catch (eD) {}
    }
    if (!audible) return _ekBad("audioNoAudible");

    if (String(o.range || "selection") === "work") {
        start = comp.workAreaStart;
        end = comp.workAreaStart + comp.workAreaDuration;
    }
    start = Math.max(0, Math.min(comp.duration, start));
    end = Math.max(start, Math.min(comp.duration, end));
    if (end - start <= 0) return _ekBad("audioEmptyRange");

    var folderText = _trim(String(o.folder || ""));
    var folder = folderText ? new Folder(folderText) : null;
    if (!folder || !folder.exists) {
        folder = Folder.selectDialog("Carpeta para el audio consolidado");
        if (!folder) return _ekBad("canceled");
    }

    var tempComp = null, renderItem = null, result = null, output = null;
    var oldStates = [];
    try {
        tempComp = comp.duplicate();
        tempComp.name = "__EDITKIT_AUDIO_TEMP__";

        for (var i = 1; i <= tempComp.numLayers; i++) {
            var layer = tempComp.layer(i);
            try { layer.solo = false; } catch (eSolo) {}
            if (!selectedIndices[i]) {
                try { if (layer.hasAudio) layer.audioEnabled = false; } catch (eMute) {}
            }
        }

        for (var r = 1; r <= app.project.renderQueue.numItems; r++) {
            var previous = app.project.renderQueue.item(r);
            var wasOn = false;
            try { wasOn = !!previous.render; } catch (eRead) {}
            oldStates.push({ item: previous, render: wasOn });
            try { previous.render = false; } catch (eOff) {}
        }

        renderItem = app.project.renderQueue.items.add(tempComp);
        renderItem.timeSpanStart = start;
        renderItem.timeSpanDuration = end - start;

        var om = renderItem.outputModule(1);
        var template = _ekAudioTemplate(om);
        if (!template) {
            var availableTemplates = [];
            try {
                for (var t = 0; t < om.templates.length; t++) availableTemplates.push(String(om.templates[t]));
            } catch (eTemplates) {}
            result = _ekBad("audioNoTemplate", availableTemplates.join(" | "));
        } else {
            om.applyTemplate(template);
            // applyTemplate invalida algunas referencias de OutputModule en
            // ciertas versiones; se obtiene de nuevo antes de tocar el archivo.
            om = renderItem.outputModule(1);
            output = _ekAudioUniqueFile(folder, _ekAudioSafeName(comp.name) + "_audio");
            om.file = output;
            renderItem.render = true;
            app.project.renderQueue.render();

            var done = false;
            try { done = renderItem.status === RQItemStatus.DONE; } catch (eStatus) { done = output.exists; }
            if (!done || !output.exists) result = _ekBad("audioRenderFailed");
            else {
                if (o.openFolder) { try { folder.execute(); } catch (eOpen) {} }
                result = _ekGood({
                    path: output.fsName,
                    name: output.name,
                    folder: folder.fsName,
                    compId: comp.id,
                    compName: comp.name,
                    start: start,
                    duration: end - start
                });
            }
        }
    } catch (eMain) {
        result = _ekBad("hostErr", _aeErr(eMain));
    } finally {
        if (renderItem) { try { renderItem.remove(); } catch (eRemoveRQ) {} }
        for (var q = 0; q < oldStates.length; q++) {
            try { oldStates[q].item.render = oldStates[q].render; } catch (eRestore) {}
        }
        if (tempComp) { try { tempComp.remove(); } catch (eRemoveComp) {} }
        try { comp.openInViewer(); } catch (eViewer) {}
    }
    return result || _ekBad("audioRenderFailed");
}

function ek_audioImport(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { return _ekBad("badArg"); }
    var comp = _ekAudioCompById(o.compId);
    if (!comp) return _ekBad("audioCompMissing");

    var isWin = false;
    try { isWin = String($.os).toLowerCase().indexOf("win") !== -1; } catch (eOS) {}
    var chosen = isWin
        ? File.openDialog("Elegir pistas procesadas", "Audio:*.wav;*.mp3;*.aif;*.aiff;*.m4a;*.aac;*.flac", true)
        : File.openDialog("Elegir pistas procesadas", undefined, true);
    if (!chosen) return _ekBad("canceled");
    if (!(chosen instanceof Array)) chosen = [chosen];
    if (!chosen.length) return _ekBad("audioNoFiles");

    var start = parseFloat(o.start);
    if (!isFinite(start)) start = 0;
    var imported = 0, folder = null;
    app.beginUndoGroup("EDITKIT: importar audio procesado");
    try {
        folder = _ekAudioProjectFolder();
        for (var i = 1; i <= comp.numLayers; i++) {
            try { comp.layer(i).selected = false; } catch (eSel) {}
        }
        for (var f = 0; f < chosen.length; f++) {
            try {
                var file = chosen[f];
                if (!file || !file.exists) continue;
                var options = new ImportOptions(file);
                var footage = app.project.importFile(options);
                if (folder) { try { footage.parentFolder = folder; } catch (eFolder) {} }
                var layer = comp.layers.add(footage);
                layer.startTime = start;
                layer.selected = true;
                imported++;
            } catch (eOne) {}
        }
        if (!imported) return _ekBad("audioImportFailed");
        try { comp.openInViewer(); } catch (eViewer) {}
        return _ekGood({ files: imported, compName: comp.name, start: start });
    } catch (eMain) {
        return _ekBad("hostErr", _aeErr(eMain));
    } finally {
        app.endUndoGroup();
    }
}

/* El icono de un boton del panel lateral. Lo pone el usuario con una imagen
   suya: aqui solo se abre el dialogo y se devuelve la ruta. No se copia el
   archivo ni se convierte a base64 — el panel guarda la ruta y la pinta, que
   para un adorno de cuarenta pixeles es todo lo que hace falta. */
function ek_pickIcon() {
    try {
        var isWin = false;
        try { isWin = String($.os).toLowerCase().indexOf("win") !== -1; } catch (eOS) {}
        var f = isWin
            ? File.openDialog("Elegir icono", "Imagenes:*.png;*.jpg;*.jpeg;*.gif;*.webp;*.bmp;*.svg")
            : File.openDialog("Elegir icono");
        if (!f) return _ekJ({ ok: false, code: "canceled" });
        return _ekGood({ path: f.fsName });
    } catch (e) {
        return _ekBad("hostErr", _aeErr(e));
    }
}

// Carpeta de salida: la elige el usuario una vez y se guarda en el panel.
function ek_pickFolder() {
    try {
        var f = Folder.selectDialog("Carpeta de salida");
        if (!f) return _ekJ({ ok: false, code: "canceled" });
        return _ekGood({ path: f.fsName });
    } catch (e) {
        return _ekBad("hostErr", _aeErr(e));
    }
}

// ============================================================================
// PERFILES — SACAR LA CONFIGURACION DEL EQUIPO Y VOLVERLA A METER
//
// Un perfil es un archivo de texto con todo lo que el usuario ha configurado
// en los tres plugins. El panel lo arma y lo lee; aqui solo se abre el dialogo
// del sistema y se escribe o se lee el archivo, porque un panel de CEP no
// puede hacer ninguna de las dos cosas por su cuenta.
//
// Dos notas sobre el dialogo:
//
//   - Se abre "desde" un archivo de la carpeta de perfiles —el metodo de
//     instancia, no el estatico— para que se abra donde estan los perfiles y no
//     donde estuviera la ultima vez. Ese archivo no tiene que existir: lo unico
//     que se usa de el es la carpeta y el nombre que propone.
//
//   - El filtro de extensiones solo lo entiende Windows. En Mac se pasa el
//     dialogo sin filtro, que es lo que hace el resto de este archivo.
// ============================================================================

// ============================================================================
// LA CARPETA DE EDITKIT: Documentos/EditKit
//
// Todo lo que el plugin guarda fuera de si mismo vive aqui: la copia de la
// bitacora y los perfiles. Estaba en la carpeta de datos de aplicacion del
// usuario (%APPDATA%\EditKit en Windows, ~/Library/Application Support/EditKit
// en Mac), que es donde lo pondria un programa, pero no donde lo busca nadie:
// en Windows esa carpeta esta oculta. Documentos es un sitio que cualquiera
// sabe abrir, y una carpeta con el nombre del plugin se reconoce sin explicar
// nada.
//
// La primera vez que se llama, se trae lo que hubiera en la carpeta vieja: la
// bitacora y cada perfil que no exista ya en la nueva. Se copia, se comprueba
// que la copia esta, y solo entonces se borra el original. Si algo falla a
// mitad, lo viejo se queda donde estaba y se vuelve a intentar la proxima vez.
// ============================================================================

var _ekHomeReady = false;

function _ekHome() {
    var dir = new Folder(Folder.myDocuments.fsName + "/EditKit");
    if (!dir.exists) dir.create();
    if (!_ekHomeReady) {
        _ekHomeReady = true;
        try { _ekMoveOldData(dir); } catch (eMove) {}
        try { _ekWriteReadme(dir); } catch (eReadme) {}
    }
    return dir;
}

// Copiar y, solo si la copia existe con el mismo tamano, borrar el original.
function _ekMoveFile(from, toFolder) {
    if (!from.exists) return false;
    var target = new File(toFolder.fsName + "/" + decodeURIComponent(from.name));
    if (target.exists) return false;              // lo nuevo manda: no se pisa
    if (!from.copy(target.fsName)) return false;
    var copied = new File(target.fsName);
    if (!copied.exists || copied.length !== from.length) return false;
    from.remove();
    return true;
}

function _ekMoveOldData(home) {
    var old = new Folder(Folder.userData.fsName + "/EditKit");
    if (!old.exists) return;
    if (old.fsName === home.fsName) return;

    _ekMoveFile(new File(old.fsName + "/bitacora.json"), home);

    var oldProfiles = new Folder(old.fsName + "/Perfiles");
    if (oldProfiles.exists) {
        var newProfiles = new Folder(home.fsName + "/Perfiles");
        if (!newProfiles.exists) newProfiles.create();
        var files = oldProfiles.getFiles("*.json");
        for (var i = 0; i < files.length; i++) {
            if (files[i] instanceof File) _ekMoveFile(files[i], newProfiles);
        }
        // una carpeta vacia se borra; si queda algo, se deja
        if (oldProfiles.getFiles().length === 0) oldProfiles.remove();
    }
    if (old.getFiles().length === 0) old.remove();
}

/* Una nota dentro de la carpeta, para quien la encuentre sin saber que es.
   Solo se escribe si no esta: si el usuario la borra o la cambia, es suya. */
function _ekWriteReadme(home) {
    var f = new File(home.fsName + "/LEEME.txt");
    if (f.exists) return;
    f.encoding = "UTF-8";
    if (!f.open("w")) return;
    f.write(
        "EDITKIT\n" +
        "\n" +
        "Esta carpeta la usa el plugin EditKit para guardar lo tuyo fuera del\n" +
        "propio plugin, para que no se pierda al desinstalarlo o al actualizarlo:\n" +
        "\n" +
        "  ajustes.json    una copia de tus ajustes, presets, colecciones y botones;\n" +
        "                  si el plugin arranca vacio, los recupera de aqui\n" +
        "  bitacora.json   el recuento de uso y los secretos encontrados\n" +
        "  Perfiles        los perfiles que guardes desde Ajustes > Perfiles\n" +
        "\n" +
        "Nada de esto sale de tu equipo. Puedes borrar la carpeta cuando quieras:\n" +
        "el plugin sigue funcionando y la vuelve a crear vacia.\n" +
        "\n" +
        "--\n" +
        "\n" +
        "EDITKIT uses this folder to keep your data outside the plugin itself, so\n" +
        "it survives an uninstall or an update. Nothing here leaves your computer.\n" +
        "You can delete the folder at any time; the plugin recreates it empty.\n"
    );
    f.close();
}

function _ekProfileDir() {
    var sub = new Folder(_ekHome().fsName + "/Perfiles");
    if (!sub.exists) sub.create();
    return sub;
}

// Un nombre de perfil puede llevar cualquier cosa; un nombre de archivo no.
function _ekSafeName(n) {
    var s2 = String(n || "Perfil");
    s2 = s2.replace(/[\\\/:*?"<>|\r\n\t]/g, " ");
    s2 = s2.replace(/\s+/g, " ");
    s2 = s2.replace(/^\s+|\s+$/g, "");
    if (!s2) s2 = "Perfil";
    if (s2.length > 60) s2 = s2.substring(0, 60);
    return s2;
}

function ek_profileSave(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { return _ekBad("badArg"); }
    var data = String(o.data || "");
    if (!data) return _ekBad("badArg");

    try {
        var isWin = false;
        try { isWin = String($.os).toLowerCase().indexOf("win") !== -1; } catch (eOS) {}

        var title = "Guardar el perfil";
        var filter = "Perfiles de EDITKIT:*.json";
        var seed = new File(_ekProfileDir().fsName + "/" + _ekSafeName(o.name) + ".json");

        var f = isWin ? seed.saveDlg(title, filter) : seed.saveDlg(title);
        if (!f) return _ekJ({ ok: false, code: "canceled" });

        // El dialogo de Windows no siempre pone la extension aunque este en el
        // filtro; sin ella, el archivo no se vuelve a encontrar al importar.
        if (!/\.json$/i.test(String(f.fsName))) {
            f = new File(f.fsName + ".json");
        }

        f.encoding = "UTF-8";
        if (!f.open("w")) return _ekBad("cantWrite");
        var wrote = f.write(data);
        var closed = f.close();
        if (wrote === false || closed === false || !f.exists) return _ekBad("cantWrite");
        return _ekGood({ path: f.fsName });
    } catch (e) {
        return _ekBad("hostErr", _aeErr(e));
    }
}

function ek_profileOpen() {
    try {
        var isWin = false;
        try { isWin = String($.os).toLowerCase().indexOf("win") !== -1; } catch (eOS) {}

        var title = "Abrir un perfil";
        var filter = "Perfiles de EDITKIT:*.json";
        var seed = new File(_ekProfileDir().fsName + "/.");

        var f = isWin ? seed.openDlg(title, filter) : seed.openDlg(title);
        if (!f) return _ekJ({ ok: false, code: "canceled" });

        f.encoding = "UTF-8";
        if (!f.open("r")) return _ekBad("cantRead");
        var txt = f.read();
        f.close();
        if (!txt) return _ekBad("emptyFile");

        return _ekGood({ data: txt, path: f.fsName, name: decodeURIComponent(String(f.name)) });
    } catch (e) {
        return _ekBad("hostErr", _aeErr(e));
    }
}

// =============================================================
// BITÁCORA — ALMACÉN FUERA DE LA EXTENSIÓN
//
// El recuento de uso vivía solo en el almacenamiento del panel, que se va con
// la extensión: desinstalar y volver a instalar lo dejaba a cero. Aquí se
// guarda una copia en Documentos/EditKit, que sobrevive a la desinstalación,
// a cambiar de versión y a mover el ZXP de sitio.
// No sale del equipo: es un archivo de texto, y se puede borrar.
// =============================================================

function _ekLogFile() {
    return new File(_ekHome().fsName + "/bitacora.json");
}

function editkit_logRead() {
    try {
        var f = _ekLogFile();
        if (!f.exists) return _ekGood({ data: "" });
        f.encoding = "UTF-8";
        if (!f.open("r")) return _ekBad("cantRead");
        var s = f.read();
        f.close();
        return _ekGood({ data: s });
    } catch (e) {
        return _ekBad("hostErr", _aeErr(e));
    }
}

function editkit_logWrite(str) {
    try {
        var f = _ekLogFile();
        f.encoding = "UTF-8";
        if (!f.open("w")) return _ekBad("cantWrite");
        f.write(String(str));
        f.close();
        return _ekGood({ path: f.fsName });
    } catch (e) {
        return _ekBad("hostErr", _aeErr(e));
    }
}

function editkit_logErase() {
    try {
        var f = _ekLogFile();
        if (f.exists) f.remove();
        return _ekGood({});
    } catch (e) {
        return _ekBad("hostErr", _aeErr(e));
    }
}

// ============================================================================
// LO QUE EL USUARIO TRAE DE FUERA
//
// Tres cosas que QuickIt puede poner en un boton de su rejilla y que no son
// funciones de este plugin: un efecto de After Effects por su nombre, un script
// .jsx del usuario y un preset de animacion .ffx.
//
// Las tres pasan por aqui y no por evalScript directo a proposito. Lo que se
// gana: un grupo de deshacer con nombre, el mismo formato de error que el resto
// —codigo, no frase— y una comprobacion previa de que hay donde aplicarlo. Sin
// eso, un nombre de efecto mal escrito devuelve una excepcion de ExtendScript
// en ingles a un panel que puede estar en espanol.
// ============================================================================

/* LA LISTA DE EFECTOS INSTALADOS

   `app.effects` la tiene After Effects siempre lista: todo lo que hay
   instalado, con su nombre visible, su nombre interno y su categoria. No hay
   que indexar ninguna carpeta ni buscar en el disco — es el propio programa
   diciendo lo que sabe hacer, incluidos los plugins de terceros.

   Se devuelve entera y de una vez. Son unos cientos de entradas y el panel se
   queda con ellas: buscar por nombre sin ir al host cada tecla es la
   diferencia entre un buscador y una espera. */
function ek_listEffects() {
    try {
        var list = app.effects || [];
        var out = [];
        for (var i = 0; i < list.length; i++) {
            var e = list[i];
            if (!e) continue;
            var n = "", m = "", c = "";
            try { n = String(e.displayName || ""); } catch (e1) {}
            try { m = String(e.matchName || ""); } catch (e2) {}
            try { c = String(e.category || ""); } catch (e3) {}
            if (!n && !m) continue;
            out.push({ n: n || m, m: m, c: c });
        }
        if (!out.length) return _ekBad("noEffectList");
        return _ekGood({ effects: out, count: out.length });
    } catch (e) {
        return _ekBad("hostErr", _aeErr(e));
    }
}

/* Un efecto por su nombre. Vale el nombre visible ("Gaussian Blur") y tambien
   el interno ("ADBE Gaussian Blur 2"): addProperty acepta los dos, y cual de
   los dos sabe el usuario depende de como tenga el After Effects.

   Cuando el boton se creo desde el buscador, ademas del visible viene el
   interno, y ese es el que se prueba primero: el visible cambia con el idioma
   del programa, el interno no. Asi un boton hecho en un After Effects en
   espanol sigue funcionando en uno en ingles. */
function ek_applyEffect(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { return _ekBad("badArg"); }
    var name = String(o.name || "");
    var match = String(o.match || "");
    if (!name && !match) return _ekBad("noName");
    if (!name) name = match;

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var sel = _ekSel(comp);
    if (!sel.length) return _ekBad("noSel");

    app.beginUndoGroup("QuickIt: " + name);
    var done = 0, failed = 0;
    try {
        for (var i = 0; i < sel.length; i++) {
            var fx = null;
            try { fx = sel[i].property("ADBE Effect Parade"); } catch (e1) { fx = null; }
            if (!fx) { failed++; continue; }
            // canAddProperty evita la excepcion en las capas que no lo admiten
            // (una capa de camara, por ejemplo) sin abortar las demas.
            var put = false;
            if (match) {
                try {
                    if (fx.canAddProperty(match)) { fx.addProperty(match); put = true; }
                } catch (e2) { put = false; }
            }
            if (!put) {
                try {
                    if (fx.canAddProperty(name)) { fx.addProperty(name); put = true; }
                } catch (e3) { put = false; }
            }
            if (put) done++; else failed++;
        }
    } catch (e3) {
        app.endUndoGroup();
        return _ekBad("hostErr", _aeErr(e3));
    }
    app.endUndoGroup();

    if (!done) return _ekBad("noEffect", name);
    return _ekGood({ layers: done, skipped: failed });
}

/* Un script del usuario. Corre en el mismo motor que este archivo, asi que
   puede hacer cualquier cosa que haga un script de After Effects — que es
   justo lo que se pidio— y por eso NO se le abre grupo de deshacer propio: si
   el script abre el suyo, dos anidados dejan el historial partido. Lo que si se
   comprueba es que el archivo siga estando donde se dijo. */
function ek_runScript(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { return _ekBad("badArg"); }
    var path = String(o.path || "");
    if (!path) return _ekBad("noPath");

    var f = new File(path);
    if (!f.exists) return _ekBad("noFile", path);

    try {
        $.evalFile(f);
        return _ekGood({ path: f.fsName });
    } catch (e) {
        return _ekBad("scriptErr", _aeErr(e));
    }
}

/* ============================================================================
   UN PRESET, VARIAS CAPAS

   `applyPreset` es de capa: para varias, un bucle. Eso ya estaba. Lo que
   faltaba es DONDE caen los keyframes.

   Un preset trae los suyos en tiempos absolutos y After Effects los coloca a
   partir del cursor de tiempo. Con cinco capas que empiezan en cinco momentos
   distintos, las cinco reciben la animacion en el mismo instante — que casi
   nunca es lo que se queria. De ahi las tres opciones, que se combinan entre
   si y valen para cualquier preset:

     at       donde empieza: en la entrada de cada capa (lo normal), en su
              salida —para una animacion de salida— o en el cursor, que es el
              comportamiento de toda la vida.
     fit      estirar o encoger el preset para que ocupe exactamente lo que
              dura la capa.
     stagger  cuantos fotogramas de retraso lleva cada capa respecto a la
              anterior, para que entren en cascada.

   COMO SE SABE QUE KEYFRAMES PUSO EL PRESET. No hay forma de preguntarselo a
   After Effects, asi que se mira antes y despues: se apunta el tiempo de cada
   keyframe que ya habia —con la ruta de su propiedad, para no confundir dos
   que coincidan— y al terminar, los que no estaban en esa lista son los que
   acaba de poner. Solo esos se mueven. Lo que la capa ya tenia animado se
   queda donde estaba, que es la mitad del valor de hacerlo asi.

   Y si el preset no trae keyframes —hay muchos que solo ponen efectos con
   valores fijos— no hay nada que recolocar y las tres opciones no hacen nada.
   Se aplica igual.

   UNA CAPA CADA VEZ, Y SOLA. `applyPreset` se llama sobre una capa, pero no
   se aplica solo a esa capa: se aplica A TODA LA SELECCION. Con cuatro capas
   elegidas, el bucle daba cuatro vueltas y en cada una las cuatro recibian el
   preset — cuatro copias en cada capa, y todas colocadas segun el tiempo que
   se habia puesto para la capa de esa vuelta. Eso es lo que se veia: los
   keyframes repetidos y con el tiempo de la primera capa aplicado a las
   demas.

   Asi que antes de cada aplicacion se suelta la seleccion entera y se deja
   marcada solo la capa que toca. Al terminar se devuelve la seleccion como
   estaba, que es lo que el usuario dejo y lo que espera encontrarse.
   ============================================================================ */

/* La ruta de una propiedad, para poder reconocerla despues de aplicar el
   preset. Lleva el indice ademas del nombre interno porque una capa puede
   tener dos efectos iguales, y un preset puede anadir un tercero: los que ya
   estaban conservan su indice, asi que la ruta sigue valiendo. */
function _ekPropPath(prop) {
    var parts = [], p = prop, guard = 0;
    while (p && guard++ < 40) {
        var mn = "", ix = 0;
        try { mn = p.matchName || p.name || ""; } catch (e) { mn = ""; }
        try { ix = p.propertyIndex || 0; } catch (e2) { ix = 0; }
        parts.push(mn + ":" + ix);
        var par = null;
        try { par = p.parentProperty; } catch (e3) { par = null; }
        if (!par) break;
        p = par;
    }
    return parts.join("/");
}

function _ekHasKeys(p) {
    var n = 0;
    try { n = p.numKeys; } catch (e) { return false; }
    return n > 0;
}

// El mapa de "esto ya estaba": ruta de la propiedad + tiempo del keyframe.
function _ekKeyTimeSet(layer) {
    var set = {}, props = _ekWalk(layer, _ekHasKeys), i, k;
    for (i = 0; i < props.length; i++) {
        var path = _ekPropPath(props[i]), n = 0;
        try { n = props[i].numKeys; } catch (e) { n = 0; }
        for (k = 1; k <= n; k++) {
            var t = null;
            try { t = props[i].keyTime(k); } catch (e2) { t = null; }
            if (t === null) continue;
            set[path + "@" + _ekRound(t, 5)] = true;
        }
    }
    return set;
}

// Lo que no estaba antes. Devuelve, por propiedad, los indices nuevos.
function _ekAddedKeys(layer, before) {
    var out = [], props = _ekWalk(layer, _ekHasKeys), i, k;
    for (i = 0; i < props.length; i++) {
        var path = _ekPropPath(props[i]), n = 0, idx = [];
        try { n = props[i].numKeys; } catch (e) { n = 0; }
        for (k = 1; k <= n; k++) {
            var t = null;
            try { t = props[i].keyTime(k); } catch (e2) { t = null; }
            if (t === null) continue;
            if (!before[path + "@" + _ekRound(t, 5)]) idx.push(k);
        }
        if (idx.length) out.push({ prop: props[i], idx: idx });
    }
    return out;
}

function _ekAddedSpan(added) {
    var lo = null, hi = null, i, k;
    for (i = 0; i < added.length; i++) {
        for (k = 0; k < added[i].idx.length; k++) {
            var t = null;
            try { t = added[i].prop.keyTime(added[i].idx[k]); } catch (e) { t = null; }
            if (t === null) continue;
            if (lo === null || t < lo) lo = t;
            if (hi === null || t > hi) hi = t;
        }
    }
    return (lo === null) ? null : { lo: lo, hi: hi };
}

// Deja marcados exactamente esos keyframes, que es lo que lee _ekRetimeProp.
function _ekSelectOnly(prop, idx) {
    var n = 0;
    try { n = prop.numKeys; } catch (e) { return; }
    var want = {}, i;
    for (i = 0; i < idx.length; i++) want[idx[i]] = true;
    for (i = 1; i <= n; i++) {
        try { prop.setSelectedAtKey(i, !!want[i]); } catch (e2) {}
    }
}

function ek_applyPreset(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { return _ekBad("badArg"); }
    var path = String(o.path || "");
    if (!path) return _ekBad("noPath");

    var f = new File(path);
    if (!f.exists) return _ekBad("noFile", path);

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var sel = _ekSel(comp);
    if (!sel.length) return _ekBad("noSel");

    var at = String(o.at || "playhead");        // "in" | "out" | "playhead"
    /* Booleano estricto y compatible con perfiles viejos. `!!"false"` seria
       true, por lo que desmarcar podia seguir ajustando si el valor habia
       viajado serializado como texto. Sin valor se usa el recomendado. */
    var hasFit = (typeof o.fit !== "undefined");
    var fit = hasFit ? (o.fit === true || o.fit === 1 || o.fit === "1" || o.fit === "true") : true;
    var stagger = Number(o.stagger);
    if (!isFinite(stagger)) stagger = 0;
    var step = stagger / comp.frameRate;

    // De arriba abajo, para que la cascada baje por la pila y no por el orden
    // en que se fue haciendo clic, que el usuario no ve.
    var layers = sel.slice();
    layers.sort(function (a, b) {
        var ia = 0, ib = 0;
        try { ia = a.index; } catch (e1) {}
        try { ib = b.index; } catch (e2) {}
        return ia - ib;
    });

    var placing = (at !== "playhead") || fit || step !== 0;
    var t0 = comp.time;

    app.beginUndoGroup("QuickIt: " + f.name);
    var done = 0, placed = 0;
    try {
        for (var i = 0; i < layers.length; i++) {
            var L = layers[i];
            var lin = 0, lout = 0;
            try { lin = L.inPoint; lout = L.outPoint; } catch (e3) { lin = 0; lout = comp.duration; }

            /* Se aplica ya cerca de su sitio: asi, cuando no hay que recolocar
               nada —el caso mas comun—, no se toca ni un keyframe despues. */
            var seed = (at === "playhead") ? t0 : lin;
            if (seed < 0) seed = 0;
            try { comp.time = seed; } catch (e4) {}

            // Sola. Ver la nota de arriba: si no, el preset cae en todas.
            _ekDeselect(comp);
            try { L.selected = true; } catch (eS) {}

            var before = placing ? _ekKeyTimeSet(L) : null;

            try { L.applyPreset(f); done++; } catch (e5) { continue; }
            if (!placing) continue;

            var added = _ekAddedKeys(L, before);
            if (!added.length) continue;
            var span = _ekAddedSpan(added);
            if (!span) continue;

            var len = span.hi - span.lo;
            var want = lout - lin;
            var scale = 1;
            if (fit && len > 1e-9 && want > 1e-9) scale = want / len;

            var offset = i * step;
            var start;
            if (at === "in") start = lin + offset;
            else if (at === "out") start = lout - len * scale + offset;
            else start = t0 + offset;
            if (start < 0) start = 0;

            var lo = span.lo, sc = scale, st = start;
            for (var j = 0; j < added.length; j++) {
                _ekSelectOnly(added[j].prop, added[j].idx);
                var n = _ekRetimeProp(added[j].prop, (function (a, b, c) {
                    return function (t) { return b + (t - a) * c; };
                })(lo, st, sc), sc, 0, false);
                if (n > 0) placed += n;
            }
        }
    } catch (e6) {
        app.endUndoGroup();
        _ekReselect(comp, layers);
        try { comp.time = t0; } catch (e7) {}
        return _ekBad("hostErr", _aeErr(e6));
    }
    _ekReselect(comp, layers);
    try { comp.time = t0; } catch (e8) {}
    app.endUndoGroup();

    if (!done) return _ekBad("presetErr", f.name);
    return _ekGood({ layers: done, keys: placed, name: f.name });
}

/* CAPTURA INTERNA, SIN PORTAPAPELES NI FOCO DE INTERFAZ.

   app.executeCommand(Copiar/Pegar) depende del panel de AE que conserve el
   foco. Al pulsar QuickIt el foco pasa a CEP y, segun la version de AE, Pegar
   puede no hacer nada aunque el comando no lance error. Por eso se guarda en
   memoria cada propiedad: ruta, valores, tiempos, interpolacion, eases y
   tangentes. _ekWriteKeys ya sabe reconstruir todo eso sin deformar curvas. */
function _ekCapturePasteLeaf(prop, seen, records) {
    var id = "";
    try { id = _ekPropPath(prop); } catch (e0) { id = ""; }
    if (!id || seen[id]) return;
    seen[id] = true;

    var address = _ekPropertyAddress(prop);
    if (!address.length) return;

    var numKeys = 0, selected = [], indices = [], keys = [], i;
    try { numKeys = prop.numKeys || 0; } catch (e1) { numKeys = 0; }
    try { selected = prop.selectedKeys || []; } catch (e2) { selected = []; }
    if (selected.length) {
        for (i = 0; i < selected.length; i++) indices.push(selected[i]);
    } else {
        for (i = 1; i <= numKeys; i++) indices.push(i);
    }
    for (i = 0; i < indices.length; i++) {
        try { keys.push(_ekReadKey(prop, indices[i])); } catch (e3) {}
    }

    var hasValue = false, value = null, expression = "", expressionEnabled = false;
    if (!keys.length) {
        try { value = prop.value; hasValue = true; } catch (e4) { hasValue = false; }
    }
    try {
        if (prop.canSetExpression) {
            expression = prop.expression || "";
            expressionEnabled = !!prop.expressionEnabled;
        }
    } catch (e5) { expression = ""; expressionEnabled = false; }

    if (!keys.length && !hasValue && !expression) return;
    var propName = "", propMatchName = "", valueType = null;
    try { propName = prop.name || ""; } catch (e6) { propName = ""; }
    try { propMatchName = prop.matchName || ""; } catch (e7) { propMatchName = ""; }
    try { valueType = prop.propertyValueType; } catch (e8) { valueType = null; }
    records.push({
        address: address,
        name: propName,
        matchName: propMatchName,
        valueType: valueType,
        keys: keys,
        hasValue: hasValue,
        value: value,
        expression: expression,
        expressionEnabled: expressionEnabled
    });
}

function _ekCapturePasteGroup(group, seen, records) {
    var n = 0, groupMatch = "";
    try { groupMatch = group.matchName || ""; } catch (eM) { groupMatch = ""; }
    try { n = group.numProperties || 0; } catch (e0) { n = 0; }
    for (var i = 1; i <= n; i++) {
        var p = null, leaf = false;
        try { p = group.property(i); } catch (e1) { p = null; }
        if (!p) continue;
        try { leaf = (p.propertyType === PropertyType.PROPERTY); } catch (e2) { leaf = false; }
        if (leaf) {
            // Animator Properties enumera tambien hojas virtuales nunca
            // añadidas. Solo una hoja modificada, animada, seleccionada o con
            // expresion representa una propiedad real que deba reconstruirse.
            if (groupMatch === "ADBE Text Animator Properties") {
                var present = false, pn = 0, pk = [], px = "";
                try { present = !!p.isModified; } catch (eP0) { present = false; }
                try { pn = p.numKeys || 0; } catch (eP1) { pn = 0; }
                try { pk = p.selectedKeys || []; } catch (eP2) { pk = []; }
                try { if (p.canSetExpression) px = p.expression || ""; } catch (eP3) { px = ""; }
                if (!present && !pn && !pk.length && !px) continue;
            }
            _ekCapturePasteLeaf(p, seen, records);
        }
        else _ekCapturePasteGroup(p, seen, records);
    }
}

function _ekPasteFitValueEqual(a, b) {
    if (typeof a === "number" && typeof b === "number") {
        if (isNaN(a) && isNaN(b)) return true;
        // Muchos plugins almacenan sus controles como float32 aunque el API
        // entregue doubles. 140.8 puede volver como 140.800003: es el mismo
        // valor visual y no debe provocar rondas de escritura innecesarias.
        var tolerance = Math.max(1e-5, Math.max(Math.abs(a), Math.abs(b)) * 1e-6);
        return Math.abs(a - b) <= tolerance;
    }
    if (a instanceof Array && b instanceof Array) {
        if (a.length !== b.length) return false;
        for (var i = 0; i < a.length; i++) {
            if (!_ekPasteFitValueEqual(a[i], b[i])) return false;
        }
        return true;
    }
    if ((typeof a === "string" || typeof a === "boolean") && typeof a === typeof b) return a === b;
    // Shape, TextDocument, MarkerValue y valores personalizados no tienen una
    // comparacion publica fiable. Si setValue no lanzo error se consideran
    // escritos; los tipos escalares y vectores si se verifican arriba.
    return true;
}

function _ekSetPasteFitStatic(layer, rec) {
    var prop = _ekPasteFitProperty(layer, rec.address, true);
    if (!prop) return false;
    try { prop.setValue(rec.value); } catch (e0) {
        // Añadir otra hoja dinamica puede invalidar la referencia anterior.
        prop = _ekPasteFitProperty(layer, rec.address, true);
        if (!prop) return false;
        try { prop.setValue(rec.value); } catch (e1) { return false; }
    }
    try { return _ekPasteFitValueEqual(prop.value, rec.value); } catch (e2) { return true; }
}

function _ekPasteFitAddressContains(address, matchName) {
    for (var i = 0; i < address.length; i++) {
        if (address[i].matchName === matchName) return true;
    }
    return false;
}

/* Algunos efectos de terceros terminan de inicializarse despues de volver el
   control a CEP y restauran entonces varios parametros a sus defaults. Una
   segunda escritura inmediata no sirve: ambas ocurren antes de ese reinicio.
   Estas tareas tardias comparan antes de tocar nada y solo reparan los valores
   escalares o vectores que realmente hayan cambiado. */
var _ekPasteFitDeferredJobs = {};
var _ekPasteFitDeferredNextId = 1;

function _ekPasteFitValueCanCompare(value) {
    if (typeof value === "number" || typeof value === "string" || typeof value === "boolean") return true;
    if (value instanceof Array) {
        for (var i = 0; i < value.length; i++) if (!_ekPasteFitValueCanCompare(value[i])) return false;
        return true;
    }
    return false;
}

function _ekQueuePasteFitDeferred(layers, records) {
    var effectRecords = [];
    for (var i = 0; i < records.length; i++) {
        var rec = records[i];
        if (!rec.hasValue || (rec.keys && rec.keys.length)) continue;
        if (!_ekPasteFitAddressContains(rec.address, "ADBE Effect Parade")) continue;
        if (!_ekPasteFitValueCanCompare(rec.value)) continue;
        effectRecords.push(rec);
    }
    if (!effectRecords.length) return;

    var id = _ekPasteFitDeferredNextId++;
    _ekPasteFitDeferredJobs[id] = { layers: layers.slice(), records: effectRecords, pass: 0 };
    try { app.scheduleTask("_ekRunPasteFitDeferred(" + id + ")", 180, false); }
    catch (e0) { delete _ekPasteFitDeferredJobs[id]; }
}

function _ekRunPasteFitDeferred(id) {
    var job = _ekPasteFitDeferredJobs[id];
    if (!job) return;
    var changed = 0;
    try {
        app.beginUndoGroup("QuickIt: finalize Paste & Fit");
        for (var li = 0; li < job.layers.length; li++) {
            var layer = job.layers[li];
            if (!layer) continue;
            for (var ri = 0; ri < job.records.length; ri++) {
                var rec = job.records[ri], prop = _ekPasteFitProperty(layer, rec.address, false);
                if (!prop) continue;
                var same = false;
                try { same = _ekPasteFitValueEqual(prop.value, rec.value); } catch (eV) { same = true; }
                if (same) continue;
                if (_ekSetPasteFitStatic(layer, rec)) changed++;
            }
        }
    } catch (e0) {
    } finally {
        try { app.endUndoGroup(); } catch (e1) {}
    }

    job.pass++;
    if (job.pass < 2) {
        // Una comprobacion rapida y otra tras la inicializacion lenta del plugin.
        try { app.scheduleTask("_ekRunPasteFitDeferred(" + id + ")", 720, false); }
        catch (e2) { delete _ekPasteFitDeferredJobs[id]; }
    } else {
        delete _ekPasteFitDeferredJobs[id];
    }
}

function _ekPreparePasteFitStructure(layer, groups, records) {
    var i, pass;
    // Los grupos antes que las hojas: crear un efecto o un Animator invalida
    // referencias internas ya obtenidas. Repetir deja la estructura estable
    // incluso con varios animadores, selectores o efectos iguales.
    for (pass = 0; pass < 3; pass++) {
        for (i = 0; i < groups.length; i++) {
            var targetGroup = _ekEnsurePropertyAddress(layer, groups[i].address);
            if (!targetGroup) continue;
            try { if (groups[i].name) targetGroup.name = groups[i].name; } catch (eGN) {}
            try { if (groups[i].enabled !== null) targetGroup.enabled = groups[i].enabled; } catch (eGE) {}
        }
        for (i = 0; i < records.length; i++) {
            _ekPasteFitProperty(layer, records[i].address, true);
        }
    }
}

// La propiedad que hace visible una animacion de texto casi nunca es la misma
// que lleva los keyframes: Inicio anima el rango, mientras Opacidad, Tracking,
// color, etc. viven como hermanas dentro del Animator. Lo mismo ocurre con un
// parametro animado de un efecto. Capturar el propietario dinamico completo
// conserva ese contexto igual que un preset .ffx.
function _ekPasteFitOwner(prop) {
    var p = prop, guard = 0;
    while (p && guard++ < 40) {
        var mn = "", par = null, pm = "";
        try { mn = p.matchName || ""; } catch (e0) { mn = ""; }
        if (mn === "ADBE Text Animator") return p;
        try { par = p.parentProperty; } catch (e1) { par = null; }
        if (!par) break;
        try { pm = par.matchName || ""; } catch (e2) { pm = ""; }
        if (pm === "ADBE Effect Parade") return p;
        p = par;
    }
    return null;
}

function _ekRememberPasteGroup(group, seen, groups) {
    var par = null, pm = "", id = "", name = "", enabled = null;
    try { par = group.parentProperty; pm = par ? (par.matchName || "") : ""; } catch (e0) { pm = ""; }
    if (pm !== "ADBE Text Animators" && pm !== "ADBE Text Selectors" && pm !== "ADBE Effect Parade") return;
    try { id = _ekPropPath(group); } catch (e1) { id = ""; }
    if (!id || seen[id]) return;
    try { name = group.name || ""; } catch (e2) { name = ""; }
    try { enabled = !!group.enabled; } catch (e3) { enabled = null; }
    seen[id] = true;
    groups.push({ address: _ekPropertyAddress(group), name: name, enabled: enabled });
}

function _ekRememberPasteGroups(group, seen, groups) {
    var n = 0;
    try { n = group.numProperties || 0; } catch (e0) { n = 0; }
    for (var i = 1; i <= n; i++) {
        var p = null, leaf = false;
        try { p = group.property(i); } catch (e1) { p = null; }
        if (!p) continue;
        try { leaf = (p.propertyType === PropertyType.PROPERTY); } catch (e2) { leaf = false; }
        if (leaf) continue;
        _ekRememberPasteGroup(p, seen, groups);
        _ekRememberPasteGroups(p, seen, groups);
    }
}

function _ekBuildPasteFitCapture(comp) {
    var layers = _ekSel(comp), records = [], seen = {}, expanded = {}, groups = [], groupSeen = {}, i, j;
    for (i = 0; i < layers.length; i++) {
        var props = [];
        try { props = layers[i].selectedProperties || []; } catch (e0) { props = []; }
        for (j = 0; j < props.length; j++) {
            var leaf = false, owner = _ekPasteFitOwner(props[j]), ownerId = "";
            if (owner) {
                try { ownerId = _ekPropPath(owner); } catch (eOwner) { ownerId = ""; }
                if (ownerId && !expanded[ownerId]) {
                    expanded[ownerId] = true;
                    _ekCapturePasteGroup(owner, seen, records);
                    _ekRememberPasteGroup(owner, groupSeen, groups);
                    _ekRememberPasteGroups(owner, groupSeen, groups);
                }
                continue;
            }
            try { leaf = (props[j].propertyType === PropertyType.PROPERTY); } catch (e1) { leaf = false; }
            if (leaf) _ekCapturePasteLeaf(props[j], seen, records);
            else {
                _ekCapturePasteGroup(props[j], seen, records);
                _ekRememberPasteGroup(props[j], groupSeen, groups);
                _ekRememberPasteGroups(props[j], groupSeen, groups);
            }
        }
    }

    var lo = null, hi = null;
    for (i = 0; i < records.length; i++) {
        for (j = 0; j < records[i].keys.length; j++) {
            var t = records[i].keys[j].t;
            if (lo === null || t < lo) lo = t;
            if (hi === null || t > hi) hi = t;
        }
    }
    return { records: records, groups: groups, lo: lo, hi: hi, properties: records.length };
}

function ek_capturePasteFit(jsonStr) {
    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var sel = _ekSel(comp);
    if (!sel.length) return _ekBad("noSel");

    var captured = _ekBuildPasteFitCapture(comp);
    if (!captured.records.length) return _ekBad("pasteNothingSelected");
    _ekPasteFitCapture = captured;
    return _ekGood({ captured: true, properties: captured.properties });
}

/* PEGA LA CAPTURA INTERNA Y LA AJUSTA A CADA CAPA.

   Es la pareja espontanea de los presets: para una animacion que se va a
   reutilizar muchas veces compensa guardarla como .ffx; para la que acaba de
   hacerse y solo hace falta repetir ahora, obligar a crear e indexar un preset
   es trabajo perdido.

   Cada destino se procesa por separado. Primero se recrea la estructura de
   propiedades y luego se escriben sus valores o keyframes ajustando el tramo
   global capturado a los puntos de entrada y salida de esa capa. */
function ek_pasteAndFit(jsonStr) {
    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var sel = _ekSel(comp);
    if (!sel.length) return _ekBad("noSel");
    if (!_ekPasteFitCapture) return _ekBad("pasteCaptureRequired");

    var layers = sel.slice();
    layers.sort(function (a, b) {
        var ia = 0, ib = 0;
        try { ia = a.index; } catch (e1) {}
        try { ib = b.index; } catch (e2) {}
        return ia - ib;
    });

    var capture = _ekPasteFitCapture;
    var records = capture.records || [];
    if (!records.length) return _ekBad("pasteCaptureRequired");

    var pasted = 0, fitted = 0, staticValues = 0, withoutKeys = 0, effectsAdded = 0;
    app.beginUndoGroup("QuickIt: Paste & Fit");
    try {
        for (var i = 0; i < layers.length; i++) {
            var L = layers[i], lin = 0, lout = comp.duration;
            try { lin = L.inPoint; lout = L.outPoint; } catch (e3) {}
            var effectsBefore = _ekEffectCount(L);
            var ri;
            var captureGroups = capture.groups || [];
            _ekPreparePasteFitStructure(L, captureGroups, records);

            var sourceLen = (capture.lo !== null && capture.hi !== null) ? capture.hi - capture.lo : 0;
            var targetLen = lout - lin;
            var scale = (sourceLen > 1e-9 && targetLen > 1e-9) ? targetLen / sourceLen : 1;
            var appliedHere = 0;

            // Segunda pasada: primero las curvas. Los valores fijos se escriben
            // despues porque algunos efectos, al recibir un parametro animado,
            // reinicializan otros controles del mismo efecto.
            for (ri = 0; ri < records.length; ri++) {
                var rec = records[ri];
                if (!rec.keys || !rec.keys.length) continue;
                var targetProp = _ekPasteFitProperty(L, rec.address, true);
                if (!targetProp) continue;

                var news = [];
                for (var ki = 0; ki < rec.keys.length; ki++) {
                    var base = (capture.lo === null) ? rec.keys[ki].t : capture.lo;
                    news.push(lin + (rec.keys[ki].t - base) * scale);
                }
                var placed = _ekWriteKeys(targetProp, rec.keys, news, scale, false);
                if (!placed || !placed.length) {
                    targetProp = _ekPasteFitProperty(L, rec.address, true);
                    if (targetProp) placed = _ekWriteKeys(targetProp, rec.keys, news, scale, false);
                }
                if (placed && placed.length) {
                    fitted += placed.length;
                    appliedHere += placed.length;
                }

                if (rec.expression) {
                    try {
                        targetProp.expression = rec.expression;
                        targetProp.expressionEnabled = rec.expressionEnabled;
                        if (!appliedHere) appliedHere++;
                    } catch (eX) {}
                }
            }

            // Tercera pasada: valores sin fotogramas. Se hacen dos rondas y se
            // verifica el resultado porque controles como presets internos,
            // modos o casillas de plugins pueden restaurar a valores por defecto
            // otros parametros que ya se habian escrito.
            for (var valuePass = 0; valuePass < 2; valuePass++) {
                for (ri = 0; ri < records.length; ri++) {
                    rec = records[ri];
                    if (!rec.hasValue || (rec.keys && rec.keys.length)) continue;
                    var writeStatic = (valuePass === 0);
                    if (!writeStatic) {
                        var verifyProp = _ekPasteFitProperty(L, rec.address, false);
                        try { writeStatic = verifyProp ? !_ekPasteFitValueEqual(verifyProp.value, rec.value) : true; }
                        catch (eVerify) { writeStatic = false; }
                    }
                    if (writeStatic && _ekSetPasteFitStatic(L, rec)) {
                        if (valuePass === 0) {
                            staticValues++;
                            appliedHere++;
                        }
                    }
                }
            }

            // Las expresiones de propiedades estaticas tambien van al final:
            // setValue puede desactivarlas temporalmente en algunas versiones.
            for (ri = 0; ri < records.length; ri++) {
                rec = records[ri];
                if (!rec.expression || (rec.keys && rec.keys.length)) continue;
                var expressionProp = _ekPasteFitProperty(L, rec.address, true);
                if (!expressionProp) continue;
                try {
                    expressionProp.expression = rec.expression;
                    expressionProp.expressionEnabled = rec.expressionEnabled;
                } catch (eSX) {}
            }

            var effectDelta = _ekEffectCount(L) - effectsBefore;
            if (effectDelta < 0) effectDelta = 0;
            effectsAdded += effectDelta;
            if (appliedHere || effectDelta) pasted++;
            else withoutKeys++;
        }
    } catch (e7) {
        app.endUndoGroup();
        _ekReselect(comp, layers);
        return _ekBad("hostErr", _aeErr(e7));
    }
    _ekReselect(comp, layers);
    app.endUndoGroup();

    // Debe programarse despues de cerrar el grupo principal: los plugins que
    // reinician sus controles lo hacen precisamente al regresar al bucle de AE.
    _ekQueuePasteFitDeferred(layers, records);

    if (!pasted) {
        return _ekBad("pasteNoKeys");
    }
    return _ekGood({
        layers: pasted,
        keys: fitted,
        values: staticValues,
        effects: effectsAdded,
        skipped: withoutKeys,
        capturedProperties: capture.properties || records.length
    });
}

/* El dialogo de archivo lo abre el host y no el navegador: un <input type=file>
   devuelve una ruta falseada por seguridad, y esa ruta hay que poder volver a
   usarla en el siguiente arranque. El filtro solo se pone en Windows: en macOS
   el segundo argumento de openDialog es una funcion, no una cadena, y pasarle
   una cadena deja el dialogo sin mostrar nada. */
function ek_pickFile(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { o = {}; }
    var kind = String(o.kind || "script");

    var title = (kind === "preset") ? "Elegir un preset de animacion" : "Elegir un script";
    var filter = (kind === "preset") ? "Presets:*.ffx" : "Scripts:*.jsx;*.jsxbin";

    /* Donde se abre el dialogo. Sin decirle nada, se abre donde estuviera la
       ultima vez, que para un preset casi nunca es donde estan los presets: se
       le pasa la carpeta del usuario y se ahorra el paseo por medio disco.

       El truco es que el dialogo se abra "desde" un archivo de esa carpeta —el
       metodo de instancia, no el estatico—. Ese archivo no tiene que existir;
       lo unico que se usa de el es la carpeta en la que estaria. */
    var startAt = String(o.dir || "");
    if (!startAt && kind === "preset") {
        var pd = null;
        try { pd = JSON.parse(ek_userPresetsDir()); } catch (eD) { pd = null; }
        if (pd && pd.ok) startAt = pd.path;
    }

    try {
        var isWin = false;
        try { isWin = String($.os).toLowerCase().indexOf("win") !== -1; } catch (eOS) {}

        var f = null;
        if (startAt) {
            var seed = new File(startAt + "/.");
            f = isWin ? seed.openDlg(title, filter) : seed.openDlg(title);
        } else {
            f = isWin ? File.openDialog(title, filter) : File.openDialog(title);
        }
        if (!f) return _ekJ({ ok: false, code: "canceled" });

        // El nombre sin extension es lo que se ensena en el boton: ".ffx" no
        // aporta nada dentro de una celda de tres caracteres.
        var n = String(f.name);
        var dot = n.lastIndexOf(".");
        if (dot > 0) n = n.substring(0, dot);

        return _ekGood({ path: f.fsName, name: decodeURIComponent(n) });
    } catch (e) {
        return _ekBad("hostErr", _aeErr(e));
    }
}

/* ============================================================================
   B5 · PRECOMPONER CADA CAPA POR SEPARADO

   La precomposicion de After Effects mete toda la seleccion en UNA sola
   composicion. Lo que hace falta muchas veces es lo contrario: veinte capas,
   veinte precomposiciones, cada una con la suya dentro. A mano son veinte
   pasadas por el mismo dialogo, y en el camino se pierde el orden y, en cuanto
   una capa no empieza en cero, tambien la duracion.

   Lo que garantiza esta funcion:

     · UNA precomposicion por capa, con el nombre de la capa.
     · El ORDEN se mantiene solo. Precomponer una sola capa la saca y mete la
       nueva en su mismo indice: entra una y sale una, asi que ninguna otra se
       mueve. Es la razon de hacerlo de una en una y no en bloque.
     · La DURACION es la de la capa, no la de la composicion padre. Es la
       casilla "Ajustar la duracion de la composicion al intervalo de tiempo de
       las capas seleccionadas" del dialogo de After Effects, que el metodo de
       scripting no ofrece: hay que hacerla a mano, y la hace
       _ekFitPrecompToLayer justo aqui debajo.
     · Y no se rompe nada de lo que suele romperse: el emparentado, las capas
       de ajuste y las guia.

   Sobre lo ultimo. "Mover todos los atributos" es lo normal y lo unico que
   admiten texto y formas, pero se lleva la transformacion DENTRO de la
   precomposicion. Con eso:

     · una capa de la que cuelgan otras deja de arrastrarlas, porque por fuera
       se queda con la transformacion en cero;
     · una capa de ajuste deja de afectar a lo que tiene debajo y pasa a
       afectar solo a lo que hay dentro de su propia precomposicion;
     · una capa guia deja de ser guia.

   En esos tres casos se deja la transformacion fuera. Y si After Effects no
   admite ese modo para esa capa —texto y formas—, se vuelve al normal: mejor
   precomponerla de la forma que sea que dejarla sin hacer y sin decir nada.
   ============================================================================ */
/* ----------------------------------------------------------------------
   Encoger una precomposicion recien hecha al trozo que se ve

   `LayerCollection.precompose()` no tiene la casilla "Ajustar la duracion de
   la composicion al intervalo de tiempo de las capas seleccionadas" que sale
   en el dialogo de After Effects. Lo que hace siempre es crear una composicion
   con la duracion de la composicion padre y dejar el contenido dentro en su
   tiempo absoluto; la capa nueva abarca de cero al final.

   Sin esto, recortar esa capa a la entrada y la salida de la que habia antes
   deja el resultado correcto A LA VISTA pero mal por dentro: la barra mide lo
   que debe, pero la composicion sigue durando lo que la padre y la capa esta
   recortada, con manijas a los dos lados. Es exactamente lo que se veia —"la
   recorta en lugar de que dure lo que debe"— y lo que hacia que "sacar a la
   composicion padre" devolviera el contenido a otro tiempo: al leer dentro, lo
   que hay en el segundo tres esta en el segundo tres, no en el cero.

   Lo que hace esta funcion, que es lo mismo que hace el dialogo:

     1. mide en tiempo de dentro el trozo visible de la capa;
     2. corre todo el contenido para que ese trozo empiece en cero;
     3. le pone a la composicion exactamente esa duracion;
     4. y vuelve a colocar la capa donde estaba.

   Se mide en vez de darlo por supuesto. El tiempo de dentro que corresponde a
   un tiempo de fuera es (fuera - arranque) / estirado, y se usa tal cual: asi
   da igual lo que precompose haya decidido dejar dentro o fuera, y da igual si
   la capa venia con el tiempo estirado.

   Lo que se corre es `startTime` de cada capa de dentro, que arrastra consigo
   la entrada, la salida y los fotogramas clave. Las manijas que quedan antes
   de cero no se pierden: siguen ahi, en tiempo negativo, igual que las deja
   After Effects.
   ---------------------------------------------------------------------- */
function _ekFitPrecompToLayer(nl) {
    var pc = null;
    try { pc = nl.source; } catch (e) { return; }
    if (!pc || !(pc instanceof CompItem)) return;

    var st = 0, k = 1, vIn = 0, vOut = 0;
    try { st = nl.startTime; } catch (e2) { return; }
    try { k = nl.stretch / 100; } catch (e3) { k = 1; }
    if (!isFinite(k) || Math.abs(k) < 1e-6) k = 1;
    try { vIn = nl.inPoint; vOut = nl.outPoint; } catch (e4) { return; }

    var lo = (vIn - st) / k;
    var hi = (vOut - st) / k;
    var span = hi - lo;
    if (!isFinite(span) || span <= 0) return;

    // Una composicion no puede durar menos de un cuadro.
    var oneFrame = 1 / 24;
    try { if (pc.frameRate > 0) oneFrame = 1 / pc.frameRate; } catch (e5) {}
    if (span < oneFrame) span = oneFrame;

    if (Math.abs(lo) > 1e-9) {
        for (var i = 1; i <= pc.numLayers; i++) {
            try { pc.layer(i).startTime = pc.layer(i).startTime - lo; } catch (e6) {}
        }
    }

    try { pc.duration = span; } catch (e7) {}
    // El area de trabajo se queda apuntando a donde ya no hay composicion.
    try { pc.workAreaStart = 0; } catch (e8) {}
    try { pc.workAreaDuration = pc.duration; } catch (e9) {}

    /* Y la capa de vuelta a su sitio: con el contenido empezando en cero, el
       arranque de la capa ES su entrada. La entrada y la salida se reescriben
       porque moverla las arrastro. */
    try { nl.startTime = vIn; } catch (eA) {}
    try { nl.inPoint = vIn; } catch (eB) {}
    try { nl.outPoint = vOut; } catch (eC) {}
}

/* El tramo que ocupan unas capas en la linea de tiempo: de la entrada mas
   temprana a la salida mas tardia. No es lo mismo que la duracion de una de
   ellas —tres capas escalonadas ocupan mas que cualquiera por separado— y es
   lo que hace falta para recortar algo a la medida de un grupo. */
function _ekTimeSpan(layers) {
    var lo = null, hi = null;
    for (var i = 0; i < layers.length; i++) {
        var a, b;
        try { a = layers[i].inPoint; b = layers[i].outPoint; } catch (e) { continue; }
        if (!isFinite(a) || !isFinite(b) || b <= a) continue;
        if (lo === null || a < lo) lo = a;
        if (hi === null || b > hi) hi = b;
    }
    if (lo === null) return null;
    return { lo: lo, hi: hi };
}

/* ============================================================================
   DOS COSAS QUE SE HACEN CIEN VECES AL DIA Y SE HACEN A MANO

   Poner una capa de ajuste encima de algo, y meter varias capas en una sola
   composicion. Las dos existen en After Effects y las dos cuestan mas clics de
   los que valen.

   Comparten boton: un clic pone la capa de ajuste, Control y clic precompone.
   Van juntas porque se usan en el mismo momento y para lo mismo —tratar un
   grupo de capas como si fuera una— y porque quien acaba de precomponer suele
   querer una capa de ajuste encima, y al reves.
   ============================================================================ */

/* LA CAPA DE AJUSTE, CON LA DURACION DE LA CAPA QUE HAY DEBAJO

   Una capa de ajuste que dura toda la composicion cuando la capa que va a
   afectar dura dos segundos es una capa de ajuste mal puesta: afecta a lo que
   haya antes y despues, que casi nunca es lo que se queria. After Effects la
   crea siempre de comp entera y arriba del todo, y recolocarla y recortarla a
   mano es lo que se hace cada vez.

   UNA POR CAPA. Con tres capas elegidas salen tres capas de ajuste, cada una
   justo encima de la suya y con su duracion. Ponia una sola, sobre la mas alta,
   y eso deja a las otras dos sin nada: quien elige tres capas y pide una capa
   de ajuste las quiere tratadas a las tres.

   Y con `span: "comp"` —Control y clic— lo mismo, en los mismos sitios, pero
   durando cada una toda la composicion. Lo unico que cambia entre las dos
   variantes es hasta donde llegan.

   Sin nada seleccionado nace una sola, arriba del todo y con la composicion
   entera, que es lo que hace el programa cuando no se le ha senalado a que capa
   acompanar. */
function ek_addAdjustment(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");

    var sel = _ekSel(comp), i;
    var wholeComp = (String(o.span || "layer") === "comp");
    var name = String(o.name || "Ajuste");

    /* Se apuntan las capas de referencia ANTES de crear nada: cada capa nueva
       corre los indices de las demas, y una lista de objetos no se descoloca.
       De arriba abajo, para que al insertar cada una encima de la suya el
       resultado conserve el orden que tenia la seleccion. */
    var refs = [];
    for (i = 0; i < sel.length; i++) refs.push(sel[i]);
    refs.sort(function (x, y) {
        var a1 = 0, b1 = 0;
        try { a1 = x.index; } catch (e1) {}
        try { b1 = y.index; } catch (e2) {}
        return a1 - b1;
    });

    var pa = 1;
    try { pa = comp.pixelAspect || 1; } catch (e3) { pa = 1; }

    app.beginUndoGroup("EDITKIT: capa de ajuste");
    try {
        var made = [], failed = 0;

        function one(ref) {
            var inP = 0, outP = comp.duration;
            if (ref && !wholeComp) {
                try { inP = ref.inPoint; outP = ref.outPoint; } catch (e4) { inP = 0; outP = comp.duration; }
            }
            if (!isFinite(inP) || !isFinite(outP) || outP <= inP) { inP = 0; outP = comp.duration; }

            /* La fuente tiene que ser lo bastante larga para cubrir el tramo, y
               se hace arrancar donde arranca la capa: asi la entrada puede ser
               exactamente la de la de abajo en lugar de quedarse limitada por
               donde empieza su material. */
            var dur = outP - inP;
            try { if (comp.duration > dur) dur = comp.duration; } catch (e5) {}

            var adj = null;
            try {
                adj = comp.layers.addSolid([1, 1, 1], name, comp.width, comp.height, pa, dur);
            } catch (e6) { adj = null; }
            if (!adj) { failed++; return null; }

            try { adj.adjustmentLayer = true; } catch (e7) {}
            try { adj.label = 5; } catch (e8) {}

            // Primero el arranque y despues los extremos: mover una capa
            // arrastra su entrada y su salida con ella.
            try { adj.startTime = inP; } catch (e9) {}
            try { adj.inPoint = inP; } catch (e10) {}
            try { adj.outPoint = outP; } catch (e11) {}

            try { if (ref && ref !== adj) adj.moveBefore(ref); } catch (e12) {}
            return adj;
        }

        if (!refs.length) {
            var solo = one(null);
            if (solo) made.push(solo);
        } else {
            for (i = 0; i < refs.length; i++) {
                var made1 = one(refs[i]);
                if (made1) made.push(made1);
            }
        }

        if (!made.length) return _ekBad("cantAddLayer");

        // Quedan seleccionadas las nuevas: lo siguiente que se hace con una
        // capa de ajuste es ponerle un efecto, y se le pone a todas a la vez.
        try {
            for (i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false;
            for (i = 0; i < made.length; i++) made[i].selected = true;
        } catch (e13) {}

        return _ekGood({
            name: name,
            layers: made.length,
            failed: failed,
            over: refs.length ? String(refs[0].name) : "",
            span: wholeComp ? "comp" : "layer"
        });
    } catch (e14) {
        return _ekBad("hostErr", _aeErr(e14));
    } finally {
        app.endUndoGroup();
    }
}

/* ============================================================================
   CUATRO CAPAS DE UN CLIC

   Un solido, una forma vacia, una camara y un congelado. Las cuatro estan en
   After Effects y las cuatro cuestan mas de lo que valen: un menu, un cuadro de
   dialogo y un par de decisiones que casi siempre son la misma.

   Las tres primeras comparten la regla de duracion que ya llevan la capa de
   ajuste y el nulo: de fabrica la composicion entera, y con `span: "sel"`
   —Control y clic— lo que dura la seleccion, de la entrada mas temprana a la
   salida mas tardia. Es la misma capa en el mismo sitio; lo unico que cambia es
   hasta donde llega.
   ============================================================================ */

/* Cuanto tiene que durar algo que se crea ahora, segun la regla de arriba.
   Devuelve {lo, hi} en tiempo de composicion. */
function _ekNewSpan(comp, sel, mode) {
    if (mode === "sel" && sel && sel.length) {
        var sp = _ekTimeSpan(sel);
        if (sp) return sp;
    }
    var d = 1;
    try { d = comp.duration; } catch (e) { d = 1; }
    return { lo: 0, hi: d };
}

// Colocar una capa recien creada en su tramo, y encima de la mas alta de la
// seleccion si habia alguna.
function _ekPlaceNew(L, span, ref) {
    try { L.startTime = span.lo; } catch (e1) {}
    try { L.inPoint = span.lo; } catch (e2) {}
    try { L.outPoint = span.hi; } catch (e3) {}
    try { if (ref && ref !== L) L.moveBefore(ref); } catch (e4) {}
}

function _ekTopOf(sel) {
    var top = null;
    for (var i = 0; i < sel.length; i++) {
        try { if (!top || sel[i].index < top.index) top = sel[i]; } catch (e) {}
    }
    return top;
}

function _ekSelectOnlyLayer(comp, L) {
    try {
        for (var i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false;
        if (L) L.selected = true;
    } catch (e) {}
}

/* UN SOLIDO

   Del tamano de la composicion, que es el tamano que se quiere el noventa por
   ciento de las veces —un fondo, una mascara, algo a lo que colgarle un
   efecto—. El color viene del panel para que se pueda elegir sin abrir nada. */
function ek_addSolid(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var sel = _ekSel(comp);

    var rgb = [0, 0, 0];
    var hex = String(o.color || "#000000");
    var m = hex.replace("#", "");
    if (m.length === 6) {
        rgb = [
            parseInt(m.substring(0, 2), 16) / 255,
            parseInt(m.substring(2, 4), 16) / 255,
            parseInt(m.substring(4, 6), 16) / 255
        ];
    }
    for (var c = 0; c < 3; c++) { if (!isFinite(rgb[c])) rgb[c] = 0; }

    var span = _ekNewSpan(comp, sel, String(o.span || "comp"));
    var name = String(o.name || "Solido");

    app.beginUndoGroup("EDITKIT: solido");
    try {
        var pa = 1;
        try { pa = comp.pixelAspect || 1; } catch (e1) { pa = 1; }
        var dur = span.hi - span.lo;
        try { if (comp.duration > dur) dur = comp.duration; } catch (e2) {}

        var L = null;
        try { L = comp.layers.addSolid(rgb, name, comp.width, comp.height, pa, dur); }
        catch (e3) { L = null; }
        if (!L) return _ekBad("cantAddLayer");

        _ekPlaceNew(L, span, _ekTopOf(sel));
        _ekSelectOnlyLayer(comp, L);
        return _ekGood({ name: name, inPoint: _ekRound(span.lo, 4), outPoint: _ekRound(span.hi, 4) });
    } catch (e4) {
        return _ekBad("hostErr", _aeErr(e4));
    } finally {
        app.endUndoGroup();
    }
}

/* UNA CAPA DE FORMA, VACIA

   Sin rectangulo ni elipse dentro: vacia es lo que hace falta para empezar a
   dibujar con la pluma, y lo que pone el programa al usar el menu. */
function ek_addShape(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var sel = _ekSel(comp);
    var span = _ekNewSpan(comp, sel, String(o.span || "comp"));

    app.beginUndoGroup("EDITKIT: capa de forma");
    try {
        var L = null;
        try { L = comp.layers.addShape(); } catch (e1) { L = null; }
        if (!L) return _ekBad("cantAddLayer");

        if (o.name) { try { L.name = String(o.name); } catch (e2) {} }
        _ekPlaceNew(L, span, _ekTopOf(sel));
        _ekSelectOnlyLayer(comp, L);
        return _ekGood({ name: String(L.name), inPoint: _ekRound(span.lo, 4), outPoint: _ekRound(span.hi, 4) });
    } catch (e3) {
        return _ekBad("hostErr", _aeErr(e3));
    } finally {
        app.endUndoGroup();
    }
}

/* UNA CAPA DE TEXTO, CENTRADA

   addText crea texto puntual nativo: no hay expresiones, efectos ni capas
   auxiliares que condicionen lo que el usuario haga despues. Se centra por
   los limites visibles —no solo por la posicion de su linea base— y queda
   seleccionada para que el siguiente gesto sea editarla o animarla.

   La duracion sigue la misma regla de Solido y Forma. Esto mantiene coherente
   el boton tanto en la categoria Comp como en la rejilla personalizable. */
function ek_addText(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var sel = _ekSel(comp);
    var span = _ekNewSpan(comp, sel, String(o.span || "comp"));
    var text = String(o.text || "Text");

    app.beginUndoGroup("EDITKIT: capa de texto");
    try {
        var L = null;
        try { L = comp.layers.addText(text); } catch (e1) { L = null; }
        if (!L) return _ekBad("cantAddLayer");

        /* Primero se mide el texto con el estilo que After Effects acaba de
           asignarle; asi no imponemos fuente, tamano, color ni interlineado. */
        try {
            var rect = L.sourceRectAtTime(comp.time, false);
            var tr = L.property("ADBE Transform Group");
            var anchor = tr.property("ADBE Anchor Point");
            var position = tr.property("ADBE Position");
            if (rect && anchor && position) {
                anchor.setValue([rect.left + rect.width / 2, rect.top + rect.height / 2]);
                position.setValue([comp.width / 2, comp.height / 2]);
            }
        } catch (e2) {
            /* Si una version antigua no puede medirla, addText ya la coloca
               cerca del centro. Crear la capa sigue siendo mas importante que
               fallar toda la accion por el centrado visual. */
        }

        _ekPlaceNew(L, span, _ekTopOf(sel));
        _ekSelectOnlyLayer(comp, L);
        return _ekGood({ name: String(L.name), inPoint: _ekRound(span.lo, 4), outPoint: _ekRound(span.hi, 4) });
    } catch (e3) {
        return _ekBad("hostErr", _aeErr(e3));
    } finally {
        app.endUndoGroup();
    }
}

/* UNA CAMARA

   De dos nodos —con punto de interes— de fabrica, que es la que trae el
   programa por defecto y la que quiere quien va a orbitar algo. Con
   `oneNode: true` —Control y clic— de un nodo, que es la que quiere quien va a
   moverla a mano o a colgarla de un nulo. */
function ek_addCamera(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");

    var name = String(o.name || "Camara");
    var oneNode = !!o.oneNode;

    app.beginUndoGroup("EDITKIT: camara");
    try {
        var cx = comp.width / 2, cy = comp.height / 2;
        var L = null;
        try { L = comp.layers.addCamera(name, [cx, cy]); } catch (e1) { L = null; }
        if (!L) return _ekBad("cantAddLayer");

        /* Una camara de un nodo es una de dos nodos a la que se le apaga el
           enfoque automatico sobre el punto de interes: se consigue poniendo la
           orientacion a cero y dejando el punto de interes bajo la camara.
           After Effects no deja elegirlo por script al crearla, asi que se
           coloca el punto de interes delante de ella —a su misma altura— para
           que apunte al frente y no gire sola. */
        if (oneNode) {
            try {
                var pos = L.property("ADBE Transform Group").property("ADBE Position").value;
                L.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([pos[0], pos[1], 0]);
            } catch (e2) {}
        }

        _ekSelectOnlyLayer(comp, L);
        return _ekGood({ name: String(L.name), oneNode: oneNode });
    } catch (e3) {
        return _ekBad("hostErr", _aeErr(e3));
    } finally {
        app.endUndoGroup();
    }
}

/* PARALLAX AUTOMATICO

   Una pila 2D no produce parallax solo por encender el cubo 3D: hay que darle
   profundidad y, al hacerlo, compensar posicion y escala para que el encuadre
   del fotograma actual no salte. Esta funcion prepara ese estado y deja la
   camara lista para animarse. Todo queda dentro de un solo Deshacer.

   Las capas con transformaciones animadas, expresiones o padres se dejan
   intactas. Alterarlas exigiría reescribir su animacion o su jerarquia, algo
   demasiado invasivo para una accion de un clic. */
function ek_autoParallax(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var selected = _ekSel(comp);
    if (!selected || selected.length < 2) return _ekBad("parallaxNeedTwo");

    var depth = Number(o.depth);
    if (!isFinite(depth)) depth = 350;
    depth = Math.max(25, Math.min(5000, Math.abs(depth)));

    var layers = [], skipped = 0, i;
    for (i = 0; i < selected.length; i++) {
        var L = selected[i], usable = true;
        try { if (L instanceof CameraLayer || L instanceof LightLayer || L.locked || L.parent) usable = false; }
        catch (e1) { usable = false; }
        var tr = null, pos = null, scale = null;
        if (usable) {
            try {
                tr = L.property("ADBE Transform Group");
                pos = tr.property("ADBE Position");
                scale = tr.property("ADBE Scale");
                if (!pos || !scale || pos.dimensionsSeparated || pos.numKeys || scale.numKeys ||
                    pos.expressionEnabled || scale.expressionEnabled) usable = false;
            } catch (e2) { usable = false; }
        }
        if (usable) layers.push({ layer: L, pos: pos, scale: scale });
        else skipped++;
    }
    if (layers.length < 2) return _ekBad("parallaxNeedTwo");

    layers.sort(function (a, b) {
        try { return a.layer.index - b.layer.index; } catch (e) { return 0; }
    });

    app.beginUndoGroup("EDITKIT: parallax automatico");
    try {
        var camera = null, cameraCreated = false, control = null;
        try { camera = comp.activeCamera; } catch (e3) { camera = null; }

        if (!camera) {
            try {
                camera = comp.layers.addCamera(String(o.cameraName || "Camera"), [comp.width / 2, comp.height / 2]);
                cameraCreated = !!camera;
            } catch (e4) { camera = null; }
        }
        if (!camera) return _ekBad("cantAddLayer");

        var camPos = null;
        try { camPos = camera.toWorld([0, 0, 0], comp.time); } catch (e5) { camPos = null; }
        if (!camPos || camPos.length < 3) {
            try { camPos = camera.property("ADBE Transform Group").property("ADBE Position").value; }
            catch (e6) { camPos = [comp.width / 2, comp.height / 2, -2000]; }
        }

        var focusX = comp.width / 2, focusY = comp.height / 2;
        try {
            var poi = camera.property("ADBE Transform Group").property("ADBE Anchor Point").value;
            if (poi && poi.length >= 2) { focusX = poi[0]; focusY = poi[1]; }
        } catch (e7) {}

        /* El centro del reparto parte del plano medio que ya tuvieran las capas
           3D. Para una seleccion 2D es cero. */
        var baseZ = 0, old = [];
        for (i = 0; i < layers.length; i++) {
            try { layers[i].layer.threeDLayer = true; } catch (e8) { skipped++; continue; }
            var pv = null, sv = null;
            try { pv = layers[i].pos.value; sv = layers[i].scale.value; } catch (e9) { pv = null; }
            if (!pv || pv.length < 3 || !sv || sv.length < 2) { skipped++; continue; }
            old.push({ ref: layers[i], p: [pv[0], pv[1], pv[2]], s: [sv[0], sv[1], sv.length > 2 ? sv[2] : 100] });
            baseZ += pv[2];
        }
        if (old.length < 2) return _ekBad("parallaxFailed");
        baseZ /= old.length;

        var done = 0;
        for (i = 0; i < old.length; i++) {
            var item = old[i];
            var targetZ = baseZ + (i - (old.length - 1) / 2) * depth;
            var oldDist = item.p[2] - camPos[2];
            var newDist = targetZ - camPos[2];
            if (Math.abs(oldDist) < 1 || newDist <= 1) { skipped++; continue; }
            var factor = newDist / oldDist;
            if (!isFinite(factor) || factor <= 0.02) { skipped++; continue; }

            var np = [
                focusX + (item.p[0] - focusX) * factor,
                focusY + (item.p[1] - focusY) * factor,
                targetZ
            ];
            var ns = [item.s[0] * factor, item.s[1] * factor, item.s[2] * factor];
            try {
                item.ref.pos.setValue(np);
                item.ref.scale.setValue(ns);
                done++;
            } catch (e10) { skipped++; }
        }
        if (!done) return _ekBad("parallaxFailed");

        if (cameraCreated) {
            try {
                control = comp.layers.addNull(comp.duration);
                control.name = String(o.controlName || "Parallax Control");
                if (control.source) control.source.name = control.name;
                control.threeDLayer = true;
                control.anchorPoint.setValue([50, 50, 0]);
                control.position.setValue([comp.width / 2, comp.height / 2, 0]);
                camera.parent = control;
                control.moveBefore(camera);
            } catch (e11) { control = null; }
        }

        try {
            for (i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false;
            var revealTemps = [];
            function prepareTransformReveal(layer) {
                if (!layer) return;
                layer.selected = true;
                try {
                    var transform = layer.property("ADBE Transform Group");
                    var wanted = [
                        "ADBE Anchor Point", /* Punto de anclaje / interes */
                        "ADBE Position",
                        "ADBE Scale",
                        "ADBE Orientation",
                        "ADBE Rotate X",
                        "ADBE Rotate Y",
                        "ADBE Rotate Z",
                        "ADBE Opacity"
                    ];
                    /* U solo revela propiedades con fotogramas. Para cada
                       propiedad estatica que exista en esta clase de capa se
                       crea uno con el mismo valor. Las camaras omiten por si
                       solas Escala y Opacidad; el control nulo incluye todo. */
                    for (var rp = 0; rp < wanted.length; rp++) {
                        var prop = null;
                        try { prop = transform.property(wanted[rp]); } catch (eRP1) { prop = null; }
                        if (!prop || prop.numKeys !== 0 || prop.expressionEnabled) continue;
                        try {
                            prop.setValueAtTime(comp.time, prop.value);
                            revealTemps.push(prop);
                        } catch (eRP2) {}
                    }
                } catch (eR1) {}
            }
            prepareTransformReveal(camera);
            if (control) prepareTransformReveal(control);

            /* 2387 es el comando nativo "Reveal Properties with Keyframes"
               (la tecla U). A diferencia de PropertyBase.selected, este si
               abre el arbol de la linea de tiempo desde un panel CEP. */
            try { app.executeCommand(2387); } catch (eR2) {
                try { app.executeCommand(2771); } catch (eR3) {}
            }
            for (var r = 0; r < revealTemps.length; r++) {
                try {
                    if (revealTemps[r].numKeys === 1) revealTemps[r].removeKey(1);
                } catch (eR4) {}
            }
        } catch (e12) {}

        return _ekGood({
            layers: done,
            skipped: skipped,
            cameraCreated: cameraCreated,
            controlCreated: !!control,
            depth: _ekRound(depth, 2)
        });
    } catch (e13) {
        return _ekBad("hostErr", _aeErr(e13));
    } finally {
        app.endUndoGroup();
    }
}

/* CONGELAR UN FOTOGRAMA

   Lo mismo que Capa > Tiempo > Congelar fotograma: se enciende la reasignacion
   de tiempo y se deja un unico keyframe de retencion con el fotograma que
   estaba en pantalla. La capa sigue durando lo que duraba; lo que cambia es que
   ensena siempre ese fotograma.

   Dos detalles: el valor se lee DESPUES de encender la reasignacion —antes no
   existe— y ANTES de borrar los keyframes que el programa acaba de poner, que
   son los que le dan ese valor. Y la entrada y la salida se apuntan y se
   reponen, porque encender la reasignacion las mueve.

   Con `at: "in"` —Control y clic— se congela el primer fotograma de la capa en
   lugar del que hay bajo el cursor. Es el mismo congelado con otro fotograma. */
function ek_freezeFrame(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var sel = _ekSel(comp);
    if (!sel.length) return _ekBad("noSel");

    var atIn = (String(o.at || "playhead") === "in");

    app.beginUndoGroup("EDITKIT: congelar fotograma");
    try {
        var done = 0, skipped = 0, i, k;
        for (i = 0; i < sel.length; i++) {
            var L = sel[i];

            var inP = 0, outP = 0;
            try { inP = L.inPoint; outP = L.outPoint; } catch (e1) { skipped++; continue; }

            var when = atIn ? inP : comp.time;
            if (when < inP) when = inP;
            if (when > outP) when = outP;

            var ok = false;
            try { L.timeRemapEnabled = true; ok = true; } catch (e2) { ok = false; }
            if (!ok) { skipped++; continue; }

            var tr = null;
            try { tr = L.property("ADBE Time Remapping"); } catch (e3) { tr = null; }
            if (!tr) { skipped++; continue; }

            var v = null;
            try { v = tr.valueAtTime(when, false); } catch (e4) { v = null; }
            if (v === null) { skipped++; continue; }

            try { for (k = tr.numKeys; k >= 1; k--) tr.removeKey(k); } catch (e5) {}
            try { tr.setValueAtTime(when, v); } catch (e6) { skipped++; continue; }
            try {
                tr.setInterpolationTypeAtKey(1,
                    KeyframeInterpolationType.HOLD, KeyframeInterpolationType.HOLD);
            } catch (e7) {}

            // Encender la reasignacion estira la capa hasta el final de la
            // composicion; se le devuelve lo que duraba.
            try { L.inPoint = inP; } catch (e8) {}
            try { L.outPoint = outP; } catch (e9) {}
            done++;
        }

        if (!done) return _ekBad("cantFreeze");
        return _ekGood({ layers: done, skipped: skipped, at: atIn ? "in" : "playhead" });
    } catch (e10) {
        return _ekBad("hostErr", _aeErr(e10));
    } finally {
        app.endUndoGroup();
    }
}

/* TODAS LAS CAPAS SELECCIONADAS EN UNA SOLA COMPOSICION

   Lo mismo que hace el programa con "Precomponer" y las dos opciones puestas
   —mover todos los atributos y ajustar la duracion al intervalo de las capas—,
   que es la combinacion que casi todo el mundo quiere y que hay que volver a
   marcar cada vez.

   La segunda de esas dos opciones no existe en la API: `precompose` siempre
   crea una composicion con la duracion de la madre y deja el contenido en su
   tiempo absoluto. Se arregla despues, midiendo, con el mismo ayudante que usa
   "precomponer cada capa". */
function ek_precomposeAll(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var sel = _ekSel(comp);
    if (!sel.length) return _ekBad("noSel");

    var idx = [], i;
    for (i = 0; i < sel.length; i++) {
        try { idx.push(sel[i].index); } catch (e1) {}
    }
    if (!idx.length) return _ekBad("noSel");

    // El nombre por defecto sale de la capa mas alta, que es la que da nombre
    // al grupo en la cabeza de casi todo el mundo.
    var lowest = idx[0];
    for (i = 1; i < idx.length; i++) { if (idx[i] < lowest) lowest = idx[i]; }
    var base = "";
    try { base = String(comp.layer(lowest).name); } catch (e2) { base = "Grupo"; }

    var name = String(o.name || "");
    if (!name) name = base + String(o.suffix || " · comp");

    /* EL TRAMO SE MIDE ANTES, Y NO SE LE PREGUNTA A LA CAPA NUEVA

       `precompose` deja una capa que ocupa la composicion ENTERA, no el trozo
       que ocupaban las capas que se metieron dentro. Aqui se leia de ella la
       entrada y la salida para saber que recortar, y lo que contestaba era
       "de cero al final": no habia nada que recortar y la precomposicion salia
       durando toda la composicion madre.

       Se mide antes, sobre las capas de verdad, y se le escribe el resultado a
       la capa nueva. Es lo que ya hacia "precomponer cada capa", que por eso si
       funcionaba. */
    var want = _ekTimeSpan(sel);

    app.beginUndoGroup("EDITKIT: precomponer la seleccion");
    try {
        var nl = null;
        // `true` es "mover todos los atributos a la composicion nueva".
        try { nl = comp.layers.precompose(idx, name, true); } catch (e3) { nl = null; }
        if (!nl) return _ekBad("cantPrecompose");

        var trimmed = false;
        if (want) {
            try { nl.inPoint = want.lo; } catch (eI) {}
            try { nl.outPoint = want.hi; } catch (eO) {}
            try { _ekFitPrecompToLayer(nl); trimmed = true; } catch (e4) { trimmed = false; }
        }

        try {
            for (i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false;
            nl.selected = true;
        } catch (e5) {}

        var secs = 0;
        try { secs = nl.source.duration; } catch (e6) { secs = 0; }

        return _ekGood({
            name: name, layers: idx.length,
            trimmed: trimmed, duration: _ekRound(secs, 4)
        });
    } catch (e7) {
        return _ekBad("hostErr", _aeErr(e7));
    } finally {
        app.endUndoGroup();
    }
}

function ek_precomposeEach(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { o = {}; }

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");
    var sel = _ekSel(comp);
    if (!sel.length) return _ekBad("noSel");

    var suffix = String(o.suffix || "");

    /* Todo lo que hay que saber se lee ANTES de tocar nada. En cuanto empieza
       la primera precomposicion, las capas de la seleccion dejan de existir
       como objetos: la que sale del indice 3 no es la misma que entra en el 3,
       y preguntarle nada a la vieja lanza una excepcion. */
    var plan = [], i;
    for (i = 0; i < sel.length; i++) {
        var L = sel[i];
        var info = null;
        try {
            info = {
                index: L.index,
                name: String(L.name),
                startTime: L.startTime,
                inPoint: L.inPoint,
                outPoint: L.outPoint,
                stretch: L.stretch,
                locked: L.locked,
                shy: L.shy,
                enabled: L.enabled,
                label: L.label,
                parentIndex: 0,
                adjustment: false,
                guide: false,
                hasKids: false
            };
            try { if (L.parent) info.parentIndex = L.parent.index; } catch (e1) {}
            try { info.adjustment = !!L.adjustmentLayer; } catch (e2) {}
            try { info.guide = !!L.guideLayer; } catch (e3) {}
        } catch (e4) { info = null; }
        if (info) plan.push(info);
    }
    if (!plan.length) return _ekBad("noSel");

    // De quien cuelga alguien. Se mira la composicion entera y no solo la
    // seleccion: la hija puede estar fuera de lo que se ha seleccionado.
    for (i = 1; i <= comp.numLayers; i++) {
        var pIdx = 0;
        try { if (comp.layer(i).parent) pIdx = comp.layer(i).parent.index; } catch (e5) { pIdx = 0; }
        if (!pIdx) continue;
        for (var k = 0; k < plan.length; k++) {
            if (plan[k].index === pIdx && pIdx !== i) plan[k].hasKids = true;
        }
    }

    app.beginUndoGroup("QuickIt: precomponer cada capa");

    var done = 0, failed = 0;
    var unlocked = [];

    try {
        // Una capa bloqueada no se puede precomponer. Se abre, se hace y se
        // vuelve a cerrar al final: el candado es del usuario, no nuestro.
        for (i = 0; i < plan.length; i++) {
            if (!plan[i].locked) continue;
            try { comp.layer(plan[i].index).locked = false; unlocked.push(plan[i].index); } catch (e6) {}
        }

        for (i = 0; i < plan.length; i++) {
            var p = plan[i];
            var name = p.name + suffix;

            /* Los tres casos que se romperian llevando la transformacion
               dentro. En ellos se deja fuera; si After Effects no lo admite
               para ese tipo de capa, se cae al modo normal. */
            var leaveOutside = p.hasKids || p.adjustment || p.guide;
            var made = false;

            if (leaveOutside) {
                try { comp.layers.precompose([p.index], name, false); made = true; } catch (e7) {}
            }
            if (!made) {
                try { comp.layers.precompose([p.index], name, true); made = true; } catch (e8) { made = false; }
            }
            if (!made) { failed++; continue; }

            // La capa nueva ocupa el mismo indice que la vieja: entro una y
            // salio una.
            var nl = null;
            try { nl = comp.layer(p.index); } catch (e9) { nl = null; }
            if (!nl) { failed++; continue; }

            /* Primero el recorte: la precomposicion recien hecha abarca la
               composicion entera, y lo que se quiere es el trozo que ocupaba
               la capa. El stretch NO se toca —se fue dentro con la capa, y
               volver a escribirlo aqui lo aplicaria dos veces. */
            try { nl.inPoint = p.inPoint; } catch (e12) {}
            try { nl.outPoint = p.outPoint; } catch (e13) {}

            // Y despues la parte que faltaba: encogerla de verdad.
            _ekFitPrecompToLayer(nl);

            try { nl.label = p.label; } catch (e14) {}
            try { nl.shy = p.shy; } catch (e15) {}
            try { if (nl.enabled !== p.enabled) nl.enabled = p.enabled; } catch (e16) {}
            // Guia y ajuste solo se reponen cuando la transformacion se quedo
            // fuera; en el otro modo se fueron dentro y ponerlas aqui las
            // aplicaria dos veces.
            if (leaveOutside) {
                try { nl.adjustmentLayer = p.adjustment; } catch (e17) {}
                try { nl.guideLayer = p.guide; } catch (e18) {}
            }

            done++;
        }

        /* El emparentado, al final y de una vez. Durante la pasada las capas
           padre se estan sustituyendo, y apuntar a una que va a desaparecer en
           la vuelta siguiente deja el enlace roto. Los indices no se han
           movido, asi que lo apuntado antes sigue valiendo. */
        for (i = 0; i < plan.length; i++) {
            if (!plan[i].parentIndex) continue;
            try {
                var kid = comp.layer(plan[i].index);
                if (kid && !kid.parent) kid.parent = comp.layer(plan[i].parentIndex);
            } catch (e19) {}
        }

        for (i = 0; i < unlocked.length; i++) {
            try { comp.layer(unlocked[i]).locked = true; } catch (e20) {}
        }
    } catch (e) {
        app.endUndoGroup();
        return _ekBad("hostErr", _aeErr(e));
    }

    app.endUndoGroup();

    if (!done) return _ekBad("precomposeFailed");
    return _ekGood({ layers: done, failed: failed });
}

/* ============================================================================
   B7 · ORDENAR LAS CAPAS

   Cambiar el orden VERTICAL de las capas —quien esta encima de quien—, no su
   sitio en el tiempo. Seis maneras de decidirlo, y la primera es la que se
   pide todos los dias: darle la vuelta a la pila.

     reverse    al reves de como estan ahora
     selection  el orden en que las fue eligiendo el usuario
     name       por nombre, de la A a la Z
     random     barajadas
     inPoint    por donde entran
     outPoint   por donde salen

   Y una regla que se respeta en las seis: LAS CAPAS QUE NO ENTRAN NO SE
   MUEVEN. Si se eligen la 1 y la 4 y entre medias hay dos que no se tocaron,
   esas dos se quedan en la 2 y en la 3. Lo que se reordena son las capas
   elegidas entre los huecos que ya ocupaban, no la composicion entera.

   Como se consigue: se apuntan los huecos —los indices ocupados, de arriba
   abajo— y se va colocando de arriba abajo. Cada pasada mete una capa en su
   hueco definitivo, y como se avanza hacia abajo, ninguna de las ya colocadas
   se vuelve a mover. Las de por medio acaban corridas y devueltas, y el saldo
   es cero.

   Sobre "selection". After Effects no guarda en ningun sitio el orden en que
   se fue haciendo clic: `comp.selectedLayers` devuelve lo que devuelve. Se usa
   tal cual, asi que en la practica esta opcion vale lo que valga esa lista, y
   si el programa la entrega por indice, el resultado es el que ya habia. Se
   incluye porque estaba en la lista pedida, no porque se pueda prometer.
   ============================================================================ */
function ek_orderLayers(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { o = {}; }
    var mode = String(o.mode || "reverse");
    var desc = !!o.desc;

    var comp = _ekComp();
    if (!comp) return _ekBad("noComp");

    var i;
    var pool = [];
    if (String(o.scope || "sel") === "all") {
        for (i = 1; i <= comp.numLayers; i++) pool.push(comp.layer(i));
    } else {
        pool = _ekSel(comp);
    }
    if (pool.length < 2) return _ekBad("orderNeedsTwo");

    /* La lista tal y como esta ahora, de arriba abajo, y los huecos que ocupa.
       Se ordena por indice a proposito: _ekSel puede venir en cualquier orden,
       y para "al reves" hace falta saber cual es el de arriba. */
    var byIndex = pool.slice();
    byIndex.sort(function (a, b) {
        var ia = 0, ib = 0;
        try { ia = a.index; } catch (e1) {}
        try { ib = b.index; } catch (e2) {}
        return ia - ib;
    });

    var slots = [];
    for (i = 0; i < byIndex.length; i++) {
        try { slots.push(byIndex[i].index); } catch (e3) { return _ekBad("hostErr", "index"); }
    }

    // El orden que se quiere, de arriba abajo.
    var want = byIndex.slice();
    if (mode === "reverse") {
        want.reverse();
    } else if (mode === "selection") {
        want = pool.slice();
    } else if (mode === "random") {
        // Fisher-Yates. Barajar de verdad y no ordenar por un numero al azar,
        // que reparte mal y deja las primeras casi siempre arriba.
        for (i = want.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));
            var tmp = want[i]; want[i] = want[j]; want[j] = tmp;
        }
    } else if (mode === "name") {
        want.sort(function (a, b) {
            var na = "", nb = "";
            try { na = String(a.name).toLowerCase(); } catch (e4) {}
            try { nb = String(b.name).toLowerCase(); } catch (e5) {}
            if (na === nb) return 0;
            return na < nb ? -1 : 1;
        });
    } else if (mode === "inPoint" || mode === "outPoint") {
        want.sort(function (a, b) {
            var ta = 0, tb = 0;
            try { ta = (mode === "inPoint") ? a.inPoint : a.outPoint; } catch (e6) {}
            try { tb = (mode === "inPoint") ? b.inPoint : b.outPoint; } catch (e7) {}
            if (ta === tb) {
                // Empate: se respeta el orden que ya tenian, que es lo unico
                // que el usuario puede predecir.
                var ia = 0, ib = 0;
                try { ia = a.index; } catch (e8) {}
                try { ib = b.index; } catch (e9) {}
                return ia - ib;
            }
            return ta - tb;
        });
    } else {
        return _ekBad("badArg", mode);
    }

    if (desc && mode !== "reverse" && mode !== "selection" && mode !== "random") want.reverse();

    if (want.length !== slots.length) return _ekBad("hostErr", "count");

    app.beginUndoGroup("EDITKIT: ordenar capas");
    var moved = 0;
    var unlocked = [];
    try {
        // Una capa bloqueada no se deja mover. Se abre, se hace y se vuelve a
        // cerrar: el candado es del usuario, no nuestro.
        for (i = 0; i < want.length; i++) {
            try {
                if (want[i].locked) { want[i].locked = false; unlocked.push(want[i]); }
            } catch (eB) {}
        }

        for (i = 0; i < want.length; i++) {
            var L = want[i], slot = slots[i], at = 0;
            try { at = L.index; } catch (eC) { continue; }
            if (at === slot) continue;
            try {
                if (at > slot) L.moveBefore(comp.layer(slot));
                else L.moveAfter(comp.layer(slot));
                moved++;
            } catch (eD) {}
        }

        for (i = 0; i < unlocked.length; i++) {
            try { unlocked[i].locked = true; } catch (eE) {}
        }
    } catch (e) {
        app.endUndoGroup();
        return _ekBad("hostErr", _aeErr(e));
    }
    app.endUndoGroup();

    return _ekGood({ layers: want.length, moved: moved, mode: mode });
}

/* ============================================================================
   B6 · LA CARPETA DE PRESETS DEL USUARIO

   After Effects guarda los presets de animacion del usuario en

       <Documentos>/Adobe/After Effects <ano>/User Presets

   y esa ruta no se puede escribir a mano en ningun sitio: cambia con el nombre
   de usuario, con el idioma del sistema —"Documentos", "Documents"— y con la
   version instalada. Ademas puede haber varias versiones una al lado de otra.

   Se busca asi: la carpeta de documentos la da el propio ExtendScript, dentro
   se miran las que empiezan por "After Effects" y se elige la del numero mas
   alto, que es la version mas nueva. Si esa no tiene "User Presets" se prueba
   con la siguiente hacia abajo, porque una instalacion recien puesta y sin usar
   no tiene esa carpeta todavia.

   Vale igual en macOS: alli la ruta tiene la misma forma.
   ============================================================================ */
function _ekPresetRoots() {
    var out = [];
    var docs = null;
    try { docs = Folder.myDocuments; } catch (e) { return out; }
    if (!docs || !docs.exists) return out;

    var adobe = new Folder(docs.fsName + "/Adobe");
    if (!adobe.exists) return out;

    var kids = [];
    try { kids = adobe.getFiles(); } catch (e2) { return out; }

    for (var i = 0; i < kids.length; i++) {
        if (!(kids[i] instanceof Folder)) continue;
        var name = decodeURIComponent(kids[i].name);
        if (name.indexOf("After Effects") !== 0) continue;
        // El numero del final ordena las versiones. Sin numero se va al fondo:
        // es una carpeta rara y no la que se estaba buscando.
        var m = name.match(/(\d+)\s*$/);
        out.push({ folder: kids[i], year: m ? parseInt(m[1], 10) : 0, name: name });
    }

    out.sort(function (a, b) { return b.year - a.year; });
    return out;
}

function ek_userPresetsDir() {
    var roots = _ekPresetRoots();
    for (var i = 0; i < roots.length; i++) {
        var f = new Folder(roots[i].folder.fsName + "/User Presets");
        if (f.exists) return _ekGood({ path: f.fsName, version: roots[i].name });
    }
    // Sin "User Presets" pero con la version encontrada, se devuelve esa: el
    // dialogo abre un escalon mas arriba, que sigue siendo mejor que abrir
    // donde estuviera la ultima vez.
    if (roots.length) return _ekGood({ path: roots[0].folder.fsName, version: roots[0].name, partial: true });
    return _ekBad("noPresetsDir");
}

/* ---------------------------------------------------------------------------
   El indice

   Recorre la carpeta y devuelve todos los .ffx que encuentra, con su nombre sin
   extension y la subcarpeta en la que estan. Con eso, el panel puede buscarlos
   por nombre en lugar de mandar al usuario a rebuscar por el arbol cada vez que
   quiere poner uno en un boton.

   Dos topes, y los dos importan: la profundidad, porque un enlace que apunte
   hacia arriba convierte el recorrido en un bucle infinito que cuelga After
   Effects; y la cantidad, porque lo que sale de aqui viaja como texto por
   evalScript y acaba en el almacenamiento del panel.
   --------------------------------------------------------------------------- */
function ek_listPresets(jsonStr) {
    var o;
    try { o = JSON.parse(jsonStr); } catch (eA) { o = {}; }

    // Sin carpeta, la del usuario. Se pregunta por la misma puerta que usa el
    // panel para no tener dos formas distintas de encontrarla.
    var dir = String(o.dir || "");
    if (!dir) {
        var parsed = null;
        try { parsed = JSON.parse(ek_userPresetsDir()); } catch (eB) { parsed = null; }
        if (!parsed || !parsed.ok) return _ekBad("noPresetsDir");
        dir = parsed.path;
    }

    var root = new Folder(dir);
    if (!root.exists) return _ekBad("noFolder", dir);

    var MAX = 3000, DEPTH = 8;
    var items = [], truncated = false;

    function walk(folder, rel, depth) {
        if (truncated || depth > DEPTH) return;
        var kids = [];
        try { kids = folder.getFiles(); } catch (e) { return; }
        for (var i = 0; i < kids.length; i++) {
            if (items.length >= MAX) { truncated = true; return; }
            var k = kids[i];
            var name = "";
            try { name = decodeURIComponent(k.name); } catch (e2) { name = String(k.name); }

            if (k instanceof Folder) {
                walk(k, rel ? (rel + "/" + name) : name, depth + 1);
                continue;
            }
            if (!/\.ffx$/i.test(name)) continue;

            items.push({
                n: name.replace(/\.ffx$/i, ""),
                p: k.fsName,
                f: rel
            });
        }
    }

    try {
        walk(root, "", 0);
    } catch (e) {
        return _ekBad("hostErr", _aeErr(e));
    }

    return _ekGood({ dir: root.fsName, items: items, count: items.length, truncated: truncated });
}
