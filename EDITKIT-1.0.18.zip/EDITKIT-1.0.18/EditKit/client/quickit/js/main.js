/* ============================================================================
   QUICKIT — LAS DOS MITADES

   Arriba, la categoria abierta y sus opciones. Abajo, tras la linea, una
   rejilla de botones que no cambia al cambiar de categoria. Las flechas mueven
   lo primero y no tocan lo segundo; ese es el trato y esta escrito aqui.

   Por que separadas: las opciones son de la funcion que estas usando ahora, y
   la rejilla es de las que usas todos los dias. Si la rejilla siguiera a la
   categoria habria que navegar hasta ella para pulsarla, que es exactamente el
   problema que este plugin viene a quitar.

   La rejilla se configura en la propia rejilla: clic derecho sobre un boton y
   ahi esta todo lo suyo. Tenerlo tambien en una hoja de ajustes era pedirle al
   usuario que se acordara de cual de los dos sitios manda.
   ============================================================================ */
(function () {
    "use strict";

    var C = window.EditKitCommands;

    function T(key) { return (window.EditKitI18n && window.EditKitI18n.t(key)) || key; }
    var K_BOOT_ERROR = "editkit_qi_last_error";
    var K_FRESH_INTRO = "editkit_qi_fresh_intro_seen_v1";
    var freshIntroTimer = null;

    function rememberBootError(phase, error) {
        var detail = phase + ": " + ((error && error.name) || "Error") + " — " +
            ((error && error.message) || String(error || "unknown"));
        try { localStorage.setItem(K_BOOT_ERROR, detail.substring(0, 500)); } catch (e) {}
    }

    function bootStep(name, fn) {
        try { fn(); return true; }
        catch (error) { rememberBootError(name, error); return false; }
    }

    function freshIntroSeen() {
        try { return localStorage.getItem(K_FRESH_INTRO) === "1"; }
        catch (e) { return false; }
    }

    function dismissFreshIntro() {
        if (freshIntroSeen()) return;
        try { localStorage.setItem(K_FRESH_INTRO, "1"); } catch (e) {}
        if (freshIntroTimer) { clearTimeout(freshIntroTimer); freshIntroTimer = null; }
        var note = $("qiFreshIntro");
        if (!note) return;
        note.classList.add("leaving");
        setTimeout(function () {
            if (note.parentNode) note.parentNode.removeChild(note);
        }, 480);
    }

    /* El contador empieza solo cuando la vista de botones esta realmente a la
       vista. Renderizarla escondida durante el arranque no significa que el
       usuario ya haya leido la explicacion. */
    function maybeAcknowledgeFreshIntro() {
        if (freshIntroSeen() || freshIntroTimer || !$("qiFreshIntro")) return;
        var app = document.querySelector(".app");
        if (!app || app.getAttribute("data-view") !== "btns" || app.classList.contains("no-grid")) return;
        freshIntroTimer = setTimeout(dismissFreshIntro, 6500);
    }

    /* ------------------------------------------------------------------
       EL ACENTO

       Esta ventana cargaba el puente del acento y no se suscribia a el. El
       resultado: el usuario elegia un color en EaseIt o en AlignIt, el shell y
       los otros dos paneles se repintaban al momento, y QuickIt se quedaba con
       el turquesa de fabrica. Un plugin donde dos de tres ventanas cambian de
       color no parece un plugin; parece dos plugins pegados.

       Se escriben tres variables y no una: --accent es el color, y los dos
       tonos que salen de el los usan los estados :active y el anillo de foco.
       Las hojas traen los del acento de fabrica escritos en numeros, asi que
       antes de que esto corra ya esta todo bien pintado.
       ------------------------------------------------------------------ */
    (function () {
        var A = window.EditKitAccent;
        if (!A || !A.onChange) return;
        A.onChange(function (hex) {
            var st = document.documentElement.style;
            st.setProperty("--accent", hex);
            if (!A.tones) return;
            var t = A.tones(hex);
            st.setProperty("--accent-soft", t.soft);
            st.setProperty("--accent-strong", t.strong);
        });
    })();
    function TF(key, a) { return (window.EditKitI18n && window.EditKitI18n.fmt(key, a)) || key; }
    function $(id) { return document.getElementById(id); }
    function each(sel, fn) {
        var els = document.querySelectorAll(sel);
        for (var i = 0; i < els.length; i++) fn(els[i], i);
    }

    // ------------------------------------------------------------------
    // Aviso
    // ------------------------------------------------------------------
    var toastTimer = null;
    /* Los avisos se pueden apagar enteros, errores incluidos. Se comprueba
       aqui y no en cada sitio que avisa: hay cuarenta acciones y ninguna tiene
       por que saber si el usuario quiere que se le cuente.

       Que los errores tambien callen es a proposito y esta dicho en los
       ajustes: un aviso que no se puede apagar deja de ser una preferencia. */
    function toastsOn() {
        try { return localStorage.getItem(K_TOASTS) !== "0"; } catch (e) { return true; }
    }

    function showToast(msg, isError) {
        if (!toastsOn()) return;
        var box = $("toast"), txt = $("toastMessage");
        if (!box || !txt) return;
        txt.textContent = msg;
        box.classList.toggle("error", !!isError);
        box.classList.add("show");
        if (toastTimer) clearTimeout(toastTimer);
        toastTimer = setTimeout(function () { box.classList.remove("show"); }, 2200);
    }
    // tools.js lo busca por aqui: el aviso se enseña en la ventana que actuo.
    window.EditKitToast = showToast;

    function host() { return window.EditKitToolsHost || null; }

    // ------------------------------------------------------------------
    // Las categorias
    // ------------------------------------------------------------------
    /* El orden es el del recorrido con las flechas, y va de lo que se toca mas
       a lo que se toca menos. No hay pestañas: solo un nombre y dos flechas
       clavadas a los extremos, que es toda la navegacion que cabe sin robarle
       sitio a las opciones. */
    var CATS = [
        { id: "hierarchy", key: "aa.hierarchy" },
        { id: "time", key: "aa.tabTime" },
        { id: "expr", key: "aa.tabExpr" },
        { id: "text", key: "aa.tabText" },
        { id: "comp", key: "aa.tabComp" },
        { id: "audio", key: "aa.tabAudio" }
    ];

    var K_CAT = "editkit_qi_cat";
    var at = 0;

    function catIndex(id) {
        for (var i = 0; i < CATS.length; i++) { if (CATS[i].id === id) return i; }
        return -1;
    }

    function showCat(i) {
        var n = CATS.length;
        at = ((i % n) + n) % n;
        var cat = CATS[at];

        try { localStorage.setItem(K_CAT, cat.id); } catch (e) {}

        var app = document.querySelector(".app");
        if (app) app.setAttribute("data-cat", cat.id);

        var title = $("qiTitle");
        if (title) title.textContent = T(cat.key);

        each(".qi-panel", function (p) {
            p.classList.toggle("active", p.getAttribute("data-cat") === cat.id);
        });

        // El desplazamiento vuelve arriba: la categoria nueva empieza por su
        // principio, no por donde se quedo la anterior.
        var zone = $("qiZone");
        if (zone) zone.scrollTop = 0;
    }

    function wireNav() {
        each("[data-qi-nav]", function (b) {
            b.addEventListener("click", function () {
                showCat(at + parseInt(b.getAttribute("data-qi-nav"), 10));
            });
        });

        /* La rueda sobre la fila tambien cambia de categoria. Es un atajo para
           quien ya sabe donde esta cada cosa; quien no, tiene las flechas ahi
           mismo y no se topa con esto por accidente. */
        var head = document.querySelector(".qi-nav");
        if (head) {
            head.addEventListener("wheel", function (e) {
                e.preventDefault();
                showCat(at + (e.deltaY > 0 ? 1 : -1));
            });
        }

        var start = 0;
        try {
            var saved = catIndex(localStorage.getItem(K_CAT) || "");
            if (saved >= 0) start = saved;
        } catch (e2) {}
        showCat(start);
    }

    // ------------------------------------------------------------------
    // La rejilla permanente
    // ------------------------------------------------------------------
    /* Un hueco de la rejilla es un objeto y no un nombre de comando suelto,
       porque puede ser cuatro cosas distintas:

         { id }                        una accion del plugin, de cualquiera de
                                       los tres paneles
         { kind:"effect", value }      un efecto de After Effects, por su nombre
         { kind:"script", value }      un .jsx del usuario
         { kind:"preset", value }      un .ffx del usuario

       Y ademas lleva lo suyo encima —nombre, abreviatura, icono, colores—
       en lugar de en tablas aparte con el id como clave. La diferencia importa:
       asi dos huecos con la misma accion pueden verse distinto, que es lo
       normal en cuanto uno empieza a colocarlos por costumbre y no por tema. */
    var GRID_DEFAULT = [
        { id: "time.hold" }, { id: "time.linear" }, { id: "time.ease" },
        { id: "time.easeIn" }, { id: "time.easeOut" }, { id: "time.bake" },
        { id: "time.scaleHalf" }, { id: "time.scaleDouble" }, { id: "time.gotoPrev" },
        { id: "time.gotoNext" }, { id: "time.reverse" }, { id: "time.reverseCopy" },
        { id: "expr.wiggle" }, { id: "expr.loop" },
        { id: "expr.inertia" }, { id: "layer.parentNull" }, { id: "layer.unparent" },
        { id: "comp.precompose" }, { id: "comp.extract" },
        { id: "layer.adjustment" }, { id: "layer.solid" }, { id: "layer.shape" },
        { id: "layer.text", fresh: true },
        { id: "layer.camera" }, { id: "time.freeze" },
        { id: "order.reverse" }, { id: "order.selection" }, { id: "order.name" },
        { id: "order.random" }, { id: "order.inPoint" }, { id: "order.outPoint" },
        { id: "comp.deepClone", fresh: true }, { id: "comp.f916", fresh: true },
        { id: "comp.f11", fresh: true }, { id: "comp.f169", fresh: true },
        { id: "comp.f45", fresh: true },
        { id: "comp.organizeProject", fresh: true, w: 3, h: 1 },
        { id: "layer.autoParallax", fresh: true, w: 2, h: 1 },
        { id: "time.capturePasteFit", fresh: true, w: 1, h: 1 },
        { id: "time.pasteFit", fresh: true, w: 1, h: 1 },
        { id: "audio.consolidate", fresh: true, w: 1, h: 1 },
        { id: "audio.import", fresh: true, w: 1, h: 1 }
    ];

    /* Lo que se anadio a la rejilla de fabrica despues de la primera version.

       Quien nunca toco la rejilla no necesita esto: se le entrega GRID_DEFAULT
       entero. El problema es el otro, el que si la toco — que es justo el que
       mas la usa: su lista esta guardada, y una lista guardada nunca vuelve a
       mirar la de fabrica. Sin este paso, las funciones nuevas quedarian
       "preinstaladas" solo para quien acaba de instalar el plugin.

       Asi que se anaden al final de la suya, una sola vez, y solo las que no
       tenga ya. Al final y no intercaladas: el sitio de cada boton en esa
       rejilla lo decidio el usuario, y meterle algo en medio le mueve todo lo
       demas de sitio. Si no las quiere, el boton derecho las oculta. */
    var GRID_ADDED = {
        2: ["time.reverse", "time.reverseCopy",
            "order.reverse", "order.selection", "order.name",
            "order.random", "order.inPoint", "order.outPoint"],
        3: ["layer.adjustment"],
        4: ["layer.solid", "layer.shape", "layer.camera", "time.freeze"],
        5: ["comp.deepClone"],
        6: ["comp.deepClone"],
        7: ["comp.f916", "comp.f11", "comp.f169", "comp.f45"],
        9: ["comp.organizeProject"],
        10: ["time.pasteFit"],
        11: [],
        12: ["layer.autoParallax"],
        13: ["audio.consolidate", "audio.import"],
        /* Se repite en la migracion de la version distribuible para cubrir
           instalaciones de prueba que llegaron a guardar la 13 antes de que
           estos dos botones estuvieran listos. La comprobacion `has` evita
           cualquier duplicado. */
        14: ["audio.consolidate", "audio.import"],
        15: ["layer.text"],
        /* Se repite para las instalaciones de prueba que alcanzaron a guardar
           la 15 antes de que el boton de texto quedara registrado. `has`
           conserva la rejilla del usuario y evita cualquier duplicado. */
        16: ["layer.text"]
    };
    var GRID_VERSION = 16;
    var FRESH_COMMANDS = ["comp.deepClone", "comp.f916", "comp.f11", "comp.f169", "comp.f45", "comp.organizeProject", "layer.autoParallax", "time.capturePasteFit", "time.pasteFit", "audio.consolidate", "audio.import", "layer.text"];

    var K_GRID = "editkit_qi_grid";
    var K_GRID_VER = "editkit_qi_grid_ver";
    var K_TEXT_GRID_MIGRATION = "editkit_qi_text_added_v1";
    var K_COLS = "editkit_qi_cols";
    var K_BTNH = "editkit_qi_btnh";
    var K_BTNMODE = "editkit_qi_btnmode";
    // El aspecto del texto de los botones. Uno por ajuste, sin objetos: asi un
    // valor que no se entienda se cae solo a su valor de fabrica sin llevarse
    // por delante a los demas.
    var K_BTNFS = "editkit_qi_btnfs";
    var K_BTNFW = "editkit_qi_btnfw";
    var K_BTNLS = "editkit_qi_btnls";
    var K_BTNRAD = "editkit_qi_btnrad";
    var K_BTNCAPS = "editkit_qi_btncaps";
    var K_PRESS = "editkit_qi_press";
    var K_SECTIONS = "editkit_qi_sections";
    var K_TOASTS = "editkit_qi_toasts";
    var K_VIEW = "editkit_qi_view";
    var K_PRESETS = "editkit_qi_presets";       // el indice
    var K_PRESETS_ASK = "editkit_qi_presets_ask";
    var K_PRESET_OPTS = "editkit_qi_preset_opts";   // como cae un preset en varias capas
    var K_EFFECTS = "editkit_qi_effects";           // la lista de efectos instalados

    function readJson(key, dflt) {
        try {
            var o = JSON.parse(localStorage.getItem(key) || "null");
            return (o && typeof o === "object") ? o : dflt;
        } catch (e) { return dflt; }
    }
    function writeJson(key, v) {
        try { localStorage.setItem(key, JSON.stringify(v)); } catch (e) {}
    }

    /* ESTILOS DE BOTON

       Tres recuadros debajo de las acciones del menu, y un clic en uno le pone
       al boton sus cuatro colores de golpe: fondo, fondo al pasar el mouse,
       texto y borde. Pintar una fila de botones del mismo color era abrir el
       selector dos veces por boton y acertar el mismo tono cada vez; con esto es
       un clic por boton.

       Los tres de fabrica son ejemplos, no una paleta cerrada. El "+" guarda el
       aspecto del boton que se esta editando como estilo nuevo, y el lapiz
       entra a editarlos: se elige uno, se cambian sus colores o se borra.

       Un estilo es una plantilla, no un enlace. Aplicarlo copia los colores al
       boton; cambiar el estilo despues no toca los botones que ya lo usan.
       Enlazarlos parece comodo hasta el dia en que se cambia un estilo para un
       boton nuevo y se repintan veinte viejos sin avisar.

       Se guardan en el almacenamiento con el resto de QuickIt, asi que viajan
       en los perfiles. Si nunca se tocaron, se leen los de fabrica; si el
       usuario los borro todos, se respeta y no vuelven. */
    var K_STYLES = "editkit_qi_styles";
    var K_STYLE_SOFT3D = "editkit_qi_style_soft3d_v1";
    var K_STYLE_NATIVE = "editkit_qi_native_styles_v1";
    var STYLE_MAX = 12;
    // Los cuatro de siempre, mas el segundo color de un degradado.
    var STYLE_KEYS = ["bg", "hover", "fg", "border", "bg2"];
    // Lo que no es un color: como se pinta el fondo, y el borde.
    var GRAD_TYPES = { linear: 1, radial: 1, conic: 1 };
    var BORDER_STYLES = { glow: 1, gradient: 1 };
    var EFFECT_STYLES = { soft3d: 1 };
    var NATIVE_IDS = { teal: 1, amber: 1, coral: 1, soft3d: 1 };
    var STYLE_SOFT3D = {
        bg: "#0d0e0e", hover: "#161818", fg: "#989a9a", border: "#292b2b",
        effect: "soft3d", nativeId: "soft3d"
    };
    var STYLE_DEFAULT = [
        { bg: "#173532", hover: "#1f4541", fg: "#7fded3", border: "#2f6f69", nativeId: "teal" },
        { bg: "#382b16", hover: "#48381d", fg: "#f0c77f", border: "#79592a", nativeId: "amber" },
        { bg: "#3a1d1b", hover: "#4b2623", fg: "#f19a90", border: "#7c3b35", nativeId: "coral" },
        STYLE_SOFT3D                                                                    // relieve oscuro
    ];
    // Lo que se guarda al pulsar "+" sobre un boton que no tiene colores propios.
    var STYLE_BLANK = { bg: "#292929", hover: "#303030", fg: "#b8b8b8", border: "#3a3a3a" };
    var HEX6 = /^#[0-9a-f]{6}$/i;

    /* Un estilo solido de siempre no lleva nada de esto: bgType, gradType,
       gradAngle, sweep y borderStyle solo aparecen cuando alguien los eligio,
       y por eso se validan aparte de los colores en vez de sumarlos a
       STYLE_KEYS —un valor mal formado ahi no debe tirar el color que si
       estaba bien—. */
    function cleanStyle(s) {
        if (!s || typeof s !== "object") return null;
        var o = {}, any = false;
        for (var i = 0; i < STYLE_KEYS.length; i++) {
            var v = s[STYLE_KEYS[i]];
            if (typeof v === "string" && HEX6.test(v)) { o[STYLE_KEYS[i]] = v.toLowerCase(); any = true; }
        }
        if (s.bgType === "gradient" && o.bg2) {
            o.bgType = "gradient";
            o.gradType = GRAD_TYPES[s.gradType] ? s.gradType : "linear";
            any = true;
        }
        if (typeof s.gradAngle === "number" && isFinite(s.gradAngle)) {
            o.gradAngle = ((Math.round(s.gradAngle) % 360) + 360) % 360;
            any = true;
        }
        if (s.sweep === true) { o.sweep = true; any = true; }
        if (BORDER_STYLES[s.borderStyle]) { o.borderStyle = s.borderStyle; any = true; }
        if (EFFECT_STYLES[s.effect]) { o.effect = s.effect; any = true; }
        if (NATIVE_IDS[s.nativeId]) o.nativeId = s.nativeId;
        return any ? o : null;
    }
    var STYLE_EXTRA = ["bgType", "gradType", "gradAngle", "sweep", "borderStyle", "effect"];
    function copyStyle(s) {
        var o = {}, i;
        for (i = 0; i < STYLE_KEYS.length; i++) if (s[STYLE_KEYS[i]]) o[STYLE_KEYS[i]] = s[STYLE_KEYS[i]];
        for (i = 0; i < STYLE_EXTRA.length; i++) if (s[STYLE_EXTRA[i]] !== undefined) o[STYLE_EXTRA[i]] = s[STYLE_EXTRA[i]];
        if (NATIVE_IDS[s.nativeId]) o.nativeId = s.nativeId;
        return o;
    }
    function nativeStyle(id) {
        for (var i = 0; i < STYLE_DEFAULT.length; i++) if (STYLE_DEFAULT[i].nativeId === id) return STYLE_DEFAULT[i];
        return null;
    }
    function ensureNativeStyles(out) {
        var found = {}, changed = false, i;
        for (i = 0; i < out.length; i++) {
            if (NATIVE_IDS[out[i].nativeId]) found[out[i].nativeId] = true;
        }
        /* Las tres paletas originales ocupaban las primeras posiciones. Esta
           deteccion conserva cualquier personalizacion que el usuario les
           haya hecho y solo les añade su identidad protegida. */
        var legacy = ["teal", "amber", "coral"];
        for (i = 0; i < legacy.length && i < out.length; i++) {
            if (!found[legacy[i]] && !out[i].nativeId) {
                out[i].nativeId = legacy[i]; found[legacy[i]] = true; changed = true;
            }
        }
        for (i = 0; i < out.length; i++) {
            if (!found.soft3d && out[i].effect === "soft3d") {
                out[i].nativeId = "soft3d"; found.soft3d = true; changed = true;
            }
        }
        ["teal", "amber", "coral", "soft3d"].forEach(function (id) {
            if (found[id]) return;
            out.push(copyStyle(nativeStyle(id)));
            found[id] = true; changed = true;
        });
        try { localStorage.setItem(K_STYLE_NATIVE, "1"); } catch (e) {}
        return changed;
    }
    function styles() {
        var a = readJson(K_STYLES, null);
        if (!a || typeof a.length !== "number") {
            try { localStorage.setItem(K_STYLE_SOFT3D, "1"); } catch (e) {}
            try { localStorage.setItem(K_STYLE_NATIVE, "1"); } catch (e2) {}
            return STYLE_DEFAULT.map(copyStyle);
        }
        var out = [];
        for (var i = 0; i < a.length && out.length < STYLE_MAX; i++) {
            var c = cleanStyle(a[i]);
            if (c) out.push(c);
        }
        var migrated = false;
        try { migrated = localStorage.getItem(K_STYLE_SOFT3D) === "1"; } catch (e3) {}
        if (!migrated) {
            var hasSoft3d = false;
            for (var j = 0; j < out.length; j++) if (out[j].effect === "soft3d") hasSoft3d = true;
            if (!hasSoft3d && out.length < STYLE_MAX) {
                out.push(copyStyle(STYLE_SOFT3D));
                writeJson(K_STYLES, out);
            }
            try { localStorage.setItem(K_STYLE_SOFT3D, "1"); } catch (e4) {}
        }
        if (ensureNativeStyles(out)) writeJson(K_STYLES, out);
        return out;
    }
    function saveStyles(list) { writeJson(K_STYLES, list); }

    // El boton guarda sus colores con los nombres de siempre (color, hover) y
    // los dos nuevos (fg, border); el estilo, con nombres que dicen lo que son.
    // Lo que no es color viaja igual en los dos lados, sin cambiar de nombre.
    var STYLE_MAP = { bg: "color", hover: "hover", fg: "fg", border: "border", bg2: "bg2",
        bgType: "bgType", gradType: "gradType", gradAngle: "gradAngle",
        sweep: "sweep", borderStyle: "borderStyle", effect: "effect" };
    function styleOfEntry(e) {
        if (!e) return null;
        return cleanStyle({ bg: e.color, hover: e.hover, fg: e.fg, border: e.border, bg2: e.bg2,
            bgType: e.bgType, gradType: e.gradType, gradAngle: e.gradAngle,
            sweep: e.sweep, borderStyle: e.borderStyle, effect: e.effect });
    }
    function putStyle(o, s) {
        for (var k in STYLE_MAP) {
            if (!STYLE_MAP.hasOwnProperty(k)) continue;
            if (s[k] !== undefined) o[STYLE_MAP[k]] = s[k]; else delete o[STYLE_MAP[k]];
        }
    }
    var STYLE_CMP = STYLE_KEYS.concat(STYLE_EXTRA);
    function sameStyle(a, b) {
        if (!a || !b) return false;
        for (var i = 0; i < STYLE_CMP.length; i++) {
            if ((a[STYLE_CMP[i]] || "") !== (b[STYLE_CMP[i]] || "")) return false;
        }
        return true;
    }

    /* El color de un degradado en una sola cadena, para que --b-bg y --b-hover
       lo lleven igual que llevaban un color plano: el CSS no necesita saber
       que hay un degradado detras. Radial no usa el angulo —el primer color
       nace en una esquina fija—, y cónico lo usa como el punto de partida. */
    function gradCss(type, angle, c1, c2) {
        if (type === "radial") return "radial-gradient(circle at 30% 20%, " + c1 + ", " + c2 + ")";
        if (type === "conic") return "conic-gradient(from " + angle + "deg, " + c1 + ", " + c2 + ", " + c1 + ")";
        return "linear-gradient(" + angle + "deg, " + c1 + ", " + c2 + ")";
    }

    function entries() {
        var a = readJson(K_GRID, null);
        if (!a || !a.length) return GRID_DEFAULT.slice();
        var out = [];
        for (var i = 0; i < a.length; i++) {
            // Las versiones viejas guardaban el id a secas.
            if (typeof a[i] === "string") out.push({ id: a[i] });
            else if (a[i] && typeof a[i] === "object") out.push(a[i]);
        }
        return out;
    }

    function firstFreshIndex(list) {
        for (var i = 0; i < list.length; i++) if (list[i] && list[i].fresh) return i;
        return -1;
    }

    /* Se corre una vez al arrancar, antes de dibujar nada. No toca la rejilla
       de quien no la tenga guardada —esa ya viene completa— ni reordena la de
       nadie: solo anade al final lo que falte. */
    function catchUpGrid() {
        var saved = readJson(K_GRID, null);
        if (!saved || !saved.length) {
            try { localStorage.setItem(K_GRID_VER, String(GRID_VERSION)); } catch (e) {}
            try { localStorage.setItem(K_TEXT_GRID_MIGRATION, "1"); } catch (e1) {}
            return;
        }

        var was = 1;
        try { was = parseInt(localStorage.getItem(K_GRID_VER), 10) || 1; } catch (e2) { was = 1; }
        var textMigrationDone = false;
        try { textMigrationDone = localStorage.getItem(K_TEXT_GRID_MIGRATION) === "1"; } catch (e3) {}
        if (was >= GRID_VERSION && textMigrationDone) return;

        var list = entries(), has = {}, i, migrated = false;
        for (i = 0; i < list.length; i++) {
            if (list[i] && list[i].id === "layer.clone") {
                // La version de desarrollo anterior tenia una accion de capa.
                // Mantener posicion y estilo al sustituirla por la de comp.
                list[i].id = "comp.deepClone";
                migrated = true;
            }
            if (list[i] && list[i].id) has[list[i].id] = true;
        }

        var added = 0;
        for (var v = was + 1; v <= GRID_VERSION; v++) {
            var ids = GRID_ADDED[v];
            if (!ids) continue;
            for (i = 0; i < ids.length; i++) {
                if (has[ids[i]]) continue;
                if (ids[i] === "comp.organizeProject") {
                    list.push({ id: ids[i], fresh: true, w: 3, h: 1 });
                } else if (ids[i] === "layer.autoParallax") {
                    list.push({ id: ids[i], fresh: true, w: 2, h: 1 });
                } else if (ids[i] === "time.pasteFit") {
                    list.push({ id: ids[i], fresh: true, w: 2, h: 1 });
                } else {
                    list.push({ id: ids[i], fresh: v >= 5 });
                }
                has[ids[i]] = true;
                added++;
            }
        }

        /* La marca propia cubre compilaciones de prueba que llegaron a guardar
           la version de rejilla antes de registrar la accion. Se escribe aun
           si el boton ya existe; si el usuario lo oculta despues, no reaparece. */
        if (!textMigrationDone && !has["layer.text"]) {
            list.push({ id: "layer.text", fresh: true });
            has["layer.text"] = true;
            added++;
        }

        /* La version 11 divide la accion experimental en una pareja fiable.
           La captura se inserta justo antes de Aplicar para que ambos botones
           queden juntos, y solo se reduce el ancho de fabrica del boton viejo. */
        if (was < 11 && !has["time.capturePasteFit"]) {
            var pasteAt = -1;
            for (i = 0; i < list.length; i++) {
                if (list[i] && list[i].id === "time.pasteFit") { pasteAt = i; break; }
            }
            if (pasteAt >= 0) {
                if ((!list[pasteAt].w || list[pasteAt].w === 2) && (!list[pasteAt].h || list[pasteAt].h === 1)) {
                    list[pasteAt].w = 1;
                    list[pasteAt].h = 1;
                }
                list.splice(pasteAt, 0, { id: "time.capturePasteFit", fresh: true, w: 1, h: 1 });
            } else {
                list.push({ id: "time.capturePasteFit", fresh: true, w: 1, h: 1 });
                list.push({ id: "time.pasteFit", fresh: true, w: 1, h: 1 });
                has["time.pasteFit"] = true;
            }
            has["time.capturePasteFit"] = true;
            added++;
            migrated = true;
        }

        /* La primera implementacion visual solo marco la clonacion en algunas
           rejillas. La version 8 reúne las cinco novedades al final sin crear
           copias y conservando cada personalizacion del usuario. */
        if (was < 8) {
            /* Una compilacion intermedia llego a guardar la version 7 aunque
               no hubiese podido terminar de agregar todos sus botones. No se
               confia solo en el numero: se comprueba cada novedad y se repone
               exclusivamente la que falte. */
            for (i = 0; i < FRESH_COMMANDS.length; i++) {
                if (has[FRESH_COMMANDS[i]]) continue;
                if (FRESH_COMMANDS[i] === "comp.organizeProject") {
                    list.push({ id: FRESH_COMMANDS[i], fresh: true, w: 3, h: 1 });
                } else if (FRESH_COMMANDS[i] === "layer.autoParallax") {
                    list.push({ id: FRESH_COMMANDS[i], fresh: true, w: 2, h: 1 });
                } else if (FRESH_COMMANDS[i] === "time.pasteFit") {
                    list.push({ id: FRESH_COMMANDS[i], fresh: true, w: 2, h: 1 });
                } else {
                    list.push({ id: FRESH_COMMANDS[i], fresh: true });
                }
                has[FRESH_COMMANDS[i]] = true;
                added++;
            }
            var fresh = [], regular = [];
            for (i = 0; i < list.length; i++) {
                var isFresh = false;
                for (var f = 0; f < FRESH_COMMANDS.length; f++) {
                    if (list[i] && list[i].id === FRESH_COMMANDS[f]) { isFresh = true; break; }
                }
                if (isFresh) { list[i].fresh = true; fresh.push(list[i]); }
                else regular.push(list[i]);
            }
            list = regular.concat(fresh);
            migrated = true;
        }

        if (added || migrated) writeJson(K_GRID, list);
        try { localStorage.setItem(K_GRID_VER, String(GRID_VERSION)); } catch (e4) {}
        try { localStorage.setItem(K_TEXT_GRID_MIGRATION, "1"); } catch (e5) {}
    }
    function setEntries(a) {
        writeJson(K_GRID, a);
        renderGrid();
    }

    // La antigua franja ya no existe. Quitar sus preferencias guardadas evita
    // que viajen en los perfiles al exportarlos; es una migracion idempotente.
    function discardOldDiscoveryState() {
        try {
            localStorage.removeItem("editkit_qi_feature_seen");
            localStorage.removeItem("editkit_qi_feature_height");
        } catch (e) {}
        var off = readJson(K_SECTIONS, {});
        if (off && Object.prototype.hasOwnProperty.call(off, "new")) {
            delete off.new;
            writeJson(K_SECTIONS, off);
        }
    }

    // ---- de donde sale cada boton ----
    /* La rejilla puede llevar acciones de los otros dos paneles. Las de aqui se
       ejecutan aqui; las de fuera se ejecutan alla, por la centralita, y el
       aviso sale donde corresponde. */
    function known(id) {
        var c = C.get(id);
        if (c) return { local: true, cmd: c };
        var f = C.foreign();
        for (var i = 0; i < f.length; i++) {
            if (f[i].id === id) return { local: false, panel: f[i].panel, label: f[i].label };
        }
        return null;
    }

    var KIND_KEY = { effect: "qi.kindEffect", script: "qi.kindScript", preset: "qi.kindPreset" };

    function nameOf(e) {
        if (e.name) return e.name;
        if (e.kind && e.kind !== "cmd") return e.value || T(KIND_KEY[e.kind] || "qi.kindEffect");
        var k = known(e.id);
        if (!k) return e.id || "?";
        return k.local ? C.label(k.cmd) : (k.label || e.id);
    }

    /* La descripcion. Es lo que convierte tres letras en algo que se entiende
       sin haberlo pulsado antes, asi que va en la descripcion de cada boton
       detras de su nombre. Las acciones de los otros dos paneles no la tienen:
       ahi se enseña el nombre solo, que es mejor que inventarse una. */
    /* Y de un boton propio —un efecto, un script, un preset— la descripcion es
       su clase, nada mas. Llevaba la clase Y el valor, y el valor casi siempre
       es el nombre otra vez: un efecto llamado "Glow" que apunta al efecto
       "Glow" daba «Glow — Efecto · Glow», y un preset daba su nombre seguido de
       la ruta entera, con el nombre dentro. Repetir no informa.

       El valor solo se anade cuando dice algo que el nombre no diga ya. Y de
       una ruta interesa el archivo, no el disco: lo que distingue dos presets
       es como se llaman, no en que carpeta estan. */
    /* Dos textos que dicen lo mismo aunque no se escriban igual. "Mi script"
       y "mi script.jsx" son el mismo nombre, y repetirlo no informa. */
    function same(a, b) {
        return String(a).toLowerCase() === String(b).toLowerCase();
    }

    function descOf(e) {
        if (e.kind && e.kind !== "cmd") {
            var kind = T(KIND_KEY[e.kind] || "qi.kindEffect");
            var n = String(nameOf(e) || ""), v = String(e.value || "");
            if (!v || same(v, n)) return kind;

            /* Un nombre interno de efecto no le dice nada a nadie: "ADBE
               Gaussian Blur 2" no es el nombre del efecto, es su matricula. Se
               reconoce porque empieza por una sigla en mayusculas —ADBE, CC,
               APC— y ningun efecto de verdad se llama asi. */
            if (e.kind === "effect") {
                if (e.match && same(v, String(e.match))) return kind;
                if (/^[A-Z][A-Z0-9]{1,5}\s/.test(v)) return kind;
            }

            // De una ruta interesa el archivo, no el disco: lo que distingue
            // dos presets es como se llaman, no en que carpeta estan.
            var base = v.replace(/\\/g, "/");
            var cut = base.lastIndexOf("/");
            if (cut >= 0) base = base.substring(cut + 1);
            var stem = base.replace(/\.[^.]+$/, "");
            if (!base || same(base, n) || same(stem, n)) return kind;

            return kind + " · " + base;
        }
        var k = "aa.d." + e.id;
        var s = T(k);
        return s === k ? "" : s;
    }

    function tipOf(e) {
        var n = nameOf(e), d = descOf(e);
        return d ? (n + " — " + d) : n;
    }

    /* Un boton de una columna conserva la lectura rapida de siempre: tres
       letras elegidas por defecto y hasta cuatro si el usuario las escribe.
       Al ensancharlo deja de ser una abreviatura y puede mostrar su nombre
       completo. El valor largo no se destruye al volverlo estrecho: solo se
       recorta al dibujarlo, para que reaparezca si se amplia otra vez. */
    var ABBR_LIMIT = 4;
    var ABBR_DEFAULT = 3;
    var LABEL_LIMIT = 40;
    function spanOf(e, key) {
        var n = parseInt(e && e[key], 10);
        return isFinite(n) ? Math.max(1, Math.min(3, n)) : 1;
    }
    function labelLimit(e) { return spanOf(e, "w") > 1 ? LABEL_LIMIT : ABBR_LIMIT; }
    function abbrOf(e) {
        var limit = labelLimit(e);
        if (e.abbr) return String(e.abbr).substring(0, limit);
        if (spanOf(e, "w") > 1) return nameOf(e).substring(0, limit);
        if (!e.kind || e.kind === "cmd") {
            var k = "aa.ab." + e.id;
            var s = T(k);
            if (s !== k) return s.substring(0, ABBR_LIMIT);
        }
        return nameOf(e).substring(0, ABBR_DEFAULT).toUpperCase();
    }

    /* Una ruta de disco no es una URL. El detalle que importa: C:/x pasa a
       /C:/x antes del prefijo, o el navegador lo lee como maquina de red y no
       carga nada. */
    function fileUrl(p) {
        if (!p) return "";
        var s = String(p).replace(/^\s+|\s+$/g, "");
        if (/^(data:|https?:|file:)/i.test(s)) return s;
        var win = /^[A-Za-z]:[\\/]/.test(s), unc = /^\\\\/.test(s), posix = /^\//.test(s);
        if (!win && !unc && !posix) return encodeURI(s.replace(/\\/g, "/"));
        var q = s.replace(/\\/g, "/");
        if (unc) return "file:" + encodeURI(q);
        if (!posix) q = "/" + q;
        return "file://" + encodeURI(q);
    }

    /* HUECOS CON DOS CARAS

       Hay botones que llevan una pareja: se pulsan y hacen lo suyo, se pulsan
       con Control y hacen la otra. La pareja se declara aqui y no dentro de
       cada funcion para que el truco valga igual en la rejilla, en el panel de
       arriba y en la paleta de comandos, sin que ninguna de las tres tenga que
       saber nada del asunto.

       Solo para parejas que son LA MISMA COSA con otro ajuste: el nulo
       recortado al tramo en vez de entero, la capa de ajuste de composicion
       entera en vez de la de la capa, precomponer todo junto en vez de por
       separado. Un Control que hace algo sin relacion con el boton no es un
       atajo, es una trampa. */
    var CTRL_PAIR = {
        "layer.adjustment": "layer.adjustmentComp",
        "layer.parentNull": "layer.parentNullSpan",
        "comp.precompose":  "comp.precomposeAll",
        "layer.solid":      "layer.solidSel",
        "layer.shape":      "layer.shapeSel",
        "layer.text":       "layer.textSel",
        "layer.camera":     "layer.cameraOne",
        "time.freeze":      "time.freezeIn"
    };

    function runEntry(e, ev) {
        var H = host();
        if (e.kind === "effect") {
            /* El nombre interno va por delante cuando lo hay: el visible cambia
               con el idioma de After Effects, el interno no. Los botones hechos
               a mano antes de que existiera el buscador solo tienen el visible,
               y siguen funcionando igual. */
            if (H) H.call("ek_applyEffect", { name: e.value, match: e.match || "" }, function (r) {
                showToast("\u2713 " + (r.layers || 0) + " \u00b7 " + nameOf(e));
            });
            return;
        }
        if (e.kind === "script") {
            if (H) H.call("ek_runScript", { path: e.value }, function () {
                showToast("\u2713 " + nameOf(e));
            });
            return;
        }
        if (e.kind === "preset") {
            /* Las tres opciones de "varias capas" viajan con CADA preset, no
               con una funcion aparte: aplicar un preset a cinco capas y que la
               animacion caiga en la entrada de cada una es lo que el usuario
               espera que pase, no una funcion que haya que ir a buscar. */
            var po = presetOpts();
            if (H) H.call("ek_applyPreset", {
                path: e.value, at: po.at, fit: po.fit, stagger: po.stagger
            }, function (r) {
                showToast("\u2713 " + (r.layers || 0) + " \u00b7 " + nameOf(e));
            });
            return;
        }
        var id = e.id;
        if (ev && (ev.ctrlKey || ev.metaKey) && CTRL_PAIR[id] && known(CTRL_PAIR[id])) {
            id = CTRL_PAIR[id];
        }
        var k = known(id);
        if (!k) return;
        if (k.local) C.run(id, true);
        else if (C.runIn) C.runIn(k.panel, id);
    }

    function press(btn) {
        btn.classList.remove("pressed");
        void btn.offsetWidth;                 // reinicia la animacion
        btn.classList.add("pressed");
        setTimeout(function () { btn.classList.remove("pressed"); }, 180);
    }

    var resizeClickUntil = 0;
    var dragClickUntil = 0;

    function gridColumns() {
        var box = $("qiGrid"), app = document.querySelector(".app"), cols = 3;
        try { cols = parseInt(localStorage.getItem(K_COLS), 10) || 3; } catch (e) {}
        if (app && app.classList.contains("wide") && box && box.clientWidth) {
            cols = Math.max(1, Math.floor((box.clientWidth + 5) / 83));
        }
        return Math.max(1, cols);
    }

    function applySpan(b, w, h) {
        var columns = gridColumns();
        w = Math.min(spanOf({ w: w }, "w"), columns);
        h = spanOf({ h: h }, "h");
        b.style.gridColumnEnd = "span " + w;
        b.style.gridRowEnd = "span " + h;
        b.style.height = "calc(var(--qi-btn-h) * " + h + " + 5px * " + (h - 1) + ")";
        b.setAttribute("data-span-w", String(w));
        b.setAttribute("data-span-h", String(h));
        if (w > 1) b.setAttribute("data-wide-button", "true");
        else b.removeAttribute("data-wide-button");
    }

    /* La muesca inferior derecha sigue la convencion conocida: moverla hacia
       la derecha amplia y moverla hacia la izquierda reduce. En 1x1, ir a la
       izquierda se queda en el minimo en vez de invertir el gesto. */
    function spanFromHorizontalDrag(start, delta, step, maximum) {
        var cells = Math.round(delta / step);
        return Math.max(1, Math.min(maximum, start + cells));
    }

    function clearSpanMorph(b) {
        if (b._qiMorphTimer) {
            clearTimeout(b._qiMorphTimer);
            b._qiMorphTimer = null;
        }
        b.classList.remove("qi-resize-morph-run");
        b.classList.remove("qi-resize-morph");
        b.style.removeProperty("--qi-morph-x");
        b.style.removeProperty("--qi-morph-y");
    }

    function morphSpan(b, w, h) {
        var before = b.getBoundingClientRect ? b.getBoundingClientRect() : null;
        clearSpanMorph(b);
        applySpan(b, w, h);
        if (!before || !b.getBoundingClientRect) return;
        var after = b.getBoundingClientRect();
        if (!after.width || !after.height) return;
        var sx = before.width / after.width, sy = before.height / after.height;
        if (Math.abs(sx - 1) < .01 && Math.abs(sy - 1) < .01) return;
        b.style.setProperty("--qi-morph-x", String(sx));
        b.style.setProperty("--qi-morph-y", String(sy));
        b.classList.add("qi-resize-morph");
        void b.offsetWidth;
        dragFrame(function () { b.classList.add("qi-resize-morph-run"); });
        b._qiMorphTimer = setTimeout(function () {
            clearSpanMorph(b);
        }, 260);
    }

    function persistSpan(index, w, h) {
        var list = entries();
        if (!list[index]) return;
        list[index].w = w;
        list[index].h = h;
        writeJson(K_GRID, list);
    }

    function wireResize(handle, b, e, index) {
        handle.addEventListener("mousedown", function (down) {
            if (down.button !== undefined && down.button !== 0) return;
            down.preventDefault();
            down.stopPropagation();
            closeMenu();
            var box = $("qiGrid"), columns = gridColumns();
            var gap = 5, startW = Math.min(spanOf(e, "w"), columns), startH = spanOf(e, "h");
            var rect = box && box.getBoundingClientRect ? box.getBoundingClientRect() : null;
            var cellW = rect && rect.width ? (rect.width - gap * (columns - 1)) / columns : 78;
            var btnH = 34;
            try {
                var rawH = localStorage.getItem(K_BTNH);
                btnH = parseInt(rawH, 10) || 34;
            } catch (ignore) {}
            var nextW = startW, nextH = startH, changed = false;
            var badge = document.createElement("span");
            badge.className = "qi-resize-size";
            b.appendChild(badge);
            badge.textContent = startW + "\u00d7" + startH;
            b.classList.add("resizing");
            b.setAttribute("draggable", "false");

            function move(ev) {
                var w = spanFromHorizontalDrag(startW,
                    ev.clientX - down.clientX, cellW + gap, Math.min(3, columns));
                var h = Math.max(1, Math.min(3,
                    startH + Math.round((ev.clientY - down.clientY) / (btnH + gap))));
                if (w === nextW && h === nextH) return;
                nextW = w;
                nextH = h;
                changed = true;
                morphSpan(b, nextW, nextH);
                badge.textContent = nextW + "\u00d7" + nextH;
            }
            function up() {
                document.removeEventListener("mousemove", move);
                document.removeEventListener("mouseup", up);
                resizeClickUntil = new Date().getTime() + 250;
                if (changed) {
                    e.w = nextW;
                    e.h = nextH;
                    persistSpan(index, nextW, nextH);
                    var label = b.querySelector ? b.querySelector(".qi-btn-label") : null;
                    if (label) label.textContent = abbrOf(e);
                }
                if (badge.parentNode) badge.parentNode.removeChild(badge);
                b.classList.remove("resizing");
                b.setAttribute("draggable", "false");
            }
            document.addEventListener("mousemove", move);
            document.addEventListener("mouseup", up);
        });
        handle.addEventListener("click", function (ev) { ev.preventDefault(); ev.stopPropagation(); });
        handle.addEventListener("contextmenu", function (ev) { ev.preventDefault(); ev.stopPropagation(); });
    }

    function suspendAnimatedButtonMedia() {
        var awake = window.EditKitAwake;
        var suspend = !!(awake && (awake.idle() || awake.performance()));
        each('.qi-btn-cell img[data-ek-gif="1"]', function (img) {
            if (suspend) {
                if (!img.hasAttribute("data-ek-paused-src")) {
                    img.setAttribute("data-ek-paused-src", img.getAttribute("src") || "");
                    img.removeAttribute("src");
                }
            } else if (img.hasAttribute("data-ek-paused-src")) {
                var src = img.getAttribute("data-ek-paused-src");
                img.removeAttribute("data-ek-paused-src");
                if (src) img.setAttribute("src", src);
            }
        });
    }
    if (window.addEventListener) {
        window.addEventListener("editkit-runtimechange", suspendAnimatedButtonMedia);
    }

    // Un boton puede ocupar de una a tres celdas en ambos ejes. El tamaño se
    // guarda en el mismo objeto que su estilo, asi que tambien viaja en perfiles.
    function cell(e, index) {
        var b = document.createElement("button");
        b.type = "button";
        b.className = "qi-btn-cell";
        if (e.fresh) b.classList.add("qi-fresh");
        b.setAttribute("draggable", "false");
        b.setAttribute("data-slot", String(index));
        if (e.id) b.setAttribute("data-command-id", e.id);
        if (e.kind && e.kind !== "cmd") b.setAttribute("data-kind", e.kind);
        applySpan(b, spanOf(e, "w"), spanOf(e, "h"));

        // Los colores del usuario ganan por variable, no por regla: asi el tipo
        // (dorado, plateado, jade) sigue poniendo el suyo cuando no hay ninguno.
        // Un degradado se pinta igual: --b-bg lleva la funcion CSS entera y al
        // CSS de siempre no le hace falta saber que hay detras.
        if (e.bgType === "gradient" && e.color && e.bg2) {
            var ang = (typeof e.gradAngle === "number") ? e.gradAngle : 135;
            var gt = e.gradType || "linear";
            b.style.setProperty("--b-bg", gradCss(gt, ang, e.color, e.bg2));
            b.style.setProperty("--b-hover", gradCss(gt, ang, e.hover || e.color, e.bg2));
        } else {
            if (e.color) b.style.setProperty("--b-bg", e.color);
            if (e.hover) b.style.setProperty("--b-hover", e.hover);
        }
        // Texto y borde llegan con los estilos. Al pasar el mouse se quedan: el
        // cambio de fondo ya dice que el cursor esta encima.
        if (e.fg) { b.style.setProperty("--b-fg", e.fg); b.style.setProperty("--b-fg-hover", e.fg); }
        if (e.border) { b.style.setProperty("--b-border", e.border); b.style.setProperty("--b-border-hover", e.border); }
        // Destello y bordes decorados: por atributo y clase, no por variable,
        // porque lo que cambian es que regla de CSS entra a jugar, no un color.
        /* El destello se dispara al entrar el mouse, pero termina esté o no
           el cursor todavia encima: la clase la enciende "mouseenter" y solo
           la apaga "animationend", nunca "mouseleave". */
        if (e.sweep) {
            b.classList.add("qi-sweep");
            // Un pase, no uno por cada vez que el mouse entra: si ya esta en
            // marcha, entrar y salir varias veces seguidas no lo reinicia,
            // solo lo deja terminar.
            b.addEventListener("mouseenter", function () {
                if (b.classList.contains("qi-sweeping")) return;
                b.classList.add("qi-sweeping");
            });
            b.addEventListener("animationend", function (ev) {
                if (ev.animationName === "qiSweep") b.classList.remove("qi-sweeping");
            });
        }
        if (BORDER_STYLES[e.borderStyle]) b.setAttribute("data-border", e.borderStyle);
        if (e.effect === "soft3d") b.setAttribute("data-effect", "soft3d");

        var txt = abbrOf(e);
        var nativeMarkup = window.EditKitQuickIcons ? window.EditKitQuickIcons.markup(e.id) : "";
        if (e.icon) {
            var img = document.createElement("img");
            img.src = fileUrl(e.icon);
            img.alt = "";
            if (/\.gif(?:$|[?#])/i.test(String(e.icon)) || /^data:image\/gif/i.test(String(e.icon))) {
                img.setAttribute("data-ek-gif", "1");
            }
            var performanceLabel = document.createElement("span");
            performanceLabel.className = "qi-performance-label";
            performanceLabel.textContent = txt;
            // Si el archivo se movio o se borro, el boton vuelve al texto en
            // lugar de quedarse como un cuadro vacio que no dice nada.
            img.addEventListener("error", function () {
                if (img.hasAttribute("data-ek-paused-src")) return;
                if (img.parentNode) img.parentNode.removeChild(img);
                b.removeAttribute("data-fill");
                performanceLabel.className = e.fresh ? "qi-btn-label qi-fresh-label" : "qi-btn-label";
                b.insertBefore(performanceLabel, b.firstChild || null);
            });
            b.appendChild(img);
            b.appendChild(performanceLabel);
            if (window.EditKitAwake && (window.EditKitAwake.idle() || window.EditKitAwake.performance())) {
                suspendAnimatedButtonMedia();
            }
            // Rellenar cubre el boton entero con la foto; el relieve de luz en
            // los bordes es del CSS y no de aqui, para que no se pueda apagar
            // por separado y dejar la imagen plana.
            if (e.fill === "cover") b.setAttribute("data-fill", "cover");
        } else if (nativeMarkup) {
            b.classList.add("qi-native-icon-button");
            /* Una abreviatura escrita a mano conserva la prioridad que tenia
               antes de existir el modo de iconos. El selector individual puede
               imponerse a ella sin borrarla, para poder volver despues. */
            if (e.nativeView === "icons") b.classList.add("qi-force-icon");
            else if (e.nativeView === "abbr" || e.abbr) b.classList.add("qi-force-abbr");
            b.innerHTML = nativeMarkup;
            var nativeLabel = document.createElement("span");
            nativeLabel.className = (e.fresh ? "qi-btn-label qi-fresh-label" : "qi-btn-label") + " qi-native-label";
            nativeLabel.textContent = txt;
            b.appendChild(nativeLabel);
        } else {
            var label = document.createElement("span");
            label.className = e.fresh ? "qi-btn-label qi-fresh-label" : "qi-btn-label";
            label.textContent = txt;
            b.appendChild(label);
        }
        if (nativeMarkup && e.id === "time.capturePasteFit") {
            var readyMark = document.createElement("span");
            readyMark.className = "qi-native-ready-mark";
            readyMark.textContent = "\u2713";
            readyMark.setAttribute("aria-hidden", "true");
            b.appendChild(readyMark);
        }
        if (e.fresh) {
            for (var sparkle = 0; sparkle < 6; sparkle++) {
                var dot = document.createElement("span");
                dot.className = "qi-fresh-spark";
                dot.setAttribute("aria-hidden", "true");
                b.appendChild(dot);
            }
        }

        var resize = document.createElement("span");
        resize.className = "qi-resize-handle";
        resize.title = T("qi.resizeHint");
        resize.setAttribute("aria-hidden", "true");
        b.appendChild(resize);
        wireResize(resize, b, e, index);

        // Nombre y descripcion en la descripcion del boton; el atajo se le pega
        // detras cuando la accion ya se ha usado unas cuantas veces.
        var tip = tipOf(e);
        b.setAttribute("aria-label", tip);
        if (!e.kind || e.kind === "cmd") {
            if (C.get(e.id)) C.decorate(b, e.id, tip);
            else b.title = tip;
        } else {
            b.title = tip;
        }

        b.addEventListener("click", function (ev) {
            if (new Date().getTime() < resizeClickUntil || new Date().getTime() < dragClickUntil) return;
            press(b); runEntry(e, ev);
        });
        if (e.fresh) b.addEventListener("click", dismissFreshIntro);
        b.addEventListener("contextmenu", function (ev) {
            ev.preventDefault();
            openMenu(index, ev.clientX, ev.clientY);
        });
        wireDrag(b, index);
        return b;
    }

    function syncHiddenBtn() {
        var b = $("qiUnhideAll");
        if (!b) return;
        var n = hiddenCount();
        b.hidden = !n;
        if (n) b.textContent = T("qi.unhideAll") + " (" + n + ")";
    }

    /* Algunas acciones forman un flujo de dos pasos. Se dibujan, mueven y
       redimensionan como una sola pieza, pero cada mitad conserva su clic, su
       menu y su estado. La tabla deja listo el tratamiento para futuras
       parejas. */
    var DEPENDENT_BUTTON_PAIRS = [
        ["time.capturePasteFit", "time.pasteFit"]
    ];

    function normalizeDependentPairOrder(list) {
        var changed = false;
        for (var p = 0; p < DEPENDENT_BUTTON_PAIRS.length; p++) {
            var ids = DEPENDENT_BUTTON_PAIRS[p], firstIndex = -1, secondIndex = -1;
            for (var i = 0; i < list.length; i++) {
                if (!list[i]) continue;
                if (firstIndex < 0 && list[i].id === ids[0]) firstIndex = i;
                if (secondIndex < 0 && list[i].id === ids[1]) secondIndex = i;
            }
            if (firstIndex < 0 || secondIndex < 0 || secondIndex === firstIndex + 1) continue;
            var second = list.splice(secondIndex, 1)[0];
            if (secondIndex < firstIndex) firstIndex--;
            list.splice(firstIndex + 1, 0, second);
            changed = true;
        }
        return changed;
    }

    function pairSpan(w, h, columns) {
        columns = Math.max(1, columns || gridColumns());
        w = Math.max(1, Math.min(Math.min(3, columns), parseInt(w, 10) || 2));
        h = Math.max(1, Math.min(3, parseInt(h, 10) || 1));
        /* Una pareja nunca puede volver a 1x1. En una rejilla de una columna
           su forma minima es vertical; con dos o mas, horizontal. */
        if (w === 1 && h === 1) {
            if (columns >= 2) w = 2;
            else h = 2;
        }
        return { w: w, h: h };
    }

    function applyPairSpan(pair, w, h) {
        var size = pairSpan(w, h, gridColumns());
        pair.style.gridColumnEnd = "span " + size.w;
        pair.style.gridRowEnd = "span " + size.h;
        pair.style.height = "calc(var(--qi-btn-h) * " + size.h + " + 5px * " + (size.h - 1) + ")";
        pair.setAttribute("data-span-w", String(size.w));
        pair.setAttribute("data-span-h", String(size.h));
        pair.setAttribute("data-orientation", size.w === 1 ? "vertical" : "horizontal");
        return size;
    }

    function persistPairSpan(firstIndex, secondIndex, w, h) {
        var list = entries();
        if (!list[firstIndex] || !list[secondIndex]) return;
        list[firstIndex].pairW = w;
        list[firstIndex].pairH = h;
        list[secondIndex].pairW = w;
        list[secondIndex].pairH = h;
        writeJson(K_GRID, list);
    }

    function wirePairResize(handle, pair, firstIndex, secondIndex) {
        handle.addEventListener("mousedown", function (down) {
            if (down.button !== undefined && down.button !== 0) return;
            down.preventDefault();
            down.stopPropagation();
            closeMenu();
            var box = $("qiGrid"), columns = gridColumns(), gap = 5;
            var startW = parseInt(pair.getAttribute("data-span-w"), 10) || 2;
            var startH = parseInt(pair.getAttribute("data-span-h"), 10) || 1;
            var rect = box && box.getBoundingClientRect ? box.getBoundingClientRect() : null;
            var cellW = rect && rect.width ? (rect.width - gap * (columns - 1)) / columns : 78;
            var btnH = 34;
            try { btnH = parseInt(localStorage.getItem(K_BTNH), 10) || 34; } catch (ignore) {}
            var nextW = startW, nextH = startH, changed = false;
            var badge = document.createElement("span");
            badge.className = "qi-resize-size";
            badge.textContent = startW + "\u00d7" + startH;
            pair.appendChild(badge);
            pair.classList.add("resizing");

            function move(ev) {
                var w = spanFromHorizontalDrag(startW,
                    ev.clientX - down.clientX, cellW + gap, Math.min(3, columns));
                var h = Math.max(1, Math.min(3,
                    startH + Math.round((ev.clientY - down.clientY) / (btnH + gap))));
                var size = pairSpan(w, h, columns);
                if (size.w === nextW && size.h === nextH) return;
                nextW = size.w;
                nextH = size.h;
                changed = true;
                applyPairSpan(pair, nextW, nextH);
                badge.textContent = nextW + "\u00d7" + nextH;
            }
            function up() {
                document.removeEventListener("mousemove", move);
                document.removeEventListener("mouseup", up);
                resizeClickUntil = new Date().getTime() + 250;
                if (changed) persistPairSpan(firstIndex, secondIndex, nextW, nextH);
                if (badge.parentNode) badge.parentNode.removeChild(badge);
                pair.classList.remove("resizing");
            }
            document.addEventListener("mousemove", move);
            document.addEventListener("mouseup", up);
        });
        handle.addEventListener("click", function (ev) { ev.preventDefault(); ev.stopPropagation(); });
        handle.addEventListener("contextmenu", function (ev) { ev.preventDefault(); ev.stopPropagation(); });
    }

    function joinDependentButtons(box) {
        if (!box) return;
        var list = entries();
        for (var i = 0; i < DEPENDENT_BUTTON_PAIRS.length; i++) {
            var ids = DEPENDENT_BUTTON_PAIRS[i];
            var first = box.querySelector('.qi-btn-cell[data-command-id="' + ids[0] + '"]');
            var second = box.querySelector('.qi-btn-cell[data-command-id="' + ids[1] + '"]');
            if (!first || !second || first.parentNode !== box || second.parentNode !== box) continue;
            var firstIndex = parseInt(first.getAttribute("data-slot"), 10);
            var secondIndex = parseInt(second.getAttribute("data-slot"), 10);
            if (isNaN(firstIndex) || isNaN(secondIndex) || !list[firstIndex] || !list[secondIndex]) continue;

            var pair = document.createElement("div");
            pair.className = "qi-dependent-pair";
            pair.setAttribute("data-pair", ids[0] + ":" + ids[1]);
            pair.setAttribute("data-first-slot", String(firstIndex));
            pair.setAttribute("data-second-slot", String(secondIndex));
            box.insertBefore(pair, first);
            first.classList.add("qi-pair-start");
            second.classList.add("qi-pair-end");
            pair.appendChild(first);
            pair.appendChild(second);
            applyPairSpan(pair,
                list[firstIndex].pairW || list[secondIndex].pairW || 2,
                list[firstIndex].pairH || list[secondIndex].pairH || 1);
            var resize = document.createElement("span");
            resize.className = "qi-resize-handle qi-pair-resize-handle";
            resize.title = T("qi.resizeHint");
            resize.setAttribute("aria-hidden", "true");
            pair.appendChild(resize);
            wirePairResize(resize, pair, firstIndex, secondIndex);
            wirePairDrag(pair, firstIndex, secondIndex);
        }
    }

    function renderGrid() {
        var box = $("qiGrid");
        if (!box) return;
        box.innerHTML = "";

        var list = entries(), shown = 0, divider = null, renderError = false;
        /* Una pareja es atomica tambien en el orden guardado. Asi arrastrar
           cualquier otro boton nunca deja una mitad en otra fila invisible ni
           desplaza elementos que no eran el destino. */
        if (normalizeDependentPairOrder(list)) writeJson(K_GRID, list);
        for (var i = 0; i < list.length; i++) {
            var e = list[i];
            if (e.off) continue;      // oculto por el usuario, no borrado
            // Una accion que ya no existe no se dibuja, pero tampoco se borra:
            // puede ser de un panel que todavia no ha anunciado lo suyo.
            if ((!e.kind || e.kind === "cmd") && !known(e.id)) continue;
            /* Un boton guardado por una version anterior, o un dato externo
               dañado, no puede volver a dejar vacia toda la rejilla. Se arma
               primero fuera del DOM; si esa entrada falla se registra para
               diagnostico y QuickIt sigue dibujando las demas. */
            var button = null;
            try { button = cell(e, i); }
            catch (cellError) {
                renderError = true;
                rememberBootError("button " + (e.id || e.kind || i), cellError);
                continue;
            }
            if (e.fresh && !divider) {
                divider = document.createElement("div");
                divider.className = "qi-fresh-divider";
                divider.setAttribute("role", "separator");
                box.appendChild(divider);
                if (!freshIntroSeen()) {
                    var intro = document.createElement("div");
                    intro.id = "qiFreshIntro";
                    intro.className = "qi-fresh-intro";
                    intro.textContent = T("qi.freshIntro");
                    box.appendChild(intro);
                }
            }
            box.appendChild(button);
            shown++;
        }

        /* Y al final, si hay algo escondido, un hueco que lo dice.

           Ocultar un boton estaba resuelto; recuperarlo habia que ir a
           buscarlo —al menu de anadir o a los ajustes—, y eso solo funciona si
           uno se acuerda de que lo oculto. Este hueco esta donde estaban los
           botones, aparece solo cuando hay alguno guardado y desaparece en
           cuanto no queda ninguno: es la misma idea que los presets ocultos de
           EaseIt, que tampoco se van del todo.

           Va con aspecto de hueco y no de boton a proposito: no ejecuta nada
           sobre la composicion, y un boton igual a sus vecinos que en realidad
           abre una lista seria una trampa en una rejilla donde todo lo demas
           aplica algo de un clic. */
        var off = hiddenCount();
        if (off) {
            var ghost = document.createElement("button");
            ghost.type = "button";
            ghost.className = "qi-btn-cell qi-ghost";
            ghost.title = TF("qi.ghostTip", off);
            ghost.innerHTML =
                '<svg class="ms" viewBox="0 -960 960 960" width="12" height="12" fill="currentColor" aria-hidden="true">' +
                '<path d="M480-320q75 0 127.5-52.5T660-500q0-75-52.5-127.5T480-680q-75 0-127.5 52.5T300-500q0 75 52.5 127.5T480-320Zm0-72q-45 0-76.5-31.5T372-500q0-45 31.5-76.5T480-608q45 0 76.5 31.5T588-500q0 45-31.5 76.5T480-392Zm0 192q-146 0-266-81.5T40-500q54-137 174-218.5T480-800q146 0 266 81.5T920-500q-54 137-174 218.5T480-200Z"/></svg>' +
                '<span class="qi-ghost-n">' + off + '</span>';
            ghost.addEventListener("click", function (ev) {
                openHidden(ev.clientX, ev.clientY);
            });
            // Con el derecho, lo mismo: es lo que se hace con todo lo demas de
            // esta rejilla.
            ghost.addEventListener("contextmenu", function (ev) {
                ev.preventDefault();
                openHidden(ev.clientX, ev.clientY);
            });
            if (divider) box.insertBefore(ghost, divider);
            else box.appendChild(ghost);
            shown++;
        }

        if (!shown) {
            var empty = document.createElement("div");
            empty.className = "qi-empty";
            empty.textContent = T("qi.gridEmpty");
            box.appendChild(empty);
        }
        joinDependentButtons(box);
        syncHiddenBtn();
        if (!renderError) {
            try { localStorage.removeItem(K_BOOT_ERROR); } catch (e2) {}
        }
        maybeAcknowledgeFreshIntro();
    }


    /* Con la rejilla vacia no queda ningun boton al que darle con el derecho,
       y es justo cuando hace falta el menu. Se le da al hueco. */
    (function () {
        var box = $("qiGrid");
        if (!box) return;
        box.addEventListener("contextmenu", function (ev) {
            if (ev.target !== box && ev.target.className !== "qi-empty") return;
            ev.preventDefault();
            openAdd(entries().length, ev.clientX, ev.clientY);
        });
    })();

    // ---- arrastrar para reordenar, en la propia rejilla ----
    /* No se usa el drag nativo de Chromium. CEP suspende los eventos de rueda
       mientras muestra su fantasma de arrastre, por lo que una pieza lejana no
       se podia llevar de una punta a otra. El gesto propio mantiene el boton
       pulsado, deja viva la rueda y solo guarda al soltar. */
    var dragFrom = -1, dragOver = -1, dragGroupSlots = null;

    function clearDragMarks() {
        each(".qi-btn-cell", function (o) {
            o.classList.remove("dragging");
            o.classList.remove("drag-over");
        });
        each(".qi-dependent-pair", function (o) { o.classList.remove("dragging"); });
        dragOver = -1;
    }

    function dragFrame(fn) {
        if (window.requestAnimationFrame) window.requestAnimationFrame(fn);
        else setTimeout(fn, 0);
    }

    function createDragGhost(source, x, y) {
        if (!source.cloneNode || !source.getBoundingClientRect || !document.body) return null;
        var rect = source.getBoundingClientRect();
        var ghost = source.cloneNode(true);
        ghost.classList.remove("dragging");
        ghost.classList.remove("drag-over");
        ghost.classList.remove("resizing");
        ghost.classList.remove("pressed");
        ghost.classList.remove("qi-sweeping");
        ghost.classList.add("qi-drag-ghost");
        /* El fantasma vive en body, fuera de .app. Por eso no hereda el modo
           global icono/abreviatura: se congela aqui exactamente la variante
           que el usuario estaba viendo antes de empezar a arrastrar. */
        var sourceLabel = source.querySelector ? source.querySelector(".qi-native-label") : null;
        if (sourceLabel && source.classList.contains("qi-dependent-pair")) {
            var sourceNative = source.querySelectorAll(".qi-native-icon-button");
            var ghostNative = ghost.querySelectorAll(".qi-native-icon-button");
            for (var ni = 0; ni < sourceNative.length && ni < ghostNative.length; ni++) {
                var itemLabel = sourceNative[ni].querySelector(".qi-native-label");
                var itemVisible = true;
                try { itemVisible = window.getComputedStyle(itemLabel).display !== "none"; }
                catch (itemDisplayError) { itemVisible = sourceNative[ni].classList.contains("qi-force-abbr"); }
                ghostNative[ni].classList.add(itemVisible ? "qi-drag-item-abbr" : "qi-drag-item-icon");
            }
        } else if (sourceLabel) {
            var labelVisible = true;
            try { labelVisible = window.getComputedStyle(sourceLabel).display !== "none"; }
            catch (displayError) { labelVisible = source.classList.contains("qi-force-abbr"); }
            ghost.classList.add(labelVisible ? "qi-drag-show-abbr" : "qi-drag-show-icon");
        }
        ghost.removeAttribute("data-slot");
        ghost.removeAttribute("draggable");
        ghost.style.width = rect.width + "px";
        ghost.style.height = rect.height + "px";
        ghost._qiGrabX = x - rect.left;
        ghost._qiGrabY = y - rect.top;
        ghost.style.left = (x - ghost._qiGrabX) + "px";
        ghost.style.top = (y - ghost._qiGrabY) + "px";
        document.body.appendChild(ghost);
        void ghost.offsetWidth;
        dragFrame(function () { ghost.classList.add("lifted"); });
        return ghost;
    }

    function moveDragGhost(ghost, x, y) {
        if (!ghost) return;
        ghost.style.left = (x - ghost._qiGrabX) + "px";
        ghost.style.top = (y - ghost._qiGrabY) + "px";
    }

    function finishDragGhost(ghost, target, preserveSize) {
        if (!ghost) return;
        if (target && target.getBoundingClientRect) {
            var rect = target.getBoundingClientRect();
            ghost.style.left = rect.left + "px";
            ghost.style.top = rect.top + "px";
            if (!preserveSize) {
                ghost.style.width = rect.width + "px";
                ghost.style.height = rect.height + "px";
            }
        }
        ghost.classList.remove("lifted");
        ghost.classList.add("dropping");
        setTimeout(function () {
            if (ghost.parentNode) ghost.parentNode.removeChild(ghost);
        }, 170);
    }

    function buttonAtPoint(x, y) {
        var node = document.elementFromPoint ? document.elementFromPoint(x, y) : null;
        while (node && node !== document.body) {
            if ((" " + (node.className || "") + " ").indexOf(" qi-btn-cell ") >= 0) return node;
            node = node.parentNode;
        }
        return null;
    }

    function markDragTarget(x, y) {
        var target = buttonAtPoint(x, y), next = -1;
        if (target) next = parseInt(target.getAttribute("data-slot"), 10);
        if (isNaN(next)) next = -1;
        if (dragGroupSlots && (next === dragGroupSlots[0] || next === dragGroupSlots[1])) next = dragFrom;
        if (next === dragOver) return;
        each(".qi-btn-cell", function (o) { o.classList.remove("drag-over"); });
        dragOver = next;
        if (target && next !== dragFrom) target.classList.add("drag-over");
    }

    function moveDraggedEntry(from, target) {
        if (from < 0 || target < 0 || from === target) return false;
        var a = entries();
        if (!a[from] || !a[target]) return false;
        var moved = a.splice(from, 1)[0];
        var firstFresh = firstFreshIndex(a);
        if (!moved.fresh && firstFresh >= 0) target = Math.min(target, firstFresh);
        if (moved.fresh && firstFresh >= 0 && target < firstFresh) delete moved.fresh;
        a.splice(target, 0, moved);
        setEntries(a);
        return true;
    }

    function moveDraggedPair(firstIndex, secondIndex, target) {
        if (firstIndex < 0 || secondIndex < 0 || target < 0 ||
            target === firstIndex || target === secondIndex) return false;
        var a = entries();
        if (!a[firstIndex] || !a[secondIndex] || !a[target]) return false;
        var first = a[firstIndex], second = a[secondIndex];
        var remove = [firstIndex, secondIndex].sort(function (x, y) { return y - x; });
        var insertAt = target;
        for (var i = 0; i < remove.length; i++) {
            if (remove[i] < target) insertAt--;
            a.splice(remove[i], 1);
        }
        insertAt = Math.max(0, Math.min(insertAt, a.length));
        var firstFresh = firstFreshIndex(a);
        if (!first.fresh && firstFresh >= 0) insertAt = Math.min(insertAt, firstFresh);
        if (first.fresh && firstFresh >= 0 && insertAt < firstFresh) {
            delete first.fresh;
            delete second.fresh;
        }
        a.splice(insertAt, 0, first, second);
        setEntries(a);
        return true;
    }

    /* La rueda llega normalmente porque ya no hay un drag nativo activo. Se
       conserva mousewheel como respaldo para las versiones antiguas de CEF
       usadas por algunas ediciones de After Effects. */
    function scrollWhileDragging(e) {
        if (dragFrom < 0) return;
        var box = $("qiGrid");
        if (!box || box.scrollHeight <= box.clientHeight) return;
        var delta = Number(e.deltaY || 0);
        if (!delta && e.wheelDelta) delta = -Number(e.wheelDelta);
        if (!delta && e.detail) delta = Number(e.detail) * 18;
        if (!delta) return;
        if (e.deltaMode === 1) delta *= 18;
        else if (e.deltaMode === 2) delta *= box.clientHeight;
        delta = Math.max(-120, Math.min(120, delta));
        if (Math.abs(delta) < 8) delta = delta < 0 ? -8 : 8;
        var before = box.scrollTop;
        box.scrollTop = Math.max(0, Math.min(box.scrollHeight - box.clientHeight, before + delta));
        if (box.scrollTop !== before) {
            e.preventDefault();
            e.stopPropagation();
            markDragTarget(e.clientX || 0, e.clientY || 0);
        }
    }
    var dragWheelEvent = ("onwheel" in document) ? "wheel" : "mousewheel";
    window.addEventListener(dragWheelEvent, scrollWhileDragging, true);

    function wireDrag(b, index) {
        b.addEventListener("mousedown", function (down) {
            if (down.button !== undefined && down.button !== 0) return;
            /* Dentro de una pareja el contenedor se encarga del gesto. El clic
               normal sigue llegando a cada mitad por separado. */
            if (b.parentNode && b.parentNode.classList &&
                b.parentNode.classList.contains("qi-dependent-pair")) return;
            var startX = down.clientX, startY = down.clientY, active = false, ghost = null;

            function move(ev) {
                if (!active) {
                    var dx = ev.clientX - startX, dy = ev.clientY - startY;
                    if (Math.sqrt(dx * dx + dy * dy) < 5) return;
                    active = true;
                    dragFrom = index;
                    dragOver = index;
                    b.classList.add("dragging");
                    ghost = createDragGhost(b, startX, startY);
                }
                moveDragGhost(ghost, ev.clientX, ev.clientY);
                markDragTarget(ev.clientX, ev.clientY);
                ev.preventDefault();
            }

            function up(ev) {
                document.removeEventListener("mousemove", move, true);
                document.removeEventListener("mouseup", up, true);
                window.removeEventListener("blur", cancel, true);
                if (!active) return;
                markDragTarget(ev.clientX, ev.clientY);
                var from = dragFrom, target = dragOver;
                var targetButton = buttonAtPoint(ev.clientX, ev.clientY);
                dragFrom = -1;
                dragClickUntil = new Date().getTime() + 300;
                finishDragGhost(ghost, targetButton || b);
                clearDragMarks();
                moveDraggedEntry(from, target);
                ev.preventDefault();
            }

            function cancel() {
                document.removeEventListener("mousemove", move, true);
                document.removeEventListener("mouseup", up, true);
                window.removeEventListener("blur", cancel, true);
                if (!active) return;
                dragFrom = -1;
                dragClickUntil = new Date().getTime() + 300;
                finishDragGhost(ghost, b);
                clearDragMarks();
            }

            document.addEventListener("mousemove", move, true);
            document.addEventListener("mouseup", up, true);
            window.addEventListener("blur", cancel, true);
        });
    }

    function wirePairDrag(pair, firstIndex, secondIndex) {
        pair.addEventListener("mousedown", function (down) {
            if (down.button !== undefined && down.button !== 0) return;
            if (down.target && (" " + (down.target.className || "") + " ").indexOf(" qi-resize-handle ") >= 0) return;
            var startX = down.clientX, startY = down.clientY, active = false, ghost = null;

            function move(ev) {
                if (!active) {
                    var dx = ev.clientX - startX, dy = ev.clientY - startY;
                    if (Math.sqrt(dx * dx + dy * dy) < 5) return;
                    active = true;
                    dragFrom = firstIndex;
                    dragOver = firstIndex;
                    dragGroupSlots = [firstIndex, secondIndex];
                    pair.classList.add("dragging");
                    ghost = createDragGhost(pair, startX, startY);
                }
                moveDragGhost(ghost, ev.clientX, ev.clientY);
                markDragTarget(ev.clientX, ev.clientY);
                ev.preventDefault();
            }

            function up(ev) {
                document.removeEventListener("mousemove", move, true);
                document.removeEventListener("mouseup", up, true);
                window.removeEventListener("blur", cancel, true);
                if (!active) return;
                markDragTarget(ev.clientX, ev.clientY);
                var target = dragOver;
                var targetButton = buttonAtPoint(ev.clientX, ev.clientY);
                dragFrom = -1;
                dragGroupSlots = null;
                dragClickUntil = new Date().getTime() + 300;
                finishDragGhost(ghost, targetButton || pair, true);
                clearDragMarks();
                moveDraggedPair(firstIndex, secondIndex, target);
                ev.preventDefault();
            }

            function cancel() {
                document.removeEventListener("mousemove", move, true);
                document.removeEventListener("mouseup", up, true);
                window.removeEventListener("blur", cancel, true);
                if (!active) return;
                dragFrom = -1;
                dragGroupSlots = null;
                dragClickUntil = new Date().getTime() + 300;
                finishDragGhost(ghost, pair, true);
                clearDragMarks();
            }

            document.addEventListener("mousemove", move, true);
            document.addEventListener("mouseup", up, true);
            window.addEventListener("blur", cancel, true);
        });
    }

    // ------------------------------------------------------------------
    // El menu de cada boton
    // ------------------------------------------------------------------
    /* Clic derecho encima y ahi esta todo lo del boton. Flota junto al cursor y
       se dobla hacia dentro cuando no cabe: este panel puede ser muy estrecho,
       y un menu que se sale por el borde no se puede usar.

       Las acciones son iconos con su descripcion, no una lista de frases: son
       seis y caben en una fila, y el menu tiene que seguir siendo mas pequeño
       que el sitio donde se abre. Lo unico escrito son los dos campos que hay
       que escribir. */
    var menuEl = null, menuIdx = -1;

    var presetScrim = null;

    function closeMenu() {
        if (presetScrim) {
            if (presetScrim.parentNode) presetScrim.parentNode.removeChild(presetScrim);
            presetScrim = null;
            lift(false);
        }
        if (!menuEl) return;
        if (menuEl.parentNode) menuEl.parentNode.removeChild(menuEl);
        menuEl = null;
        menuIdx = -1;
    }

    function iconBtn(path, titleKey, onClick, extraClass) {
        var b = document.createElement("button");
        b.type = "button";
        b.className = "qi-menu-icon" + (extraClass ? " " + extraClass : "");
        b.title = T(titleKey);
        b.innerHTML = '<svg class="ms" viewBox="0 -960 960 960" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="' + path + '"/></svg>';
        b.addEventListener("click", onClick);
        return b;
    }

    var ICON = {
        image: "M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm40-80h480L570-480 450-320l-90-120-120 160Zm-40 80v-560 560Z",
        trash: "M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z",
        plus: "M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z",
        undo: "M280-200v-80h284q63 0 109.5-40T720-420q0-60-46.5-100T564-560H312l104 104-56 56-200-200 200-200 56 56-104 104h252q97 0 166.5 63T800-420q0 94-69.5 157T564-200H280Z",
        // Ojo tachado: ocultar. Y el ojo abierto para recuperar.
        eyeOff: "m644-428-58-58q9-47-27-83t-83-27l-58-58q17-8 34.5-12t47.5-4q75 0 127.5 52.5T680-490q0 30-4 47.5T644-428Zm128 126-58-56q38-29 67.5-63.5T832-490q-50-101-143.5-160.5T480-710q-29 0-57 4t-55 12l-62-62q41-17 86-25.5t88-8.5q143 0 261.5 77.5T920-490q-22 57-58.5 103.5T772-302Zm20 246L624-222q-35 11-70.5 16.5T480-200q-146 0-264.5-81.5T40-490q22-53 61-99.5t84-77.5L56-792l56-56 736 736-56 56ZM241-611q-30 26-55 57t-42 64q50 101 143.5 160.5T480-270q20 0 39-2.5t39-5.5l-36-38q-11 3-21 4.5t-21 1.5q-75 0-127.5-52.5T300-490q0-11 1.5-21t4.5-21l-65-79Zm287 97Zm-96 24Z",
        eye: "M480-320q75 0 127.5-52.5T660-500q0-75-52.5-127.5T480-680q-75 0-127.5 52.5T300-500q0 75 52.5 127.5T480-320Zm0-72q-45 0-76.5-31.5T372-500q0-45 31.5-76.5T480-608q45 0 76.5 31.5T588-500q0 45-31.5 76.5T480-392Zm0 192q-146 0-266-81.5T40-500q54-137 174-218.5T480-800q146 0 266 81.5T920-500q-54 137-174 218.5T480-200Zm0-300Zm0 220q113 0 207.5-59.5T832-500q-50-101-144.5-160.5T480-720q-113 0-207.5 59.5T128-500q50 101 144.5 160.5T480-280Z",
        // Gota: el color del boton. Cursor: el de cuando el mouse esta encima.
        drop: "M480-80q-134 0-227-91.5T160-397q0-63 24.5-120.5T254-621l226-220 226 220q45 44 69.5 101.5T800-397q0 134-93 225.5T480-80Zm0-80q100 0 170-68.5T720-397q0-46-18-89t-51-75L480-728 309-561q-33 32-51 75t-18 89q0 100 70 168.5T480-160Z",
        cursor: "M320-410l79-110h170L320-716v306ZM551-80 406-392 240-160v-720l560 440H516l144 309-109 51ZM399-520Z",
        // Estilos: la letra, el texto; el cuadrado, el borde; lapiz y visto, editar y terminar.
        text: "M80 0v-160h800V0H80Zm140-280 210-560h100l210 560h-96l-50-144H368l-52 144h-96Zm176-224h168l-82-232h-4l-82 232Z",
        symbol: "M480-820 700-600 480-380 260-600l220-220Zm0 112L372-600l108 108 108-108-108-108ZM160-160v-80h640v80H160Z",
        border: "M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Z",
        edit: "M200-200h57l391-391-57-57-391 391v57Zm-80 80v-170l528-527q12-11 26.5-17t30.5-6q16 0 31 6t26 18l55 56q12 11 17.5 26t5.5 30q0 16-5.5 30.5T817-647L290-120H120Zm640-584-56-56 56 56Zm-141 85-28-29 57 57-29-28Z",
        check: "M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z",
        close: "m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"
    };

    function field(labelKey, value, maxLen, onSave) {
        var wrap = document.createElement("label");
        wrap.className = "qi-menu-field";
        var lab = document.createElement("span");
        lab.textContent = T(labelKey);
        var inp = document.createElement("input");
        inp.type = "text";
        inp.value = value || "";
        if (maxLen) inp.maxLength = maxLen;
        inp.addEventListener("change", function () { onSave(inp.value); });
        // Enter guarda y cierra: es lo que espera cualquiera que acabe de
        // escribir tres letras en un menu que ocupa media ventana.
        inp.addEventListener("keydown", function (ev) {
            if (ev.key === "Enter") { onSave(inp.value); closeMenu(); }
        });
        wrap.appendChild(lab);
        wrap.appendChild(inp);
        return wrap;
    }

    /* Un cuadrado del color que tiene puesto, con un dibujo encima que dice
       cual de los dos es: la gota, el color del boton; el cursor, el de cuando
       el mouse esta encima. Antes eran dos <input type="color"> a secas, uno al
       lado del otro y distinguibles solo por el orden y por su descripcion.

       El selector del sistema sigue siendo el que abre —es el unico que sabe
       hablar con el cuentagotas—, pero va debajo y transparente: lo que se ve
       es el cuadrado.

       El dibujo se pinta claro u oscuro segun lo que tenga detras. Un icono
       blanco sobre amarillo no se ve, y esos son justo los colores que elige
       quien quiere que un boton destaque. */
    function colorCell(value, dflt, path, titleKey, onPick) {
        var wrap = document.createElement("label");
        wrap.className = "qi-menu-swatch";
        wrap.title = T(titleKey);

        wrap.innerHTML = '<svg class="ms" viewBox="0 -960 960 960" width="13" height="13" fill="currentColor" aria-hidden="true"><path d="' + path + '"/></svg>';

        var inp = document.createElement("input");
        inp.type = "color";
        inp.className = "qi-menu-color";
        paintSwatch(wrap, inp, value, dflt);
        inp.addEventListener("input", function () {
            wrap.style.setProperty("--sw", inp.value);
            wrap.style.setProperty("--sw-ink", inkOn(inp.value));
            wrap.classList.remove("unset");
            onPick(inp.value);
        });
        wrap.appendChild(inp);
        wrap.repaint = function (v) { paintSwatch(wrap, inp, v, dflt); };
        return wrap;
    }

    function paintSwatch(wrap, inp, value, dflt) {
        var cur = value || dflt;
        wrap.style.setProperty("--sw", cur);
        wrap.style.setProperty("--sw-ink", inkOn(cur));
        inp.value = cur;
        // Sin color propio se marca: el boton usa el de su tipo, no este.
        wrap.classList.toggle("unset", !value);
    }

    /* Blanco o negro encima, el que se lea. La formula es la de siempre —el
       ojo ve mucho mas el verde que el azul—, y el corte en 150 sobre 255 es
       el que deja legibles los amarillos, que es donde falla el 128. */
    function inkOn(hex) {
        var h = String(hex || "").replace("#", "");
        if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
        if (h.length !== 6) return "#fff";
        var r = parseInt(h.substring(0, 2), 16);
        var g = parseInt(h.substring(2, 4), 16);
        var b = parseInt(h.substring(4, 6), 16);
        if (!isFinite(r) || !isFinite(g) || !isFinite(b)) return "#fff";
        return (0.299 * r + 0.587 * g + 0.114 * b) > 150 ? "#101010" : "#fff";
    }

    function patch(index, fn) {
        var a = entries();
        if (!a[index]) return;
        fn(a[index]);
        setEntries(a);
    }

    function globalNativeView() {
        try { return localStorage.getItem(K_BTNMODE) === "icons" ? "icons" : "abbr"; }
        catch (e) { return "abbr"; }
    }

    function nativeViewOf(e) {
        if (e && (e.nativeView === "icons" || e.nativeView === "abbr")) return e.nativeView;
        if (e && e.abbr) return "abbr";
        return globalNativeView();
    }

    function openMenu(index, x, y) {
        closeMenu();
        var list = entries(), e = list[index];
        if (!e) return;
        menuIdx = index;
        styleEditing = false;
        styleSel = -1;

        menuEl = document.createElement("div");
        menuEl.className = "qi-menu";

        var head = document.createElement("div");
        head.className = "qi-menu-head";
        head.textContent = nameOf(e);
        head.title = tipOf(e);
        menuEl.appendChild(head);

        menuEl.appendChild(field("qi.mName", e.name || nameOf(e), 40, function (v) {
            patch(index, function (o) { o.name = v || ""; });
        }));
        menuEl.appendChild(field("qi.mAbbr", abbrOf(e), labelLimit(e), function (v) {
            patch(index, function (o) { o.abbr = String(v || "").substring(0, LABEL_LIMIT); });
        }));

        var row = document.createElement("div");
        row.className = "qi-menu-row";

        row.appendChild(iconBtn(ICON.image, "qi.mIcon", function () {
            var H = host();
            if (!H) return;
            H.call("ek_pickIcon", null, {
                onOk: function (r) { patch(index, function (o) { o.icon = r.path; }); closeMenu(); },
                onFail: function (r) { return r.code === "canceled"; }
            });
        }));

        /* Para acciones nativas, alternar aqui solo afecta a este hueco. Una
           imagen propia sigue por encima: si hay una, el selector no aparece
           porque cambiar icono/abreviatura no produciria ningun cambio visible. */
        var menuNativeMarkup = window.EditKitQuickIcons ? window.EditKitQuickIcons.markup(e.id) : "";
        if (menuNativeMarkup && !e.icon) {
            var currentNativeView = nativeViewOf(e);
            row.appendChild(iconBtn(currentNativeView === "icons" ? ICON.text : ICON.symbol,
                currentNativeView === "icons" ? "qi.mUseAbbr" : "qi.mUseIcon",
                function () {
                    patch(index, function (o) {
                        o.nativeView = nativeViewOf(o) === "icons" ? "abbr" : "icons";
                    });
                    closeMenu();
                }));
        }

        /* Solo tiene sentido con una imagen ya puesta: rellenar el hueco
           entero con ella, o dejarla como un icono pequeno en medio —lo de
           siempre—. Alternar cierra el menu porque el cambio se ve en la
           rejilla, no aqui dentro. */
        if (e.icon) {
            var isCover = e.fill === "cover";
            row.appendChild(iconBtn(isCover ? ICON.border : ICON.image,
                isCover ? "qi.mFillIcon" : "qi.mFillCover",
                function () {
                    patch(index, function (o) {
                        if (o.fill === "cover") delete o.fill; else o.fill = "cover";
                    });
                    closeMenu();
                }, isCover ? "on" : ""));
        }

        var dropCell = colorCell(e.color, "#292929", ICON.drop, "qi.mColor", function (v) {
            patch(index, function (o) { o.color = v; });
        });
        row.appendChild(dropCell);

        var hoverCell = colorCell(e.hover, "#303030", ICON.cursor, "qi.mHover", function (v) {
            patch(index, function (o) { o.hover = v; });
        });
        row.appendChild(hoverCell);

        /* Ocultar y borrar no son lo mismo, y por eso estan los dos. Casi nadie
           quiere perder un boton para siempre: lo que quiere es no verlo esta
           semana. Oculto se queda con su nombre, su color y su icono, y vuelve
           donde estaba. */
        row.appendChild(iconBtn(ICON.eyeOff, "qi.mHide", function () {
            patch(index, function (o) { o.off = true; });
            closeMenu();
            showToast("\u2713 " + T("qi.hidden"));
        }));

        row.appendChild(iconBtn(ICON.undo, "qi.mReset", function () {
            patch(index, function (o) {
                delete o.color; delete o.hover; delete o.fg; delete o.border; delete o.icon; delete o.abbr;
                delete o.bg2; delete o.bgType; delete o.gradType; delete o.gradAngle;
                delete o.sweep; delete o.borderStyle; delete o.effect; delete o.fill; delete o.nativeView;
                if (!o.kind || o.kind === "cmd") delete o.name;
            });
            closeMenu();
        }));

        row.appendChild(iconBtn(ICON.plus, "qi.mAdd", function () {
            closeMenu();
            openAdd(index + 1, x, y);
        }));

        /* Quitar va el ultimo y con dos botones de por medio. Es la unica
           accion del menu que no se puede deshacer, y estaba pegada a
           ocultar: dos vecinos de un clic con consecuencias muy distintas. */
        row.appendChild(iconBtn(ICON.trash, "qi.mRemove", function () {
            var a = entries();
            a.splice(index, 1);
            setEntries(a);
            closeMenu();
        }, "danger"));

        menuEl.appendChild(row);

        menuEl.appendChild(styleBox(index, {
            sync: function (s) { dropCell.repaint(s.bg); hoverCell.repaint(s.hover); }
        }));

        var hint = document.createElement("p");
        hint.className = "qi-menu-hint";
        hint.textContent = T("qi.mDragHint");
        menuEl.appendChild(hint);

        placeMenu(x, y);
    }

    // ---- añadir un boton ----
    function openAdd(where, x, y) {
        closeMenu();
        menuEl = document.createElement("div");
        menuEl.className = "qi-menu";

        var head = document.createElement("div");
        head.className = "qi-menu-head";
        head.textContent = T("qi.mAdd");
        menuEl.appendChild(head);

        // 1) una accion que ya existe. El buscador no sustituye el selector:
        //    cuando esta vacio se puede seguir explorando la lista por grupos.
        var search = document.createElement("input");
        search.type = "search";
        search.className = "qi-menu-search";
        search.placeholder = T("qi.mSearchActions");
        search.setAttribute("aria-label", search.placeholder);
        menuEl.appendChild(search);

        var sel = document.createElement("select");
        sel.className = "qi-menu-select";
        /* En un panel estrecho los nombres largos se recortan. Solo este
           desplegable pide ayuda por opcion: el resto de selects tienen textos
           cortos y un globo en cada fila estorbaria mas de lo que ayuda. */
        sel.setAttribute("data-option-tips", "");
        var first = document.createElement("option");
        first.value = "";
        first.textContent = T("qi.mPickAction");
        sel.appendChild(first);

        var all = everyCommand(), lastGroup = null, group = null;
        for (var i = 0; i < all.length; i++) {
            if (all[i].group !== lastGroup) {
                lastGroup = all[i].group;
                group = document.createElement("optgroup");
                group.label = lastGroup;
                sel.appendChild(group);
            }
            var op = document.createElement("option");
            op.value = all[i].id;
            op.textContent = all[i].label;
            group.appendChild(op);
        }
        sel.addEventListener("change", function () {
            if (!sel.value) return;
            insert(where, { id: sel.value });
        });
        menuEl.appendChild(sel);

        var results = document.createElement("div");
        results.className = "qi-menu-list qi-add-results";
        results.hidden = true;
        menuEl.appendChild(results);
        function matchText(value) {
            var s = String(value || "").toLowerCase();
            try { s = s.normalize("NFD").replace(/[\u0300-\u036f]/g, ""); } catch (e) {}
            return s;
        }
        function filterActions() {
            var query = matchText(search.value).trim();
            results.innerHTML = "";
            sel.hidden = !!query;
            results.hidden = !query;
            if (!query) return;
            var words = query.split(/\s+/), found = 0;
            for (var n = 0; n < all.length; n++) {
                var item = all[n];
                var haystack = matchText(item.label + " " + item.group + " " + item.id);
                var matches = true;
                for (var w = 0; w < words.length; w++) {
                    if (haystack.indexOf(words[w]) < 0) { matches = false; break; }
                }
                if (!matches) continue;
                var row = document.createElement("button");
                row.type = "button";
                row.className = "qi-menu-row";
                row.title = item.label;
                var label = document.createElement("span");
                label.className = "qi-row-name";
                label.textContent = item.label;
                var groupName = document.createElement("span");
                groupName.className = "qi-row-folder";
                groupName.textContent = item.group;
                row.appendChild(label);
                row.appendChild(groupName);
                (function (id) { row.addEventListener("click", function () { insert(where, { id: id }); }); })(item.id);
                results.appendChild(row);
                found++;
            }
            if (!found) {
                var empty = document.createElement("p");
                empty.className = "qi-menu-hint";
                empty.textContent = T("qi.mNoActions");
                results.appendChild(empty);
            }
            // El menu puede crecer al filtrar; mantenerlo dentro del panel.
            if (menuEl.parentNode) {
                var bottomLimit = document.documentElement.clientHeight - menuEl.offsetHeight - 4;
                var currentTop = parseInt(menuEl.style.top, 10) || 4;
                menuEl.style.top = Math.max(4, Math.min(currentTop, bottomLimit)) + "px";
            }
        }
        search.addEventListener("input", filterActions);
        search.addEventListener("keydown", function (ev) {
            if (ev.key !== "Enter" && ev.key !== "ArrowDown") return;
            var firstResult = results.querySelector("button");
            if (!firstResult) return;
            ev.preventDefault();
            if (ev.key === "Enter") firstResult.click();
            else firstResult.focus();
        });

        // 2) lo que el usuario traiga de fuera
        var row = document.createElement("div");
        row.className = "qi-menu-kinds";

        function kindBtn(kind, key) {
            var b = document.createElement("button");
            b.type = "button";
            b.className = "qi-menu-kind";
            b.setAttribute("data-kind", kind);
            b.textContent = T(key);
            b.title = T(key + "Tip");
            b.addEventListener("click", function () { addOfKind(kind, where); });
            return b;
        }
        row.appendChild(kindBtn("effect", "qi.kindEffect"));
        row.appendChild(kindBtn("script", "qi.kindScript"));
        row.appendChild(kindBtn("preset", "qi.kindPreset"));
        menuEl.appendChild(row);

        // 3) y lo que se oculto, que se recupera desde el mismo sitio donde se
        //    anaden botones: es lo que uno va a buscar cuando lo eche de menos.
        var off = hiddenList();
        if (off.length) {
            var back = document.createElement("select");
            back.className = "qi-menu-select";
            var b0 = document.createElement("option");
            b0.value = "";
            b0.textContent = T("qi.mUnhidePick") + " (" + off.length + ")";
            back.appendChild(b0);
            for (var j = 0; j < off.length; j++) {
                var bo = document.createElement("option");
                bo.value = String(off[j].at);
                bo.textContent = nameOf(off[j].e);
                back.appendChild(bo);
            }
            back.addEventListener("change", function () {
                if (back.value === "") return;
                unhide(parseInt(back.value, 10));
                closeMenu();
            });
            menuEl.appendChild(back);
        }

        var hint = document.createElement("p");
        hint.className = "qi-menu-hint";
        hint.textContent = T("qi.mAddHint");
        menuEl.appendChild(hint);

        placeMenu(x, y);
    }

    /* La lista de los escondidos, junto al hueco que la abre. Cada fila lo
       devuelve a su sitio —no al final— y el pie los devuelve todos. */
    function openHidden(x, y) {
        closeMenu();
        var off = hiddenList();
        if (!off.length) return;

        menuEl = document.createElement("div");
        menuEl.className = "qi-menu";

        var head = document.createElement("div");
        head.className = "qi-menu-head";
        head.textContent = T("qi.hiddenTitle");
        menuEl.appendChild(head);

        var list = document.createElement("div");
        list.className = "qi-menu-list";
        list.setAttribute("data-ek-scroll", "");
        menuEl.appendChild(list);

        for (var i = 0; i < off.length; i++) {
            (function (it) {
                var r = document.createElement("button");
                r.type = "button";
                r.className = "qi-menu-row";
                var n = document.createElement("span");
                n.className = "qi-row-name";
                n.textContent = nameOf(it.e);
                r.appendChild(n);
                var a = document.createElement("span");
                a.className = "qi-row-folder";
                a.textContent = abbrOf(it.e);
                r.appendChild(a);
                r.title = tipOf(it.e);
                r.addEventListener("click", function () {
                    unhide(it.at);
                    // Se queda abierta mientras quede alguno: recuperar tres de
                    // cinco es un gesto normal y cerrar en cada uno obliga a
                    // volver a abrir la lista tres veces.
                    if (hiddenCount()) openHidden(x, y); else closeMenu();
                });
                list.appendChild(r);
            })(off[i]);
        }

        var foot = document.createElement("div");
        foot.className = "qi-menu-foot";
        var all = document.createElement("button");
        all.type = "button";
        all.className = "qi-menu-link";
        all.textContent = T("qi.unhideAll");
        all.addEventListener("click", function () {
            var n = hiddenCount();
            unhideAll();
            closeMenu();
            showToast("\u2713 " + TF("qi.unhidden", n));
        });
        foot.appendChild(all);
        menuEl.appendChild(foot);

        placeMenu(x, y);
    }

    // ---- los que estan ocultos ----
    function hiddenList() {
        var a = entries(), out = [];
        for (var i = 0; i < a.length; i++) {
            if (a[i] && a[i].off) out.push({ at: i, e: a[i] });
        }
        return out;
    }

    function hiddenCount() { return hiddenList().length; }

    // Vuelve donde estaba, no al final: el sitio de un boton es parte de lo
    // que uno recuerda de el.
    function unhide(at) {
        var a = entries();
        if (!a[at]) return;
        delete a[at].off;
        setEntries(a);
        syncHiddenBtn();
    }

    function unhideAll() {
        var a = entries();
        for (var i = 0; i < a.length; i++) { if (a[i]) delete a[i].off; }
        setEntries(a);
        syncHiddenBtn();
    }

    function insert(where, entry) {
        var a = entries();
        var at = Math.max(0, Math.min(a.length, where));
        var firstFresh = firstFreshIndex(a);
        if (!entry.fresh && firstFresh >= 0) at = Math.min(at, firstFresh);
        a.splice(at, 0, entry);
        setEntries(a);
        closeMenu();
    }

    /* Un efecto y un preset se buscan por nombre; un script se elige del disco.

       Lo del efecto era una caja de texto que pedia el nombre exacto, y el
       nombre exacto no se lo sabe nadie: "Desenfoque gaussiano" o "Gaussian
       Blur" segun el idioma, y "ADBE Gaussian Blur 2" si se queria el interno.
       Una letra de mas y el boton no hacia nada. Ahora se busca en la lista
       que el propio After Effects tiene de todo lo que hay instalado. */
    function addOfKind(kind, where) {
        var H = host();
        if (kind === "effect") { openEffects(where); return; }
        // Los presets tienen sitio propio y pueden estar indexados: eso se
        // resuelve en su pantalla, no aqui.
        if (kind === "preset") { openPresets(where); return; }
        if (!H) return;
        H.call("ek_pickFile", { kind: kind }, {
            onOk: function (r) {
                insert(where, { kind: kind, value: r.path, name: r.name || r.path });
            },
            onFail: function (r) { return r.code === "canceled"; }
        });
    }

    /* ==================================================================
       LOS PRESETS DEL USUARIO

       Un preset de animacion no esta en cualquier sitio: After Effects los
       guarda todos en la misma carpeta del usuario, y hasta ahora el dialogo se
       abria donde hubiera estado la ultima vez. El host sabe encontrarla —el
       nombre de usuario, el idioma del sistema y la version cambian la ruta— y
       el dialogo arranca alli.

       Y encima se pueden indexar. Quien tiene doscientos presets repartidos en
       carpetas no quiere navegar hasta uno: quiere escribir tres letras de su
       nombre. El indice es una lista de nombre y ruta que se guarda aqui, se
       hace una vez y se rehace cuando el usuario quiera.

       Indexar se PREGUNTA, no se hace por las buenas: recorrer una carpeta
       entera del disco del usuario es algo que se pide, no algo que uno se
       encuentra hecho. Y la respuesta se recuerda, para no volver a preguntar
       lo mismo cada vez que se anade un boton.
       ================================================================== */
    /* ---- como cae un preset cuando hay varias capas ----

       Se guarda una vez y vale para todos. Por defecto empieza en la entrada
       de cada capa: es lo que se espera al soltar un preset con keyframes
       sobre cinco capas que arrancan en cinco momentos distintos, y dejarlo
       en el cursor —lo que hacia antes— pone las cinco animaciones encima de
       la misma. Ajustar al largo viene encendido porque es la opcion
       recomendada; escalonar sigue apagado hasta que se pida. */
    function presetOpts() {
        var o = readJson(K_PRESET_OPTS, null) || {};
        var at = String(o.at || "in");
        if (at !== "in" && at !== "out" && at !== "playhead") at = "in";
        var st = Number(o.stagger);
        if (!isFinite(st) || st < 0) st = 0;
        /* Perfiles muy antiguos llegaron a guardar booleanos como texto. `!!`
           convierte "false" en true, justo lo contrario de lo elegido. Solo
           los valores afirmativos conocidos activan el ajuste; si nunca hubo
           valor, se usa el recomendado: activado. */
        var hasFit = Object.prototype.hasOwnProperty.call(o, "fit");
        var fit = hasFit ? (o.fit === true || o.fit === 1 || o.fit === "1" || o.fit === "true") : true;
        return { at: at, fit: fit, stagger: Math.round(st) };
    }

    function presetIndex() {
        var o = readJson(K_PRESETS, null);
        return (o && o.items && o.items.length) ? o : null;
    }

    function askedBefore() {
        try { return localStorage.getItem(K_PRESETS_ASK) === "1"; } catch (e) { return false; }
    }
    function markAsked() {
        try { localStorage.setItem(K_PRESETS_ASK, "1"); } catch (e) {}
    }

    function forgetIndex() {
        try {
            localStorage.removeItem(K_PRESETS);
            localStorage.removeItem(K_PRESETS_ASK);
        } catch (e) {}
        syncPresetBtn();
    }

    // Construir el indice. Puede tardar con una carpeta grande, asi que el
    // boton se queda diciendo que esta en ello en lugar de no hacer nada.
    function buildIndex(btn, done) {
        var H = host();
        if (!H) return;
        markAsked();
        if (btn) { btn.disabled = true; btn.textContent = T("qi.pIndexing"); }
        H.call("ek_listPresets", {}, {
            onOk: function (r) {
                writeJson(K_PRESETS, { dir: r.dir, at: Date.now(), items: r.items || [] });
                syncPresetBtn();
                showToast("\u2713 " + TF("qi.pIndexed", r.count));
                if (r.truncated) {
                    setTimeout(function () { toastWarn(T("qi.pTruncated")); }, 1500);
                }
                if (done) done(true);
            },
            onFail: function () {
                if (btn) { btn.disabled = false; btn.textContent = T("qi.pIndex"); }
                if (done) done(false);
                return false;          // que el error salga como cualquier otro
            }
        });
    }

    function toastWarn(msg) { showToast(msg, true); }

    /* El estado del indice, en los ajustes. Se ensena la carpeta y cuantos
       presets hay: sin eso, "indexar" es un boton que promete algo y no dice
       si lo cumplio. */
    function syncPresetBtn() {
        var state = $("qiPresetState");
        var idx = presetIndex();
        var btn = $("qiPresetIndex"), forget = $("qiPresetForget");

        if (state) {
            state.removeAttribute("data-i18n");
            state.textContent = idx
                ? TF("qi.pState", idx.items.length) + "\n" + (idx.dir || "")
                : T("qi.pNoIndex");
        }
        if (btn) btn.textContent = idx ? T("qi.pReindex") : T("qi.pIndex");
        if (forget) forget.hidden = !idx;
    }

    /* ---- la pantalla de presets ----

       Esta no se cuelga del cursor como el resto del menu: se centra y ocupa lo
       que necesita, con el marco estirado igual que las hojas de ajustes. Dos
       razones, y las dos son de sitio.

       Una: no es un menu, es una busqueda. Un campo de texto, una lista de
       nombres con su carpeta al lado y un pie con la cuenta no caben en los 178
       px que deja un panel estrecho — los nombres salen todos cortados por la
       mitad, que es justo lo que un buscador no puede permitirse.

       Dos: en cuanto se estira el marco, las coordenadas del clic que abrio el
       menu dejan de valer. La herramienta se queda clavada donde estaba, pero
       la ventana pasa a medir lo que mide EditKit entero, y un "30 px desde la
       izquierda" que antes caia dentro del panel ahora cae en el de al lado.
       Centrarla no es solo mas bonito: es lo unico que sigue siendo cierto. */
    function openPresets(where) {
        /* Al pasar de una pantalla a otra —de la pregunta al buscador— se
           cambia lo de dentro y no se desmonta el fondo. Cerrarlo y volver a
           abrirlo devolvia el marco y lo volvia a pedir en el mismo suspiro, y
           en ese hueco la ventana ya media lo estirado: la herramienta se
           quedaba sin clavar y desparramada por toda la pantalla. */
        if (presetScrim) {
            if (menuEl && menuEl.parentNode) menuEl.parentNode.removeChild(menuEl);
            menuEl = null;
        } else {
            closeMenu();
            lift(true);
            presetScrim = document.createElement("div");
            presetScrim.className = "qi-modal";
            // Fuera de la pantalla se cierra; dentro no, o cada clic en la
            // lista la cerraria por debajo de la mano.
            presetScrim.addEventListener("mousedown", function (e) {
                if (e.target === presetScrim) closeMenu();
            });
            document.body.appendChild(presetScrim);
        }

        menuEl = document.createElement("div");
        menuEl.className = "qi-menu qi-menu-sheet";

        var head = document.createElement("div");
        head.className = "qi-menu-head";
        head.textContent = T("qi.kindPreset");
        menuEl.appendChild(head);

        var idx = presetIndex();

        if (idx) {
            buildSearch(idx, where);
        } else if (!askedBefore()) {
            buildAsk(where);
        } else {
            buildPlain(where);
        }

        presetScrim.appendChild(menuEl);

        var first = menuEl.querySelector("input, button");
        if (first) { try { first.focus(); } catch (e) {} }
    }

    // 1) la pregunta, una sola vez
    function buildAsk(where) {
        var p = document.createElement("p");
        p.className = "qi-menu-hint";
        p.textContent = T("qi.pAsk");
        menuEl.appendChild(p);

        var row = document.createElement("div");
        row.className = "qi-menu-kinds";

        var yes = document.createElement("button");
        yes.type = "button";
        yes.className = "qi-menu-kind";
        yes.setAttribute("data-kind", "preset");
        yes.textContent = T("qi.pIndex");
        yes.addEventListener("click", function () {
            buildIndex(yes, function () {
                var idx = presetIndex();
                if (!idx) return;
                // Se abre el buscador con el indice recien hecho: quien acaba
                // de decir que si estaba a punto de elegir un preset.
                openPresets(where);
            });
        });
        row.appendChild(yes);

        var no = document.createElement("button");
        no.type = "button";
        no.className = "qi-menu-kind";
        no.textContent = T("qi.pBrowse");
        no.addEventListener("click", function () {
            markAsked();
            pickPresetFile(where);
        });
        row.appendChild(no);

        menuEl.appendChild(row);
    }

    // 2) sin indice y ya preguntado: el dialogo de siempre, en su carpeta
    function buildPlain(where) {
        var p = document.createElement("p");
        p.className = "qi-menu-hint";
        p.textContent = T("qi.pNoIndex");
        menuEl.appendChild(p);

        var row = document.createElement("div");
        row.className = "qi-menu-kinds";

        var b1 = document.createElement("button");
        b1.type = "button";
        b1.className = "qi-menu-kind";
        b1.setAttribute("data-kind", "preset");
        b1.textContent = T("qi.pBrowse");
        b1.addEventListener("click", function () { pickPresetFile(where); });
        row.appendChild(b1);

        var b2 = document.createElement("button");
        b2.type = "button";
        b2.className = "qi-menu-kind";
        b2.textContent = T("qi.pIndex");
        b2.addEventListener("click", function () {
            buildIndex(b2, function () { openPresets(where); });
        });
        row.appendChild(b2);

        menuEl.appendChild(row);
    }

    /* 3) el buscador.

       Filtra por trozos sueltos y no por la frase entera: "gl fu" encuentra
       "Glow fuerte" igual que "fuerte glow". Quien busca un preset se acuerda
       de dos palabras, no del orden en que las escribio quien lo guardo. */
    function buildSearch(idx, where) {
        var inp = document.createElement("input");
        inp.type = "text";
        inp.className = "qi-menu-search";
        inp.placeholder = T("qi.pSearch");
        menuEl.appendChild(inp);

        var list = document.createElement("div");
        list.className = "qi-menu-list";
        list.setAttribute("data-ek-scroll", "");
        menuEl.appendChild(list);

        var foot = document.createElement("div");
        foot.className = "qi-menu-foot";
        menuEl.appendChild(foot);

        var count = document.createElement("span");
        count.className = "qi-menu-count";
        foot.appendChild(count);

        var again = document.createElement("button");
        again.type = "button";
        again.className = "qi-menu-link";
        again.textContent = T("qi.pReindex");
        again.title = idx.dir || "";
        again.addEventListener("click", function () {
            buildIndex(null, function () { openPresets(where); });
        });
        foot.appendChild(again);

        var browse = document.createElement("button");
        browse.type = "button";
        browse.className = "qi-menu-link";
        browse.textContent = T("qi.pBrowse");
        browse.addEventListener("click", function () { pickPresetFile(where); });
        foot.appendChild(browse);

        var MAX_ROWS = 40;

        function match(q) {
            var parts = String(q).toLowerCase().split(/\s+/), out = [], i, j;
            for (i = 0; i < idx.items.length; i++) {
                var it = idx.items[i];
                var hay = (it.n + " " + (it.f || "")).toLowerCase();
                var ok = true;
                for (j = 0; j < parts.length; j++) {
                    if (parts[j] && hay.indexOf(parts[j]) === -1) { ok = false; break; }
                }
                if (ok) out.push(it);
                if (out.length >= MAX_ROWS) break;
            }
            return out;
        }

        function draw() {
            var hits = match(inp.value);
            list.innerHTML = "";
            for (var i = 0; i < hits.length; i++) {
                (function (it) {
                    var r = document.createElement("button");
                    r.type = "button";
                    r.className = "qi-menu-row";
                    // La carpeta al lado del nombre: en una biblioteca grande
                    // hay tres "Glow" y lo que los distingue es donde estan.
                    r.innerHTML = "";
                    var n = document.createElement("span");
                    n.className = "qi-row-name";
                    n.textContent = it.n;
                    r.appendChild(n);
                    if (it.f) {
                        var f = document.createElement("span");
                        f.className = "qi-row-folder";
                        f.textContent = it.f;
                        r.appendChild(f);
                    }
                    r.title = it.p;
                    r.addEventListener("click", function () {
                        insert(where, { kind: "preset", value: it.p, name: it.n });
                    });
                    list.appendChild(r);
                })(hits[i]);
            }
            if (!hits.length) {
                var none = document.createElement("div");
                none.className = "qi-menu-hint";
                none.textContent = T("qi.pNone");
                list.appendChild(none);
            }
            count.textContent = hits.length + (hits.length >= MAX_ROWS ? "+" : "") +
                                " / " + idx.items.length;
        }

        inp.addEventListener("input", draw);
        // Enter con un solo resultado lo pone: es lo que espera cualquiera que
        // haya escrito hasta dejar uno.
        inp.addEventListener("keydown", function (ev) {
            if (ev.key !== "Enter") return;
            var hits = match(inp.value);
            if (hits.length === 1) insert(where, { kind: "preset", value: hits[0].p, name: hits[0].n });
        });
        draw();
    }

    /* ==================================================================
       LOS EFECTOS INSTALADOS

       No hay que indexar nada: After Effects lleva la lista puesta
       (`app.effects`) y la entrega entera de una vez, con el nombre visible, el
       interno y la categoria de cada efecto. Se pide una vez por sesion, se
       guarda para la siguiente, y el buscador trabaja contra esa copia — sin
       ir al host en cada tecla.

       Y a diferencia del indice de presets, esto NO se pregunta: leer la lista
       de efectos del programa no toca el disco del usuario ni tarda nada.
       ================================================================== */
    var fxCache = null;          // la lista, ya en memoria

    function effectList() {
        if (fxCache) return fxCache;
        var o = readJson(K_EFFECTS, null);
        if (o && o.items && o.items.length) { fxCache = o.items; return fxCache; }
        return null;
    }

    function fetchEffects(done) {
        var H = host();
        if (!H) { done(null); return; }
        H.call("ek_listEffects", null, {
            onOk: function (r) {
                fxCache = r.effects || [];
                writeJson(K_EFFECTS, { at: Date.now(), items: fxCache });
                done(fxCache);
            },
            onFail: function () { done(null); return false; }
        });
    }

    function openEffects(where) {
        // Mismo marco que la pantalla de presets, y por las mismas razones:
        // un buscador no cabe colgado del cursor en un panel estrecho.
        if (presetScrim) {
            if (menuEl && menuEl.parentNode) menuEl.parentNode.removeChild(menuEl);
            menuEl = null;
        } else {
            closeMenu();
            lift(true);
            presetScrim = document.createElement("div");
            presetScrim.className = "qi-modal";
            presetScrim.addEventListener("mousedown", function (e) {
                if (e.target === presetScrim) closeMenu();
            });
            document.body.appendChild(presetScrim);
        }

        menuEl = document.createElement("div");
        menuEl.className = "qi-menu qi-menu-sheet";

        var head = document.createElement("div");
        head.className = "qi-menu-head";
        head.textContent = T("qi.fxTitle");
        menuEl.appendChild(head);

        presetScrim.appendChild(menuEl);

        var list = effectList();
        if (list) { buildEffectSearch(list, where); return; }

        var wait = document.createElement("p");
        wait.className = "qi-menu-hint";
        wait.textContent = T("qi.fxLoading");
        menuEl.appendChild(wait);

        fetchEffects(function (got) {
            if (!menuEl) return;              // se cerro mientras tanto
            if (!got || !got.length) { buildEffectManual(where); return; }
            if (wait.parentNode) wait.parentNode.removeChild(wait);
            buildEffectSearch(got, where);
        });
    }

    /* El respaldo: si el host no contesta —el panel abierto suelto, sin After
       Effects detras— sigue habiendo forma de poner el boton. */
    function buildEffectManual(where) {
        var p = document.createElement("p");
        p.className = "qi-menu-hint";
        p.textContent = T("qi.fxManualHint");
        menuEl.appendChild(p);

        var inp = document.createElement("input");
        inp.type = "text";
        inp.className = "qi-menu-search";
        inp.placeholder = T("qi.fxSearch");
        menuEl.appendChild(inp);

        var row = document.createElement("div");
        row.className = "qi-menu-kinds";
        var add = document.createElement("button");
        add.type = "button";
        add.className = "qi-menu-kind";
        add.setAttribute("data-kind", "effect");
        add.textContent = T("qi.fxManual");
        function put() {
            var v = String(inp.value || "");
            if (!v) return;
            insert(where, { kind: "effect", value: v, name: v });
        }
        add.addEventListener("click", put);
        inp.addEventListener("keydown", function (ev) { if (ev.key === "Enter") put(); });
        row.appendChild(add);
        menuEl.appendChild(row);
        try { inp.focus(); } catch (e) {}
    }

    /* El buscador. Igual que el de presets, incluido el filtro por trozos
       sueltos: "gau blu" encuentra "Gaussian Blur" y tambien "Blur Gaussian"
       si alguna version lo llama asi. La categoria hace de segunda columna,
       que es lo que distingue dos "Fill" de dos sitios distintos. */
    function buildEffectSearch(items, where) {
        var inp = document.createElement("input");
        inp.type = "text";
        inp.className = "qi-menu-search";
        inp.placeholder = T("qi.fxSearch");
        menuEl.appendChild(inp);

        var list = document.createElement("div");
        list.className = "qi-menu-list";
        list.setAttribute("data-ek-scroll", "");
        menuEl.appendChild(list);

        var foot = document.createElement("div");
        foot.className = "qi-menu-foot";
        menuEl.appendChild(foot);

        var count = document.createElement("span");
        count.className = "qi-menu-count";
        foot.appendChild(count);

        var again = document.createElement("button");
        again.type = "button";
        again.className = "qi-menu-link";
        again.textContent = T("qi.fxRefresh");
        again.addEventListener("click", function () {
            fxCache = null;
            try { localStorage.removeItem(K_EFFECTS); } catch (e) {}
            fetchEffects(function () { openEffects(where); });
        });
        foot.appendChild(again);

        var MAX_ROWS = 40;

        function match(q) {
            var parts = String(q).toLowerCase().split(/\s+/), out = [], i, j;
            for (i = 0; i < items.length; i++) {
                var it = items[i];
                var hay = (it.n + " " + (it.c || "") + " " + (it.m || "")).toLowerCase();
                var ok = true;
                for (j = 0; j < parts.length; j++) {
                    if (parts[j] && hay.indexOf(parts[j]) === -1) { ok = false; break; }
                }
                if (ok) out.push(it);
                if (out.length >= MAX_ROWS) break;
            }
            return out;
        }

        function put(it) {
            insert(where, { kind: "effect", value: it.n, match: it.m || "", name: it.n });
        }

        function draw() {
            var hits = match(inp.value);
            list.innerHTML = "";
            for (var i = 0; i < hits.length; i++) {
                (function (it) {
                    var r = document.createElement("button");
                    r.type = "button";
                    r.className = "qi-menu-row";
                    var n = document.createElement("span");
                    n.className = "qi-row-name";
                    n.textContent = it.n;
                    r.appendChild(n);
                    if (it.c) {
                        var f = document.createElement("span");
                        f.className = "qi-row-folder";
                        f.textContent = it.c;
                        r.appendChild(f);
                    }
                    r.title = it.m || it.n;
                    r.addEventListener("click", function () { put(it); });
                    list.appendChild(r);
                })(hits[i]);
            }
            if (!hits.length) {
                var none = document.createElement("div");
                none.className = "qi-menu-hint";
                none.textContent = T("qi.fxNone");
                list.appendChild(none);
            }
            count.textContent = hits.length + (hits.length >= MAX_ROWS ? "+" : "") +
                                " / " + items.length;
        }

        inp.addEventListener("input", draw);
        inp.addEventListener("keydown", function (ev) {
            if (ev.key !== "Enter") return;
            var hits = match(inp.value);
            if (hits.length === 1) put(hits[0]);
        });
        draw();
        try { inp.focus(); } catch (e) {}
    }

    /* ==================================================================
       BIBLIOTECA RAPIDA

       El buscador fijo no crea una tercera base de datos. Mezcla las dos que
       QuickIt ya usa al añadir botones: app.effects y el índice de .ffx. El
       resultado principal se aplica al instante; el + usa exactamente la
       misma entrada que la rejilla permanente.
       ================================================================== */
    var libraryFxLoading = false;

    function libraryEntry(hit) {
        if (hit.kind === "preset") {
            return { kind: "preset", value: hit.item.p, name: hit.item.n };
        }
        return {
            kind: "effect", value: hit.item.n,
            match: hit.item.m || "", name: hit.item.n
        };
    }

    function libraryMatches(q) {
        var parts = String(q || "").toLowerCase().replace(/^\s+|\s+$/g, "").split(/\s+/);
        var out = [], i, j, it, hay, ok;
        if (!parts[0]) return out;

        var fx = effectList() || [];
        for (i = 0; i < fx.length; i++) {
            it = fx[i];
            hay = (it.n + " " + (it.c || "") + " " + (it.m || "")).toLowerCase();
            ok = true;
            for (j = 0; j < parts.length; j++) if (hay.indexOf(parts[j]) === -1) { ok = false; break; }
            if (ok) out.push({ kind: "effect", item: it, hay: hay });
        }

        var pi = presetIndex();
        var ps = pi ? pi.items : [];
        for (i = 0; i < ps.length; i++) {
            it = ps[i];
            hay = (it.n + " " + (it.f || "")).toLowerCase();
            ok = true;
            for (j = 0; j < parts.length; j++) if (hay.indexOf(parts[j]) === -1) { ok = false; break; }
            if (ok) out.push({ kind: "preset", item: it, hay: hay });
        }

        var whole = parts.join(" ");
        out.sort(function (a, b) {
            var an = String(a.item.n || "").toLowerCase();
            var bn = String(b.item.n || "").toLowerCase();
            var as = an === whole ? 0 : (an.indexOf(whole) === 0 ? 1 : 2);
            var bs = bn === whole ? 0 : (bn.indexOf(whole) === 0 ? 1 : 2);
            if (as !== bs) return as - bs;
            if (an !== bn) return an < bn ? -1 : 1;
            return a.kind < b.kind ? -1 : 1;
        });
        return out.slice(0, 30);
    }

    function drawLibrary() {
        var inp = $("qiLibraryInput"), box = $("qiLibraryResults"), status = $("qiLibraryStatus");
        if (!inp || !box || !status) return;
        var q = String(inp.value || "").replace(/^\s+|\s+$/g, "");
        box.innerHTML = "";
        if (!q) {
            box.hidden = true;
            status.hidden = true;
            return;
        }

        var hits = libraryMatches(q);
        if (!hits.length) {
            box.hidden = true;
            status.hidden = false;
            status.textContent = libraryFxLoading ? T("qi.libLoading") :
                (presetIndex() ? T("qi.libNone") : T("qi.libNoPresets"));
            return;
        }

        status.hidden = true;
        box.hidden = false;
        for (var i = 0; i < hits.length; i++) {
            (function (hit) {
                var row = document.createElement("div");
                row.className = "qi-library-result";

                var apply = document.createElement("button");
                apply.type = "button";
                apply.className = "qi-library-apply";
                apply.title = T("qi.libApply");
                var name = document.createElement("span");
                name.className = "qi-library-name";
                name.textContent = hit.item.n;
                apply.appendChild(name);
                var kind = document.createElement("span");
                kind.className = "qi-library-kind";
                kind.textContent = T(hit.kind === "preset" ? "qi.kindPreset" : "qi.kindEffect");
                apply.appendChild(kind);
                apply.addEventListener("click", function () {
                    runEntry(libraryEntry(hit), null);
                    box.hidden = true;
                });
                row.appendChild(apply);

                var add = document.createElement("button");
                add.type = "button";
                add.className = "qi-library-add";
                add.textContent = "+";
                add.title = T("qi.libAdd");
                add.setAttribute("aria-label", T("qi.libAdd"));
                add.addEventListener("click", function () {
                    insert(entries().length, libraryEntry(hit));
                    showToast("\u2713 " + T("qi.libAdded"));
                    drawLibrary();
                });
                row.appendChild(add);
                box.appendChild(row);
            })(hits[i]);
        }
    }

    function ensureLibraryEffects() {
        if (effectList() || libraryFxLoading) return;
        libraryFxLoading = true;
        drawLibrary();
        fetchEffects(function () {
            libraryFxLoading = false;
            drawLibrary();
        });
    }

    function refreshLibrary() {
        var btn = $("qiLibraryRefresh"), pending = 2;
        if (btn) { btn.disabled = true; btn.classList.add("busy"); }
        function done() {
            pending--;
            if (pending > 0) return;
            if (btn) { btn.disabled = false; btn.classList.remove("busy"); }
            drawLibrary();
        }
        fxCache = null;
        try { localStorage.removeItem(K_EFFECTS); } catch (e) {}
        fetchEffects(done);
        buildIndex(null, done);
    }

    function wireLibrary() {
        var inp = $("qiLibraryInput"), refresh = $("qiLibraryRefresh"), box = $("qiLibraryResults");
        if (!inp) return;
        inp.placeholder = T("qi.libSearch");
        inp.addEventListener("focus", function () { ensureLibraryEffects(); drawLibrary(); });
        inp.addEventListener("input", function () { ensureLibraryEffects(); drawLibrary(); });
        inp.addEventListener("keydown", function (ev) {
            if (ev.key === "Escape") { inp.value = ""; drawLibrary(); return; }
            if (ev.key !== "Enter") return;
            var hits = libraryMatches(inp.value);
            if (hits.length) {
                runEntry(libraryEntry(hits[0]), ev);
                if (box) box.hidden = true;
            }
        });
        if (refresh) refresh.addEventListener("click", refreshLibrary);
        document.addEventListener("mousedown", function (ev) {
            var root = $("qiLibrary");
            if (!root || root.contains(ev.target)) return;
            if (box) box.hidden = true;
            var status = $("qiLibraryStatus");
            if (status) status.hidden = true;
        });
    }

    function pickPresetFile(where) {
        var H = host();
        if (!H) return;
        H.call("ek_pickFile", { kind: "preset" }, {
            onOk: function (r) {
                insert(where, { kind: "preset", value: r.path, name: r.name || r.path });
            },
            onFail: function (r) { return r.code === "canceled"; }
        });
    }

    /* Flotante de verdad: se mide despues de estar en el documento, porque
       hasta entonces no se sabe cuanto ocupa, y se dobla hacia dentro por el
       lado que se salga. */
    /* El bloque de estilos del menu de un boton. Se redibuja entero al cambiar
       de modo o de estilo elegido, pero NO mientras se arrastra un color: el
       selector del sistema esta enganchado a su <input>, y rehacer el bloque
       lo dejaria hablando con un elemento que ya no existe. Mientras se elige
       un color solo se repinta el recuadro que cambia. */
    var styleEditing = false, styleSel = -1;

    function styleChip(s) {
        var c = document.createElement("button");
        c.type = "button";
        c.className = "qi-style";
        paintChip(c, s);
        c.appendChild(document.createTextNode("Aa"));
        return c;
    }
    function paintChip(c, s) {
        // El chip solo ensena el fondo, el degradado incluido: a 26-40px no hay
        // sitio para un destello o un borde decorado que se lean como tales, y
        // ensenarlos a medias seria peor que no ensenarlos.
        if (s.bgType === "gradient" && s.bg && s.bg2) {
            var ang = (typeof s.gradAngle === "number") ? s.gradAngle : 135;
            var gt = s.gradType || "linear";
            c.style.setProperty("--st-bg", gradCss(gt, ang, s.bg, s.bg2));
            c.style.setProperty("--st-hover", gradCss(gt, ang, s.hover || s.bg, s.bg2));
        } else {
            c.style.setProperty("--st-bg", s.bg || "#292929");
            c.style.setProperty("--st-hover", s.hover || s.bg || "#303030");
        }
        c.style.setProperty("--st-fg", s.fg || "#b8b8b8");
        c.style.setProperty("--st-border", s.border || "#3a3a3a");
        if (EFFECT_STYLES[s.effect]) c.setAttribute("data-effect", s.effect);
        else c.removeAttribute("data-effect");
    }

    function styleBox(index, swatches) {
        var box = document.createElement("div");
        box.className = "qi-styles";

        function refit() {
            if (!menuEl || !menuEl.parentNode) return;
            var r = menuEl.getBoundingClientRect();
            var H2 = document.documentElement.clientHeight;
            if (r.bottom > H2 - 4) menuEl.style.top = Math.max(4, H2 - r.height - 4) + "px";
        }

        function render() {
            box.innerHTML = "";
            var list = styles(), e = entries()[index];
            if (!e) return;
            var mine = styleOfEntry(e);

            var head = document.createElement("div");
            head.className = "qi-styles-head";
            var lab = document.createElement("span");
            lab.textContent = T("qi.stTitle");
            head.appendChild(lab);
            var edit = iconBtn(styleEditing ? ICON.check : ICON.edit, styleEditing ? "qi.stDone" : "qi.stEdit", function () {
                styleEditing = !styleEditing;
                styleSel = -1;
                render();
            }, "qi-styles-toggle" + (styleEditing ? " on" : ""));
            head.appendChild(edit);
            box.appendChild(head);

            var rowEl = document.createElement("div");
            rowEl.className = "qi-styles-row";
            var chips = [];
            list.forEach(function (s, i) {
                var c = styleChip(s);
                if (styleEditing) {
                    c.title = T("qi.stPick");
                    if (i === styleSel) c.className += " sel";
                } else {
                    c.title = T("qi.stApply");
                    if (sameStyle(mine, s)) c.className += " on";
                }
                c.addEventListener("click", function () {
                    if (styleEditing) {
                        styleSel = (styleSel === i) ? -1 : i;
                        render();
                        return;
                    }
                    patch(index, function (o) { putStyle(o, s); });
                    swatches.sync(s);
                    render();
                });
                chips.push(c);
                rowEl.appendChild(c);
            });

            if (list.length < STYLE_MAX) {
                var add = document.createElement("button");
                add.type = "button";
                add.className = "qi-style qi-style-add";
                add.title = T("qi.stSave");
                add.innerHTML = '<svg class="ms" viewBox="0 -960 960 960" width="12" height="12" fill="currentColor" aria-hidden="true"><path d="' + ICON.plus + '"/></svg>';
                add.addEventListener("click", function () {
                    var cur = styleOfEntry(entries()[index]) || copyStyle(STYLE_BLANK);
                    var all = styles();
                    if (all.length >= STYLE_MAX) return;
                    all.push(cur);
                    saveStyles(all);
                    if (styleEditing) styleSel = all.length - 1;
                    render();
                    showToast("\u2713 " + T("qi.stSaved"));
                });
                rowEl.appendChild(add);
            }
            box.appendChild(rowEl);

            if (styleEditing) {
                var picked = list[styleSel];
                if (picked) {
                    var ed = document.createElement("div");
                    ed.className = "qi-menu-row qi-style-edit";
                    var fields = [
                        ["bg", "#292929", ICON.drop, "qi.stBg"],
                        ["hover", "#303030", ICON.cursor, "qi.stHover"],
                        ["fg", "#b8b8b8", ICON.text, "qi.stFg"],
                        ["border", "#3a3a3a", ICON.border, "qi.stBorder"]
                    ];
                    fields.forEach(function (f) {
                        ed.appendChild(colorCell(picked[f[0]], f[1], f[2], f[3], function (v) {
                            var all = styles();
                            if (!all[styleSel]) return;
                            all[styleSel][f[0]] = v;
                            saveStyles(all);
                            picked[f[0]] = v;
                            paintChip(chips[styleSel], picked);
                        }));
                    });

                    /* Tipo de fondo: solido de siempre, o uno de los tres
                       degradados. Se junta con el tipo de degradado en un solo
                       selector porque "solido" no es una cuarta forma de
                       degradado, es la ausencia de uno. */
                    var bgSel = document.createElement("select");
                    bgSel.className = "qi-menu-select";
                    [["solid", "qi.stBgSolid"], ["linear", "qi.stBgLinear"],
                     ["radial", "qi.stBgRadial"], ["conic", "qi.stBgConic"]].forEach(function (o) {
                        var op = document.createElement("option");
                        op.value = o[0];
                        op.textContent = T(o[1]);
                        bgSel.appendChild(op);
                    });
                    bgSel.value = (picked.bgType === "gradient") ? (picked.gradType || "linear") : "solid";
                    bgSel.addEventListener("change", function () {
                        var all = styles();
                        if (!all[styleSel]) return;
                        if (bgSel.value === "solid") {
                            delete all[styleSel].bgType; delete all[styleSel].gradType;
                        } else {
                            all[styleSel].bgType = "gradient";
                            all[styleSel].gradType = bgSel.value;
                            // Un degradado sin segundo color no es un degradado
                            // todavia: se arranca de algo, no de un hueco vacio.
                            if (!all[styleSel].bg2) all[styleSel].bg2 = all[styleSel].hover || "#3a3a3a";
                        }
                        saveStyles(all);
                        picked.bgType = all[styleSel].bgType;
                        picked.gradType = all[styleSel].gradType;
                        picked.bg2 = all[styleSel].bg2;
                        paintChip(chips[styleSel], picked);
                        // Un momento despues y no en el acto: "change" puede
                        // llegar todavia a medio cerrar la lista nativa del
                        // select, y rehacer el editor debajo de esa lista lo
                        // deja hablando con un select que ya no esta.
                        setTimeout(render, 0);
                    });
                    ed.appendChild(bgSel);

                    if (picked.bgType === "gradient") {
                        ed.appendChild(colorCell(picked.bg2, "#3a3a3a", ICON.drop, "qi.stBg2", function (v) {
                            var all = styles();
                            if (!all[styleSel]) return;
                            all[styleSel].bg2 = v;
                            saveStyles(all);
                            picked.bg2 = v;
                            paintChip(chips[styleSel], picked);
                        }));

                        if (picked.gradType !== "radial") {
                            var angleWrap = document.createElement("label");
                            angleWrap.className = "qi-style-angle";
                            var angleTxt = document.createElement("span");
                            angleTxt.textContent = T("qi.stAngle");
                            var angleInp = document.createElement("input");
                            angleInp.type = "range";
                            angleInp.min = "0"; angleInp.max = "359"; angleInp.step = "1";
                            angleInp.value = String((typeof picked.gradAngle === "number") ? picked.gradAngle : 135);
                            angleInp.addEventListener("input", function () {
                                var all = styles();
                                if (!all[styleSel]) return;
                                all[styleSel].gradAngle = parseInt(angleInp.value, 10);
                                saveStyles(all);
                                picked.gradAngle = all[styleSel].gradAngle;
                                paintChip(chips[styleSel], picked);
                            });
                            angleWrap.appendChild(angleTxt);
                            angleWrap.appendChild(angleInp);
                            ed.appendChild(angleWrap);
                        }
                    }

                    /* El destello y el tipo de borde no cambian el fondo ni
                       piden mas campos, asi que no hace falta volver a pintar
                       el editor entero al tocarlos. */
                    var sweepLbl = document.createElement("label");
                    sweepLbl.className = "qi-style-check";
                    var sweepChk = document.createElement("input");
                    sweepChk.type = "checkbox";
                    sweepChk.checked = !!picked.sweep;
                    sweepChk.addEventListener("change", function () {
                        var all = styles();
                        if (!all[styleSel]) return;
                        if (sweepChk.checked) all[styleSel].sweep = true; else delete all[styleSel].sweep;
                        saveStyles(all);
                        picked.sweep = all[styleSel].sweep;
                    });
                    sweepLbl.appendChild(sweepChk);
                    sweepLbl.appendChild(document.createTextNode(T("qi.stSweep")));
                    ed.appendChild(sweepLbl);

                    var borderSel = document.createElement("select");
                    borderSel.className = "qi-menu-select";
                    [["solid", "qi.stBorderSolid"], ["glow", "qi.stBorderGlow"],
                     ["gradient", "qi.stBorderGradient"]].forEach(function (o) {
                        var op = document.createElement("option");
                        op.value = o[0];
                        op.textContent = T(o[1]);
                        borderSel.appendChild(op);
                    });
                    borderSel.value = picked.borderStyle || "solid";
                    borderSel.addEventListener("change", function () {
                        var all = styles();
                        if (!all[styleSel]) return;
                        if (borderSel.value === "solid") delete all[styleSel].borderStyle;
                        else all[styleSel].borderStyle = borderSel.value;
                        saveStyles(all);
                        picked.borderStyle = all[styleSel].borderStyle;
                    });
                    ed.appendChild(borderSel);

                    var effectSel = document.createElement("select");
                    effectSel.className = "qi-menu-select";
                    [["none", "qi.stEffectNone"], ["soft3d", "qi.stEffectSoft3d"]].forEach(function (o) {
                        var op = document.createElement("option");
                        op.value = o[0];
                        op.textContent = T(o[1]);
                        effectSel.appendChild(op);
                    });
                    effectSel.value = picked.effect || "none";
                    effectSel.addEventListener("change", function () {
                        var all = styles();
                        if (!all[styleSel]) return;
                        if (effectSel.value === "none") delete all[styleSel].effect;
                        else all[styleSel].effect = effectSel.value;
                        saveStyles(all);
                        picked.effect = all[styleSel].effect;
                        paintChip(chips[styleSel], picked);
                    });
                    ed.appendChild(effectSel);

                    if (picked.nativeId) {
                        var nativeNote = document.createElement("span");
                        nativeNote.className = "qi-native-style-note";
                        nativeNote.textContent = T("qi.stNative");
                        nativeNote.title = T("qi.stNativeHint");
                        ed.appendChild(nativeNote);
                    } else {
                        ed.appendChild(iconBtn(ICON.trash, "qi.stRemove", function () {
                            var all = styles();
                            all.splice(styleSel, 1);
                            saveStyles(all);
                            styleSel = -1;
                            render();
                        }, "danger"));
                    }
                    box.appendChild(ed);
                } else {
                    var hint = document.createElement("p");
                    hint.className = "qi-menu-hint";
                    hint.textContent = list.length ? T("qi.stEditHint") : T("qi.stEmpty");
                    box.appendChild(hint);
                }
            }
            refit();
        }

        render();
        return box;
    }

    /* La X de cerrar, igual en los tres menus que usan placeMenu. Fija en la
       esquina de arriba a la derecha aunque el menu se desplace por dentro
       —position: sticky, no absolute—, porque con estilos avanzados el menu
       puede ser mas alto que la ventana y la X tiene que seguir a mano. */
    function closeButton() {
        var b = document.createElement("button");
        b.type = "button";
        b.className = "qi-menu-close";
        b.title = T("qi.mClose");
        b.setAttribute("aria-label", T("qi.mClose"));
        b.innerHTML = '<svg class="ms" viewBox="0 -960 960 960" width="10" height="10" fill="currentColor" aria-hidden="true"><path d="' + ICON.close + '"/></svg>';
        b.addEventListener("click", function (e) { e.stopPropagation(); closeMenu(); });
        return b;
    }

    function placeMenu(x, y) {
        if (!menuEl.querySelector(".qi-menu-close")) {
            menuEl.insertBefore(closeButton(), menuEl.firstChild);
        }
        menuEl.style.left = "0px";
        menuEl.style.top = "0px";
        document.body.appendChild(menuEl);

        var w = menuEl.offsetWidth, h = menuEl.offsetHeight;
        var W = document.documentElement.clientWidth;
        var H2 = document.documentElement.clientHeight;
        /* Los menus pueden ocupar casi todo el panel. Pegarlos al punto del
           clic hace que, al topar con el borde derecho, parezcan corridos. La
           posicion vertical sigue contando de donde salieron, pero en el eje
           horizontal se centran siempre dentro de QuickIt. */
        var left = Math.max(4, Math.round((W - w) / 2));
        var top = (y + h + 4 <= H2) ? y : Math.max(4, y - h);
        menuEl.style.left = left + "px";
        menuEl.style.top = top + "px";

        var first = menuEl.querySelector("input, select");
        if (first) { try { first.focus(); } catch (e) {} }
    }

    /* Cuando se elige una opcion de un <select> nativo, el navegador puede
       soltar un mousedown que no llega con el select como objetivo —el menu
       propio del sistema operativo no cuelga del arbol de la pagina—, y ese
       clic se leia como uno de fuera y cerraba todo el menu. No hay forma de
       reconocerlo por su objetivo, asi que se reconoce por cuando pasa: justo
       despues de un "change" dentro del menu. */
    var lastMenuChange = 0;
    document.addEventListener("change", function (e) {
        if (menuEl && menuEl.contains(e.target)) lastMenuChange = Date.now();
    }, true);

    document.addEventListener("mousedown", function (e) {
        if (!menuEl) return;
        var t = e.target;
        if (menuEl.contains(t)) return;
        /* Elegir una opcion de un <select> a veces deja el clic en un nodo que
           ya no esta en el arbol —el menu se redibujo entre el mousedown y
           este momento— o en un <option> de la lista nativa, que no cuelga de
           menuEl aunque sea del mismo select. Ninguno de los dos es un clic
           fuera de verdad. */
        if (!document.contains(t)) return;
        if (t.tagName === "OPTION") return;
        if (Date.now() - lastMenuChange < 300) return;
        // La pantalla de presets tiene su propio fondo y se cierra desde ahi;
        // este es el del menu junto al cursor, que no lo tiene.
        if (presetScrim) return;
        closeMenu();
        /* El mismo clic que cierra el menu no tiene por que activar lo que
           hubiera debajo: sin esto, cerrar el menu sobre un boton de la
           rejilla lo pulsaba de paso. */
        var swallow = function (ev) {
            ev.stopPropagation();
            ev.preventDefault();
            document.removeEventListener("click", swallow, true);
        };
        document.addEventListener("click", swallow, true);
        setTimeout(function () { document.removeEventListener("click", swallow, true); }, 400);
    }, true);
    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape" && menuEl) closeMenu();
    });
    window.addEventListener("blur", closeMenu);

    // Todas las acciones que se pueden meter en la rejilla, las de aqui y las
    // de los otros dos paneles, ordenadas por grupo y nombre.
    function everyCommand() {
        var out = [], i;
        var mine = C.all();
        for (i = 0; i < mine.length; i++) {
            out.push({ id: mine[i].id, label: C.label(mine[i]), group: C.group(mine[i]) });
        }
        var far = C.foreign();
        for (i = 0; i < far.length; i++) {
            out.push({ id: far[i].id, label: far[i].label, group: far[i].group });
        }
        out.sort(function (a, b) {
            if (a.group !== b.group) return a.group < b.group ? -1 : 1;
            return a.label < b.label ? -1 : 1;
        });
        return out;
    }

    // ------------------------------------------------------------------
    // Aspecto y secciones
    // ------------------------------------------------------------------
    var CORE_SECTIONS = ["nav", "zone", "grid"];
    var SECTIONS = ["nav", "zone", "grid", "search"];

    function sectionOff() {
        var o = readJson(K_SECTIONS, {});
        return o && typeof o === "object" ? o : {};
    }

    function applyLook() {
        var app = document.querySelector(".app");
        if (!app) return;
        var cols = 3, h = 34, fx = true, btnMode = "abbr";
        var fs = 10, fw = 700, ls = 0.04, rad = 6, caps = false;
        try {
            cols = parseInt(localStorage.getItem(K_COLS), 10) || 3;
            h = parseInt(localStorage.getItem(K_BTNH), 10) || 34;
            btnMode = localStorage.getItem(K_BTNMODE) === "icons" ? "icons" : "abbr";
            fx = localStorage.getItem(K_PRESS) !== "0";
            fs = parseFloat(localStorage.getItem(K_BTNFS)) || 10;
            fw = parseInt(localStorage.getItem(K_BTNFW), 10) || 700;
            /* Cuidado con el cero: la separacion entre letras puede ser 0 y "0"
               es falso. Se pregunta si hay algo guardado antes de quedarse con
               el valor de fabrica. */
            var lsRaw = localStorage.getItem(K_BTNLS);
            if (lsRaw !== null && isFinite(parseFloat(lsRaw))) ls = parseFloat(lsRaw);
            var radRaw = localStorage.getItem(K_BTNRAD);
            if (radRaw !== null && isFinite(parseFloat(radRaw))) rad = parseFloat(radRaw);
            caps = localStorage.getItem(K_BTNCAPS) === "1";
        } catch (e) {}

        app.style.setProperty("--qi-cols", String(cols));
        app.style.setProperty("--qi-btn-h", h + "px");
        app.style.setProperty("--qi-btn-fs", fs + "px");
        app.style.setProperty("--qi-btn-fw", String(fw));
        app.style.setProperty("--qi-btn-ls", ls + "em");
        app.style.setProperty("--qi-btn-r", rad + "px");
        app.classList.toggle("caps", caps);
        app.classList.toggle("no-press", !fx);
        app.classList.toggle("native-abbr", btnMode === "abbr");

        var off = sectionOff();
        app.classList.toggle("no-nav", !!off.nav);
        app.classList.toggle("no-zone", !!off.zone);
        app.classList.toggle("no-grid", !!off.grid);
        app.classList.toggle("no-search", !!off.search);
        // Apagar una seccion puede dejar la vista guardada apuntando a la que ya
        // no esta; aqui se vuelve a decidir, sin animacion porque no es un
        // cambio de vista sino una consecuencia.
        applyView(false);

        var s1 = $("qiCols"), s2 = $("qiBtnH"), s3 = $("qiBtnMode"), c2 = $("qiPressFx"), c3 = $("qiToasts");
        if (s1) s1.value = String(cols);
        if (s2) s2.value = String(h);
        if (s3) s3.value = btnMode;
        if (c2) c2.checked = fx;
        if (c3) c3.checked = toastsOn();

        var f1 = $("qiBtnFS"), f2 = $("qiBtnFW"), f3 = $("qiBtnLS"),
            f4 = $("qiBtnRad"), f5 = $("qiBtnCaps");
        if (f1) f1.value = String(fs);
        if (f2) f2.value = String(fw);
        if (f3) f3.value = String(ls);
        if (f4) f4.value = String(rad);
        if (f5) f5.checked = caps;

        var po = presetOpts();
        var pa = $("qiPAt"), pf = $("qiPFit"), ps = $("qiPStagger");
        if (pa) pa.value = po.at;
        if (pf) pf.checked = po.fit;
        if (ps) ps.value = String(po.stagger);
        syncHiddenBtn();
        syncPresetBtn();
        for (var i = 0; i < SECTIONS.length; i++) {
            var box = $("qiSec_" + SECTIONS[i]);
            if (box) box.checked = !off[SECTIONS[i]];
        }
    }

    /* SECRETO: LETRERO DE CINE. Las letras de los botones al maximo Y todo en
       mayusculas: la rejilla pasa a leerse como el cartel de una pelicula.

       Hacen falta las dos cosas, y por eso es un secreto y no un ajuste
       extremo: cada una por separado es una preferencia razonable, y solo
       juntas son una broma. */
    function marquee() {
        var ls = $("qiBtnLS"), caps = $("qiBtnCaps");
        if (!ls || !caps) return;
        if (parseFloat(ls.value) < 0.1 || !caps.checked) return;
        try { if (window.EditKitLog) window.EditKitLog.found("y6"); } catch (e) {}
    }

    function wireLook() {
        var pairs = [
            ["qiCols", K_COLS, "value"], ["qiBtnH", K_BTNH, "value"],
            ["qiBtnMode", K_BTNMODE, "value"],
            ["qiBtnFS", K_BTNFS, "value"], ["qiBtnFW", K_BTNFW, "value"],
            ["qiBtnLS", K_BTNLS, "value"], ["qiBtnRad", K_BTNRAD, "value"],
            ["qiBtnCaps", K_BTNCAPS, "check"],
            ["qiPressFx", K_PRESS, "check"], ["qiToasts", K_TOASTS, "check"]
        ];
        for (var i = 0; i < pairs.length; i++) {
            (function (p) {
                var el = $(p[0]);
                if (!el) return;
                el.addEventListener("change", function () {
                    var v = (p[2] === "check") ? (el.checked ? "1" : "0") : el.value;
                    try { localStorage.setItem(p[1], v); } catch (e) {}
                    applyLook();
                    marquee();
                });
            })(pairs[i]);
        }

        /* Las tres de "varias capas" van juntas en un solo objeto: se leen las
           tres cada vez que se aplica un preset, y guardarlas por separado solo
           daria tres formas de quedarse a medias. */
        var po3 = ["qiPAt", "qiPFit", "qiPStagger"];
        for (i = 0; i < po3.length; i++) {
            (function (id) {
                var el = $(id);
                if (!el) return;
                el.addEventListener("change", function () {
                    var a = $("qiPAt"), f = $("qiPFit"), g = $("qiPStagger");
                    var st = g ? parseInt(g.value, 10) : 0;
                    if (!isFinite(st) || st < 0) st = 0;
                    writeJson(K_PRESET_OPTS, {
                        at: a ? a.value : "in",
                        fit: !!(f && f.checked),
                        stagger: st
                    });
                    applyLook();
                });
            })(po3[i]);
        }

        /* Los perfiles se aplican desde el shell, otra ventana CEP. Esto
           sincroniza la casilla en el mismo momento y evita que conserve el
           valor anterior hasta un repintado posterior. */
        window.addEventListener("storage", function (ev) {
            if (!ev || ev.key === K_PRESET_OPTS || ev.key === null) applyLook();
        });

        /* Ninguna se puede apagar del todo si es la ultima que queda. No es una
           regla de cortesia: sin ninguna seccion la ventana es un rectangulo
           vacio, y el interruptor para recuperarla esta en los ajustes del
           plugin entero, que es otro sitio. */
        for (i = 0; i < SECTIONS.length; i++) {
            (function (name) {
                var el = $("qiSec_" + name);
                if (!el) return;
                el.addEventListener("change", function () {
                    var off = sectionOff();
                    off[name] = !el.checked;
                    var live = 0;
                    for (var j = 0; j < CORE_SECTIONS.length; j++) { if (!off[CORE_SECTIONS[j]]) live++; }
                    if (name !== "search" && !live) {
                        off[name] = false;
                        el.checked = true;
                        showToast(T("qi.secLast"), true);
                    }
                    writeJson(K_SECTIONS, off);
                    applyLook();
                });
            })(SECTIONS[i]);
        }

        applyLook();
    }

    // ------------------------------------------------------------------
    // Las dos vistas
    // ------------------------------------------------------------------
    /* Las dos mitades de esta ventana ya no comparten el alto: se turnan, y el
       boton de la cabecera las intercambia.

       Se llaman como se llaman las secciones en los ajustes —"Categorias" y
       "Botones"— a proposito. Son las palabras que el usuario ya vio ahi, y una
       palabra nueva para lo mismo es una cosa mas que aprender.

       Lo que se ve no lo decide solo esto: los interruptores de secciones
       siguen mandando encima. Si el usuario apago la rejilla, no hay dos vistas
       que intercambiar y el boton se retira en lugar de llevar a una pagina
       vacia. Ese es el "no cambia nada de lo que ya habia": esto es una capa
       por encima, no una regla nueva que discuta con las de antes. */

    function getView() {
        var v = null;
        try { v = localStorage.getItem(K_VIEW); } catch (e) {}
        return (v === "btns") ? "btns" : "cats";
    }

    /* Con una sola mitad encendida no hay nada que intercambiar, y la vista
       guardada podria estar apuntando justo a la que no esta. Se contesta con
       la que quede, sin tocar lo guardado: apagar una seccion un rato no tiene
       por que borrar la vista preferida. */
    function liveView() {
        var off = sectionOff();
        var hasGrid = !off.grid || !off.search;
        var hasCats = !off.zone || !off.nav;
        if (!hasGrid) return "cats";
        if (!hasCats) return "btns";
        return getView();
    }

    function onlyOneView() {
        var off = sectionOff();
        return (!!off.grid && !!off.search) || (!!off.zone && !!off.nav);
    }

    function applyView(animate) {
        var app = document.querySelector(".app");
        if (!app) return;
        var v = liveView();
        var was = app.getAttribute("data-view");
        app.setAttribute("data-view", v);
        app.classList.toggle("one-view", onlyOneView());
        scheduleFeatureSeen();

        var btn = $("qiView");
        if (btn) {
            // La descripcion dice a donde lleva, no donde esta: es lo que hace
            // falta saber antes de pulsarlo.
            var key = (v === "cats") ? "qi.viewToButtons" : "qi.viewToCats";
            btn.setAttribute("data-i18n-title", key);
            btn.title = T(key);
        }

        maybeAcknowledgeFreshIntro();

        if (!animate || !was || was === v) return;

        /* Lo que entra llega por el lado contrario al que se fue lo otro: de
           las categorias a los botones, desde la derecha; de vuelta, desde la
           izquierda. Sin ese movimiento el boton parece que apaga cosas; con el
           se entiende que hay dos paginas y que esta es la otra. */
        var from = (v === "btns") ? "view-from-right" : "view-from-left";
        app.classList.remove("view-from-right", "view-from-left");
        void app.offsetWidth;                 // reinicia la animacion
        app.classList.add(from);
        setTimeout(function () { app.classList.remove(from); }, 300);
    }

    function toggleView() {
        if (onlyOneView()) return;
        var v = (liveView() === "cats") ? "btns" : "cats";
        try { localStorage.setItem(K_VIEW, v); } catch (e) {}
        applyView(true);
        // La rejilla acaba de cambiar de alto: su barra de desplazamiento tiene
        // que volver a medirse, y quien la dibuja mira cada medio segundo.
        try {
            if (window.EditKitThinScroll) window.EditKitThinScroll.scan();
        } catch (e2) {}
    }

    function wireView() {
        var btn = $("qiView");
        if (btn) btn.addEventListener("click", toggleView);
        applyView(false);
    }

    // ------------------------------------------------------------------
    // De pie o tumbada
    // ------------------------------------------------------------------
    /* Cuando el usuario apila los tres paneles, este pasa a medir todo el ancho
       y un palmo de alto. Ahi las dos mitades no caben una encima de otra, asi
       que se ponen de lado. Se decide midiendo y no con un punto de corte
       escrito a mano: el reparto depende de como haya dejado el usuario los
       divisores, y ninguna cifra elegida de antemano acierta en los dos casos.

       El vigilante con intervalo no es plan B de ResizeObserver: el Chromium de
       CEP 9 es anterior a el, y donde si existe no dispara mientras el panel no
       se esta dibujando —volver de otra extension cae justo en ese hueco—.
       Leer innerWidth es barato; lo que cuesta es cambiar la clase, y eso solo
       pasa cuando de verdad ha cambiado la forma. */
    var wasWide = null, wasWideCols = null;
    function fitShape() {
        var app = document.querySelector(".app");
        if (!app) return;
        /* Con los ajustes abiertos, el shell estira este marco hasta cubrir
           EditKit entero y la ventana pasa a medir 900 de ancho. La herramienta
           que hay debajo no ha cambiado de tamano —esta clavada en su hueco de
           siempre—, asi que medir la ventana aqui la pondria de lado detras de
           la hoja y la devolveria a su sitio al cerrar. Dos recolocaciones para
           nada. */
        var L = window.EditKitLift;
        if (L && L.isOn()) return;
        var w = window.innerWidth, h = window.innerHeight;
        if (!w || !h) return;
        var wide = w > h;
        var changed = wide !== wasWide;
        if (changed) {
            wasWide = wide;
            app.classList.toggle("wide", wide);
        }

        /* En horizontal no dejamos que CSS adivine cuantas columnas caben.
           El iframe puede cambiar de ancho sin cambiar de orientacion (sobre
           todo dentro de la disposicion apilada), asi que medimos siempre y
           redibujamos solo si de verdad cambia la cantidad. */
        var box = $("qiGrid"), liveCols = null;
        if (wide && box && box.clientWidth) {
            liveCols = Math.max(1, Math.floor((box.clientWidth + 5) / 83));
            box.style.setProperty("--qi-wide-cols", String(liveCols));
        } else if (box) {
            box.style.removeProperty("--qi-wide-cols");
        }
        var colsChanged = liveCols !== wasWideCols;
        wasWideCols = liveCols;
        if ((changed || colsChanged) && booted) setTimeout(renderGrid, 0);
    }

    function watchShape() {
        fitShape();
        window.addEventListener("resize", fitShape);
        if (window.ResizeObserver) {
            try { new ResizeObserver(fitShape).observe(document.documentElement); } catch (e) {}
        }
        /* Y el vigilante, solo mientras se vea el panel: uno de CEP no se
           descarga al cambiar de pestana, se queda corriendo detras, y medir la
           ventana dos veces y media por segundo para nadie no le sirve a nadie.
           Quien sabe si se esta viendo es repaint-guard.js, que no se cree un
           "oculto" que nunca dijo "visible"; si no esta cargado, se mide como
           siempre. Al volver a aparecer, una pasada en el acto. */
        setInterval(function () {
            var A = window.EditKitAwake;
            if (A && A.idle()) return;
            fitShape();
        }, 400);
        if (window.EditKitAwake) window.EditKitAwake.onWake(fitShape);
    }

    // ------------------------------------------------------------------
    // Los ajustes de este plugin
    // ------------------------------------------------------------------
    /* La hoja se abre sobre el plugin entero y no solo sobre esta ventana: se
       le pide al shell que estire este marco hasta cubrirlo todo. En un panel
       de 190 px, una hoja encerrada aqui dentro salia con cada frase en cinco
       lineas. Suelto, sin shell, no hay a quien pedirselo y se abre como
       siempre. */
    function lift(on) {
        var L = window.EditKitLift;
        if (!L || !L.available) return;
        if (on) L.on(); else L.off();
    }

    function openSheet() {
        var ov = $("qiOverlay");
        if (!ov) return;
        lift(true);
        ov.hidden = false;
        var g = $("qiGear");
        if (g) g.classList.add("active");
    }
    function closeSheet() {
        var ov = $("qiOverlay");
        if (ov) ov.hidden = true;
        lift(false);
        var g = $("qiGear");
        if (g) g.classList.remove("active");
    }

    function wireSheet() {
        var gear = $("qiGear"), close = $("qiClose"), ov = $("qiOverlay");
        if (gear) gear.addEventListener("click", function () {
            if (ov && ov.hidden) openSheet(); else closeSheet();
        });
        if (close) close.addEventListener("click", closeSheet);
        // Fuera de la hoja se cierra; dentro no, o cada clic en un desplegable
        // la cerraria por debajo de la mano.
        if (ov) {
            ov.addEventListener("mousedown", function (e) {
                if (e.target === ov) closeSheet();
            });
        }
        document.addEventListener("keydown", function (e) {
            if (e.key === "Escape" && ov && !ov.hidden && !menuEl) closeSheet();
        });

        each(".qi-sheet-tab", function (t) {
            t.addEventListener("click", function () {
                var name = t.getAttribute("data-sheet-pane");
                each(".qi-sheet-tab", function (o) { o.classList.toggle("active", o === t); });
                each(".qi-sheet-pane", function (p) {
                    var on = p.getAttribute("data-sheet-content") === name;
                    p.classList.toggle("active", on);
                    p.hidden = !on;
                });
                var sheetBody = document.querySelector(".qi-sheet-body");
                if (sheetBody) sheetBody.scrollTop = 0;
            });
        });

        var pIndex = $("qiPresetIndex");
        if (pIndex) {
            pIndex.addEventListener("click", function () {
                buildIndex(pIndex, function () {
                    pIndex.disabled = false;
                    syncPresetBtn();
                });
            });
        }
        var pForget = $("qiPresetForget");
        if (pForget) {
            pForget.addEventListener("click", function () {
                forgetIndex();
                showToast("\u2713 " + T("qi.pForgotten"));
            });
        }

        var back = $("qiUnhideAll");
        if (back) {
            back.addEventListener("click", function () {
                var n = hiddenCount();
                unhideAll();
                showToast("\u2713 " + TF("qi.unhidden", n));
            });
        }

        var reset = $("qiResetGrid");
        if (reset) {
            reset.addEventListener("click", function () {
                try { localStorage.removeItem(K_GRID); } catch (e) {}
                renderGrid();
                showToast("\u2713 " + T("qi.gridReset"));
            });
        }
    }

    // ------------------------------------------------------------------
    // Arranque
    // ------------------------------------------------------------------
    var booted = false, bootRetries = 0;
    function boot() {
        if (booted) return;
        C = C || window.EditKitCommands;
        if (!C) {
            if (bootRetries++ < 20) { setTimeout(boot, 50); return; }
            rememberBootError("commands", new Error("EditKitCommands unavailable"));
            return;
        }
        booted = true;
        bootStep("cleanup", discardOldDiscoveryState);
        // Antes de dibujar: la rejilla guardada puede ser de una version
        // anterior y faltarle los botones que ahora vienen de fabrica.
        bootStep("migration", catchUpGrid);
        // La rejilla se pinta antes que los controles secundarios: un error en
        // Ajustes o en la deteccion de forma nunca debe dejar QuickIt vacio.
        bootStep("grid", renderGrid);
        bootStep("library", wireLibrary);
        bootStep("navigation", wireNav);
        bootStep("view", wireView);
        bootStep("appearance", wireLook);
        bootStep("settings", wireSheet);
        bootStep("icon", function () {
            if (window.EditKitMountToolIcon) window.EditKitMountToolIcon("quickit");
        });
        bootStep("shape", watchShape);

        /* Cuando llegan las acciones de los otros paneles hay que volver a
           dibujar: la rejilla puede tener huecos apuntando a ellas y hasta este
           momento no se sabia ni como se llaman. */
        document.addEventListener("editkit-foreign-changed", renderGrid);
        document.addEventListener("editkit-shortcuts-changed", renderGrid);
        document.addEventListener("editkit-lang-changed", function () {
            showCat(at);
            renderGrid();
            closeMenu();
            var libraryInput = $("qiLibraryInput");
            if (libraryInput) libraryInput.placeholder = T("qi.libSearch");
            drawLibrary();
            /* Y todo lo que se escribe a mano. i18n reescribe lo que lleva
               data-i18n, pero no lo que se arma aqui con una cifra dentro
               —"Recuperar los ocultos (3)", "40 presets indexados"—: eso hay
               que volver a componerlo, o se queda en el idioma de antes. */
            applyLook();
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
})();
