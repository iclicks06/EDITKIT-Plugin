/* ============================================================================
   LA VENTANA DEL MEDIO — HERRAMIENTAS

   El eje que faltaba. AlignIt sabia donde esta una capa; a partir de aqui el
   panel sabe tambien cuando pasa cada cosa, de quien cuelga, que dice su
   expresion y en que formato se entrega.

   Este archivo es solo la mitad de arriba: recoge lo que el usuario pide,
   valida lo poco que se puede validar sin mirar la composicion, llama al host
   y traduce lo que vuelve. Todo el trabajo real —y todos los grupos de
   deshacer— estan en host/index.jsx.

   Vive en esta ventana y no en AlignIt a proposito. AlignIt alinea, lleva anos
   haciendolo, y no hay razon para tocarlo cada vez que se anade una
   herramienta. Lo unico que comparten es el diccionario.
   ============================================================================ */
(function () {
    "use strict";

    var cs = new CSInterface();
    var C = window.EditKitCommands;

    function T(key) { return (window.EditKitI18n && window.EditKitI18n.t(key)) || key; }
    function TF(key, a) { return (window.EditKitI18n && window.EditKitI18n.fmt(key, a)) || key; }

    /* El aviso se ensena aqui, que es donde se pulso. Mandarlo al panel de al
       lado seria contar en una ventana lo que paso en otra. */
    function toast(msg, err) {
        if (typeof window.EditKitToast === "function") window.EditKitToast(msg, err);
    }
    function ok(msg) { toast("✓ " + msg); }
    function fail(msg) { toast(msg, true); }

    function $(id) { return document.getElementById(id); }
    function num(id, dflt) {
        var el = $(id);
        if (!el) return dflt;
        var v = parseFloat(el.value);
        return isFinite(v) ? v : dflt;
    }
    function val(id, dflt) {
        var el = $(id);
        return el ? el.value : dflt;
    }

    /* Control en Windows y Comando en Mac. Tres botones de este panel llevan
       pareja: hacen lo suyo con un clic y su variante con esta tecla. La
       variante siempre es la MISMA cosa con otro ajuste —el nulo recortado en
       vez de entero, la capa de ajuste de composicion entera en vez de la de
       la capa, precomponer todo junto en vez de por separado—, nunca otra cosa
       distinta. Un Control que hace algo sin relacion con el boton no es un
       atajo, es una trampa. */
    function ctrl(ev) { return !!(ev && (ev.ctrlKey || ev.metaKey)); }

    // ------------------------------------------------------------------
    // Puente con el host
    // ------------------------------------------------------------------
    /* Los errores vuelven como código, no como frase: el host no sabe en qué
       idioma está el panel y no tiene por qué. Aquí se traducen, y lo que no
       esté en la tabla se enseña tal cual en lugar de convertirse en un
       "error" a secas que no ayuda a nadie. */
    function errText(code, detail) {
        var key = "aa.e." + code;
        var s = T(key);
        if (s === key) s = detail ? String(detail) : code;
        else if (detail && code === "hostErr") s = s + " — " + detail;
        return s;
    }

    /* Solo ASCII cruza el puente.

       evalScript no manda datos: manda una LINEA DE CODIGO que el interprete de
       ExtendScript tiene que leer. Y ese interprete lee el texto con la pagina
       de codigos del sistema, no siempre en UTF-8: un nombre con acento puede
       llegar partido en dos caracteres raros y acabar asi de nombre de capa.

       Escapar a \uXXXX no cambia lo que llega —es la misma cadena, escrita de
       otra manera, y JSON.parse la deshace al otro lado— y quita el problema de
       raiz sin tener que adivinar la pagina de codigos de nadie. */
    function ascii(str) {
        return String(str).replace(/[-￿]/g, function (ch) {
            var h = ch.charCodeAt(0).toString(16);
            while (h.length < 4) h = "0" + h;
            return "\\u" + h;
        });
    }

    function call(fn, args, done) {
        var script = (args === null || typeof args === "undefined")
            ? fn + "()"
            : fn + "(" + ascii(JSON.stringify(JSON.stringify(args))) + ")";

        cs.evalScript(script, function (raw) {
            var r = null;
            try { r = JSON.parse(raw); } catch (e) { r = null; }
            if (!r) {
                if (done && done.onFail) {
                    try { done.onFail({ ok: false, code: "hostErr", detail: raw || "" }); } catch (eFail) {}
                }
                fail(T("aa.e.hostErr") + (raw ? " — " + String(raw).substring(0, 90) : ""));
                return;
            }
            if (!r.ok) {
                if (done && done.onFail && done.onFail(r)) return;
                fail(errText(r.code, r.detail));
                return;
            }
            try { if (window.EditKitLog) window.EditKitLog.bump("tools"); } catch (e2) {}
            if (typeof done === "function") done(r);
            else if (done && done.onOk) done.onOk(r);
        });
    }

    // ------------------------------------------------------------------
    // A — tiempo y keyframes
    // ------------------------------------------------------------------
    function setInterp(kind) {
        call("ek_setInterp", { kind: kind }, function (r) {
            ok(TF("aa.done.keys", r.keys));
        });
    }

    function shiftKeys(sign) {
        var f = Math.round(num("shiftFrames", 1));
        if (!f) return;
        call("ek_timeShift", { frames: f * sign }, function (r) {
            ok(TF("aa.done.shifted", (sign > 0 ? "+" : "−") + f));
        });
    }

    function scaleKeys(factor) {
        if (!isFinite(factor) || factor <= 0) return;
        call("ek_timeScale", { factor: factor, anchor: val("scaleAnchor", "first") }, function (r) {
            ok(TF("aa.done.retimed", "×" + factor));
        });
    }

    /* Invertir el tiempo de los keyframes, y su variante que deja copia.

       No se le pasa nada al host: el tramo lo decide el, que es quien ve la
       seleccion. La copia se escribe a partir del cursor de tiempo, y tampoco
       hace falta decirselo — lo lee de la composicion. */
    function reverseKeys() {
        call("ek_reverseKeys", {}, function (r) {
            ok(TF("aa.done.reversed", r.keys));
        });
    }

    function reverseKeysCopy() {
        call("ek_reverseKeysCopy", {}, function (r) {
            ok(TF("aa.done.reverseCopied", r.keys));
        });
    }

    function setPasteFitReady(ready) {
        try {
            if (ready) document.body.setAttribute("data-paste-fit-ready", "1");
            else document.body.removeAttribute("data-paste-fit-ready");
        } catch (e) {}
    }

    /* La captura es explicita: el host usa el comando Copiar de After Effects
       y conserva las rutas internas. El panel no necesita permiso para leer
       el portapapeles de Windows o macOS. */
    function capturePasteFit() {
        call("ek_capturePasteFit", {}, function (r) {
            setPasteFitReady(true);
            ok(TF("aa.done.pasteCapturedCount", r.properties));
        });
    }

    /* Aplica exclusivamente la ultima captura confirmada. Si aun no existe,
       el host responde antes de mover el cabezal o modificar la composicion. */
    function pasteAndFit() {
        call("ek_pasteAndFit", {}, function (r) {
            ok(TF("aa.done.pasteFit", r.layers));
            if (r.skipped) {
                setTimeout(function () { toast(TF("aa.warn.pasteFitSkipped", r.skipped), true); }, 1400);
            }
        });
    }

    // ------------------------------------------------------------------
    // Orden vertical de las capas
    // ------------------------------------------------------------------
    function orderLayers(mode) {
        call("ek_orderLayers", { mode: mode, scope: val("orderScope", "sel") }, function (r) {
            ok(TF("aa.done.ordered", r.layers));
        });
    }

    function gotoKey(dir) {
        call("ek_gotoKey", { dir: dir }, function (r) {
            ok(TF("aa.done.atFrame", r.frame));
        });
    }

    function bakeExpression() {
        call("ek_bakeExpression", { range: val("bakeRange", "layer") }, function (r) {
            ok(TF("aa.done.keys", r.keys));
        });
    }

    // ------------------------------------------------------------------
    // B — capas y jerarquía
    // ------------------------------------------------------------------
    /* El nulo. Con Control, recortado al tramo que ocupan las capas que le
       cuelgan en lugar de cruzar la composicion entera. */
    function parentNull(at, span) {
        call("ek_parentNull", { at: at, name: T("aa.nullName"), span: !!span }, function (r) {
            ok(TF("aa.done.parented", r.linked) + (r.trimmed ? " \u00b7 " + T("aa.done.nullTrimmed") : ""));
        });
    }

    function unparent() {
        call("ek_unparentKeep", {}, function (r) {
            ok(TF("aa.done.unparented", r.layers));
            // Los avisos no son errores: la operación se hizo, pero conviene
            // decir en qué se ha tenido que aproximar.
            if (r.warn) setTimeout(function () { toast(T("aa.warn." + r.warn), true); }, 1400);
        });
    }

    /* CAPA DE AJUSTE Y PRECOMPONER LA SELECCION

       Comparten boton: un clic lo primero, Control y clic lo segundo. El
       reparto se decide aqui y no en cada sitio donde puede estar el boton
       —el panel, la rejilla, la paleta— para que el truco valga igual en los
       tres. */
    function addAdjustment(span) {
        call("ek_addAdjustment", { name: T("aa.adjName"), span: span || "layer" }, function (r) {
            var msg = r.over ? TF("aa.done.adjOver", r.over) : T("aa.done.adj");
            ok(msg + (r.span === "comp" ? " \u00b7 " + T("aa.done.adjWhole") : ""));
        });
    }

    /* Las tres capas nuevas y el congelado. Todas con su variante de Control,
       que es siempre la misma cosa con otro ajuste. */
    function addSolid(span) {
        call("ek_addSolid", {
            name: T("aa.solidName"), color: val("solidColor", "#000000"), span: span || "comp"
        }, function (r) { ok(TF("aa.done.newLayer", r.name)); });
    }

    function addShape(span) {
        call("ek_addShape", { name: T("aa.shapeName"), span: span || "comp" }, function (r) {
            ok(TF("aa.done.newLayer", r.name));
        });
    }

    /* Texto puntual, como el clic normal de la herramienta Texto. El host lo
       centra visualmente y deja la capa seleccionada; no añade expresiones ni
       cajas auxiliares, de modo que sigue siendo texto nativo y editable. */
    function addText(span) {
        call("ek_addText", { text: T("aa.textName"), span: span || "comp" }, function () {
            ok(T("aa.done.textLayer"));
        });
    }

    function addCamera(oneNode) {
        call("ek_addCamera", { name: T("aa.cameraName"), oneNode: !!oneNode }, function (r) {
            ok(TF("aa.done.newLayer", r.name));
        });
    }

    function autoParallax() {
        call("ek_autoParallax", {
            depth: num("parallaxDepth", 350),
            cameraName: T("aa.cameraName"),
            controlName: T("aa.parallaxControlName")
        }, function (r) {
            ok(TF("aa.done.parallax", r.layers) + (r.cameraCreated ? " · " + T("aa.done.parallaxCamera") : ""));
            if (r.skipped) {
                setTimeout(function () { toast(TF("aa.warn.parallaxSkipped", r.skipped), true); }, 1400);
            }
        });
    }

    function freezeFrame(at) {
        call("ek_freezeFrame", { at: at || "playhead" }, function (r) {
            ok(TF("aa.done.frozen", r.layers));
        });
    }

    function precomposeAll() {
        call("ek_precomposeAll", { suffix: T("aa.precAllSuffix") }, function (r) {
            ok(TF("aa.done.precAll", r.layers));
        });
    }

    function fitComp() {
        call("ek_compToContent", { margin: num("fitMargin", 0) }, function (r) {
            ok(r.width + " × " + r.height);
        });
    }

    /* Sacar un precomp es la única de la lista que puede estropear el proyecto
       de otra persona, así que no se ejecuta a la primera: el host devuelve lo
       que no va a poder reproducir y el panel lo pregunta antes de insistir. */
    function extractPrecomp(force) {
        call("ek_extractPrecomp", { force: !!force }, {
            onOk: function (r) {
                ok(TF("aa.done.extracted", r.layers));
                /* Los dos avisos van detras del recuento y no en su lugar: lo
                   primero que hay que saber es que se hizo. El de la
                   composicion suelta no es un error —no se ha borrado nada—,
                   pero conviene decirlo antes de que el usuario la encuentre
                   por su cuenta en el panel de proyecto. */
                var later = [];
                if (r.warn) later.push(T("aa.warn." + r.warn));
                if (r.orphan) later.push(TF("aa.done.orphan", r.name));
                for (var i = 0; i < later.length; i++) {
                    (function (msg, n) {
                        setTimeout(function () { toast(msg, true); }, 1400 + n * 1800);
                    })(later[i], i);
                }
            },
            onFail: function (r) {
                if (r.code !== "precompRisky") return false;
                var names = [];
                for (var i = 0; i < r.issues.length; i++) names.push(T("aa.risk." + r.issues[i]));

                /* La lista va como lista y no pegada al enunciado con saltos de
                   linea y vinetas escritas a mano. Eso era lo unico que se
                   podia hacer con el cuadro del sistema, que solo acepta texto
                   plano; el nuestro acepta nodos. */
                window.EditKitAsk.confirm({
                    text: T("aa.precompConfirm"),
                    list: names,
                    go: T("aa.ask.pullOut"),
                    keep: T("aa.ask.keep"),
                    danger: true
                }, function (yes) {
                    if (yes) extractPrecomp(true);
                });
                return true;
            }
        });
    }

    /* Una precomposicion por capa, no una para todas. Es lo contrario de lo
       que hace el dialogo de After Effects con una seleccion multiple, y a
       mano son tantas pasadas por ese dialogo como capas haya. El host se
       encarga de que el orden y los tiempos salgan intactos. */
    function precomposeEach() {
        call("ek_precomposeEach", { suffix: val("precomposeSuffix", "") }, function (r) {
            ok(TF("aa.done.precomposed", r.layers));
            // Alguna se quedo fuera: se dice, pero despues del recuento. Lo
            // que se hizo es lo primero que hay que saber.
            if (r.failed) {
                setTimeout(function () {
                    toast(TF("aa.warn.precomposeSkipped", r.failed), true);
                }, 1400);
            }
        });
    }

    // ------------------------------------------------------------------
    // C — expresiones
    // ------------------------------------------------------------------
    function applyExpression(kind) {
        var o = { kind: kind };
        if (kind === "wiggle") {
            o.freq = num("wgFreq", 3);
            o.amp = num("wgAmp", 30);
            o.axis = val("wgAxis", "both");
        } else if (kind === "loop") {
            o.mode = val("loopMode", "cycle");
            o.dir = val("loopDir", "out");
        } else if (kind === "inertia") {
            o.amp = num("inAmp", 0.08);
            o.freq = num("inFreq", 2.5);
            o.decay = num("inDecay", 6);
        } else if (kind === "autofade") {
            o.fadeIn = num("fdIn", 0.5);
            o.fadeOut = num("fdOut", 0.5);
        }
        call("ek_expression", o, function (r) {
            ok(TF("aa.done.props", r.props));
        });
    }

    function clearExpression() {
        call("ek_clearExpression", null, function (r) {
            ok(TF("aa.done.props", r.props));
        });
    }

    // ------------------------------------------------------------------
    // D — formas y texto
    // ------------------------------------------------------------------
    function strokeStyle() {
        call("ek_strokeStyle", {
            cap: parseInt(val("strokeCap", "1"), 10),
            join: parseInt(val("strokeJoin", "1"), 10)
        }, function (r) {
            ok(TF("aa.done.strokes", r.strokes));
        });
    }

    function splitText(mode) {
        call("ek_splitText", { mode: mode }, function (r) {
            ok(TF("aa.done.layers", r.layers));
        });
    }

    function textBox() {
        // La caja nace del color de acento del panel: es la única pista visual
        // que ata la capa nueva a la herramienta que la creó.
        var rgb = accentRgb();
        call("ek_textBox", {
            padX: num("boxPadX", 24),
            padY: num("boxPadY", 14),
            radius: num("boxRadius", 0),
            color: rgb
        }, function (r) {
            ok(r.name);
        });
    }

    function accentRgb() {
        var hex = "#49c9bd";
        try {
            var v = getComputedStyle(document.documentElement).getPropertyValue("--accent");
            if (v) hex = v.replace(/\s/g, "");
        } catch (e) {}
        var m = /^#?([0-9a-f]{6})$/i.exec(hex);
        if (!m) return [0.09, 0.09, 0.09];
        var n = parseInt(m[1], 16);
        // After Effects trabaja en 0–1, y sin corrección de gamma: el color
        // llega algo más claro que en pantalla, que es lo correcto para un
        // fondo detrás de texto.
        return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
    }

    // ------------------------------------------------------------------
    // E — entrega
    // ------------------------------------------------------------------
    var K_FOLDER = "editkit_out_folder";
    var K_AUDIO_JOB = "editkit_qi_audio_job_v1";
    function outFolder() {
        try { return localStorage.getItem(K_FOLDER) || ""; } catch (e) { return ""; }
    }
    function setOutFolder(p) {
        try { localStorage.setItem(K_FOLDER, p); } catch (e) {}
        showFolder();
    }
    function showFolder() {
        var p = outFolder();
        var ids = ["outFolderPath", "audioFolderPath"];
        for (var i = 0; i < ids.length; i++) {
            var el = $(ids[i]);
            if (!el) continue;
            el.hidden = !p;
            el.textContent = p;
            el.title = p;
        }
    }

    function pickFolder() {
        call("ek_pickFolder", null, {
            onOk: function (r) { setOutFolder(r.path); ok(T("aa.done.folder")); },
            onFail: function (r) { return r.code === "canceled"; }
        });
    }

    function saveFrame() {
        call("ek_saveFrame", { folder: outFolder() }, {
            onOk: function (r) { ok(T("aa.done.frame")); },
            onFail: function (r) { return r.code === "canceled"; }
        });
    }

    function toQueue() {
        call("ek_addToQueue", { folder: outFolder() }, function (r) {
            ok(TF("aa.done.queued", r.name));
        });
    }

    function formatVersion(w, h) {
        call("ek_formatVersion", { w: w, h: h, mode: val("formatMode", "fit") }, function (r) {
            ok(r.name);
        });
    }

    function cloneComp() {
        var option = $("cloneFootage");
        var locale = window.EditKitI18n && window.EditKitI18n.getLanguage ?
            window.EditKitI18n.getLanguage() : "es";
        call("ek_cloneComp", { duplicateFootage: !!(option && option.checked), lang: locale }, function (r) {
            ok(TF("aa.done.cloned", r.comps));
            if (r.skipped) {
                setTimeout(function () { toast(TF("aa.warn.cloneFootageSkipped", r.skipped), true); }, 1400);
            }
        });
    }

    function organizeProject() {
        var locale = window.EditKitI18n && window.EditKitI18n.getLanguage ?
            window.EditKitI18n.getLanguage() : "es";
        call("ek_organizeProject", { lang: locale }, function (r) {
            ok(r.moved ? TF("aa.done.organized", r.moved) : T("aa.done.alreadyOrganized"));
        });
    }

    // ------------------------------------------------------------------
    // F — audio: preparar fuera y devolver a su sitio
    // ------------------------------------------------------------------
    function audioJob() {
        try {
            var value = JSON.parse(localStorage.getItem(K_AUDIO_JOB) || "null");
            return value && typeof value === "object" ? value : null;
        } catch (e) { return null; }
    }

    function saveAudioJob(job) {
        try { localStorage.setItem(K_AUDIO_JOB, JSON.stringify(job)); } catch (e) {}
        showAudioJob();
    }

    function showAudioJob() {
        var el = $("audioJobStatus"), btn = $("audioImportBtn"), job = audioJob();
        if (btn) btn.disabled = !job;
        if (!el) return;
        el.hidden = !job;
        if (!job) return;
        el.setAttribute("data-state", "ready");
        el.textContent = TF("aa.audioLast", job.name || job.path || "");
        el.title = job.path || "";
    }

    function audioStatus(text, state) {
        var el = $("audioJobStatus");
        if (!el) return;
        el.hidden = !text;
        el.textContent = text || "";
        el.title = text || "";
        el.setAttribute("data-state", state || "");
    }

    function audioBusy(on) {
        var btn = $("audioConsolidateBtn");
        if (!btn) return;
        btn.disabled = !!on;
        btn.classList.toggle("busy", !!on);
        btn.textContent = T(on ? "aa.audioProcessing" : "aa.audioMixDo");
    }

    function consolidateAudio() {
        audioBusy(true);
        audioStatus(T("aa.audioProcessing"), "busy");
        call("ek_audioConsolidate", {
            folder: outFolder(),
            range: val("audioRange", "selection"),
            openFolder: !!($("audioOpenFolder") && $("audioOpenFolder").checked)
        }, {
            onOk: function (r) {
                audioBusy(false);
                if (r.folder) setOutFolder(r.folder);
                saveAudioJob({
                    compId: r.compId,
                    compName: r.compName,
                    start: r.start,
                    duration: r.duration,
                    path: r.path,
                    name: r.name
                });
                ok(TF("aa.done.audioMixed", r.name));
            },
            onFail: function (r) {
                audioBusy(false);
                if (r.code === "canceled") {
                    showAudioJob();
                    return true;
                }
                var audioError = errText(r.code, r.detail);
                if (r.detail && r.code !== "hostErr") audioError += " — " + String(r.detail);
                audioStatus(audioError, "error");
                return r.code === "canceled";
            }
        });
    }

    function importAudioResult() {
        var job = audioJob();
        if (!job) { fail(T("aa.e.audioNoExport")); return; }
        call("ek_audioImport", job, {
            onOk: function (r) { ok(TF("aa.done.audioImported", r.files)); },
            onFail: function (r) { return r.code === "canceled"; }
        });
    }

    // ------------------------------------------------------------------
    // Cableado de la interfaz
    // ------------------------------------------------------------------
    function each(sel, fn) {
        var els = document.querySelectorAll(sel);
        for (var i = 0; i < els.length; i++) fn(els[i], i);
    }

    function wire() {
        each("[data-interp]", function (b) {
            b.addEventListener("click", function () { setInterp(b.getAttribute("data-interp")); });
        });
        each("[data-shift]", function (b) {
            b.addEventListener("click", function () { shiftKeys(parseInt(b.getAttribute("data-shift"), 10)); });
        });
        each("[data-scale]", function (b) {
            b.addEventListener("click", function () { scaleKeys(parseFloat(b.getAttribute("data-scale"))); });
        });
        each("[data-goto]", function (b) {
            b.addEventListener("click", function () { gotoKey(b.getAttribute("data-goto")); });
        });
        each("[data-expr]", function (b) {
            b.addEventListener("click", function () { applyExpression(b.getAttribute("data-expr")); });
        });
        each("[data-split]", function (b) {
            b.addEventListener("click", function () { splitText(b.getAttribute("data-split")); });
        });
        each("[data-format]", function (b) {
            b.addEventListener("click", function () {
                var wh = b.getAttribute("data-format").split("x");
                formatVersion(parseInt(wh[0], 10), parseInt(wh[1], 10));
            });
        });

        var pairs = [
            ["scaleApplyBtn", function () { scaleKeys(num("scaleFactor", 1)); }],
            ["bakeBtn", bakeExpression],
            ["exprClearBtn", clearExpression],
            ["strokeApplyBtn", strokeStyle],
            ["boxCreateBtn", textBox],
            ["fitCompBtn", fitComp],
            ["outFolderBtn", pickFolder],
            ["saveFrameBtn", saveFrame],
            ["queueBtn", toQueue],
            ["audioFolderBtn", pickFolder],
            ["audioConsolidateBtn", consolidateAudio],
            ["audioImportBtn", importAudioResult],
            ["extractBtn", function () { extractPrecomp(false); }],
            ["precomposeEachBtn", function (ev) { if (ctrl(ev)) precomposeAll(); else precomposeEach(); }],
            ["cloneCompBtn", cloneComp],
            ["parentNullBtn", function (ev) { parentNull(val("nullAt", "center"), ctrl(ev)); }],
            ["adjustmentBtn", function (ev) { addAdjustment(ctrl(ev) ? "comp" : "layer"); }],
            ["solidBtn", function (ev) { addSolid(ctrl(ev) ? "sel" : "comp"); }],
            ["shapeBtn", function (ev) { addShape(ctrl(ev) ? "sel" : "comp"); }],
            ["cameraBtn", function (ev) { addCamera(ctrl(ev)); }],
            ["textBtn", function (ev) { addText(ctrl(ev) ? "sel" : "comp"); }],
            ["parallaxBtn", autoParallax],
            ["freezeBtn", function (ev) { freezeFrame(ctrl(ev) ? "in" : "playhead"); }],
            ["unparentBtn", unparent],
            ["reverseKeysBtn", reverseKeys],
            ["reverseCopyBtn", reverseKeysCopy]
        ];
        for (var i = 0; i < pairs.length; i++) {
            var el = $(pairs[i][0]);
            if (el) el.addEventListener("click", pairs[i][1]);
        }

        // Las seis maneras de ordenar comparten boton y se distinguen por su
        // atributo, igual que la interpolacion y el desplazamiento.
        var ords = document.querySelectorAll("[data-order]");
        for (var k = 0; k < ords.length; k++) {
            ords[k].addEventListener("click", (function (m) {
                return function () { orderLayers(m); };
            })(ords[k].getAttribute("data-order")));
        }
        showFolder();
        showAudioJob();
    }

    // ------------------------------------------------------------------
    // Comandos
    // ------------------------------------------------------------------
    /* Todo lo que esta ventana sabe hacer entra aqui. Lo de alinear, distribuir
       y copiar transformaciones no esta: es de AlignIt y se registra alli.
       Desde aqui se llega igual, por la centralita de comandos. */
    function reg(id, group, key, run, keys) {
        C.register({
            id: id,
            group: function () { return T(group); },
            label: function () { return T(key); },
            run: run,
            keys: keys || ""
        });
    }

    function registerAll() {
        var G_TIME = "aa.tabTime", G_HIER = "aa.hierarchy",
            G_EXPR = "aa.tabExpr", G_TEXT = "aa.tabText", G_COMP = "aa.tabComp",
            G_AUDIO = "aa.tabAudio";

        reg("time.hold", G_TIME, "aa.cmdHold", function () { setInterp("hold"); }, "alt+h");
        reg("time.linear", G_TIME, "aa.cmdLinear", function () { setInterp("linear"); }, "alt+l");
        reg("time.ease", G_TIME, "aa.cmdEase", function () { setInterp("ease"); }, "alt+e");
        reg("time.easeIn", G_TIME, "aa.cmdEaseIn", function () { setInterp("easeIn"); }, "");
        reg("time.easeOut", G_TIME, "aa.cmdEaseOut", function () { setInterp("easeOut"); }, "");
        reg("time.shiftBack", G_TIME, "aa.cmdShiftBack", function () { shiftKeys(-1); }, "alt+ArrowLeft");
        reg("time.shiftFwd", G_TIME, "aa.cmdShiftFwd", function () { shiftKeys(1); }, "alt+ArrowRight");
        reg("time.scaleHalf", G_TIME, "aa.cmdScaleHalf", function () { scaleKeys(0.5); }, "");
        reg("time.scaleDouble", G_TIME, "aa.cmdScaleDouble", function () { scaleKeys(2); }, "");
        reg("time.scaleApply", G_TIME, "aa.cmdScaleApply", function () { scaleKeys(num("scaleFactor", 1)); }, "");
        reg("time.gotoPrev", G_TIME, "aa.cmdGotoPrev", function () { gotoKey("prev"); }, "ArrowLeft");
        reg("time.gotoNext", G_TIME, "aa.cmdGotoNext", function () { gotoKey("next"); }, "ArrowRight");
        reg("time.gotoFirst", G_TIME, "aa.cmdGotoFirst", function () { gotoKey("first"); }, "");
        reg("time.gotoLast", G_TIME, "aa.cmdGotoLast", function () { gotoKey("last"); }, "");
        reg("time.bake", G_TIME, "aa.cmdBake", bakeExpression, "");
        reg("time.reverse", G_TIME, "aa.cmdReverse", reverseKeys, "");
        reg("time.reverseCopy", G_TIME, "aa.cmdReverseCopy", reverseKeysCopy, "");
        reg("time.capturePasteFit", G_TIME, "aa.cmdCapturePasteFit", capturePasteFit, "");
        reg("time.pasteFit", G_TIME, "aa.cmdPasteFit", pasteAndFit, "");

        reg("layer.solid", G_COMP, "aa.cmdSolid", function () { addSolid("comp"); }, "");
        reg("layer.solidSel", G_COMP, "aa.cmdSolidSel", function () { addSolid("sel"); }, "");
        reg("layer.shape", G_COMP, "aa.cmdShape", function () { addShape("comp"); }, "");
        reg("layer.shapeSel", G_COMP, "aa.cmdShapeSel", function () { addShape("sel"); }, "");
        reg("layer.text", G_COMP, "aa.cmdText", function () { addText("comp"); }, "");
        reg("layer.textSel", G_COMP, "aa.cmdTextSel", function () { addText("sel"); }, "");
        reg("layer.camera", G_COMP, "aa.cmdCamera", function () { addCamera(false); }, "");
        reg("layer.cameraOne", G_COMP, "aa.cmdCameraOne", function () { addCamera(true); }, "");
        reg("layer.autoParallax", G_COMP, "aa.cmdAutoParallax", autoParallax, "");
        reg("time.freeze", G_TIME, "aa.cmdFreeze", function () { freezeFrame("playhead"); }, "");
        reg("time.freezeIn", G_TIME, "aa.cmdFreezeIn", function () { freezeFrame("in"); }, "");
        reg("layer.adjustment", G_COMP, "aa.cmdAdjustment", function () { addAdjustment("layer"); }, "");
        reg("layer.adjustmentComp", G_COMP, "aa.cmdAdjustmentComp", function () { addAdjustment("comp"); }, "");
        reg("comp.precomposeAll", G_COMP, "aa.cmdPrecomposeAll", precomposeAll, "");
        reg("layer.parentNull", G_HIER, "aa.cmdParentNull", function () { parentNull("center"); }, "alt+n");
        reg("layer.parentNullSpan", G_HIER, "aa.cmdParentNullSpan", function () { parentNull("center", true); }, "");
        reg("layer.parentNullAnchor", G_HIER, "aa.cmdParentNullAnchor", function () { parentNull("anchor"); }, "");
        reg("layer.unparent", G_HIER, "aa.cmdUnparent", unparent, "alt+u");
        reg("order.reverse", G_HIER, "aa.cmdOrderReverse", function () { orderLayers("reverse"); }, "");
        reg("order.selection", G_HIER, "aa.cmdOrderSelection", function () { orderLayers("selection"); }, "");
        reg("order.name", G_HIER, "aa.cmdOrderName", function () { orderLayers("name"); }, "");
        reg("order.random", G_HIER, "aa.cmdOrderRandom", function () { orderLayers("random"); }, "");
        reg("order.inPoint", G_HIER, "aa.cmdOrderIn", function () { orderLayers("inPoint"); }, "");
        reg("order.outPoint", G_HIER, "aa.cmdOrderOut", function () { orderLayers("outPoint"); }, "");

        reg("expr.wiggle", G_EXPR, "aa.exprWiggle", function () { applyExpression("wiggle"); }, "");
        reg("expr.loop", G_EXPR, "aa.exprLoop", function () { applyExpression("loop"); }, "");
        reg("expr.inertia", G_EXPR, "aa.exprInertia", function () { applyExpression("inertia"); }, "");
        reg("expr.autofade", G_EXPR, "aa.exprFade", function () { applyExpression("autofade"); }, "");
        reg("expr.seed", G_EXPR, "aa.exprSeed", function () { applyExpression("seed"); }, "");
        reg("expr.follow", G_EXPR, "aa.exprFollow", function () { applyExpression("follow"); }, "");
        reg("expr.clear", G_EXPR, "aa.exprClear", clearExpression, "");

        reg("text.stroke", G_TEXT, "aa.cmdStroke", strokeStyle, "");
        reg("text.splitLine", G_TEXT, "aa.cmdSplitLine", function () { splitText("line"); }, "");
        reg("text.splitWord", G_TEXT, "aa.cmdSplitWord", function () { splitText("word"); }, "");
        reg("text.splitChar", G_TEXT, "aa.cmdSplitChar", function () { splitText("char"); }, "");
        reg("text.box", G_TEXT, "aa.boxCreate", textBox, "");

        reg("comp.fit", G_COMP, "aa.cmdFitComp", fitComp, "");
        reg("comp.f916", G_COMP, "aa.cmdF916", function () { formatVersion(1080, 1920); }, "");
        reg("comp.f11", G_COMP, "aa.cmdF11", function () { formatVersion(1080, 1080); }, "");
        reg("comp.f169", G_COMP, "aa.cmdF169", function () { formatVersion(1920, 1080); }, "");
        reg("comp.f45", G_COMP, "aa.cmdF45", function () { formatVersion(1080, 1350); }, "");
        reg("comp.saveFrame", G_COMP, "aa.saveFrame", saveFrame, "");
        reg("comp.queue", G_COMP, "aa.toQueue", toQueue, "");
        reg("comp.precompose", G_COMP, "aa.precomposeDo", precomposeEach, "");
        reg("comp.deepClone", G_COMP, "aa.cmdClone", cloneComp, "");
        reg("comp.organizeProject", G_COMP, "aa.cmdOrganizeProject", organizeProject, "");
        reg("comp.extract", G_COMP, "aa.extractDo", function () { extractPrecomp(false); }, "");
        reg("comp.folder", G_COMP, "aa.pickFolder", pickFolder, "");
        reg("audio.consolidate", G_AUDIO, "aa.cmdAudioConsolidate", consolidateAudio, "");
        reg("audio.import", G_AUDIO, "aa.cmdAudioImport", importAudioResult, "");
    }

    // ------------------------------------------------------------------
    // Editor de atajos
    // ------------------------------------------------------------------
    function renderShortcuts() {
        var box = $("shortcutEditor");
        if (!box) return;
        box.innerHTML = "";

        var all = C.all(), bad = C.conflicts(), clash = false;
        all.sort(function (a, b) {
            var ga = C.group(a), gb = C.group(b);
            if (ga !== gb) return ga < gb ? -1 : 1;
            return C.label(a) < C.label(b) ? -1 : 1;
        });

        var lastGroup = null;
        for (var i = 0; i < all.length; i++) {
            var cmd = all[i], g = C.group(cmd);
            if (g !== lastGroup) {
                var h = document.createElement("div");
                h.className = "settings-group-title";
                h.textContent = g;
                box.appendChild(h);
                lastGroup = g;
            }

            var row = document.createElement("div");
            row.className = "ek-keys-row";

            var name = document.createElement("span");
            name.className = "ek-keys-name";
            name.textContent = C.label(cmd);
            row.appendChild(name);

            var btn = document.createElement("button");
            btn.type = "button";
            btn.className = "ek-keys-btn";
            var combo = C.shortcutFor(cmd.id);
            btn.textContent = combo ? C.comboLabel(combo) : "—";
            if (combo && bad[combo]) { btn.classList.add("clash"); clash = true; }
            btn.addEventListener("click", (function (id, b) {
                return function () {
                    if (b.classList.contains("rec")) return;
                    b.classList.add("rec");
                    b.textContent = T("aa.keysPress");
                    C.record(function (combo2) {
                        b.classList.remove("rec");
                        if (combo2 === null) { renderShortcuts(); return; }   // Esc
                        C.setShortcut(id, combo2);
                        renderShortcuts();
                    });
                };
            })(cmd.id, btn));
            row.appendChild(btn);
            box.appendChild(row);
        }

        var warn = $("shortcutWarn");
        if (warn) {
            warn.hidden = !clash;
            warn.textContent = T("aa.keysClash");
        }
    }

    // ------------------------------------------------------------------
    // El panel enseña sus atajos
    // ------------------------------------------------------------------
    /* Cada botón que tenga comando detrás va aprendiendo a contarlo. La
       descripción del botón sigue diciendo lo mismo; detrás, y solo cuando la
       acción ya se ha usado varias veces, aparece el atajo. */
    /* Cada boton de esta ventana con una accion detras. La tabla sirve para dos
       cosas a la vez y por eso esta completa y no solo con los que tienen
       atajo: pone la descripcion —nombre y que hace— y cuenta los usos con el
       raton para saber cuando ensenar el atajo. */
    var COACH = [
        ['[data-interp="hold"]', "time.hold"], ['[data-interp="linear"]', "time.linear"],
        ['[data-interp="ease"]', "time.ease"],
        ['[data-interp="easeIn"]', "time.easeIn"], ['[data-interp="easeOut"]', "time.easeOut"],
        ['[data-shift="-1"]', "time.shiftBack"], ['[data-shift="1"]', "time.shiftFwd"],
        ['[data-scale="0.5"]', "time.scaleHalf"], ['[data-scale="2"]', "time.scaleDouble"],
        ["#scaleApplyBtn", "time.scaleApply"],
        ["#reverseKeysBtn", "time.reverse"], ["#reverseCopyBtn", "time.reverseCopy"],
        ['[data-order="reverse"]', "order.reverse"], ['[data-order="selection"]', "order.selection"],
        ['[data-order="name"]', "order.name"], ['[data-order="random"]', "order.random"],
        ['[data-order="inPoint"]', "order.inPoint"], ['[data-order="outPoint"]', "order.outPoint"],
        ['[data-goto="first"]', "time.gotoFirst"], ['[data-goto="prev"]', "time.gotoPrev"],
        ['[data-goto="next"]', "time.gotoNext"], ['[data-goto="last"]', "time.gotoLast"],
        ["#bakeBtn", "time.bake"],

        ["#parentNullBtn", "layer.parentNull"], ["#unparentBtn", "layer.unparent"],
        ["#adjustmentBtn", "layer.adjustment"], ["#solidBtn", "layer.solid"],
        ["#shapeBtn", "layer.shape"], ["#cameraBtn", "layer.camera"], ["#textBtn", "layer.text"],
        ["#freezeBtn", "time.freeze"],

        ['[data-expr="wiggle"]', "expr.wiggle"], ['[data-expr="loop"]', "expr.loop"],
        ['[data-expr="inertia"]', "expr.inertia"], ['[data-expr="autofade"]', "expr.autofade"],
        ['[data-expr="seed"]', "expr.seed"], ['[data-expr="follow"]', "expr.follow"],
        ["#exprClearBtn", "expr.clear"],

        ["#strokeApplyBtn", "text.stroke"],
        ['[data-split="line"]', "text.splitLine"], ['[data-split="word"]', "text.splitWord"],
        ['[data-split="char"]', "text.splitChar"], ["#boxCreateBtn", "text.box"],

        ["#fitCompBtn", "comp.fit"],
        ['[data-format="1080x1920"]', "comp.f916"], ['[data-format="1080x1080"]', "comp.f11"],
        ['[data-format="1920x1080"]', "comp.f169"], ['[data-format="1080x1350"]', "comp.f45"],
        ["#audioConsolidateBtn", "audio.consolidate"], ["#audioImportBtn", "audio.import"],
        ["#saveFrameBtn", "comp.saveFrame"], ["#queueBtn", "comp.queue"],
        ["#outFolderBtn", "comp.folder"], ["#extractBtn", "comp.extract"],
        ["#precomposeEachBtn", "comp.precompose"]
    ];

    /* La descripcion completa: el nombre de la accion y, detras, una linea de
       que hace. Las tres letras de un boton de la rejilla y las dos palabras de
       uno de la pestana dan para reconocer algo, no para entenderlo la primera
       vez, y esta ventana tiene cuarenta acciones.

       Se recalcula siempre y no se lee del atributo: al cambiar de idioma i18n
       reescribe el title entero, y guardarlo una vez dejaria la descripcion
       pegada a un texto que ya no esta. */
    function baseTitle(el, id) {
        var cmd = C.get(id);
        var name = cmd ? C.label(cmd) : "";
        var k = "aa.d." + id;
        var d = T(k);
        if (d === k) d = "";
        if (name && d) return name + " \u2014 " + d;
        if (name) return name;
        var key = el.getAttribute("data-i18n-title");
        return key ? T(key) : (el.getAttribute("data-base-title") || el.title || "");
    }

    function applyCoaching() {
        for (var i = 0; i < COACH.length; i++) {
            var el = document.querySelector(COACH[i][0]);
            if (!el) continue;
            // decorate le pega el atajo detras cuando ya se ha usado varias
            // veces con el raton; sin atajo, deja la descripcion tal cual.
            C.decorate(el, COACH[i][1], baseTitle(el, COACH[i][1]));
        }
    }

    // Contar el uso con el ratón: se envuelve el click de cada botón conocido.
    function countMouseUse() {
        for (var i = 0; i < COACH.length; i++) {
            (function (sel, id) {
                var el = document.querySelector(sel);
                if (!el) return;
                // Solo cuenta lo que sale del raton: quien ya usa el atajo no
                // necesita que se lo enseñen.
                el.addEventListener("click", function () {
                    C.bump(id);
                    applyCoaching();
                });
            })(COACH[i][0], COACH[i][1]);
        }
    }

    // ------------------------------------------------------------------
    // Arranque
    // ------------------------------------------------------------------
    function boot() {
        if (!C) return;
        wire();
        registerAll();
        renderShortcuts();
        applyCoaching();
        countMouseUse();

        var reset = $("resetShortcutsBtn");
        if (reset) {
            reset.addEventListener("click", function () {
                C.resetShortcuts();
                renderShortcuts();
                ok(T("aa.keysReset"));
            });
        }

        /* El interruptor de atajos gobierna el registro entero, en los tres
           paneles. Por eso se guarda en una clave propia y compartida y no
           dentro de los ajustes de ninguno: quien lo apaga aqui lo apaga para
           todo, y cada panel lo lee al arrancar sin preguntarle a los demas. */
        var en = $("shortcutsEnabledCheckbox");
        if (en) {
            var off = false;
            try { off = localStorage.getItem("editkit_shortcuts_off") === "1"; } catch (e3) {}
            en.checked = !off;
            en.addEventListener("change", function () {
                try { localStorage.setItem("editkit_shortcuts_off", en.checked ? "0" : "1"); } catch (e4) {}
                C.setEnabled(en.checked);
            });
            C.setEnabled(en.checked);
        }

        document.addEventListener("editkit-shortcuts-changed", applyCoaching);
        document.addEventListener("editkit-lang-changed", function () {
            renderShortcuts();
            applyCoaching();
        });
    }

    /* main.js dibuja la rejilla y necesita poder abrir el dialogo de icono.
       Se le presta el puente con el host y nada mas: el resto de este archivo
       sigue siendo suyo. */
    window.EditKitToolsHost = { call: call };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
})();
