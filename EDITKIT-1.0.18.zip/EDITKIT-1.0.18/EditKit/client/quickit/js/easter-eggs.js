/* ============================================================================
   QUICKIT — SECRETOS

   Tres, y los tres salen de lo que esta ventana es: una rejilla de botones que
   se pulsan y cinco categorias por las que se pasa. No hay ninguno colgado de
   algo que ejecute nada sobre la composicion; eso seria pedirle al usuario que
   repita diez veces una operacion sobre su proyecto para ver una broma.

      1. LA OLA        cinco toques en el nombre "QuickIt" y la rejilla se
                       enciende de arriba abajo, un boton detras de otro.
      2. INSISTENCIA   el mismo boton diez veces seguidas y el hueco del
                       subtitulo contesta.
      3. LA VUELTA     tres vueltas enteras a las categorias sin parar y el
                       hueco del subtitulo dice cuantas hay.

   Los dos ultimos escriben en el hueco que dejo el subtitulo al quitarlo de la
   cabecera. Estaba vacio y no hacia nada; ahora es el sitio donde esta ventana
   contesta cuando alguien se pasa de insistente.

   Nada de esto llama al host. Son clases CSS y un texto que se quita solo.
   ============================================================================ */
(function () {
    "use strict";

    var log = window.EditKitLog;

    var lang = "es";
    try { lang = localStorage.getItem("editkit_lang") || "es"; } catch (e) {}
    function isEn() { return lang === "en"; }

    // El idioma puede cambiar con el panel abierto.
    document.addEventListener("editkit-lang-changed", function () {
        try { lang = localStorage.getItem("editkit_lang") || "es"; } catch (e) {}
    });

    var sub = document.getElementById("qiSub");

    /* Una linea en el hueco del subtitulo, y se va sola. Si ya hay una puesta
       no se pisa: dos secretos a la vez es ruido, no premio. */
    var saying = false;
    function say(text, ms) {
        if (!sub || saying) return;
        saying = true;
        sub.textContent = text;
        setTimeout(function () {
            sub.style.opacity = "0";
            setTimeout(function () {
                sub.textContent = "";
                sub.style.opacity = "";
                saying = false;
            }, 220);
        }, ms || 2200);
    }

    // ------------------------------------------------------------------
    // 1. LA OLA
    // ------------------------------------------------------------------
    /* Cinco toques en el nombre. Va en el nombre y no en la rejilla porque los
       botones de la rejilla hacen cosas de verdad sobre las capas.

       La ola se dibuja sobre los botones que haya en ese momento: la rejilla la
       arma el usuario, asi que no puede haber una lista escrita a mano de por
       donde pasa. */
    var running = false;

    function wave() {
        if (running) return;
        var cells = document.querySelectorAll(".qi-grid .qi-btn-cell");
        if (!cells.length) return;
        running = true;
        if (log) log.found("m2");

        var list = Array.prototype.slice.call(cells);
        var step = 55;

        for (var i = 0; i < list.length; i++) {
            (function (el, n) {
                setTimeout(function () {
                    el.classList.add("egg-lit");
                    setTimeout(function () { el.classList.remove("egg-lit"); }, 260);
                }, n * step);
            })(list[i], i);
        }

        setTimeout(function () { running = false; }, list.length * step + 400);
    }

    (function () {
        var name = document.querySelector(".topbar .brand-name");
        if (!name) return;
        var taps = 0, last = 0;
        name.addEventListener("click", function () {
            // Cinco clics seguidos seleccionan el texto; se deshace, que si no
            // el nombre se queda azul despues de la broma.
            try {
                var s = window.getSelection();
                if (s && s.removeAllRanges) s.removeAllRanges();
            } catch (e) {}
            var now = Date.now();
            taps = (now - last < 600) ? taps + 1 : 1;
            last = now;
            if (taps < 5) return;
            taps = 0;
            wave();
        });
    })();

    // ------------------------------------------------------------------
    // 2. INSISTENCIA
    // ------------------------------------------------------------------
    /* Diez veces el mismo boton sin cambiar de boton y sin parar. Se cuenta en
       la fase de captura para no meterse en medio de lo que hace el boton: la
       accion se ejecuta igual, aqui solo se lleva la cuenta.

       El hueco vuelve a cero al cambiar de boton o al dejar pasar tres
       segundos: alguien aplicando una interpolacion a veinte capas de una en
       una esta trabajando, no insistiendo. */
    (function () {
        var grid = document.getElementById("qiGrid");
        if (!grid) return;

        var lastBtn = null, n = 0, when = 0;

        grid.addEventListener("click", function (e) {
            var el = e.target;
            while (el && el !== grid && !el.classList.contains("qi-btn-cell")) el = el.parentNode;
            if (!el || el === grid) return;

            var now = Date.now();
            if (el !== lastBtn || now - when > 3000) { lastBtn = el; n = 0; }
            when = now;
            n++;

            if (n < 10) return;
            n = 0;
            if (log) log.found("j5");
            say(isEn() ? "it knows that one by heart" : "esa se la sabe de memoria");
        }, true);
    })();

    // ------------------------------------------------------------------
    // 3. LA VUELTA
    // ------------------------------------------------------------------
    /* Tres vueltas enteras a las cinco categorias, en la misma direccion y sin
       parar. Quince pulsaciones de la misma flecha: nadie llega ahi buscando
       una categoria. */
    (function () {
        var LAPS = 3, CATS = 5;
        var dir = 0, n = 0, when = 0;

        document.addEventListener("click", function (e) {
            var el = e.target;
            while (el && el !== document.body && !el.getAttribute) el = el.parentNode;
            var d = null;
            while (el && el !== document.body) {
                d = el.getAttribute("data-qi-nav");
                if (d) break;
                el = el.parentNode;
            }
            if (!d) return;

            var now = Date.now();
            if (d !== dir || now - when > 1600) { dir = d; n = 0; }
            when = now;
            n++;

            if (n < LAPS * CATS) return;
            n = 0;
            if (log) log.found("f7");
            say(isEn() ? "there are only five" : "solo hay cinco");
        }, true);
    })();
})();
