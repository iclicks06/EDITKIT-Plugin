/* QUICKIT — ICONOS NATIVOS
   Un vocabulario vectorial pequeño y compartido. Los dibujos usan siempre el
   mismo lienzo, trazo y primitivas; main.js decide cuándo mostrarlos para no
   imponerse sobre imágenes o abreviaturas elegidas por el usuario. */
(function () {
    "use strict";

    var ICONS = {
        "time.hold": '<path d="M3 18h4V8h5v6h5V5h4"/><path d="M5 15.8 7.2 18 5 20.2M19 2.8 21.2 5 19 7.2"/>',
        "time.linear": '<path d="M4 18 20 6"/><path d="M4 15.7 6.3 18 4 20.3M20 3.7 22.3 6 20 8.3"/>',
        "time.ease": '<path d="M4 18c7 0 3-12 16-12"/><path d="M4 15.7 6.3 18 4 20.3M20 3.7 22.3 6 20 8.3"/>',
        "time.easeIn": '<path d="M4 18c9 0 6-12 16-12"/><path d="M4 15.7 6.3 18 4 20.3"/><path d="m17 4 3 2-3 2"/>',
        "time.easeOut": '<path d="M4 18c10 0 7-12 16-12"/><path d="m7 16-3 2 3 2"/><path d="M20 3.7 22.3 6 20 8.3"/>',
        "time.bake": '<path d="M3 6h5l2 5 2-5h4M9 18h12"/><path d="M13 15.8 15.2 18 13 20.2M19 15.8 21.2 18 19 20.2"/>',
        "time.scaleHalf": '<path d="M3 12h18M3 9v6M21 9v6"/><path d="m8 9 3 3-3 3m8-6-3 3 3 3"/>',
        "time.scaleDouble": '<path d="M3 12h18M3 9v6M21 9v6"/><path d="m10 9-3 3 3 3m4-6 3 3-3 3"/>',
        "time.gotoPrev": '<path d="M5 5v14m14-11-4 4 4 4M15 12H8"/><path d="M9 9.8 11.2 12 9 14.2"/>',
        "time.gotoNext": '<path d="M19 5v14M5 8l4 4-4 4m4-4h7"/><path d="M15 9.8 17.2 12 15 14.2"/>',
        "time.reverse": '<path d="M5 8h12l-3-3m3 3-3 3M19 16H7l3 3m-3-3 3-3"/><path d="M6 5.8 8.2 8 6 10.2M18 13.8 20.2 16 18 18.2"/>',
        "time.reverseCopy": '<path d="M4 8h10l-3-3m3 3-3 3M16 16H6l3 3m-3-3 3-3"/><path d="M5 5.8 7.2 8 5 10.2M15 13.8 17.2 16 15 18.2M20 5v6m-3-3h6"/>',
        "expr.wiggle": '<path d="M2.5 12c2.2-8 4.4 8 6.6 0s4.4 8 6.6 0 4.2 4 5.8 0"/>',
        "expr.loop": '<path d="M7 7h9a5 5 0 0 1 0 10H8"/><path d="m7 4-3 3 3 3m1 10-3-3 3-3"/>',
        "expr.inertia": '<path d="M4 6h7a7 7 0 0 1 7 7v1"/><circle cx="18" cy="17" r="2"/><path d="M8 9c2 0 4 1 5 3" opacity=".55"/>',
        "layer.parentNull": '<rect x="4" y="4" width="7" height="7" rx="1"/><path d="M7.5 2v11M2 7.5h11m-1 8.5h8v5h-8zM9 12l5 4"/>',
        "layer.unparent": '<path d="m8.5 14.5-2 2a3 3 0 0 1-4.2-4.2l3-3a3 3 0 0 1 4.2 0M15.5 9.5l2-2a3 3 0 1 1 4.2 4.2l-3 3a3 3 0 0 1-4.2 0M4 4l16 16"/>',
        "comp.precompose": '<rect x="4" y="5" width="10" height="8" rx="1"/><rect x="7" y="8" width="10" height="8" rx="1"/><path d="M12 20h8V12m0 0-3 3m3-3-3-3"/>',
        "comp.extract": '<rect x="7" y="6" width="10" height="12" rx="1"/><path d="M9 10 3 4m0 0v5m0-5h5M15 14l6 6m0 0v-5m0 5h-5"/>',
        "layer.adjustment": '<rect x="4" y="5" width="16" height="6" rx="1"/><rect x="4" y="14" width="16" height="5" rx="1"/><path d="M12 5a3 3 0 0 0 0 6 3 3 0 0 0 0-6Z"/>',
        "layer.solid": '<rect x="4" y="4" width="16" height="16" rx="2" fill="currentColor" stroke="none"/><path d="M7 17 17 7" stroke="var(--qi-icon-cut,#111)" opacity=".35"/>',
        "layer.shape": '<rect x="3.5" y="4" width="8" height="8" rx="1"/><circle cx="16.5" cy="15.5" r="4"/>',
        "layer.text": '<rect x="3.5" y="4" width="17" height="16" rx="1"/><path d="M7 8h10M12 8v9M9 17h6"/>',
        "layer.camera": '<path d="M4 8h11v9H4zM15 11l5-3v9l-5-3z"/><circle cx="9.5" cy="12.5" r="2.2"/>',
        "time.freeze": '<path d="M12 2v20M4 6l16 12M20 6 4 18M9 4l3 2 3-2M9 20l3-2 3 2M3 10l3 2-3 2M21 10l-3 2 3 2"/>',
        "order.reverse": '<path d="M6 5h12M6 12h12M6 19h12M3 7V3m0 0L1 5m2-2 2 2M21 17v4m0 0-2-2m2 2 2-2"/>',
        "order.selection": '<path d="M8 5h12M8 12h12M8 19h12"/><circle cx="3.5" cy="5" r="1.5"/><circle cx="3.5" cy="12" r="1.5"/><circle cx="3.5" cy="19" r="1.5"/>',
        "order.name": '<path d="M10 6h11M10 12h8M10 18h5M3 18 6 6l3 12M4.2 14h3.6"/>',
        "order.random": '<path d="M3 7h3c5 0 5 10 10 10h5M18 14l3 3-3 3M3 17h3c2.2 0 3.5-2 4.8-4M14 8c.7-.6 1.3-1 2.2-1H21m-3-3 3 3-3 3"/>',
        "order.inPoint": '<path d="M4 6h16M7 11h13M10 16h10M13 21h7M4 3v6"/>',
        "order.outPoint": '<path d="M4 6h16M4 11h13M4 16h10M4 21h7M20 3v6"/>',
        "comp.deepClone": '<rect x="3" y="6" width="13" height="12" rx="1"/><rect x="7" y="3" width="13" height="12" rx="1"/><path d="M18 17v6m-3-3h6"/>',
        "comp.f916": '<rect x="8" y="2.5" width="8" height="19" rx="1"/><path d="M10 6h4M10 18h4"/>',
        "comp.f11": '<rect x="4" y="4" width="16" height="16" rx="1"/><path d="M8 8h8v8H8z" opacity=".55"/>',
        "comp.f169": '<rect x="2.5" y="7" width="19" height="10" rx="1"/><path d="M6 10h12M6 14h12"/>',
        "comp.f45": '<rect x="7" y="3" width="10" height="18" rx="1"/><path d="M9.5 8h5M9.5 16h5"/>',
        "comp.organizeProject": '<path d="M3 6h7l2 2h9v11H3z"/><path d="M7 11h3v2H7zm7 0h3v2h-3zm-7 4h3v2H7zm7 0h3v2h-3z"/>',
        "layer.autoParallax": '<path d="m3 16 7-4 7 4-7 4zM7 10l7-4 7 4-7 4z"/><circle cx="4" cy="5" r="2"/><path d="M5.5 6.5 8 9"/>',
        "time.capturePasteFit": '<path d="M7 4h10v3h3v14H4V7h3zM9 4a3 3 0 0 1 6 0"/><path d="M7 15h10M7 12l2 3-2 3m10-6-2 3 2 3"/>',
        "time.pasteFit": '<path d="M7 4h10v3h3v14H4V7h3zM9 4a3 3 0 0 1 6 0"/><path d="M8 15h8m-5-3-3 3 3 3m2-6 3 3-3 3"/>',
        "audio.consolidate": '<path d="M3 7v4m3-7v10m3-6v4m3-8v10m3-6v4"/><path d="M4 18h12m0 0-3-3m3 3-3 3M20 14v8"/>',
        "audio.import": '<path d="M3 8v8m4-11v14m4-9v4m4-7v10"/><path d="M20 3v12m-4-4 4 4 4-4M17 21h6"/>'
    };

    function markup(id) {
        var inner = ICONS[id];
        if (!inner) return "";
        return '<svg class="qi-native-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + inner + '</svg>';
    }

    window.EditKitQuickIcons = { markup: markup };
}());
