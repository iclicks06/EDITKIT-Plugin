/* ============================================================================
   EDITKIT — ARRASTRAR UN PLUGIN A OTRO SITIO (lado del panel)

   Los tres plugins viven en <iframe>. Un iframe se traga sus propios eventos de
   raton, asi que el shell —que es quien puede mover las ventanas— no ve nada de
   lo que pasa dentro. Este archivo es la mitad de dentro: mira si el usuario
   agarra la cabecera y empieza a arrastrar, y le va contando al shell donde
   esta el cursor. Mover, decidir el sitio y guardarlo es cosa de alla.

   Por que la cabecera y no toda la ventana: es la unica banda que no hace nada
   al pulsarla, en los tres. Cualquier otra cosa es un boton, un campo o un
   lienzo, y agarrar uno de esos para mover la ventana seria pisarlos.

   No toca nada mas: sin estilos, sin globales, y nada de lo que escucha
   impide que los manejadores del propio panel vean sus eventos.
   ============================================================================ */
(function () {
    "use strict";

    if (window.parent === window) return;   // suelto, no hay a quien contarle

    var TAG = "pane";
    var THRESHOLD = 4;      // px antes de dar el gesto por arrastre

    // Quien soy. La misma cuenta que hace la centralita de comandos.
    var PANEL = (function () {
        if (window.EDITKIT_PANEL) return window.EDITKIT_PANEL;
        var p = String(location.pathname || "");
        if (p.indexOf("easeit") >= 0) return "easeit";
        if (p.indexOf("alignit") >= 0) return "alignit";
        if (p.indexOf("quickit") >= 0) return "quickit";
        return "shell";
    })();

    function send(msg) {
        msg.__editkit = TAG;
        msg.panel = PANEL;
        try { window.parent.postMessage(msg, "*"); } catch (e) {}
    }

    var down = null;        // {x, y} donde se pulso
    var dragging = false;

    function headerOf(el) {
        while (el && el !== document.body) {
            if (el.classList &&
                (el.classList.contains("topbar") || el.id === "header")) return el;
            el = el.parentNode;
        }
        return null;
    }

    /* Un boton dentro de la cabecera no arranca el arrastre. Sin esto, pulsar
       el engranaje y mover un pixel sin querer se lleva la ventana de sitio en
       lugar de abrir los ajustes. */
    function onControl(el) {
        while (el && el !== document.body) {
            var t = el.tagName;
            if (t === "BUTTON" || t === "INPUT" || t === "SELECT" || t === "TEXTAREA" || t === "A") return true;
            if (el.classList && (el.classList.contains("help-btn") ||
                el.classList.contains("size-switch") ||
                el.classList.contains("topbar-gear"))) return true;
            el = el.parentNode;
        }
        return false;
    }

    document.addEventListener("mousedown", function (e) {
        if (e.button !== 0) return;
        if (!headerOf(e.target) || onControl(e.target)) return;
        down = { x: e.clientX, y: e.clientY };
    }, true);

    document.addEventListener("mousemove", function (e) {
        if (!down) return;
        if (!dragging) {
            // Un umbral, no un clic: la cabecera tambien se puede pulsar sin
            // querer mover nada, y hay un secreto colgado de eso.
            if (Math.abs(e.clientX - down.x) < THRESHOLD &&
                Math.abs(e.clientY - down.y) < THRESHOLD) return;
            dragging = true;
            send({ type: "start" });
        }
        send({ type: "move", x: e.clientX, y: e.clientY });
    }, true);

    function end() {
        if (dragging) send({ type: "end" });
        down = null;
        dragging = false;
    }

    document.addEventListener("mouseup", end, true);
    window.addEventListener("blur", end);

    // El cursor puede salir del iframe y seguir moviendose por el shell. Alla
    // se recoge el resto del gesto; aqui solo hay que dejar de estorbar.
    document.addEventListener("mouseleave", function () {
        if (dragging) send({ type: "out" });
    });
})();
