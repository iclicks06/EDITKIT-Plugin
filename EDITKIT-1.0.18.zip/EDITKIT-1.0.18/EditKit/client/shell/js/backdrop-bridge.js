/* ============================================================================
   EDITKIT — BACKDROP BRIDGE (loaded by all three panes, not by the shell)

   The animated backdrop is drawn once in the shell document, behind both
   iframes. An iframe swallows its own mouse events though, so without this
   the aura would go still the moment the cursor crossed into either tool —
   which is most of the panel. This forwards pointer position and clicks up to
   the shell, and takes the veil strength back down.

   It touches nothing else in the page: no globals, no styles beyond one CSS
   variable on <html>, no listeners that stop events reaching the app.
   ============================================================================ */
(function () {
    "use strict";

    if (window.parent === window) return; // running standalone, nothing to talk to

    var TAG = "bd";
    var last = 0;
    var THROTTLE = 33; // ~30/s, matching the backdrop's own frame budget

    function send(msg) {
        msg.__editkit = TAG;
        try { window.parent.postMessage(msg, "*"); } catch (e) {}
    }

    // Capture phase and never preventDefault: these are observers, the app's
    // own handlers still see every event exactly as before.
    window.addEventListener("mousemove", function (e) {
        var now = Date.now();
        if (now - last < THROTTLE) return;
        last = now;
        send({ type: "pointer", x: e.clientX, y: e.clientY });
    }, true);

    window.addEventListener("mousedown", function (e) {
        send({ type: "click", x: e.clientX, y: e.clientY });
    }, true);

    document.addEventListener("mouseleave", function () {
        send({ type: "leave" });
    });

    // The veil each pane lays over the shared backdrop, so its own text keeps
    // its contrast. Set as a variable on <html> and consumed by the
    // "backdrop integration" rule at the bottom of each pane's stylesheet.
    window.addEventListener("message", function (e) {
        var d = e.data;
        if (!d || d.__editkit !== "bd-style") return;
        if (typeof d.scrim === "number") {
            document.documentElement.style.setProperty("--bd-scrim", String(d.scrim));
        }
    });

    // The shell can't know when we finished loading, so we tell it — it
    // replies with the current veil value.
    send({ type: "ready" });
    window.addEventListener("load", function () { send({ type: "ready" }); });
})();
