/* ============================================================================
   EDITKIT — BITÁCORA

   Un contador diminuto y local: cuántas veces se abrió el panel, cuántas
   curvas se aplicaron, cuántas alineaciones y herramientas se usaron, desde
   qué día y cuántos días seguidos. Nada de esto sale del equipo, y no se
   muestra en ninguna parte hasta que alguien encuentra el secreto que lo abre
   (siete toques sobre el número de versión, en Ajustes > Acerca de).

   Existe por una razón sola: darle algo que mirar a quien use el panel todos
   los días. No se envía, no se comparte y se borra entero desde la propia
   bitácora.

   Lo cargan las tres superficies porque las tres suman cosas distintas. El
   contador de sesiones lo lleva solo el shell: los <iframe> se recargan por su
   cuenta y contarían de más.

   ── DÓNDE VIVE ─────────────────────────────────────────────────────────────
   En dos sitios, y por una razón concreta. El almacenamiento del panel es
   rápido y lo comparten las tres superficies, pero se va con la extensión:
   desinstalar y volver a instalar dejaba la cuenta a cero, y eso convierte
   "300 días con EditKit" en un número que no se puede mirar con cariño.

   Así que hay además una copia en la carpeta de datos del usuario, fuera de
   la extensión, que sobrevive a desinstalar, a actualizar y a mover el
   paquete de sitio. Al arrancar se funden las dos: se queda la fecha más
   antigua, el contador más alto y la unión de los secretos encontrados. El
   archivo lo escribe solo el shell, para que tres superficies no se pisen.
   Sigue sin salir del equipo: es un archivo de texto en el perfil, y se borra
   desde el mismo botón que borra el resto.
   ============================================================================ */
(function () {
    "use strict";

    var KEY = "editkit_log";
    var EGGS_KEY = "editkit_eggs";
    var COUNTERS = ["sessions", "curves", "aligns", "tools"];

    function today() {
        var d = new Date();
        function two(n) { return n < 10 ? "0" + n : String(n); }
        return d.getFullYear() + "-" + two(d.getMonth() + 1) + "-" + two(d.getDate());
    }

    function daysBetween(a, b) {
        // Fechas "YYYY-MM-DD" a mediodía UTC: así ningún cambio de horario de
        // verano puede convertir un día en 23 horas y romper la racha.
        function at(s) {
            var p = String(s).split("-");
            return Date.UTC(+p[0], +p[1] - 1, +p[2], 12);
        }
        return Math.round((at(b) - at(a)) / 86400000);
    }

    function blank() {
        return {
            v: 2, first: today(), last: today(),
            sessions: 0, curves: 0, aligns: 0, tools: 0,
            streak: 1, best: 1
        };
    }

    function read() {
        try {
            var raw = localStorage.getItem(KEY);
            if (!raw) return blank();
            var o = JSON.parse(raw);
            if (!o || typeof o !== "object") return blank();
            var b = blank();
            for (var k in b) if (typeof o[k] !== typeof b[k]) o[k] = b[k];
            return o;
        } catch (e) { return blank(); }
    }

    function write(o) {
        try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {}
        schedulePush();
    }

    function bump(field, by) {
        var o = read();
        if (typeof o[field] !== "number") return;
        o[field] += (by === undefined ? 1 : by);
        write(o);
    }

    /* Una sesión por carga del shell. Aprovecha para mover la racha: mismo día
       no cuenta, el día siguiente la alarga, y cualquier hueco la reinicia. */
    function startSession() {
        var o = read();
        var t = today();
        var gap = daysBetween(o.last, t);
        if (gap === 1) o.streak += 1;
        else if (gap > 1 || gap < 0) o.streak = 1;
        if (o.streak > o.best) o.best = o.streak;
        o.last = t;
        o.sessions += 1;
        write(o);
    }

    function reset() {
        try { localStorage.removeItem(KEY); localStorage.removeItem(EGGS_KEY); } catch (e) {}
        // Y la copia de fuera: si no, la siguiente carga la resucitaría entera
        // y el botón de borrar sería mentira.
        host("editkit_logErase()", null);
    }

    // ---- registro de secretos encontrados ----------------------------------
    /* Se guarda aparte del resto para que borrar la bitácora borre también el
       tablero de secretos: si alguien quiere volver a buscarlos, los quiere
       buscar de verdad. */
    function eggs() {
        try {
            var o = JSON.parse(localStorage.getItem(EGGS_KEY) || "{}");
            return (o && typeof o === "object") ? o : {};
        } catch (e) { return {}; }
    }

    function found(id) {
        try {
            var o = eggs();
            if (o[id]) return false;          // ya estaba: no es un hallazgo nuevo
            o[id] = today();
            localStorage.setItem(EGGS_KEY, JSON.stringify(o));
            schedulePush();
            return true;
        } catch (e) { return false; }
    }

    // ------------------------------------------------------------------
    // La copia de fuera
    // ------------------------------------------------------------------
    var IS_SHELL = (function () {
        try { return window.parent === window; } catch (e) { return false; }
    })();

    var cs = null;
    function host(script, done) {
        if (!IS_SHELL) return;
        try {
            if (!cs) {
                if (!window.CSInterface) return;
                cs = new CSInterface();
            }
            cs.evalScript(script, function (raw) {
                if (!done) return;
                var r = null;
                try { r = JSON.parse(raw); } catch (e) { r = null; }
                done(r);
            });
        } catch (e2) {}
    }

    function merge(mine, theirs) {
        if (!theirs || typeof theirs !== "object") return mine;
        var out = mine, i, f;

        // La fecha de inicio es la más antigua de las dos: es el dato que
        // convierte la bitácora en algo que mirar, y el que más duele perder.
        if (theirs.first && theirs.first < out.first) out.first = theirs.first;
        if (theirs.last && theirs.last > out.last) out.last = theirs.last;

        for (i = 0; i < COUNTERS.length; i++) {
            f = COUNTERS[i];
            if (typeof theirs[f] === "number" && theirs[f] > out[f]) out[f] = theirs[f];
        }
        if (typeof theirs.best === "number" && theirs.best > out.best) out.best = theirs.best;

        /* La racha no se funde por el mayor: es un dato derivado de `last`, y
           quedarse con la más alta de las dos daría por buenos días que no se
           abrió el panel. Se recalcula. */
        var gap = daysBetween(out.last, today());
        if (gap > 1 || gap < 0) out.streak = 1;
        if (out.streak > out.best) out.best = out.streak;
        return out;
    }

    function mergeEggs(theirs) {
        if (!theirs || typeof theirs !== "object") return;
        var mine = eggs(), changed = false;
        for (var k in theirs) {
            if (!theirs.hasOwnProperty(k)) continue;
            if (!mine[k] || theirs[k] < mine[k]) { mine[k] = theirs[k]; changed = true; }
        }
        if (changed) {
            try { localStorage.setItem(EGGS_KEY, JSON.stringify(mine)); } catch (e) {}
        }
    }

    var pushTimer = null, ready = false;

    function schedulePush() {
        if (!IS_SHELL || !ready) return;
        if (pushTimer) clearTimeout(pushTimer);
        // Con un respiro: aplicar veinte curvas seguidas no debe escribir
        // veinte veces en el disco.
        pushTimer = setTimeout(push, 4000);
    }

    function push() {
        pushTimer = null;
        if (!IS_SHELL || !ready) return;
        var payload = { log: read(), eggs: eggs() };
        var s = JSON.stringify(payload);
        host("editkit_logWrite(" + JSON.stringify(s) + ")", null);
    }

    function pull() {
        host("editkit_logRead()", function (r) {
            if (r && r.ok && r.data) {
                var parsed = null;
                try { parsed = JSON.parse(r.data); } catch (e) { parsed = null; }
                if (parsed) {
                    var merged = merge(read(), parsed.log || parsed);
                    try { localStorage.setItem(KEY, JSON.stringify(merged)); } catch (e2) {}
                    mergeEggs(parsed.eggs);
                }
            }
            // A partir de aquí ya se puede escribir: antes de fundir, guardar
            // machacaría el archivo con lo poco que hubiera en local.
            ready = true;
            push();
            try {
                document.dispatchEvent(new CustomEvent("editkit-log-synced"));
            } catch (e3) {}
        });
    }

    if (IS_SHELL) {
        // CSInterface se carga después que este archivo, así que la primera
        // lectura espera a que la página esté entera.
        if (document.readyState === "complete") setTimeout(pull, 200);
        else window.addEventListener("load", function () { setTimeout(pull, 200); });

        // Y un último volcado al cerrar, para no perder la última sesión.
        window.addEventListener("beforeunload", function () {
            if (pushTimer) { clearTimeout(pushTimer); pushTimer = null; }
            push();
        });
    }

    window.EditKitLog = {
        read: read,
        bump: bump,
        startSession: startSession,
        reset: reset,
        eggs: eggs,
        found: found,
        daysBetween: daysBetween,
        today: today,
        sync: pull
    };
})();
