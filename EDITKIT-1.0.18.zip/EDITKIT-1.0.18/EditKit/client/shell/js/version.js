/* ============================================================================
   EDITKIT — LA VERSION, LEIDA DE UN SOLO SITIO

   Antes esta linea era un numero escrito a mano, y para que "Acerca de" y el
   menu del panel dijeran la verdad habia que acordarse de cambiarlo aqui cada
   vez que se cambiaba en CSXS/manifest.xml — que es lo unico que After
   Effects lee de verdad para saber que version esta instalando. Dos sitios
   que tienen que decir lo mismo y nada que los revise es como se desincroniza
   un numero sin que nadie se de cuenta.

   Asi que ahora esto LEE manifest.xml, con la misma capa de disco de siempre
   (cep.fs, con cep_node de respaldo), en vez de repetirlo. Si por lo que sea
   no se puede leer —fuera de After Effects, por ejemplo, mirando el panel en
   un navegador— se queda con el numero de mas abajo, que hay que mantener
   igual al de manifest.xml a mano solo para ese caso.

   Va primero en la pagina, antes de CSInterface.js: no lo necesita, habla con
   el puente igual que persist.js.
   ============================================================================ */
window.EditKitVersion = "1.0.18";   // respaldo: solo se usa si no se pudo leer manifest.xml

(function () {
    "use strict";

    function bridge() {
        try { return window.__adobe_cep__ || window.top.__adobe_cep__; } catch (e) { return null; }
    }
    function cepFs() {
        try { if (window.cep && window.cep.fs && window.cep.fs.readFile) return window.cep.fs; } catch (e) {}
        try { if (window.top.cep && window.top.cep.fs && window.top.cep.fs.readFile) return window.top.cep.fs; } catch (e2) {}
        return null;
    }

    // Lo mismo que hace CSInterface.getSystemPath("extension"), que aun no
    // esta cargado: la carpeta donde vive esta misma extension, sea cual sea
    // —el modo desarrollador la deja en cualquier sitio—.
    function extensionRoot() {
        var b = bridge();
        if (!b || !b.getSystemPath) return "";
        var p = "";
        try { p = decodeURI(b.getSystemPath("extension")) || ""; } catch (e) { return ""; }
        p = /^Win/i.test(navigator.platform) ? p.replace("file:///", "") : p.replace("file://", "");
        return p;
    }

    try {
        var root = extensionRoot();
        var fs = cepFs();
        if (root && fs) {
            var r = fs.readFile(root + "/CSXS/manifest.xml");
            if (r && r.err === 0 && r.data) {
                var m = /ExtensionBundleVersion="([^"]+)"/.exec(r.data);
                if (m && m[1]) window.EditKitVersion = m[1];
            }
        }
    } catch (e) {}
})();
