(function () {
    "use strict";

    var mounted = [];
    var LEAVES = "label,button,h4,p,.qi-sec-title,.micro-label,.bd-label,.settings-hint-text,.easeit-order-label,.ek-keys-row";
    var BLOCKS = ".set-field,.setting-item,.qi-field,.qi-check,.toggle,.accent-row,.easeit-order-row,.community-card,.surface-color-field,.bd-slider-head,.bd-hint,.qi-hint,.qi-sec-title,.micro-label,.settings-hint-text,.settings-footer,.qi-sheet-actions,.section-list,.prof-toolbar,.prof-list,.thm-row,.surface-media-mount";

    function normal(value) {
        value = String(value || "").toLowerCase();
        try { return value.normalize("NFD").replace(/[\u0300-\u036f]/g, ""); } catch (e) { return value; }
    }

    function config(root) {
        if (!root) return null;
        if (root.classList.contains("bd-sheet")) return {
            nav: root.querySelector(".set-tabs"), panes: root.querySelectorAll("[data-set-pane]"),
            paneAttr: "data-set-pane", tabAttr: "data-pane", tabSelector: ".set-tab",
            body: root.querySelector(".bd-sheet-body")
        };
        if (root.classList.contains("qi-sheet")) return {
            nav: root.querySelector(".qi-sheet-tabs"), panes: root.querySelectorAll("[data-sheet-content]"),
            paneAttr: "data-sheet-content", tabAttr: "data-sheet-pane", tabSelector: ".qi-sheet-tab",
            body: root.querySelector(".qi-sheet-body")
        };
        return {
            nav: root.querySelector(".settings-nav"), panes: root.querySelectorAll("[data-settings-content]"),
            paneAttr: "data-settings-content", tabAttr: "data-settings-panel", tabSelector: ".settings-nav-btn",
            body: root.querySelector(".ek-sheet-body")
        };
    }

    function mount(root) {
        if (!root || root.getAttribute("data-ek-search-mounted") === "1") return;
        var cfg = config(root);
        if (!cfg || !cfg.nav || !cfg.body || !cfg.panes.length) return;
        root.setAttribute("data-ek-search-mounted", "1");

        var lang = "es";
        try { lang = localStorage.getItem("editkit_lang") === "en" ? "en" : "es"; } catch (e) {}
        var wrap = document.createElement("div");
        wrap.className = "ek-settings-search";
        wrap.innerHTML = '<svg viewBox="0 -960 960 960" fill="currentColor" aria-hidden="true"><path d="M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z"/></svg>';
        var input = document.createElement("input");
        input.type = "search";
        input.autocomplete = "off";
        input.spellcheck = false;
        input.placeholder = lang === "en" ? "Search settings…" : "Buscar ajustes…";
        input.setAttribute("aria-label", input.placeholder);
        var clear = document.createElement("button");
        clear.type = "button";
        clear.className = "ek-settings-search-clear";
        clear.textContent = "×";
        clear.title = lang === "en" ? "Clear search" : "Borrar búsqueda";
        wrap.appendChild(input);
        wrap.appendChild(clear);

        var empty = document.createElement("span");
        empty.className = "ek-settings-search-empty";
        empty.textContent = lang === "en" ? "No matching settings" : "No hay ajustes que coincidan";
        empty.hidden = true;

        cfg.nav.parentNode.insertBefore(wrap, cfg.nav.nextSibling);
        wrap.parentNode.insertBefore(empty, wrap.nextSibling);

        var previousTab = null, results = [], cursor = -1;
        function tabs() { return cfg.nav.querySelectorAll(cfg.tabSelector); }
        function tabFor(name) {
            var list = tabs();
            for (var i = 0; i < list.length; i++) if (list[i].getAttribute(cfg.tabAttr) === name) return list[i];
            return null;
        }
        function activeTab() {
            var list = tabs();
            for (var i = 0; i < list.length; i++) if (list[i].classList.contains("active")) return list[i];
            return list[0] || null;
        }
        function clearMarks() {
            var marked = root.querySelectorAll(".ek-search-match");
            for (var i = 0; i < marked.length; i++) marked[i].classList.remove("ek-search-match");
            var list = tabs();
            for (var j = 0; j < list.length; j++) {
                list[j].classList.remove("ek-search-tab-hit");
                list[j].removeAttribute("data-ek-search-count");
            }
        }
        function reveal(result) {
            if (!result) return;
            var tab = tabFor(result.pane.getAttribute(cfg.paneAttr));
            if (tab && !tab.classList.contains("active")) tab.click();
            setTimeout(function () {
                try { result.block.scrollIntoView({ block: "center", behavior: "smooth" }); }
                catch (e) { cfg.body.scrollTop = Math.max(0, result.block.offsetTop - 18); }
            }, 0);
        }
        function search() {
            clearMarks();
            results = []; cursor = -1;
            var query = normal(input.value).replace(/^\s+|\s+$/g, "");
            wrap.classList.toggle("has-query", !!query);
            if (!query) {
                empty.hidden = true;
                if (previousTab) { previousTab.click(); previousTab = null; }
                return;
            }
            if (!previousTab) previousTab = activeTab();
            for (var p = 0; p < cfg.panes.length; p++) {
                var pane = cfg.panes[p], leaves = pane.querySelectorAll(LEAVES), seen = [], count = 0;
                for (var i = 0; i < leaves.length; i++) {
                    if (normal(leaves[i].textContent).indexOf(query) < 0) continue;
                    var block = leaves[i].closest ? leaves[i].closest(BLOCKS) : null;
                    block = block || leaves[i];
                    if (seen.indexOf(block) >= 0) continue;
                    seen.push(block); count++;
                    block.classList.add("ek-search-match");
                    results.push({ pane: pane, block: block });
                }
                if (count) {
                    var tab = tabFor(pane.getAttribute(cfg.paneAttr));
                    if (tab) {
                        tab.classList.add("ek-search-tab-hit");
                        tab.setAttribute("data-ek-search-count", String(count));
                    }
                }
            }
            empty.hidden = results.length !== 0;
            var current = activeTab(), currentName = current && current.getAttribute(cfg.tabAttr);
            var currentHas = false;
            for (var r = 0; r < results.length; r++) {
                if (results[r].pane.getAttribute(cfg.paneAttr) === currentName) { currentHas = true; cursor = r; break; }
            }
            if (!currentHas && results.length) { cursor = 0; reveal(results[0]); }
        }
        input.addEventListener("input", search);
        input.addEventListener("keydown", function (event) {
            if (event.key === "Escape") { input.value = ""; search(); input.blur(); return; }
            if (event.key !== "Enter" || !results.length) return;
            event.preventDefault();
            cursor = (cursor + 1) % results.length;
            reveal(results[cursor]);
        });
        clear.addEventListener("click", function () { input.value = ""; search(); input.focus(); });
        mounted.push({ root: root, input: input });
    }

    function boot() {
        var roots = document.querySelectorAll(".bd-sheet,.qi-sheet,.aa-sheet");
        for (var i = 0; i < roots.length; i++) mount(roots[i]);
    }
    window.EditKitSettingsSearch = { mount: mount, boot: boot };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
    else boot();
})();
