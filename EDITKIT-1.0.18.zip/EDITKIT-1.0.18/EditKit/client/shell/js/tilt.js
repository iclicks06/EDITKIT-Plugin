/* ============================================================================
   EDITKIT — INCLINACION (el mismo relieve de Temas, en otras tarjetas)

   El efecto de shell/js/themes.js sobre las cartas de tema se replica aqui
   para dos sitios mas que son, en el fondo, lo mismo: una tarjeta pequena que
   se elige mirandola, no un boton de accion.

     · EaseIt   — los presets de la cuadricula (.preset-tile, entera).
     · QuickIt  — los estilos guardados del menu de un boton (.qi-style).
     · AlignIt  — los nueve botones del recuadro (.btn-align), en los dos
       modos que comparten esa misma rejilla: Alinear y Anchor.

   No hace falta enganchar cada cuadricula por separado ni volver a hacerlo
   cuando se redibujan: el mismo truco de themes.js, un solo oyente que
   delega, pero aqui a nivel de documento —el de EaseIt o el de QuickIt, cada
   uno en su propio iframe, nunca el de los otros dos— porque los estilos de
   QuickIt viven dentro de un menu flotante que se crea y se destruye cada vez
   que se abre, y delegar mas arriba es la unica forma de no perderlo.

   Los botones normales, las filas de ajustes y las listas no llevan esto:
   ahi el gesto es pulsar una accion, no elegir mirando una miniatura, y el
   relieve se sentiria decorativo y no funcional.
   ============================================================================ */
(function () {
    "use strict";

    var still = false;
    try { still = window.matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) {}
    if (still) return;

    /* Un grupo por tipo de tarjeta: donde esta (tile), que parte gira (face,
       o la propia tarjeta si no se da) y cuanto —una cuadricula de presets
       mide el doble que un chip de estilos, y girar los dos igual de fuerte
       dejaria el chip temblando. */
    var GROUPS = [
        { tile: ".preset-tile", face: null, maxTilt: 6 },
        { tile: ".qi-style", face: null, maxTilt: 4 },
        { tile: ".btn-align", face: null, maxTilt: 5 }
    ];

    var VARS = ["--tilt-x", "--tilt-y", "--tilt-light-x", "--tilt-light-y"];

    function is(node, sel) {
        var m = node.matches || node.msMatchesSelector || node.webkitMatchesSelector;
        return m ? m.call(node, sel) : false;
    }

    function findTile(node) {
        while (node && node.nodeType === 1) {
            for (var i = 0; i < GROUPS.length; i++) {
                if (is(node, GROUPS[i].tile)) return { tile: node, def: GROUPS[i] };
            }
            node = node.parentNode;
        }
        return null;
    }

    function clamp(v) { return v < -1 ? -1 : (v > 1 ? 1 : v); }

    var hot = null, pend = null, frame = 0;

    function paint() {
        frame = 0;
        if (!pend) return;
        var face = pend.face, nx = pend.nx, ny = pend.ny, mt = pend.maxTilt;
        pend = null;
        face.style.setProperty("--tilt-x", (-ny * mt).toFixed(2) + "deg");
        face.style.setProperty("--tilt-y", (nx * mt).toFixed(2) + "deg");
        face.style.setProperty("--tilt-light-x", (50 + nx * 45).toFixed(1) + "%");
        face.style.setProperty("--tilt-light-y", (50 + ny * 45).toFixed(1) + "%");
    }

    function ask() {
        if (frame) return;
        if (window.requestAnimationFrame) frame = window.requestAnimationFrame(paint);
        else paint();
    }

    function cool() {
        if (!hot) return;
        var face = hot.face;
        hot = null;
        pend = null;
        face.classList.remove("tilt-tracking");
        for (var i = 0; i < VARS.length; i++) face.style.removeProperty(VARS[i]);
    }

    function track(ev) {
        var awake = window.EditKitAwake;
        if (awake && (awake.idle() || awake.performance())) { cool(); return; }
        var found = findTile(ev.target);
        if (!found) { cool(); return; }
        var face = found.def.face ? found.tile.querySelector(found.def.face) : found.tile;
        if (!face) { cool(); return; }
        if (!hot || hot.face !== face) {
            cool();
            hot = { face: face };
            face.classList.add("tilt-tracking");
        }
        var r = found.tile.getBoundingClientRect();
        if (!r.width || !r.height) return;
        var nx = clamp(((ev.clientX - r.left) / r.width) * 2 - 1);
        var ny = clamp(((ev.clientY - r.top) / r.height) * 2 - 1);
        pend = { face: face, nx: nx, ny: ny, maxTilt: found.def.maxTilt };
        ask();
    }

    // Solo cuenta salir del documento entero, no pasar de una tarjeta a otra
    // —eso ya lo resuelve `track` al ver que `hot.face` cambio—.
    function onOut(ev) { if (!ev.relatedTarget) cool(); }

    document.addEventListener("mousemove", track);
    document.addEventListener("mouseout", onOut);
})();
