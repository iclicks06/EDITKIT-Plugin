/* ============================================================================
   EDITKIT — ACCENT BRIDGE (loaded by the shell and by both panes)

   One accent colour for the whole plugin. Whoever changes it — EaseIt's panel
   settings, EaseIt's own flyout picker, or AlignIt's Appearance tab —
   hands it to this file, which persists it, gives it to every surface that
   registered a painter, and relays it across the iframe boundary so the shell
   chrome and the other tool repaint at the same moment instead of waiting for
   a reload.

   Shape: the shell is the hub. A pane posts changes up to it; the shell paints
   its own chrome and fans the colour back down to the other pane. Four rules
   keep that from ever ringing, in this order of importance:

     1. a colour is never posted back to the window it came from — in both
        directions, so the message graph has no cycle at all;
     2. a change asked for from inside a repaint is dropped, not queued — that
        can only be feedback from the repaint itself;
     3. applications are paced (60ms), so a colour drag repaints at a sane rate
        instead of rebuilding every preset thumbnail per pixel;
     4. and if changes ever arrive faster than a human picks colours AND only
        restate a colour applied moments ago, they are treated as an echo.

   Rules 1 and 2 are the fix; 3 and 4 are there so a feedback path built
   outside this file cannot turn into a visible strobe.

   The storage key is "easeit_accent", read by EaseIt's core on boot.
   ============================================================================ */
(function () {
    "use strict";

    var KEY = "easeit_accent";
    var DEFAULT = "#49c9bd";
    var TAG = "accent";
    var isShell = (window.parent === window);

    var painters = [];
    var current = DEFAULT;

    // ---- colour maths — byte-identical to EaseIt's, so both agree on shades ----
    function normalize(hex) {
        if (!hex) return null;
        var h = String(hex).trim().replace(/^#/, "");
        if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
        if (!/^[0-9a-fA-F]{6}$/.test(h)) return null;
        return "#" + h.toLowerCase();
    }

    function toRgb(hex) {
        var h = normalize(hex);
        if (!h) return null;
        return {
            r: parseInt(h.substr(1, 2), 16),
            g: parseInt(h.substr(3, 2), 16),
            b: parseInt(h.substr(5, 2), 16)
        };
    }

    function clamp255(v) { return Math.max(0, Math.min(255, Math.round(v))); }

function rgba(hex, alpha) {
        var c = toRgb(hex);
        if (!c) return hex;
        return "rgba(" + c.r + "," + c.g + "," + c.b + "," + alpha + ")";
    }

    /* MEZCLAR DOS COLORES

       `shade` suma lo mismo a los tres canales, que es la cuenta de EaseIt y
       sirve para aclarar u oscurecer. Pero para "este color al 60% sobre
       blanco" hace falta una mezcla de verdad: sumar 102 a un acento que ya
       tiene el rojo a 240 lo deja clavado en 255 y el tono se va.

       Esto existe porque `color-mix()` de CSS —que es exactamente esta
       cuenta— llego en Chromium 111, y el Chromium que trae CEP es mas
       viejo en TODAS las versiones de After Effects y Premiere que el panel
       admite. Dos hojas de estilo lo usaban para definir --accent-soft y
       --accent-strong: en la maquina del usuario esas dos variables no
       llegaban a existir, y con ellas se caian los estados :active, el relleno
       de los botones centrales de AlignIt y el anillo de foco de los dos
       paneles. No se veia como un error —se veia como que pulsar no hacia
       nada—, que es la peor forma de que algo este roto. */
    function mix(hex, other, ratio) {
        var a = toRgb(hex), b = toRgb(other);
        if (!a || !b) return hex;
        var k = (ratio === undefined) ? 0.5 : ratio;
        return "rgb(" + clamp255(a.r * k + b.r * (1 - k)) + "," +
                        clamp255(a.g * k + b.g * (1 - k)) + "," +
                        clamp255(a.b * k + b.b * (1 - k)) + ")";
    }

    /* Los tonos que sale de un acento, con los mismos nombres que usan las
       hojas de los paneles. Un solo sitio donde estan las proporciones: si
       manana el relleno tenue sube al 20%, sube en los tres paneles. */
    function tones(hex) {
        return {
            soft: rgba(hex, 0.16),            // relleno tenue: :active, elegido
            strong: mix(hex, "#ffffff", 0.6), // texto y anillo sobre ese relleno
            mid: mix(hex, "#363636", 0.45),   // borde a medio camino del normal
            dim: rgba(hex, 0.16),
            border: rgba(hex, 0.5)
        };
    }

    // ---- storage ----
    function read() {
        try {
            var raw = localStorage.getItem(KEY);
            var hex = normalize(raw);
            /* A malformed value has to be repaired, not just ignored: EaseIt's
               core reads this key directly, and anything that isn't a hex makes
               it refuse to repaint at all. (One could get in there: EaseIt's own
               accent modal binds its click handler to every ".swatches .sw" in
               the document, so a swatch built elsewhere without a data-c
               attribute made it store the string "null".) */
            if (raw !== null && !hex) { try { localStorage.setItem(KEY, DEFAULT); } catch (e1) {} }
            return hex || DEFAULT;
        } catch (e) { return DEFAULT; }
    }
    function write(hex) {
        try { localStorage.setItem(KEY, hex); } catch (e) {}
    }

    // ---- transport ----
    /* A colour is never posted back to the window it just arrived from — in
       BOTH directions. That is what makes the graph acyclic: a change travels
       pane -> shell -> other pane and stops there, in exactly two hops, no
       matter what the values are.

       The earlier version enforced this only in the shell; a pane echoed every
       colour it received straight back up, and the only thing keeping that from
       ringing forever was comparing hex strings. That guard holds right up
       until two surfaces disagree about what "the same colour" means — which
       is exactly what a native colour chooser does when it round-trips a value
       through HSV and hands back something a bit-off. */
    function relay(hex, exceptWindow) {
        var msg = { __editkit: TAG, hex: hex };
        if (isShell) {
            var frames = document.querySelectorAll("iframe");
            for (var i = 0; i < frames.length; i++) {
                var w = null;
                try { w = frames[i].contentWindow; } catch (e) { continue; }
                if (!w || w === exceptWindow) continue;
                try { w.postMessage(msg, "*"); } catch (e2) {}
            }
        } else {
            if (exceptWindow && exceptWindow === window.parent) return; // came from the hub
            try { window.parent.postMessage(msg, "*"); } catch (e3) {}
        }
    }

    function paint(hex) {
        for (var i = 0; i < painters.length; i++) {
            try { painters[i](hex); } catch (e) {}
        }
    }

    /* ---- pacing ----
       Repainting is not cheap: EaseIt redraws the graph and rebuilds every
       preset thumbnail. Dragging inside a colour picker can fire a hundred
       changes a second, so applications are spaced out, with the last value
       always landing. This also damps any feedback that manages to form
       outside this file. */
    var MIN_MS = 60;
    var applying = false;      // true while paint()/relay() run
    var lastApplied = 0;
    var timer = null;
    var pendingHex = null, pendingFrom = null, pendingForce = false;

    /* Last-resort circuit breaker. Nothing here can ring on its own, but
       painters reach code this file does not own, and a colour that keeps
       being re-announced would show up as both panels strobing forever. If
       changes arrive faster than any human picks colours AND the incoming one
       merely restates something applied moments ago, it is an echo, not a
       decision. Below the storm threshold this never engages. */
    var history = [];          // {hex, t} of recent applications
    var STORM_MS = 1000, STORM_N = 8;
    function noteApplied(hex, t) {
        history.push({ hex: hex, t: t });
        if (history.length > 24) history.shift();
    }
    /* "Restates" is deliberately fuzzy about the last bit or two: a colour that
       has been through a chooser's HSV maths and back comes home a shade off,
       never exactly equal, so an exact match would miss the very case this
       guards against. Four counts out of 255 is invisible, and this only ever
       runs mid-storm, where nobody could see it anyway. */
    function near(a, b) {
        var x = toRgb(a), y = toRgb(b);
        if (!x || !y) return a === b;
        return Math.abs(x.r - y.r) <= 4 && Math.abs(x.g - y.g) <= 4 && Math.abs(x.b - y.b) <= 4;
    }
    function isEcho(hex, now) {
        var recent = 0, seen = false, i;
        for (i = history.length - 1; i >= 0; i--) {
            if (now - history[i].t > STORM_MS) break;
            recent++;
            if (near(history[i].hex, hex)) seen = true;
        }
        return recent > STORM_N && seen;
    }

    function flush() {
        if (timer) { clearTimeout(timer); timer = null; }
        if (applying || !pendingHex) return;

        applying = true;
        try {
            var hex = pendingHex, from = pendingFrom, force = pendingForce;
            pendingHex = null; pendingFrom = null; pendingForce = false;
            if (hex !== current || force) {
                var now = Date.now();
                current = hex;
                lastApplied = now;
                noteApplied(hex, now);
                write(hex);
                paint(hex);
                relay(hex, from);
            }
        } finally {
            applying = false;
        }
        // Nothing can be pending here: set() refuses to queue anything while a
        // repaint is running, which is the whole point of rule 2.
    }

    function set(hex, opts) {
        hex = normalize(hex);
        if (!hex) return;
        opts = opts || {};

        /* A painter is asking to change the colour while the colour is being
           applied. That is feedback from our own repaint — a user click cannot
           happen synchronously inside paint() — so it is dropped rather than
           queued. Queuing it is what turns two surfaces that disagree into an
           endless ping-pong. */
        if (applying) return;

        if (hex === current && !opts.force) return;

        var now = Date.now();
        if (isEcho(hex, now)) return;

        pendingHex = hex;
        pendingFrom = opts.from || null;
        pendingForce = !!opts.force;

        var wait = MIN_MS - (now - lastApplied);
        if (wait > 0) {
            if (!timer) timer = setTimeout(flush, wait);
            return;
        }
        flush();
    }

    window.addEventListener("message", function (e) {
        var d = e.data;
        if (!d || d.__editkit !== TAG) return;
        // A pane that just booted asking the hub what the colour is.
        if (d.request) {
            if (isShell && e.source) {
                try { e.source.postMessage({ __editkit: TAG, hex: current }, "*"); } catch (err) {}
            }
            return;
        }
        set(d.hex, { from: e.source });
    });

    // The shell paints its own chrome: header, splitter, backdrop sheet.
    function paintShell(hex) {
        var s = document.documentElement.style;
        s.setProperty("--shell-accent", hex);
        // relleno del hover de los botones de icono de la barra
        s.setProperty("--shell-accent-fill", rgba(hex, 0.22));
        s.setProperty("--shell-accent-border", rgba(hex, 0.5));
    }

    current = read();

    window.EditKitAccent = {
        get: function () { return current; },
        set: set,
        /* Registers a painter and runs it once with the colour in effect, so a
           caller never has to apply the current value itself. */
        onChange: function (fn) {
            if (typeof fn !== "function") return;
            painters.push(fn);
            try { fn(current); } catch (e) {}
        },
        tones: tones
    };

    if (isShell) {
        window.EditKitAccent.onChange(paintShell);
    } else {
        // Panes boot from the shared storage key, but ask the hub too in case
        // storage isn't shared — same belt-and-braces the language sync uses.
        function askHub() {
            try { window.parent.postMessage({ __editkit: TAG, request: true }, "*"); } catch (e) {}
        }
        askHub();
        window.addEventListener("load", askHub);
    }
})();
