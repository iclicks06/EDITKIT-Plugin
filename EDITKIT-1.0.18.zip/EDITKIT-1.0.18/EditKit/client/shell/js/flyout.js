/* ============================================================================
   EDITKIT — EL MENU DEL PANEL

   El menú que sale del icono de líneas que está junto al nombre del panel, en
   la barra del programa. No es HTML: lo dibuja After Effects, se declara con un
   XML y solo devuelve el identificador de lo que se pulsó.

   ── POR QUE ESTE ARCHIVO EXISTE ────────────────────────────────────────────
   Ese menú no era de EDITKIT. Lo registraba el núcleo de EaseIt desde su
   <iframe> —cualquier marco del panel puede hacerlo, y el último que llama
   gana—, así que el panel que se llama EDITKIT abría un menú que decía
   «Acerca de EaseIt…», y que solo ofrecía las opciones de una de las tres
   herramientas. Además llevaba «Buscar actualizaciones…», que en esta
   compilación no busca nada: no hay canal de actualización ni red de ninguna
   clase, así que el panel prometía algo que no hace.

   Ahora lo registra el shell, que es el marco principal del panel y el único
   que conoce las tres ventanas. El núcleo de EaseIt ya no declara ningún menú:
   el suyo se quitó al limpiarlo, junto con todo lo que colgaba de él.

   ── QUE ENTRA Y QUE NO ─────────────────────────────────────────────────────
   Las cuatro primeras opciones del menú (cerrar el panel, desacoplarlo, cerrar
   los demás del grupo y la configuración del grupo) las pone el programa. No
   se pueden quitar ni hace falta: son suyas y el usuario ya las conoce.

   De lo que ponemos nosotros, la regla es que cada opción tenga que estar aquí
   por algo que no se pueda hacer igual de bien dentro del panel:

     · los ajustes y los perfiles, porque abrir ajustes desde el menú del panel
       es donde los busca la mitad de la gente;
     · las tres ventanas y el idioma, porque son interruptores y un menú del
       sistema los dibuja con su marca de verificación, gratis;
     · la ayuda y la página de novedades, porque abren el navegador y no tienen
       sitio natural dentro del panel;
     · copiar el diagnóstico, porque cuando algo va mal el usuario tiene que
       poder pegar datos en un correo sin que el panel los mande a ninguna
       parte;
     · y «Acerca de», que es lo que se busca ahí cuando se quiere la versión —
       y por eso la trae puesta en el propio nombre, sin tener que abrirlo.

   Lo que se fue, y por qué: «Buscar actualizaciones…» tal como estaba (un
   comprobador automático que no comprobaba nada: no hay canal de
   actualización, así que prometía algo que no hacía). Eso sigue fuera de
   este menú; el botón de verdad —uno que el usuario pulsa cuando quiere, y
   que solo abre la página del producto para comparar a mano— vive en Ajustes
   > Acerca de, que es donde ya está la versión con la que se compara.
   «Color de acento…» (está en Personalizar, y una cosa se cambia en un
   sitio), «Preferencias…» (lo mismo: es la ventana de ajustes) y el submenú
   de soporte con sus cuatro formularios, que no tenían a dónde enviar nada —
   queda una dirección de ayuda, que es lo único cierto.
   ============================================================================ */
(function () {
    "use strict";

    var cs = null;
    try { cs = new CSInterface(); } catch (e) { cs = null; }
    if (!cs || !window.__adobe_cep__) return;   // sin programa detrás no hay menú

    var LANG_KEY = "editkit_lang";
    var VERSION = window.EditKitVersion || "";

    var T = {
        es: {
            settings: "Ajustes de EDITKIT…",
            profiles: "Perfiles…",
            panes: "Ventanas",
            lang: "Idioma",
            es: "Español",
            en: "English",
            welcome: "Recorrido inicial…",
            features: "Nuevas funciones…",
            help: "Ayuda…",
            news: "Novedades y descargas…",
            diag: "Copiar diagnóstico",
            about: "Acerca de EDITKIT (%v)…",
            copied: "Diagnóstico copiado",
            copyFail: "No se pudo copiar"
        },
        en: {
            settings: "EDITKIT settings…",
            profiles: "Profiles…",
            panes: "Windows",
            lang: "Language",
            es: "Español",
            en: "English",
            welcome: "Initial tour…",
            features: "New features…",
            help: "Help…",
            news: "What's new and downloads…",
            diag: "Copy diagnostics",
            about: "About EDITKIT (%v)…",
            copied: "Diagnostics copied",
            copyFail: "Could not copy"
        }
    };

    function lang() {
        var l = "es";
        try { l = localStorage.getItem(LANG_KEY) || "es"; } catch (e) {}
        return T[l] ? l : "es";
    }
    function t(k) { return T[lang()][k] || T.es[k] || k; }

    /* La version, visible aqui igual que en Ajustes > Acerca de: es donde este
       menu deja mirar sin abrir nada, y donde se compara de un vistazo con lo
       que ensena la pagina de PayHip. Sin version.js cargado —no deberia
       pasar, pero un guion que no carga no tiene por que tirar el menu
       entero— se quita el hueco entero en vez de dejar un "(v)" vacio. */
    function aboutLabel() {
        var base = t("about");
        if (!VERSION) return base.replace(" (%v)", "");
        return base.replace("%v", "v" + VERSION);
    }

    function $(id) { return document.getElementById(id); }

    /* El XML del menú no perdona: un `&` o un `<` sin escapar dentro de una
       etiqueta y el programa se queda sin menú, sin decir nada. Los textos son
       nuestros, pero pasan por aquí de todas formas. */
    function esc(v) {
        return String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;")
                        .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }

    function item(id, label, checked) {
        return '<MenuItem Id="' + id + '" Label="' + esc(label) + '" Enabled="true"' +
               ' Checked="' + (checked ? "true" : "false") + '"/>';
    }
    var SEP = '<MenuItem Label="---"/>';

    // ------------------------------------------------------------------
    // Lo que hay marcado ahora mismo
    // ------------------------------------------------------------------
    var PANES = [
        ["easeit", "EaseIt", "easeitToggle"],
        ["quickit", "QuickIt", "quickitToggle"],
        ["alignit", "AlignIt", "alignitToggle"]
    ];

    // Las casillas de Personalizar son la verdad: llevan ya aplicada la regla
    // de que siempre quede una ventana, y así el menú no puede contradecirlas.
    function paneBox(id) { return $(id); }

    function onlyEaseIt() {
        try { return document.body.classList.contains("host-ppro"); } catch (e) { return false; }
    }

    function xml() {
        var out = "<Menu>";
        out += item("ek_settings", t("settings"));
        out += item("ek_profiles", t("profiles"));
        out += SEP;

        /* En Premiere hay una sola ventana —AlignIt y QuickIt son de After
           Effects—, así que el submenú de ventanas no tendría nada que
           gobernar. Tres casillas que no hacen nada es peor que no tenerlas. */
        if (!onlyEaseIt()) {
            out += '<MenuItem Label="' + esc(t("panes")) + '" Enabled="true">';
            for (var i = 0; i < PANES.length; i++) {
                var box = paneBox(PANES[i][2]);
                var on = box ? box.checked : true;
                /* La última que queda se muestra marcada y apagada, igual que su
                   casilla en Personalizar: que el interruptor se resista se lee
                   mejor que dejarlo pulsar y deshacerlo por detrás. */
                var lock = box ? box.disabled : false;
                out += '<MenuItem Id="ek_pane_' + PANES[i][0] + '" Label="' +
                       esc(PANES[i][1]) + '" Enabled="' + (lock ? "false" : "true") +
                       '" Checked="' + (on ? "true" : "false") + '"/>';
            }
            out += "</MenuItem>";
        }

        var l = lang();
        out += '<MenuItem Label="' + esc(t("lang")) + '" Enabled="true">';
        out += item("ek_lang_es", t("es"), l === "es");
        out += item("ek_lang_en", t("en"), l === "en");
        out += "</MenuItem>";

        out += SEP;
        out += item("ek_welcome", t("welcome"));
        out += item("ek_features", t("features"));
        out += item("ek_help", t("help"));
        out += item("ek_news", t("news"));
        out += item("ek_diag", t("diag"));
        out += SEP;
        out += item("ek_about", aboutLabel());
        out += "</Menu>";
        return out;
    }

    function paint() {
        try { cs.setPanelFlyoutMenu(xml()); } catch (e) {}
    }

    // ------------------------------------------------------------------
    // El diagnóstico
    // ------------------------------------------------------------------
    /* Lo que hace falta para entender un problema por correo, y nada más. Sin
       rutas, sin nombres de proyecto y sin cuentas de uso: esto lo copia el
       usuario y lo pega donde quiera, y tiene derecho a leerlo entero de un
       vistazo antes de pegarlo. */
    function diagnostics() {
        /* getHostEnvironment ya devuelve un objeto: CSInterface hace el
           JSON.parse por dentro. Volver a parsearlo convertia el objeto en la
           cadena "[object Object]", reventaba dentro del try, y el diagnostico
           salia con interrogantes justo donde tenia que decir en que programa y
           en que version esta corriendo el panel. */
        var env = {};
        try {
            var raw = cs.getHostEnvironment();
            env = (typeof raw === "string") ? (JSON.parse(raw) || {}) : (raw || {});
        } catch (e) { env = {}; }
        var api = "";
        try {
            var v = cs.getCurrentApiVersion();
            api = v ? (v.major + "." + v.minor + "." + v.micro) : "";
        } catch (e2) {}

        var vers = $("setAboutVersionValue");
        var lines = [
            "EDITKIT " + (vers ? vers.textContent : "?"),
            "Programa: " + (env.appName || "?") + " " + (env.appVersion || ""),
            "CEP: " + (api || "?"),
            "Sistema: " + (navigator.platform || "?"),
            "Idioma del panel: " + lang() + "   Programa: " + (env.appLocale || "?"),
            "Ventana: " + window.innerWidth + "×" + window.innerHeight +
                (window.devicePixelRatio !== 1 ? "  (x" + window.devicePixelRatio + ")" : "")
        ];

        var on = [];
        for (var i = 0; i < PANES.length; i++) {
            var box = paneBox(PANES[i][2]);
            if (!box || box.checked) on.push(PANES[i][1]);
        }
        lines.push("A la vista: " + (on.join(", ") || "?"));

        function read(k, dflt) {
            try { return localStorage.getItem(k) || dflt; } catch (e) { return dflt; }
        }

        /* El acento y el fondo se le preguntan a quien los pinta, no al
           almacenamiento: antes de que el usuario toque nada no hay nada
           guardado, y lo que se ve son los valores de fabrica. Un
           diagnostico que pone "?" donde el panel tiene un valor no
           sirve para diagnosticar nada. */
        var accent = read("easeit_accent", "");
        try { if (window.EditKitAccent) accent = window.EditKitAccent.get(); } catch (e4) {}

        lines.push("Disposición: " + read("editkit_layout", "auto") +
                   "   Tema: " + read("editkit_theme_last", "—") +
                   "   Acento: " + (accent || "—"));

        var bd = {};
        try {
            if (window.EditKitBackdrop && window.EditKitBackdrop.state) {
                bd = window.EditKitBackdrop.state();
            } else {
                bd = JSON.parse(localStorage.getItem("editkit_backdrop") || "{}") || {};
            }
        } catch (e3) { bd = {}; }
        lines.push("Fondo: " + (bd.mode || "?") +
                   (bd.mode === "aura" && bd.preset ? " (" + bd.preset + ")" : "") +
                   "   Velo: " + (bd.scrim === undefined ? "?" : bd.scrim) +
                   "%   Cuadros: " + (bd.fps === undefined ? "?" : bd.fps));
        lines.push("Ayuda al pasar el cursor: " + read("editkit_tips", "900"));

        return lines.join("\n");
    }

    /* Copiar sin pedirle permiso a nada: un campo de texto fuera de la vista,
       se selecciona y se copia. `navigator.clipboard` necesita un origen
       seguro y el de un panel de CEP es `file://`, así que ahí no existe. */
    function copy(text) {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.setAttribute("readonly", "readonly");
        ta.style.position = "fixed";
        ta.style.left = "-9999px";
        ta.style.top = "0";
        document.body.appendChild(ta);
        var ok = false;
        try {
            ta.select();
            ta.setSelectionRange(0, text.length);
            ok = document.execCommand("copy");
        } catch (e) { ok = false; }
        if (ta.parentNode) ta.parentNode.removeChild(ta);
        return ok;
    }

    // ------------------------------------------------------------------
    // Lo que hace cada opción
    // ------------------------------------------------------------------
    /* Nada de lógica nueva: cada opción pulsa el control que ya existe dentro
       del panel. Así el menú no puede desviarse de lo que hace la ventana de
       ajustes —las reglas, los guardados y los avisos son los mismos— y si
       mañana cambia una de esas reglas, cambia en un solo sitio. */
    function openSheet(tab) {
        var btn = $("shellSettingsBtn"), overlay = $("bdOverlay");
        if (!btn) return;
        if (overlay && overlay.hidden) btn.click();
        var tabBtn = $(tab);
        if (tabBtn) tabBtn.click();
    }

    function say(msg) {
        /* El menú del panel no tiene dónde contestar, así que se contesta en el
           sitio del panel donde ya se contestan estas cosas. */
        var hint = $("thmHint");
        if (!hint) return;
        var before = hint.textContent;
        hint.textContent = msg;
        setTimeout(function () { if (hint) hint.textContent = before; }, 2500);
    }

    var DO = {
        ek_settings: function () { openSheet("setTabCustom"); },
        ek_profiles: function () { openSheet("setTabProfiles"); },
        ek_about: function () { openSheet("setTabAbout"); },

        ek_welcome: function () {
            if (window.EditKitWelcome) window.EditKitWelcome.start();
        },
        ek_features: function () {
            if (window.EditKitWhatsNew) window.EditKitWhatsNew.open();
        },
        ek_help: function () {
            if (window.EditKitShell) window.EditKitShell.openURL("https://zickfx.com/help");
        },
        ek_news: function () {
            if (window.EditKitShell) window.EditKitShell.openURL("https://zickfx.com/b/editkit/");
        },

        ek_diag: function () {
            var ok = copy(diagnostics());
            openSheet("setTabAbout");
            say(ok ? t("copied") : t("copyFail"));
        },

        /* El idioma es un interruptor de dos posiciones: pulsar el que ya está
           puesto no hace nada, y no es un error del usuario — es lo que pasa al
           volver a elegir lo que ya tenía. */
        ek_lang_es: function () { if (lang() !== "es") clickLang(); },
        ek_lang_en: function () { if (lang() !== "en") clickLang(); }
    };

    function clickLang() {
        var b = $("langToggle");
        if (b) b.click();
    }

    for (var i = 0; i < PANES.length; i++) {
        (function (p) {
            DO["ek_pane_" + p[0]] = function () {
                var box = paneBox(p[2]);
                if (box && !box.disabled) box.click();
            };
        })(PANES[i]);
    }

    // ------------------------------------------------------------------
    // Arranque
    // ------------------------------------------------------------------
    try {
        cs.addEventListener("com.adobe.csxs.events.flyoutMenuClicked", function (ev) {
            var id = "";
            try { id = (ev && ev.data && ev.data.menuId) || ""; } catch (e) { id = ""; }
            var fn = DO[id];
            if (!fn) return;
            try { fn(); } catch (e2) {}
            paint();      // las marcas de verificación pueden haber cambiado
        });
    } catch (e) {}

    /* Y se vuelve a declarar cuando cambia algo que el menú muestra. El idioma
       no avisa con un evento propio: se detecta en el mismo botón que lo
       cambia, después de que haya corrido su propio manejador. */
    function watch() {
        var b = $("langToggle");
        if (b) b.addEventListener("click", function () { setTimeout(paint, 0); });
        for (var j = 0; j < PANES.length; j++) {
            var box = paneBox(PANES[j][2]);
            if (box) box.addEventListener("change", function () { setTimeout(paint, 0); });
        }
    }

    function boot() {
        watch();
        paint();
        /* Y otra vez un momento después: los tres <iframe> cargan detrás del
           shell, y si alguno llegara a declarar un menú propio, este tiene que
           ser el último. Cuesta una llamada. */
        setTimeout(paint, 1500);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }

    window.EditKitFlyout = { refresh: paint };
})();
