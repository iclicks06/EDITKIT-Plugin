(function () {
  "use strict";

  // ---- EDIT ME: fill in your real links before shipping ----
  var DONATE_LINKS = {
    paypal: "https://www.paypal.com/paypalme/rxlxs",
    kofi: "https://ko-fi.com/zickfx",
    bmc: "https://buymeacoffee.com/zickfx",
    // Product page, "donations" section — redirects there directly.
    site: "https://zickfx.com/b/editkit/"
  };

  // Community URLs live in their own small file because they are expected to
  // change more often than the UI. Keep the interface independent from the
  // actual Discord channel or Telegram post currently in use.
  var COMMUNITY_LINKS = window.EditKitCommunityLinks || {};

  var cs = null;
  try { cs = new CSInterface(); } catch (e) { cs = null; }

  var body = document.getElementById("shellBody");
  var splitter = document.getElementById("shellSplitter");
  var splitter2 = document.getElementById("shellSplitter2");
  var paneEaseIt = document.getElementById("paneEaseIt");
  var paneQuickIt = document.getElementById("paneQuickIt");
  var paneAlignIt = document.getElementById("paneAlignIt");
  var toolTabs = document.getElementById("toolTabs");
  var toolTabButtons = toolTabs ? toolTabs.querySelectorAll(".shell-tool-tab") : [];

  var layoutToggle = document.getElementById("layoutToggle");
  var layoutIcon = document.getElementById("layoutIcon");

  var donateBtn = document.getElementById("donateBtn");
  var donatePopover = document.getElementById("donatePopover");
  var panelVisibilityBtn = document.getElementById("panelVisibilityBtn");
  var panelVisibilityPopover = document.getElementById("panelVisibilityPopover");

  var langToggle = document.getElementById("langToggle");
  var langLabel = document.getElementById("langLabel");

  var frameEaseIt = document.getElementById("frameEaseIt");
  var frameQuickIt = document.getElementById("frameQuickIt");
  var frameAlignIt = document.getElementById("frameAlignIt");
  var performanceStatus = document.getElementById("performanceStatus");

  /* En el ancho minimo los controles no caben junto a la marca. Se mueven a
     una bandeja hija directa de body, porque en CEP un iframe puede cubrir a
     los descendientes del header aunque tengan un z-index mayor. */
  (function wireNarrowHeaderTray() {
    var header = document.querySelector(".shell-header");
    var brand = document.getElementById("shellBrand");
    var left = header ? header.querySelector(".shell-left") : null;
    var actions = header ? header.querySelector(".shell-actions") : null;
    var tray = document.getElementById("narrowHeaderTray");
    if (!header || !brand || !left || !actions || !tray) return;

    var narrow = false, closeTimer = null;
    function openTray() {
      if (!narrow) return;
      if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; }
      tray.classList.add("open");
      tray.setAttribute("aria-hidden", "false");
    }
    function closeTraySoon() {
      if (closeTimer) clearTimeout(closeTimer);
      closeTimer = setTimeout(function () {
        tray.classList.remove("open");
        tray.setAttribute("aria-hidden", "true");
        closeTimer = null;
      }, 150);
    }
    function sync() {
      var next = window.innerWidth <= 190;
      if (next === narrow && ((next && left.parentNode === tray) || (!next && left.parentNode === header))) return;
      narrow = next;
      tray.classList.remove("open");
      tray.setAttribute("aria-hidden", "true");
      if (narrow) {
        tray.appendChild(left);
        tray.appendChild(actions);
        document.body.classList.add("narrow-header-controls");
      } else {
        header.insertBefore(left, brand);
        header.appendChild(actions);
        document.body.classList.remove("narrow-header-controls");
      }
    }

    header.addEventListener("mouseenter", openTray);
    header.addEventListener("mouseleave", closeTraySoon);
    header.addEventListener("focusin", openTray);
    header.addEventListener("focusout", closeTraySoon);
    tray.addEventListener("mouseenter", openTray);
    tray.addEventListener("mouseleave", closeTraySoon);
    tray.addEventListener("focusin", openTray);
    tray.addEventListener("focusout", closeTraySoon);
    window.addEventListener("resize", sync);
    sync();
  }());

  var STACK_BREAKPOINT = 560; // px — "auto" mode stacks below this width
  var STORE_SPLIT_H = "editkit_split_h";
  var STORE_SPLIT_V = "editkit_split_v";
  var STORE_LAYOUT_MODE = "editkit_layout_mode"; // "auto" | "horizontal" | "vertical"
  var STORE_TOOL_VIEW = "editkit_tool_view"; // "all" | "tabs" | "smart"
  var STORE_ACTIVE_TOOL = "editkit_active_tool";
  var STORE_PERFORMANCE = "editkit_performance_mode";
  var LANG_KEY = "editkit_lang"; // shared key; each iframe also reads it independently on boot
  var MIN_RATIO = 0.15;
  var MAX_RATIO = 0.85;

  /* La ventana del medio se mide en pixeles y no en fracciones: lo que lleva
     dentro son botones de tamano fijo, y estirarlos no ensena nada mas. Los
     limites son los de siempre —lo que hace falta para que quepan tres
     columnas de botones, y lo que deja de tener sentido— y hay uno por
     orientacion porque a lo alto lo que se reparte es otra cosa. */
  var STORE_QI_H = "editkit_quickit_w";
  var STORE_QI_V = "editkit_quickit_h";
  var STORE_QI_OFF = "editkit_quickit_off";
  /* Uno por panel, y con el mismo sentido que el que ya habia: la clave dice
     lo que esta APAGADO, no lo que esta encendido. Asi, quien nunca toco nada
     no tiene ninguna clave guardada y los tres se ven, que es lo que debe
     pasar la primera vez. */
  var PANE_OFF = {
      easeit: "editkit_easeit_off",
      quickit: STORE_QI_OFF,
      alignit: "editkit_alignit_off"
  };
  var QI_MIN = 120;
  var QI_MAX = 460;
  var QI_DEFAULT = 190;

  /* Pesos del reparto automatico. No son anchos rigidos: describen cuanto
     provecho obtiene cada herramienta del espacio disponible. En horizontal
     EaseIt necesita sitio para la curva y sus presets; QuickIt para una rejilla
     legible; AlignIt puede trabajar un poco mas compacto. En vertical QuickIt
     recibe algo mas porque su lista suele ser la mas larga. */
  var SMART_WEIGHT_H = { easeit: 0.44, quickit: 0.30, alignit: 0.26 };
  var SMART_WEIGHT_V = { easeit: 0.34, quickit: 0.38, alignit: 0.28 };
  var SMART_MIN_H = { easeit: 320, quickit: 230, alignit: 220 };
  var SMART_MIN_V = { easeit: 210, quickit: 240, alignit: 190 };

  // ==========================================================
  // Icons (Material Symbols Outlined, same 24px grid as the markup)
  // ==========================================================
  // Only the few this file injects at runtime; everything static lives in
  // index.html. Filled paths, so they take the element's own colour.
  var MS = {
    cafe: "M160-120v-80h640v80H160Zm160-160q-66 0-113-47t-47-113v-400h640q33 0 56.5 23.5T880-760v120q0 33-23.5 56.5T800-560h-80v120q0 66-47 113t-113 47H320Zm0-80h240q33 0 56.5-23.5T640-440v-320H240v320q0 33 23.5 56.5T320-360Zm400-280h80v-120h-80v120ZM320-360h-80 400-320Z",
    card: "M880-720v480q0 33-23.5 56.5T800-160H160q-33 0-56.5-23.5T80-240v-480q0-33 23.5-56.5T160-800h640q33 0 56.5 23.5T880-720Zm-720 80h640v-80H160v80Zm0 160v240h640v-240H160Zm0 240v-480 480Z",
    heart: "m480-120-58-52q-101-91-167-157T150-447.5Q111-500 95.5-544T80-634q0-94 63-157t157-63q52 0 99 22t81 62q34-40 81-62t99-22q94 0 157 63t63 157q0 46-15.5 90T810-447.5Q771-395 705-329T538-172l-58 52Zm0-108q96-86 158-147.5t98-107q36-45.5 50-81t14-70.5q0-60-40-100t-100-40q-47 0-87 26.5T518-680h-76q-15-41-55-67.5T300-774q-60 0-100 40t-40 100q0 35 14 70.5t50 81q36 45.5 98 107T480-228Zm0-273Z",
    globe: "M480-80q-82 0-155-31.5t-127.5-86Q143-252 111.5-325T80-480q0-83 31.5-155.5t86-127Q252-817 325-848.5T480-880q83 0 155.5 31.5t127 86q54.5 54.5 86 127T880-480q0 82-31.5 155t-86 127.5q-54.5 54.5-127 86T480-80Zm0-82q26-36 45-75t31-83H404q12 44 31 83t45 75Zm-104-16q-18-33-31.5-68.5T322-320H204q29 50 72.5 87t99.5 55Zm208 0q56-18 99.5-55t72.5-87H638q-9 38-22.5 73.5T584-178ZM170-400h136q-3-20-4.5-39.5T300-480q0-21 1.5-40.5T306-560H170q-5 20-7.5 39.5T160-480q0 21 2.5 40.5T170-400Zm216 0h188q3-20 4.5-39.5T580-480q0-21-1.5-40.5T574-560H386q-3 20-4.5 39.5T380-480q0 21 1.5 40.5T386-400Zm268 0h136q5-20 7.5-39.5T800-480q0-21-2.5-40.5T790-560H654q3 20 4.5 39.5T660-480q0 21-1.5 40.5T654-400Zm-16-240h118q-29-50-72.5-87T584-782q18 33 31.5 68.5T638-640Zm-234 0h152q-12-44-31-83t-45-75q-26 36-45 75t-31 83Zm-200 0h118q9-38 22.5-73.5T376-782q-56 18-99.5 55T204-640Z"
,
    /* Variante FILL 1 del corazon: mismo glifo, misma rejilla, silueta cerrada.
       Solo la necesita el boton de la barra, que al pasar el mouse cambia de
       contorno a relleno (ver .icon-swap en shell.css). */
    heartFill: "m480-120-58-52q-101-91-167-157T150-447.5Q111-500 95.5-544T80-634q0-94 63-157t157-63q52 0 99 22t81 62q34-40 81-62t99-22q94 0 157 63t63 157q0 46-15.5 90T810-447.5Q771-395 705-329T538-172l-58 52Z"
  };
  function icon(name, size) {
    return '<svg class="ms" viewBox="0 -960 960 960" width="' + size + '" height="' + size +
           '" fill="currentColor" aria-hidden="true"><path d="' + MS[name] + '"/></svg>';
  }
  /* Las dos variantes juntas, apiladas por CSS. El contorno es el estado en
     reposo; la rellena espera con opacidad 0 en el mismo sitio. Las dos van en
     el DOM desde el principio para que el cambio sea una transicion y no un
     salto, y para que el navegador no tenga nada que cargar al pasar el mouse. */
  function iconSwap(name, size) {
    return icon(name, size).replace('class="ms"', 'class="ms ms-outline"') +
           icon(name + 'Fill', size).replace('class="ms"', 'class="ms ms-fill"');
  }

  // ==========================================================
  // Language (shell chrome text + propagate to both iframes)
  // ==========================================================
  var SHELL_DICT = {
    es: {
      donateTip: "Este plugin es gratis. Si te resulta útil, puedes apoyar el desarrollo con una donación opcional — nunca es necesario.",
      donateBtn: "Apoyar el proyecto",
      donateTitle: "Apoyar el proyecto",
      donateHint: "100% opcional — el plugin funciona igual sin donar.",
      donatePaypal: "PayPal",
      donateKofi: "Ko-fi",
      donateBmc: "Buy Me a Coffee",
      donateSite: "Ver todas las formas de apoyar",
      langTip: "Cambiar idioma / Switch language",
      layoutHorizontal: "Orientación: lado a lado (clic para cambiar a vertical)",
      layoutVertical: "Orientación: uno sobre otro (clic para cambiar a automático)",
      layoutAuto: "Orientación: automática según el ancho (clic para forzar lado a lado)",
      toolTabsLabel: "Herramientas de EditKit",
      panelMenuTitle: "Paneles visibles",
      panelMenuHint: "Marca las herramientas que quieres mantener en tu espacio de trabajo.",
      panelMenuDragHint: "También puedes intercambiar su posición arrastrando la cabecera de cada herramienta.",
      panelMenuButton: "Elegir paneles visibles",
      viewAll: "Todos los paneles", viewTabs: "Pestañas", viewSmart: "Inteligente",
      optionLayoutAuto: "Automática según el ancho", optionLayoutHorizontal: "Lado a lado",
      optionLayoutVertical: "Uno sobre otro",
      splitterTip: "Arrastra para redimensionar · Doble clic para equilibrar automáticamente",
      performanceOn: "Modo rendimiento activado",
      performanceOff: "Modo rendimiento desactivado",
      settingsPerformance: "Ajustes · Modo rendimiento activado"
    },
    en: {
      donateTip: "This plugin is free. If you find it useful, you can support development with an optional donation — never required.",
      donateBtn: "Support the project",
      donateTitle: "Support the project",
      donateHint: "100% optional — the plugin works exactly the same either way.",
      donatePaypal: "PayPal",
      donateKofi: "Ko-fi",
      donateBmc: "Buy Me a Coffee",
      donateSite: "See all ways to support",
      langTip: "Cambiar idioma / Switch language",
      layoutHorizontal: "Orientation: side by side (click to switch to vertical)",
      layoutVertical: "Orientation: one above another (click to switch to automatic)",
      layoutAuto: "Orientation: automatic based on width (click to force side by side)",
      toolTabsLabel: "EditKit tools",
      panelMenuTitle: "Visible panels",
      panelMenuHint: "Choose which tools stay visible in your workspace.",
      panelMenuDragHint: "You can also rearrange them by dragging each tool's header.",
      panelMenuButton: "Choose visible panels",
      viewAll: "All panels", viewTabs: "Tabs", viewSmart: "Smart",
      optionLayoutAuto: "Automatic based on width", optionLayoutHorizontal: "Side by side",
      optionLayoutVertical: "One above another",
      splitterTip: "Drag to resize · Double-click to balance automatically",
      performanceOn: "Performance mode enabled",
      performanceOff: "Performance mode disabled",
      settingsPerformance: "Settings · Performance mode enabled"
    }
  };

  /* Solo se detecta cuando todavia no hay una eleccion guardada. After Effects
     manda sobre el sistema; si su idioma no es uno de los dos disponibles se
     prueba el del sistema, y finalmente inglés. Desde el primer cambio manual
     la clave existe y nunca se vuelve a imponer una deteccion. */
  var lang = "";
  try { lang = localStorage.getItem(LANG_KEY) || ""; } catch (e) {}
  if (!SHELL_DICT[lang]) {
    var env = {};
    try { env = (cs && cs.hostEnvironment) || {}; } catch (e2) { env = {}; }
    if (window.EditKitLanguage && window.EditKitLanguage.detect) {
      lang = window.EditKitLanguage.detect(env, navigator);
    } else {
      var rawLocale = env.appUILocale || env.appLocale || navigator.language || "";
      lang = /^es(?:[-_]|$)/i.test(rawLocale) ? "es" : "en";
    }
    try { localStorage.setItem(LANG_KEY, lang); } catch (e3) {}
  }

  function st(key) { return SHELL_DICT[lang][key] || SHELL_DICT.es[key] || key; }

  function applyShellLanguage() {
    langLabel.textContent = lang.toUpperCase();
    langToggle.title = st("langTip");
    langToggle.setAttribute("aria-label", st("langTip"));
    /* En la barra es un icono a secas: el nombre de la accion va en el title
       y en el titulo del propio popover, que es donde se lee sin estorbar. */
    donateBtn.innerHTML = iconSwap("heart", 15);
    donateBtn.title = st("donateBtn") + " — " + st("donateTip");
    donateBtn.setAttribute("aria-label", st("donateBtn"));
    function opt(id, ico, key) {
      document.getElementById(id).innerHTML =
        '<span class="donate-option-icon">' + icon(ico, 15) + '</span><span>' + st(key) + '</span>';
    }
    opt("donatePaypal", "card", "donatePaypal");
    opt("donateKofi", "cafe", "donateKofi");
    opt("donateBmc", "heart", "donateBmc");
    opt("donateSite", "globe", "donateSite");
    document.querySelector(".donate-popover-title").textContent = st("donateTitle");
    document.querySelector(".donate-popover-hint").textContent = st("donateHint");
    // backdrop.js loads after this file, so it isn't there for the first call —
    // it reads the same stored language itself on boot, and only needs telling
    // about later switches.
    if (window.EditKitBackdrop) window.EditKitBackdrop.setLanguage(lang);
    // Y lo mismo con las dos pestanas que dibujan su contenido a mano.
    if (window.EditKitProfiles) window.EditKitProfiles.setLanguage(lang);
    if (window.EditKitThemes) window.EditKitThemes.setLanguage(lang);
    if (window.EditKitEggs) window.EditKitEggs.setLanguage(lang);
    if (window.EditKitFeedback) window.EditKitFeedback.setLanguage(lang);
    if (window.EditKitSurfaces) window.EditKitSurfaces.setLanguage(lang);
    if (window.EditKitSurfaceMedia) window.EditKitSurfaceMedia.setLanguage(lang);
    if (window.EditKitFlyout) window.EditKitFlyout.refresh();
    if (window.EditKitWelcome) window.EditKitWelcome.setLanguage();
    if (window.EditKitWhatsNew) window.EditKitWhatsNew.setLanguage();
    if (window.EditKitUpdater) window.EditKitUpdater.setLanguage();
    if (toolTabs) toolTabs.setAttribute("aria-label", st("toolTabsLabel"));
    if (panelVisibilityBtn) {
      panelVisibilityBtn.title = st("panelMenuButton");
      panelVisibilityBtn.setAttribute("aria-label", st("panelMenuButton"));
    }
    if (splitter) splitter.title = st("splitterTip");
    if (splitter2) splitter2.title = st("splitterTip");
    var panelMenuTitle = document.getElementById("panelVisibilityTitle");
    var panelMenuHint = document.getElementById("panelVisibilityHint");
    var panelMenuDragHint = document.getElementById("panelVisibilityDragHint");
    if (panelMenuTitle) panelMenuTitle.textContent = st("panelMenuTitle");
    if (panelMenuHint) panelMenuHint.textContent = st("panelMenuHint");
    if (panelMenuDragHint) panelMenuDragHint.textContent = st("panelMenuDragHint");
    function optionText(selectId, value, key) {
      var select = document.getElementById(selectId);
      if (!select) return;
      var option = select.querySelector('option[value="' + value + '"]');
      if (option) option.textContent = st(key);
    }
    optionText("toolViewSelect", "all", "viewAll");
    optionText("toolViewSelect", "tabs", "viewTabs");
    optionText("toolViewSelect", "smart", "viewSmart");
    optionText("layoutSelect", "auto", "optionLayoutAuto");
    optionText("layoutSelect", "horizontal", "optionLayoutHorizontal");
    optionText("layoutSelect", "vertical", "optionLayoutVertical");
    refreshLayoutToggleUI();
    syncPerformanceUI();
    try { window.dispatchEvent(new CustomEvent("editkit:language", { detail: { lang: lang } })); } catch (e) {}
  }

  function pushLanguageToFrame(frame) {
    try {
      if (frame.contentWindow && frame.contentWindow.EditKitI18n) {
        frame.contentWindow.EditKitI18n.setLanguage(lang);
      }
      if (frame.contentWindow && frame.contentWindow.EditKitSurfaceMedia) {
        frame.contentWindow.EditKitSurfaceMedia.setLanguage(lang);
      }
    } catch (e) {}
  }

  function broadcastLanguage() {
    pushLanguageToFrame(frameEaseIt);
    pushLanguageToFrame(frameQuickIt);
    pushLanguageToFrame(frameAlignIt);
  }

  // Each iframe app applies the persisted language on its own boot (they
  // read the same localStorage key), but if the panel loads slowly or the
  // key isn't shared for some reason, push it explicitly once each frame
  // finishes loading too.
  frameEaseIt.addEventListener("load", function () { pushLanguageToFrame(frameEaseIt); });
  frameQuickIt.addEventListener("load", function () { pushLanguageToFrame(frameQuickIt); });
  frameAlignIt.addEventListener("load", function () { pushLanguageToFrame(frameAlignIt); });

  langToggle.addEventListener("click", function () {
    lang = lang === "es" ? "en" : "es";
    try { localStorage.setItem(LANG_KEY, lang); } catch (e) {}
    applyShellLanguage();
    broadcastLanguage();
  });

  // ==========================================================
  // Layout mode (manual override for the splitter orientation)
  // ==========================================================
  var layoutMode = "auto";
  try { layoutMode = localStorage.getItem(STORE_LAYOUT_MODE) || "auto"; } catch (e) {}
  if (["auto", "horizontal", "vertical"].indexOf(layoutMode) < 0) layoutMode = "auto";

  var toolViewMode = "smart";
  try { toolViewMode = localStorage.getItem(STORE_TOOL_VIEW) || "smart"; } catch (e2) {}
  if (["all", "tabs", "smart"].indexOf(toolViewMode) < 0) toolViewMode = "smart";

  /* Material Symbols, same 0 -960 960 960 grid as the wrapper in index.html:
     a pane split down the middle, split across, and the mosaic for "decide by
     width". Only the path changes — the <svg> element itself is never rebuilt. */
  var LAYOUT_ICONS = {
    horizontal: '<path d="M120-360v-80h320v80H120Zm0 160v-80h320v80H120Zm0-320v-80h320v80H120Zm0-160v-80h320v80H120Zm480 480q-33 0-56.5-23.5T520-280v-400q0-33 23.5-56.5T600-760h160q33 0 56.5 23.5T840-680v400q0 33-23.5 56.5T760-200H600Zm0-80h160v-400H600v400Zm80-200Z"/>',
    vertical: '<path d="M120-200v-240h720v240H120Zm0-320v-80h720v80H120Zm0-160v-80h720v80H120Z"/>',
    auto: '<path d="M440-120H200q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h240v720Zm-80-80v-560H200v560h160Zm160-320v-320h240q33 0 56.5 23.5T840-760v240H520Zm80-80h160v-160H600v160Zm-80 480v-320h320v240q0 33-23.5 56.5T760-120H520Zm80-80h160v-160H600v160ZM360-480Zm240-120Zm0 240Z"/>'
  };

  function isStacked() {
    if (layoutMode === "horizontal") return false;
    if (layoutMode === "vertical") return true;
    return window.innerWidth < STACK_BREAKPOINT; // auto
  }

  function refreshLayoutToggleUI() {
    layoutIcon.innerHTML = LAYOUT_ICONS[layoutMode];
    layoutToggle.title = st("layout" + layoutMode.charAt(0).toUpperCase() + layoutMode.slice(1));
    layoutToggle.classList.toggle("active", layoutMode !== "auto");
  }

  layoutToggle.addEventListener("click", function () {
    layoutMode = layoutMode === "auto" ? "horizontal" : (layoutMode === "horizontal" ? "vertical" : "auto");
    try { localStorage.setItem(STORE_LAYOUT_MODE, layoutMode); } catch (e) {}
    refreshLayoutToggleUI();
    applyLayoutMode();
  });

  // ---- Split ratio ----
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

  function getStoredRatio() {
    var key = isStacked() ? STORE_SPLIT_V : STORE_SPLIT_H;
    var v = null;
    try { v = parseFloat(localStorage.getItem(key)); } catch (e) {}
    if (!isFinite(v) || v < MIN_RATIO || v > MAX_RATIO) return null;
    return v;
  }

  function setStoredRatio(ratio) {
    var key = isStacked() ? STORE_SPLIT_V : STORE_SPLIT_H;
    try { localStorage.setItem(key, String(ratio)); } catch (e) {}
  }

  /* ----------------------------------------------------------------
     El orden de los tres plugins

     Lo elige el usuario arrastrando cualquiera por su cabecera. Se cambia con
     la propiedad `order` del flex y NO moviendo los nodos: mover un <iframe>
     en el DOM lo recarga, y recargarlo es perder el estado de la herramienta
     —la curva a medio editar, la categoria abierta— cada vez que alguien
     reordena las ventanas.

     Y el reparto de sitio va por posicion y no por identidad: el primero se
     lleva su fraccion, el del medio unos pixeles fijos y el ultimo lo que
     sobre. Antes estaba escrito con nombres (EaseIt primero, QuickIt en medio)
     y con eso, arrastrar QuickIt a la izquierda dejaba el divisor moviendo un
     panel y el raton en otro.
     ---------------------------------------------------------------- */
  var PANE_ORDER = "editkit_pane_order";
  var PANES = { easeit: paneEaseIt, quickit: paneQuickIt, alignit: paneAlignIt };
  var DEFAULT_ORDER = ["easeit", "quickit", "alignit"];

  function paneOrder() {
    var a = null;
    try { a = JSON.parse(localStorage.getItem(PANE_ORDER) || "null"); } catch (e) {}
    if (!a || a.length !== DEFAULT_ORDER.length) return DEFAULT_ORDER.slice();
    // Una lista guardada que no cubra los tres se descarta entera: media lista
    // deja un panel sin sitio, que es peor que perder el orden.
    for (var i = 0; i < DEFAULT_ORDER.length; i++) {
      var found = false;
      for (var j = 0; j < a.length; j++) { if (a[j] === DEFAULT_ORDER[i]) found = true; }
      if (!found) return DEFAULT_ORDER.slice();
    }
    return a;
  }

  function setPaneOrder(a) {
    try { localStorage.setItem(PANE_ORDER, JSON.stringify(a)); } catch (e) {}
    layoutPanes();
  }

  function visiblePanes() {
    var order = paneOrder(), out = [];
    for (var i = 0; i < order.length; i++) {
      var el = PANES[order[i]];
      if (el && !el.hidden && !el.classList.contains("view-hidden")) out.push(el);
    }
    return out;
  }

  function paneIdOf(el) {
    for (var id in PANES) if (PANES.hasOwnProperty(id) && PANES[id] === el) return id;
    return "easeit";
  }

  /* Calcula un punto de partida util para cualquier orden de paneles. Solo se
     usa mientras el usuario no haya movido los divisores; en cuanto lo hace,
     sus medidas guardadas vuelven a mandar. */
  function smartLayout(vis) {
    var stacked = isStacked();
    var weights = stacked ? SMART_WEIGHT_V : SMART_WEIGHT_H;
    var minimums = stacked ? SMART_MIN_V : SMART_MIN_H;
    var rect = body.getBoundingClientRect();
    var total = stacked ? rect.height : rect.width;
    var usable = Math.max(1, total - Math.max(0, vis.length - 1) * 6);
    var weightTotal = 0, minimumTotal = 0, i;
    for (i = 0; i < vis.length; i++) {
      var id = paneIdOf(vis[i]);
      weightTotal += weights[id] || 1;
      minimumTotal += minimums[id] || 0;
    }
    if (!weightTotal) weightTotal = vis.length || 1;

    function ideal(el) {
      var id = paneIdOf(el);
      var px = usable * (weights[id] || 1) / weightTotal;
      /* Los minimos solo se fuerzan cuando caben todos. En ventanas pequenas
         manda la proporcion, evitando que un panel empuje a otro fuera. */
      if (usable >= minimumTotal) px = Math.max(px, minimums[id] || 0);
      return px;
    }

    return {
      ratio: clamp(ideal(vis[0]) / Math.max(1, total), MIN_RATIO, MAX_RATIO),
      middle: vis.length === 3 ? clamp(ideal(vis[1]), QI_MIN, QI_MAX) : null
    };
  }

  function effectiveRatio(vis) {
    var stored = getStoredRatio();
    return stored === null ? smartLayout(vis || visiblePanes()).ratio : stored;
  }

  /* Reparte los numeros de `order`: los paneles visibles en 0, 2, 4 y los
     divisores en los huecos impares que quedan entre ellos. Los divisores no
     llevan un sitio fijo por eso mismo: con un panel oculto, un divisor con
     numero fijo puede acabar en el borde, sin nada a un lado. */
  function layoutPanes() {
    var order = paneOrder(), i, visibleIndex = 0;
    for (i = 0; i < order.length; i++) {
      var el = PANES[order[i]];
      if (!el) continue;
      /* Compacta los numeros de los que realmente participan en el reparto.
         Si el primero está apagado, el divisor debe seguir quedando ENTRE los
         dos restantes y no delante de ambos. */
      if (!el.hidden && !el.classList.contains("view-hidden")) {
        el.style.order = String(visibleIndex * 2);
        visibleIndex++;
      }
    }
    var vis = visiblePanes();
    splitter.style.order = "1";
    splitter2.style.order = "3";
    /* Un divisor que no separa nada es un tirador que al arrastrarlo cambia un
       tamano invisible. Con un solo panel no hay ninguno; con dos, uno. */
    splitter.hidden = vis.length < 2;
    splitter2.hidden = vis.length < 3;
    applySizes();
  }

  function applySizes() {
    var vis = visiblePanes(), i;
    for (i = 0; i < vis.length; i++) vis[i].style.flex = "";

    if (!vis.length) return;
    if (vis.length === 1) { vis[0].style.flex = "1 1 auto"; return; }

    var smart = smartLayout(vis);
    var ratio = clamp(effectiveRatio(vis), MIN_RATIO, MAX_RATIO);
    vis[0].style.flex = "0 0 " + (ratio * 100) + "%";
    if (vis.length === 3) {
      var storedMiddle = getQuickItSize();
      setQuickItSize(storedMiddle === null ? smart.middle : storedMiddle);
      vis[1].style.flex = "0 0 var(--quickit-size, 190px)";
    }
    vis[vis.length - 1].style.flex = "1 1 auto";
  }

  function setRatio(ratio) {
    if (document.body.classList.contains("host-ppro")) {
      paneEaseIt.style.flex = "1 1 auto";
      return ratio;
    }
    ratio = clamp(ratio, MIN_RATIO, MAX_RATIO);
    var vis = visiblePanes();
    if (vis.length > 1) vis[0].style.flex = "0 0 " + (ratio * 100) + "%";
    return ratio;
  }

  // El del medio, sea cual sea: el tamano es de la posicion, no del plugin.
  function midPane() {
    var vis = visiblePanes();
    return vis.length === 3 ? vis[1] : null;
  }

  // ---- La ventana del medio ----
  /* SIEMPRE QUEDA UNO

     Se puede esconder cualquiera de los tres, pero no los tres: un panel vacio
     no es una preferencia, es una averia que el usuario no sabria deshacer
     —sin paneles no hay engranaje que pulsar—.

     La regla se aplica ANTES de guardar, no al leer. La primera version lo
     hacia al leer —"si esta apagado pero es el ultimo, ensenalo igual"— y eso
     deja la clave diciendo una cosa y la pantalla otra: el panel se veia con su
     ajuste en apagado, y al encender otro desaparecia de golpe sin que nadie
     hubiera tocado su interruptor. Guardado siempre honesto, leido sin
     excepciones. */
  var PANE_IDS = ["easeit", "quickit", "alignit"];
  var PANE_FRAMES = { easeit: frameEaseIt, quickit: frameQuickIt, alignit: frameAlignIt };
  var performanceMode = false;
  try { performanceMode = localStorage.getItem(STORE_PERFORMANCE) === "1"; } catch (e) {}
  var performanceNoticeTimer = null;

  function paneRuntimeVisible(id) {
    var pane = PANES[id];
    return !!(pane && paneOn(id) && !pane.hidden && !pane.classList.contains("view-hidden"));
  }

  function sendRuntimeToFrame(id) {
    var frame = PANE_FRAMES[id];
    if (!frame || !frame.contentWindow) return;
    try {
      frame.contentWindow.postMessage({
        __editkit: "runtime",
        paneVisible: paneRuntimeVisible(id),
        performance: performanceMode
      }, "*");
    } catch (e) {}
  }

  function broadcastRuntime() {
    if (window.EditKitAwake && window.EditKitAwake.setRuntime) {
      window.EditKitAwake.setRuntime({ paneVisible: true, performance: performanceMode });
    }
    for (var i = 0; i < PANE_IDS.length; i++) sendRuntimeToFrame(PANE_IDS[i]);
  }

  function announcePerformance() {
    if (!performanceStatus) return;
    performanceStatus.textContent = st(performanceMode ? "performanceOn" : "performanceOff");
    performanceStatus.classList.remove("show");
    void performanceStatus.offsetWidth;
    performanceStatus.classList.add("show");
    clearTimeout(performanceNoticeTimer);
    performanceNoticeTimer = setTimeout(function () {
      performanceStatus.classList.remove("show");
    }, 2600);
  }

  function syncPerformanceUI() {
    var checkbox = document.getElementById("performanceToggle");
    var gear = document.getElementById("shellSettingsBtn");
    if (checkbox) checkbox.checked = performanceMode;
    if (gear) {
      gear.classList.toggle("performance-on", performanceMode);
      gear.title = performanceMode ? st("settingsPerformance") : (lang === "en" ? "Settings" : "Ajustes");
      gear.setAttribute("aria-label", gear.title);
    }
  }

  function setPerformanceMode(on, announce) {
    performanceMode = !!on;
    try { localStorage.setItem(STORE_PERFORMANCE, performanceMode ? "1" : "0"); } catch (e) {}
    syncPerformanceUI();
    broadcastRuntime();
    if (announce) announcePerformance();
  }

  for (var runtimeId in PANE_FRAMES) {
    if (PANE_FRAMES.hasOwnProperty(runtimeId) && PANE_FRAMES[runtimeId]) {
      (function (id) {
        PANE_FRAMES[id].addEventListener("load", function () { sendRuntimeToFrame(id); });
      })(runtimeId);
    }
  }

  function paneAvailable(id) {
    if (id === "easeit") return true;
    return !document.body.classList.contains("host-ppro");
  }

  function paneOn(id) {
    if (!paneAvailable(id)) return false;
    try { return localStorage.getItem(PANE_OFF[id]) !== "1"; } catch (e) { return true; }
  }

  function countOn() {
    var n = 0;
    for (var i = 0; i < PANE_IDS.length; i++) if (paneOn(PANE_IDS[i])) n++;
    return n;
  }

  // El unico que queda encendido: su interruptor se queda fijo.
  function onlyOne(id) { return paneOn(id) && countOn() === 1; }

  // Cuantos podria ver el usuario en este programa, encendidos o no.
  function countAvailable() {
    var n = 0;
    for (var i = 0; i < PANE_IDS.length; i++) if (paneAvailable(PANE_IDS[i])) n++;
    return n;
  }

  function tabViewActive() {
    if (countOn() <= 1) return false;
    if (toolViewMode === "tabs") return true;
    return toolViewMode === "smart" && window.innerWidth < STACK_BREAKPOINT;
  }

  function firstActiveTool() {
    var order = paneOrder();
    for (var i = 0; i < order.length; i++) if (paneOn(order[i])) return order[i];
    return "easeit";
  }

  function storedActiveTool() {
    var active = "";
    try { active = localStorage.getItem(STORE_ACTIVE_TOOL) || ""; } catch (e) {}
    return paneOn(active) ? active : firstActiveTool();
  }

  function selectActiveTool(id, animate) {
    if (!paneOn(id)) id = firstActiveTool();
    try { localStorage.setItem(STORE_ACTIVE_TOOL, id); } catch (e) {}
    applyToolView(animate !== false);
  }

  /* Las pestañas no desmontan ni mueven iframes. Solo apartan dos paneles del
     reparto visual, de modo que curvas, categorías y selecciones sobreviven
     al cambio exactamente igual que al ocultar una ventana detrás de otra. */
  function applyToolView(animate) {
    var tabbed = tabViewActive();
    var active = storedActiveTool();
    document.body.classList.toggle("tool-tabs-active", tabbed);
    if (toolTabs) toolTabs.hidden = !tabbed;

    for (var i = 0; i < PANE_IDS.length; i++) {
      var id = PANE_IDS[i], pane = PANES[id];
      if (!pane) continue;
      var wasHidden = pane.classList.contains("view-hidden");
      var shouldHide = tabbed && id !== active && paneOn(id);
      pane.classList.toggle("view-hidden", shouldHide);
      pane.setAttribute("aria-hidden", (!paneOn(id) || shouldHide) ? "true" : "false");
      if (tabbed && id === active && wasHidden && animate) {
        pane.classList.remove("pane-tab-enter");
        void pane.offsetWidth;
        pane.classList.add("pane-tab-enter");
      }
    }

    for (var j = 0; j < toolTabButtons.length; j++) {
      var button = toolTabButtons[j];
      var tool = button.getAttribute("data-tool");
      var selected = tabbed && tool === active;
      button.hidden = !paneOn(tool);
      button.classList.toggle("active", selected);
      button.setAttribute("aria-selected", selected ? "true" : "false");
      button.tabIndex = selected ? 0 : -1;
    }
    layoutPanes();
    broadcastRuntime();
  }

function getQuickItSize() {
    var key = isStacked() ? STORE_QI_V : STORE_QI_H;
    var v = null;
    try { v = parseFloat(localStorage.getItem(key)); } catch (e) {}
    if (!isFinite(v)) return null;
    return clamp(v, QI_MIN, QI_MAX);
  }

  function setQuickItSize(px) {
    px = clamp(px, QI_MIN, QI_MAX);
    // En el contenedor y no en el panel: quien lo lee es el que este en medio,
    // y ese cambia cuando el usuario reordena.
    body.style.setProperty("--quickit-size", px + "px");
    return px;
  }

  function storeQuickItSize(px) {
    var key = isStacked() ? STORE_QI_V : STORE_QI_H;
    try { localStorage.setItem(key, String(px)); } catch (e) {}
  }

  /* Quitarla es quitar tambien su divisor. Dejarlo seria dejar un tirador que
     no separa nada, y arrastrarlo cambiaria un tamano que no se ve. */
  var PANE_CHECK = {
      easeit: "easeitToggle", quickit: "quickitToggle", alignit: "alignitToggle"
  };
  var PANE_MENU_CHECK = {
      easeit: "menuEaseItToggle", quickit: "menuQuickItToggle", alignit: "menuAlignItToggle"
  };

  function syncPaneCheckbox(map, id, on) {
    var chk = document.getElementById(map[id]);
    if (!chk) return;
    chk.checked = on;
    chk.disabled = onlyOne(id);
    if (chk.parentNode && chk.parentNode.classList) {
      chk.parentNode.classList.toggle("disabled", chk.disabled);
    }
  }

  function applyPanesVisible() {
    var i;
    for (i = 0; i < PANE_IDS.length; i++) {
      var id = PANE_IDS[i], on = paneOn(id);
      if (PANES[id]) PANES[id].hidden = !on;
      /* Los ajustes y el menu rapido son dos vistas del mismo estado. El
         ultimo que queda se deja marcado y sin poder desmarcarse: que el
         interruptor se resista es mas claro que dejarlo pulsar y deshacerlo
         por detras, que se lee como que el panel no funciona. */
      syncPaneCheckbox(PANE_CHECK, id, on);
      syncPaneCheckbox(PANE_MENU_CHECK, id, on);
    }

    /* SECRETO: UNO SOLO. Dejar un panel a la vista es una manera legitima de
       trabajar —quien solo alinea no necesita las curvas— y ademas nadie la
       encuentra por casualidad, porque hay que entrar en Personalizar y
       apagar dos interruptores. Se anota en la bitacora. */
    /* Y solo cuenta donde de verdad haya tres que apagar. En Premiere hay uno
       y nada mas —AlignIt y QuickIt son de After Effects—, asi que ahi "queda
       uno" es el estado normal del panel y regalar el secreto seria mentirle
       al usuario: la pista le diria que apague dos paneles que no existen. */
    if (countOn() === 1 && countAvailable() > 1) {
      try { if (window.EditKitLog) window.EditKitLog.found("g9"); } catch (e) {}
    }

    applyToolView(false);
  }

function applyLayoutMode() {
    body.classList.toggle("stacked", isStacked());
    applyToolView(false);
  }

  // ---- Dragging ----
  // The two tools live in <iframe>s. A plain document-level "mousemove"
  // listener stops receiving events the instant the cursor crosses into an
  // iframe (it becomes a separate event target), which is what made the
  // splitter feel broken/jumpy. Fix: while dragging, disable pointer events
  // on both iframes (via the .splitter-dragging class) so every mousemove
  // stays targeted at the top document, and throttle updates with rAF so
  // the drag never lags behind the cursor.
  var dragging = false;
  var pendingClientPos = null;
  var rafId = null;
  var dragStacked = false;
  var dragOrigin = 0;
  var dragTotal = 0;
  var lastSplitterDown = 0;

  function onPointerDown(e) {
    /* En CEP, preventDefault() sobre el primer mousedown puede impedir que
       Chromium emita despues el evento `dblclick`. `detail` ya contiene el
       numero de pulsaciones y nos permite reconocer la segunda antes de
       iniciar otro arrastre, manteniendo el gesto fiable en After Effects. */
    var now = Date.now();
    if (e.detail > 1 || (lastSplitterDown && now - lastSplitterDown < 420)) {
      lastSplitterDown = 0;
      restoreSmartLayout(e);
      return;
    }
    lastSplitterDown = now;
    e.preventDefault();
    dragging = true;
    dragStacked = isStacked();

    var bodyRect = body.getBoundingClientRect();
    dragOrigin = dragStacked ? bodyRect.top : bodyRect.left;
    dragTotal = dragStacked ? bodyRect.height : bodyRect.width;

    splitter.classList.add("dragging");
    document.body.classList.add("splitter-dragging");
    if (dragStacked) document.body.classList.add("stacked-drag");

    document.addEventListener("mousemove", onMove);
    document.addEventListener("mouseup", onUp);
    window.addEventListener("blur", onUp);
  }

  function onMove(e) {
    pendingClientPos = dragStacked ? e.clientY : e.clientX;
    if (rafId === null) rafId = requestAnimationFrame(flush);
  }

  function flush() {
    rafId = null;
    if (!dragging || pendingClientPos === null || dragTotal <= 0) return;
    var ratio = (pendingClientPos - dragOrigin) / dragTotal;
    ratio = setRatio(ratio);
    setStoredRatio(ratio);
  }

  function onUp() {
    if (!dragging) return;
    dragging = false;
    pendingClientPos = null;
    if (rafId !== null) { cancelAnimationFrame(rafId); rafId = null; }
    document.removeEventListener("mousemove", onMove);
    document.removeEventListener("mouseup", onUp);
    window.removeEventListener("blur", onUp);
    splitter.classList.remove("dragging");
    document.body.classList.remove("splitter-dragging", "stacked-drag");
  }

  splitter.addEventListener("mousedown", onPointerDown);

  /* El segundo divisor. Repite la mecanica del primero —desactivar los
     iframes mientras se arrastra, y un rAF por cuadro— porque el problema es
     el mismo: sin eso el raton deja de existir en cuanto cruza a un panel.
     Lo unico distinto es lo que se calcula: aqui, la distancia entre el borde
     izquierdo de la ventana del medio y el cursor. */
  var drag2 = false;
  var pending2 = null;
  var raf2 = null;
  var drag2Stacked = false;
  var drag2Origin = 0;
  var lastSplitter2Down = 0;

  function onDown2(e) {
    var now = Date.now();
    if (e.detail > 1 || (lastSplitter2Down && now - lastSplitter2Down < 420)) {
      lastSplitter2Down = 0;
      restoreSmartLayout(e);
      return;
    }
    lastSplitter2Down = now;
    e.preventDefault();
    drag2 = true;
    drag2Stacked = isStacked();
    var mid = midPane();
    if (!mid) { drag2 = false; return; }
    var r = mid.getBoundingClientRect();
    drag2Origin = drag2Stacked ? r.top : r.left;

    splitter2.classList.add("dragging");
    document.body.classList.add("splitter-dragging");
    if (drag2Stacked) document.body.classList.add("stacked-drag");

    document.addEventListener("mousemove", onMove2);
    document.addEventListener("mouseup", onUp2);
    window.addEventListener("blur", onUp2);
  }

  function onMove2(e) {
    pending2 = drag2Stacked ? e.clientY : e.clientX;
    if (raf2 === null) raf2 = requestAnimationFrame(flush2);
  }

  function flush2() {
    raf2 = null;
    if (!drag2 || pending2 === null) return;
    var px = setQuickItSize(pending2 - drag2Origin);
    storeQuickItSize(px);
  }

  function onUp2() {
    if (!drag2) return;
    drag2 = false;
    pending2 = null;
    if (raf2 !== null) { cancelAnimationFrame(raf2); raf2 = null; }
    document.removeEventListener("mousemove", onMove2);
    document.removeEventListener("mouseup", onUp2);
    window.removeEventListener("blur", onUp2);
    splitter2.classList.remove("dragging");
    document.body.classList.remove("splitter-dragging", "stacked-drag");
  }

  splitter2.addEventListener("mousedown", onDown2);

  /* Un doble clic en cualquiera de los dos divisores descarta solamente las
     medidas de la orientacion actual. El orden de los paneles, su visibilidad y
     los ajustes de la otra orientacion permanecen intactos. */
  function restoreSmartLayout(e) {
    if (e) e.preventDefault();
    var splitKey = isStacked() ? STORE_SPLIT_V : STORE_SPLIT_H;
    var middleKey = isStacked() ? STORE_QI_V : STORE_QI_H;
    try {
      localStorage.removeItem(splitKey);
      localStorage.removeItem(middleKey);
    } catch (err) {}
    splitter.classList.remove("smart-reset");
    splitter2.classList.remove("smart-reset");
    void splitter.offsetWidth;
    splitter.classList.add("smart-reset");
    splitter2.classList.add("smart-reset");
    applySizes();
  }

  splitter.addEventListener("dblclick", restoreSmartLayout);
  splitter2.addEventListener("dblclick", restoreSmartLayout);

  // Los interruptores de Ajustes y del menu rapido escriben el mismo estado.
  (function () {
    for (var i = 0; i < PANE_IDS.length; i++) {
      (function (id) {
        function bind(map) {
          var chk = document.getElementById(map[id]);
          if (!chk) return;
          chk.addEventListener("change", function () {
          /* Apagar el ultimo no se guarda: se devuelve el interruptor a su
             sitio y no pasa nada mas. La casilla del ultimo ya viene
             deshabilitada, asi que esto es la red de debajo —por si llega
             desde un perfil, desde un tema o desde el teclado—. */
            if (!chk.checked && countOn() <= 1) {
              chk.checked = true;
              return;
            }
            try { localStorage.setItem(PANE_OFF[id], chk.checked ? "0" : "1"); } catch (e) {}
            applyPanesVisible();
          });
        }
        bind(PANE_CHECK);
        bind(PANE_MENU_CHECK);
      })(PANE_IDS[i]);
    }
  })();
  applyPanesVisible();
  layoutPanes();

  /* ----------------------------------------------------------------
     Recoger el arrastre que empieza dentro de un panel

     El gesto nace en la cabecera de un <iframe> (shell/js/pane-drag.js) y
     llega aqui como mensajes. Las coordenadas vienen relativas a su propio
     documento, asi que hay que sumarles donde esta ese iframe: lo mismo que
     hace el fondo animado con el puntero.

     Lo que se ve mientras dura: el panel que viaja se apaga y el que va a
     recibirlo se marca por el borde. Nada se mueve hasta soltar, porque
     reacomodar en vivo con tres paneles hace que el destino salte bajo el
     cursor justo cuando uno va a soltar.
     ---------------------------------------------------------------- */
  var paneDragFrom = null;   // "easeit" | "quickit" | "alignit"
  var paneDragOver = null;
  var paneDragFocus = document.createElement("div");
  var paneDragFocusTimer = null;
  var paneSettleTimer = null;
  paneDragFocus.className = "pane-reorder-focus";
  paneDragFocus.setAttribute("aria-hidden", "true");
  document.body.appendChild(paneDragFocus);

  /* Un solo marco viaja entre las ventanas, en lugar de encender y apagar un
     borde distinto en cada una. Como se animan left/top/width/height con la
     misma curva del recorrido inicial, el rectangulo parece transformarse
     para adoptar la forma de cada destino, incluso al cambiar entre la
     disposicion horizontal y la apilada. */
  function placePaneDragFocus(panel, instant) {
    var el = PANES[panel];
    if (!el || el.hidden) return hidePaneDragFocus();
    if (paneDragFocusTimer !== null) {
      clearTimeout(paneDragFocusTimer);
      paneDragFocusTimer = null;
    }
    var r = el.getBoundingClientRect(), pad = 4;
    if (instant) paneDragFocus.classList.add("instant");
    paneDragFocus.style.left = Math.round(r.left + pad) + "px";
    paneDragFocus.style.top = Math.round(r.top + pad) + "px";
    paneDragFocus.style.width = Math.max(8, Math.round(r.width - pad * 2)) + "px";
    paneDragFocus.style.height = Math.max(8, Math.round(r.height - pad * 2)) + "px";
    paneDragFocus.classList.add("active");
    if (instant) requestAnimationFrame(function () {
      paneDragFocus.classList.remove("instant");
    });
  }

  function hidePaneDragFocus(delay) {
    if (paneDragFocusTimer !== null) clearTimeout(paneDragFocusTimer);
    paneDragFocusTimer = setTimeout(function () {
      paneDragFocus.classList.remove("active");
      paneDragFocusTimer = null;
    }, delay || 0);
  }

  function capturePaneRects() {
    var out = {}, key, el;
    for (key in PANES) {
      if (!PANES.hasOwnProperty(key)) continue;
      el = PANES[key];
      if (el && !el.hidden) out[key] = el.getBoundingClientRect();
    }
    return out;
  }

  function stopPaneSettle() {
    if (paneSettleTimer !== null) {
      clearTimeout(paneSettleTimer);
      paneSettleTimer = null;
    }
    for (var key in PANES) {
      if (!PANES.hasOwnProperty(key) || !PANES[key]) continue;
      PANES[key].classList.remove("pane-reorder-moving");
      PANES[key].style.transition = "";
      PANES[key].style.transform = "";
      PANES[key].style.transformOrigin = "";
    }
    document.body.classList.remove("panes-settling");
  }

  /* FLIP: primero se guarda la geometria anterior; despues de cambiar el
     orden se aplica la transformacion inversa y se anima hasta la geometria
     real. Asi se mueve la ventana completa —contenido incluido— sin recargar
     ningun iframe ni interpolar flex-basis cuadro por cuadro. */
  function animatePaneSettle(before) {
    var moving = [], key, el, oldRect, nextRect, dx, dy, sx, sy;
    stopPaneSettle();
    for (key in PANES) {
      if (!PANES.hasOwnProperty(key)) continue;
      el = PANES[key]; oldRect = before[key];
      if (!el || el.hidden || !oldRect) continue;
      nextRect = el.getBoundingClientRect();
      if (!nextRect.width || !nextRect.height) continue;
      dx = oldRect.left - nextRect.left;
      dy = oldRect.top - nextRect.top;
      sx = oldRect.width / nextRect.width;
      sy = oldRect.height / nextRect.height;
      if (Math.abs(dx) < .5 && Math.abs(dy) < .5 && Math.abs(sx - 1) < .005 && Math.abs(sy - 1) < .005) continue;
      el.style.transition = "none";
      el.style.transformOrigin = "0 0";
      el.style.transform = "translate3d(" + dx + "px," + dy + "px,0) scale(" + sx + "," + sy + ")";
      moving.push(el);
    }
    if (!moving.length) return;
    /* Fuerza el primer estado a existir antes de pedir el segundo. */
    void body.offsetWidth;
    document.body.classList.add("panes-settling");
    for (var i = 0; i < moving.length; i++) {
      moving[i].style.transition = "";
      moving[i].classList.add("pane-reorder-moving");
    }
    requestAnimationFrame(function () {
      for (var j = 0; j < moving.length; j++) moving[j].style.transform = "translate3d(0,0,0) scale(1,1)";
    });
    paneSettleTimer = setTimeout(stopPaneSettle, 380);
  }

  function paneAt(clientX, clientY) {
    var order = paneOrder();
    for (var i = 0; i < order.length; i++) {
      var el = PANES[order[i]];
      if (!el || el.hidden) continue;
      var r = el.getBoundingClientRect();
      if (clientX >= r.left && clientX <= r.right &&
          clientY >= r.top && clientY <= r.bottom) return order[i];
    }
    return null;
  }

  function paintPaneDrag() {
    for (var k in PANES) {
      if (!PANES.hasOwnProperty(k)) continue;
      PANES[k].classList.toggle("pane-dragging", k === paneDragFrom);
    }
    document.body.classList.toggle("panes-reordering", !!paneDragFrom);
  }

  function endPaneDrag(commit) {
    var movedPanel = paneDragFrom;
    var didMove = false;
    var before = null;
    if (paneDragFrom && commit && paneDragOver && paneDragOver !== paneDragFrom) {
      var a = paneOrder();
      var from = -1, to = -1, i;
      for (i = 0; i < a.length; i++) {
        if (a[i] === paneDragFrom) from = i;
        if (a[i] === paneDragOver) to = i;
      }
      if (from >= 0 && to >= 0) {
        before = capturePaneRects();
        a.splice(to, 0, a.splice(from, 1)[0]);
        setPaneOrder(a);
        animatePaneSettle(before);
        didMove = true;
      }
    }
    paneDragFrom = null;
    paneDragOver = null;
    paintPaneDrag();
    if (didMove && movedPanel) {
      /* layoutPanes ya cambio el reparto. En el siguiente cuadro las medidas
         son las definitivas y el marco termina su morph sobre la ventana que
         acaba de viajar antes de desvanecerse. */
      requestAnimationFrame(function () {
        placePaneDragFocus(movedPanel, false);
        hidePaneDragFocus(240);
      });
    } else {
      hidePaneDragFocus(0);
    }
  }

  function frameOf(panel) {
    if (panel === "easeit") return frameEaseIt;
    if (panel === "quickit") return frameQuickIt;
    if (panel === "alignit") return frameAlignIt;
    return null;
  }

  window.addEventListener("message", function (e) {
    var d = e.data;
    if (!d || d.__editkit !== "pane") return;

    if (d.type === "start") {
      /* En modo pestañas no hay otro panel visible que pueda recibir el
         reordenamiento. Ignorar el gesto evita mostrar un marco de arrastre
         que no podría terminar en ningún destino. */
      if (tabViewActive()) return;
      stopPaneSettle();
      paneDragFrom = d.panel;
      paneDragOver = null;
      paintPaneDrag();
      placePaneDragFocus(paneDragFrom, true);
      return;
    }
    if (d.type === "move" && paneDragFrom) {
      var fr = frameOf(d.panel);
      if (!fr) return;
      var r = fr.getBoundingClientRect();
      paneDragOver = paneAt(r.left + d.x, r.top + d.y);
      paintPaneDrag();
      if (paneDragOver) placePaneDragFocus(paneDragOver, false);
      else hidePaneDragFocus(80);
      return;
    }
    if (d.type === "end") { endPaneDrag(true); return; }
    if (d.type === "out") { return; }   // el cursor salio; se sigue esperando el "end"
  });

  // Si el gesto se pierde (el panel se recarga, la ventana pierde el foco), se
  // cancela en lugar de dejar dos paneles pintados para siempre.
  window.addEventListener("blur", function () { endPaneDrag(false); });
  document.addEventListener("mouseup", function () { if (paneDragFrom) endPaneDrag(true); });
  document.addEventListener("mousemove", function (e) {
    if (!paneDragFrom) return;
    paneDragOver = paneAt(e.clientX, e.clientY);
    paintPaneDrag();
    if (paneDragOver) placePaneDragFocus(paneDragOver, false);
    else hidePaneDragFocus(80);
  });

  /* ----------------------------------------------------------------
     Levantar la hoja de ajustes de un plugin por encima de todo

     Un <iframe> no puede dibujar fuera de su recuadro, asi que la hoja de
     ajustes de cada plugin se quedaba encerrada en su panel: en uno estrecho
     salia aplastada mientras al lado sobraba sitio. Lo que se hace aqui es
     estirar ese iframe —solo el iframe— hasta cubrir el panel entero, cabecera
     de EditKit incluida, mientras la hoja este abierta.

     El panel sigue en su sitio en el reparto: no cambia de tamano, no se saca
     del flujo y nadie mas se entera. Por eso se puede seguir midiendo donde
     estaba, que es lo que necesita el plugin para clavar su contenido y que no
     de un salto al abrir y otro al cerrar.
     ---------------------------------------------------------------- */
  var liftedPanel = null;

  function paneOf(panel) {
    return PANES[panel] || null;
  }

  /* Donde esta el hueco del panel y cuanto mide, en coordenadas de la ventana
     entera. El origen lo necesita el iframe estirado, porque al estirarse
     arranca justo en la esquina de la ventana.

     Y el tamano tambien se manda, aunque el marco podria medirselo solo: solo
     puede si ya lo han maquetado, y no siempre es el caso. El modal de
     bienvenida de EaseIt aparece durante el arranque de su nucleo, antes de que
     su iframe tenga tamano; alli innerWidth vale 0, la caja salia 0x0 y la
     herramienta entera desaparecia. Esta medida es de fuera y es cierta
     siempre. */
  /* EL GOLPE AL ABRIR LOS AJUSTES, Y POR QUE ERA INEVITABLE POR MENSAJE

     Esto iba en dos tiempos: el plugin pedia "estirame", el shell estiraba su
     marco, y despues le mandaba por `postMessage` las coordenadas del hueco
     para que clavara su contenido y no se moviera de sitio.

     Entre lo uno y lo otro hay al menos un fotograma, porque `postMessage` es
     asincrono. Y en ese fotograma el marco ya media el panel entero mientras la
     herramienta seguia clavada en la esquina de arriba a la izquierda: el
     contenido daba un salto hacia el borde y volvia. Eso es el golpe que se veia
     al abrir los ajustes de cualquiera de los tres, y el mismo al cerrarlos.

     No hay manera de ganar esa carrera desde el otro lado: el plugin no puede
     clavarse antes, porque hasta que el marco no se estira sus coordenadas
     estan mal, y no puede clavarse despues sin perder un fotograma.

     Asi que lo hace el shell, que puede hacer las dos cosas en la misma linea.
     Los tres marcos son del mismo origen que este documento —ya se les habla
     asi para el idioma—, de modo que se les escribe el estilo directamente y se
     estira el marco a continuacion, todo en el mismo bloque: el navegador ve un
     solo cambio y pinta un solo fotograma, que ya es el bueno.

     El mensaje se sigue mandando. Sirve de respaldo por si algun dia el marco
     no se deja tocar por dentro, y de correccion cuando el panel de Adobe
     cambia de tamano con los ajustes abiertos. */

  function rootOf(panel) {
    var fr = frameOf(panel), doc = null;
    try { doc = fr && fr.contentDocument; } catch (e) { return null; }
    if (!doc) return null;
    return doc.getElementById("wrapper") || doc.querySelector(".app") || null;
  }

  // Devuelve true si se pudo clavar aqui; si no, que lo intente el plugin.
  function pinRoot(panel, r) {
    var el = rootOf(panel);
    if (!el) return false;
    if (!r) {
      el.style.position = "";
      el.style.left = ""; el.style.top = "";
      el.style.width = ""; el.style.height = "";
      return true;
    }
    el.style.position = "absolute";
    el.style.left = Math.round(r.left) + "px";
    el.style.top = Math.round(r.top) + "px";
    el.style.width = Math.round(r.width) + "px";
    el.style.height = Math.round(r.height) + "px";
    return true;
  }

  function sendGeom(panel, pinned) {
    var pane = paneOf(panel), fr = frameOf(panel);
    if (!pane || !fr || !fr.contentWindow) return;
    var r = pane.getBoundingClientRect();
    try {
      fr.contentWindow.postMessage({
        __editkit: "lift", type: "geom", pinned: !!pinned,
        x: Math.round(r.left), y: Math.round(r.top),
        w: Math.round(r.width), h: Math.round(r.height)
      }, "*");
    } catch (e) {}
  }

  function liftOn(panel) {
    var pane = paneOf(panel);
    if (!pane || liftedPanel === panel) return;
    if (liftedPanel) liftOff(liftedPanel);
    liftedPanel = panel;

    /* Medir, clavar y estirar, en este orden y sin soltar el hilo. La medida
       se toma antes de estirar porque despues el hueco ya no es el hueco. */
    var pinned = pinRoot(panel, pane.getBoundingClientRect());
    pane.classList.add("pane-lifted");
    body.classList.add("pane-lifted-on");

    sendGeom(panel, pinned);
  }

  function liftOff(panel) {
    var pane = paneOf(panel);
    if (!pane || liftedPanel !== panel) return;
    liftedPanel = null;

    // Y al reves, tambien de una sola vez: encoger y soltar.
    pane.classList.remove("pane-lifted");
    body.classList.remove("pane-lifted-on");
    var pinned = pinRoot(panel, null);

    var fr = frameOf(panel);
    if (fr && fr.contentWindow) {
      try { fr.contentWindow.postMessage({ __editkit: "lift", type: "down", pinned: pinned }, "*"); } catch (e) {}
    }
  }

  window.addEventListener("message", function (e) {
    var d = e.data;
    if (!d || d.__editkit !== "lift") return;
    if (d.type === "on") liftOn(d.panel);
    else if (d.type === "off") liftOff(d.panel);
  });

  /* Si el panel se recarga con la hoja abierta —lo hace al cambiar de idioma, y
     lo hace Adobe al mover la extension de sitio—, el "off" no llega nunca y el
     marco se queda estirado tapandolo todo, sin nada dentro que lo cierre. El
     documento nuevo no sabe nada de esto, asi que se cierra desde aqui. */
  (function liftGuard() {
    var frames = { easeit: frameEaseIt, quickit: frameQuickIt, alignit: frameAlignIt };
    for (var k in frames) {
      if (!frames.hasOwnProperty(k) || !frames[k]) continue;
      (function (panel, fr) {
        fr.addEventListener("load", function () { liftOff(panel); });
      })(k, frames[k]);
    }
  })();

  /* Si cambia el tamano del panel de Adobe con los ajustes abiertos, el hueco
     del plugin se mueve y el contenido clavado dejaria de coincidir. Se vuelve
     a medir: el panel nunca salio del flujo, asi que sigue diciendo la verdad. */
  window.addEventListener("resize", function () {
    if (!liftedPanel) return;
    /* Se vuelve a medir el hueco. Hay que quitar el estirado un instante para
       medirlo: el panel nunca salio del flujo, pero su marco si, y con el
       puesto la medida sale de lo estirado. */
    var pane = paneOf(liftedPanel);
    var pinned = false;
    if (pane) {
      pane.classList.remove("pane-lifted");
      var r = pane.getBoundingClientRect();
      pinned = pinRoot(liftedPanel, r);
      pane.classList.add("pane-lifted");
    }
    sendGeom(liftedPanel, pinned);
  });

  /* Una puerta minuscula para lo que vive fuera de este archivo. Las pistas
     contextuales la usan para ofrecer soluciones de un clic sin duplicar la
     logica del shell ni escribir claves de almacenamiento por su cuenta. */
  window.EditKitShell = {
    setSplit: function (r) {
      var v = setRatio(r);
      setStoredRatio(v);
      return v;
    },
    getSplit: function () { return effectiveRatio(visiblePanes()); },
    setToolView: function (mode) {
      if (["all", "tabs", "smart"].indexOf(mode) < 0) return false;
      toolViewMode = mode;
      try { localStorage.setItem(STORE_TOOL_VIEW, mode); } catch (e) {}
      var select = document.getElementById("toolViewSelect");
      if (select) select.value = mode;
      applyToolView(true);
      return true;
    },
    balancePanels: function () {
      restoreSmartLayout();
      return true;
    },
    setPaneVisible: function (id, visible) {
      if (!PANE_OFF[id] || !paneAvailable(id)) return false;
      if (!visible && onlyOne(id)) return false;
      try { localStorage.setItem(PANE_OFF[id], visible ? "0" : "1"); } catch (e) {}
      applyPanesVisible();
      return paneOn(id) === !!visible;
    },
    highlightPaneHeaders: function () {
      closePanelVisibilityMenu();
      document.body.classList.remove("ek-context-reorder-ready");
      void document.body.offsetWidth;
      document.body.classList.add("ek-context-reorder-ready");
      setTimeout(function () { document.body.classList.remove("ek-context-reorder-ready"); }, 2600);
      return true;
    },
    focusQuickItSearch: function () {
      if (!paneAvailable("quickit")) return false;
      if (!paneOn("quickit")) {
        try { localStorage.setItem(PANE_OFF.quickit, "0"); } catch (e) {}
        applyPanesVisible();
      }
      if (tabViewActive()) selectActiveTool("quickit", true);
      var doc = null;
      try { doc = frameQuickIt && frameQuickIt.contentDocument; } catch (e2) {}
      if (!doc) return false;
      var sectionToggle = doc.getElementById("qiSec_search");
      if (sectionToggle && !sectionToggle.checked) {
        sectionToggle.checked = true;
        try { sectionToggle.dispatchEvent(new Event("change", { bubbles: true })); } catch (e3) {}
      }
      var app = doc.querySelector(".app");
      var view = doc.getElementById("qiView");
      if (app && app.getAttribute("data-view") === "cats" && view) view.click();
      setTimeout(function () {
        var input = doc.getElementById("qiLibraryInput");
        if (!input) return;
        try { input.scrollIntoView({ block: "nearest", behavior: "smooth" }); } catch (e4) { input.scrollIntoView(); }
        try { input.focus(); } catch (e5) {}
      }, 90);
      return true;
    },
    beginProfileSave: function () {
      if (window.EditKitBackdrop) window.EditKitBackdrop.open();
      var profileTab = document.getElementById("setTabProfiles");
      if (profileTab) profileTab.click();
      setTimeout(function () {
        var save = document.getElementById("profSave");
        if (save) save.click();
      }, 60);
      return true;
    },
    /* Abrir una direccion en el navegador del sistema. Lo necesita el menu del
       panel, que no tiene DOM propio donde poner un enlace: sus opciones son
       las del programa anfitrion y solo devuelven un identificador. */
    openURL: openURL
  };

  window.addEventListener("resize", applyLayoutMode);
  applyShellLanguage();
  applyLayoutMode();

  // ---- Donate popover: no pressure, just quiet options. No nags. ----
  /* Dos caminos, y el segundo tiene que poder correr.

     Estaba escrito como "si hay CSInterface, por ahi; si no, por el
     navegador", pero CSInterface se construye sin quejarse aunque el programa
     no este detras: el primer camino se tomaba siempre y fallaba dentro del
     try, y el segundo no llegaba a existir. Daba igual mientras esto solo lo
     usaran los botones de apoyo; ahora tambien lo usan las direcciones de
     "Acerca de".

     Se pregunta por el puente que inyecta el programa, que esta o no esta, y
     el respaldo cuelga fuera del primer try para que un fallo del uno deje
     correr al otro. */
  function openURL(url) {
    if (!url) return;
    try {
      if (window.__adobe_cep__ && cs) { cs.openURLInDefaultBrowser(url); return; }
    } catch (err) {}
    try { window.open(url, "_blank"); } catch (err2) {}
  }

  /* Las direcciones de la pestana "Acerca de". Delegado en el documento y no
     enganchado a cada una: el texto de esa pestana se reescribe entero cada vez
     que se cambia de idioma, y un enganche puesto sobre el enlace se iria con
     el. */
  document.addEventListener("click", function (e) {
    var el = e.target;
    while (el && el !== document.body) {
      if (el.getAttribute && el.getAttribute("data-ek-url")) {
        e.preventDefault();
        openURL(el.getAttribute("data-ek-url"));
        return;
      }
      el = el.parentNode;
    }
  });

  function closePopover() {
    donatePopover.hidden = true;
    donateBtn.classList.remove("active");
  }
  /* Al estar fuera del encabezado ya no puede colgar de su boton por CSS, asi
     que se le dan coordenadas al abrirlo. Se ancla al borde izquierdo del
     corazon y, si no cabe, se recuesta contra el borde derecho del panel. */
  function placePopover() {
    var b = donateBtn.getBoundingClientRect();
    var w = donatePopover.offsetWidth || 220;
    var left = Math.max(6, Math.min(b.left, window.innerWidth - w - 6));
    donatePopover.style.left = Math.round(left) + "px";
    donatePopover.style.top = Math.round(b.bottom + 6) + "px";
  }
  function togglePopover(e) {
    e.stopPropagation();
    var willOpen = donatePopover.hidden;
    if (willOpen) closePanelVisibilityMenu();
    donatePopover.hidden = !willOpen;
    if (willOpen) placePopover();
    donateBtn.classList.toggle("active", willOpen);
  }
  window.addEventListener("resize", function () {
    if (!donatePopover.hidden) placePopover();
  });

  /* El bloque de apoyo volvio a la barra, asi que el popover vuelve a
     abrirse y cerrarse. Se cierra al tocar fuera, con Escape, y al abrir la
     ventana de ajustes — tres formas de salir sin quedar atrapado. */
  if (donateBtn && donatePopover) {
    donatePopover.hidden = true;
    donateBtn.addEventListener("click", togglePopover);
    document.addEventListener("click", function (e) {
      if (donatePopover.hidden) return;
      if (donateBtn.contains(e.target) || donatePopover.contains(e.target)) return;
      closePopover();
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closePopover();
    });
    // abrir un enlace de donacion tambien lo cierra
    donatePopover.addEventListener("click", function (e) {
      if (e.target.closest && e.target.closest(".donate-option")) closePopover();
    });
  }

  /* El selector de paneles se comporta como una pequena paleta: cambiar una
     casilla no lo cierra, de forma que se pueden elegir dos o tres
     herramientas en una sola visita. Se cierra solo de manera deliberada. */
  function closePanelVisibilityMenu() {
    if (!panelVisibilityPopover || !panelVisibilityBtn) return;
    panelVisibilityPopover.hidden = true;
    panelVisibilityBtn.classList.remove("active");
    panelVisibilityBtn.setAttribute("aria-expanded", "false");
  }
  function placePanelVisibilityMenu() {
    if (!panelVisibilityPopover || !panelVisibilityBtn) return;
    var b = panelVisibilityBtn.getBoundingClientRect();
    var w = panelVisibilityPopover.offsetWidth || 206;
    var left = Math.max(6, Math.min(b.right - w, window.innerWidth - w - 6));
    panelVisibilityPopover.style.left = Math.round(left) + "px";
    panelVisibilityPopover.style.top = Math.round(b.bottom + 6) + "px";
  }
  function togglePanelVisibilityMenu(e) {
    e.stopPropagation();
    var willOpen = panelVisibilityPopover.hidden;
    if (willOpen) closePopover();
    panelVisibilityPopover.hidden = !willOpen;
    panelVisibilityBtn.classList.toggle("active", willOpen);
    panelVisibilityBtn.setAttribute("aria-expanded", willOpen ? "true" : "false");
    if (willOpen) {
      applyPanesVisible();
      placePanelVisibilityMenu();
    }
  }
  if (panelVisibilityBtn && panelVisibilityPopover) {
    panelVisibilityPopover.hidden = true;
    panelVisibilityBtn.addEventListener("click", togglePanelVisibilityMenu);
    document.addEventListener("click", function (e) {
      if (panelVisibilityPopover.hidden) return;
      if (panelVisibilityBtn.contains(e.target) || panelVisibilityPopover.contains(e.target)) return;
      closePanelVisibilityMenu();
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closePanelVisibilityMenu();
    });
    window.addEventListener("resize", function () {
      if (!panelVisibilityPopover.hidden) placePanelVisibilityMenu();
    });
  }

  [
    ["donatePaypal", DONATE_LINKS.paypal],
    ["donateKofi", DONATE_LINKS.kofi],
    ["donateBmc", DONATE_LINKS.bmc],
    ["donateSite", DONATE_LINKS.site]
  ].forEach(function (pair) {
    var el = document.getElementById(pair[0]);
    var url = pair[1];
    el.href = url;
    el.addEventListener("click", function (e) {
      e.preventDefault();
      openURL(url);
    });
  });

  // ==========================================================
  // Settings window — one entry point for language, backdrop and about
  // ==========================================================
  // The window itself is the backdrop sheet, reused: it already had the whole
  // Aura / Color / Imagen UI and its own open/close. This only adds the outer
  // pair of tabs on top and points the header gear at it.
  var settingsBtn = document.getElementById("shellSettingsBtn");
  if (settingsBtn) {
    settingsBtn.addEventListener("click", function (e) {
      e.stopPropagation();
      closePanelVisibilityMenu();
      var overlay = document.getElementById("bdOverlay");
      var open = overlay && overlay.hidden;
      if (window.EditKitBackdrop) {
        if (open) window.EditKitBackdrop.open(); else window.EditKitBackdrop.close();
      }
      settingsBtn.classList.toggle("active", !!open);
    });
  }

  // The two dropdowns drive the old buttons rather than duplicating their
  // logic: a change clicks #langToggle / #layoutToggle as many times as it
  // takes to land on the chosen value. Everything downstream — persistence,
  // broadcasting the language into both panes, the layout icon state — keeps
  // running through the code that already did it.
  var langSelect = document.getElementById("langSelect");
  if (langSelect) {
    langSelect.value = lang;
    langSelect.addEventListener("change", function () {
      if (langSelect.value !== lang) langToggle.click();   // two languages: one toggle
    });
  }

  /* CUANTO TARDA EN SALIR LA AYUDA

     El globo lo pinta shell/js/tooltip.js, que lee esta clave en cada gesto
     —es una lectura de microsegundos y ahorra tener que avisar a tres
     ventanas—. Aqui solo se escribe.

     "No mostrarla" es una opcion de verdad y no un gesto de cortesia: quien se
     sabe el panel de memoria no necesita que le expliquen cada boton cada vez
     que cruza la rejilla con el cursor. */
  var STORE_TIPS = "editkit_tips";
  var tipsSelect = document.getElementById("tipsSelect");
  if (tipsSelect) {
    var saved = null;
    try { saved = localStorage.getItem(STORE_TIPS); } catch (e) {}
    if (saved) tipsSelect.value = saved;
    tipsSelect.addEventListener("change", function () {
      try { localStorage.setItem(STORE_TIPS, tipsSelect.value); } catch (e2) {}
      // Si estaba uno abierto, se cierra: el ajuste nuevo manda ya.
      try { if (window.EditKitTip) window.EditKitTip.hide(); } catch (e3) {}
    });
  }

  var performanceToggle = document.getElementById("performanceToggle");
  if (performanceToggle) {
    performanceToggle.checked = performanceMode;
    performanceToggle.addEventListener("change", function () {
      setPerformanceMode(performanceToggle.checked, true);
    });
  }
  setPerformanceMode(performanceMode, false);

  var LAYOUT_ORDER = ["auto", "horizontal", "vertical"];
  var toolViewSelect = document.getElementById("toolViewSelect");
  if (toolViewSelect) {
    toolViewSelect.value = toolViewMode;
    toolViewSelect.addEventListener("change", function () {
      toolViewMode = toolViewSelect.value;
      try { localStorage.setItem(STORE_TOOL_VIEW, toolViewMode); } catch (e) {}
      applyToolView(true);
    });
  }

  Array.prototype.forEach.call(toolTabButtons, function (button) {
    button.addEventListener("click", function () {
      selectActiveTool(button.getAttribute("data-tool"), true);
    });
    button.addEventListener("keydown", function (e) {
      if (["ArrowLeft", "ArrowRight", "Home", "End"].indexOf(e.key) < 0) return;
      var shown = [];
      for (var i = 0; i < toolTabButtons.length; i++) if (!toolTabButtons[i].hidden) shown.push(toolTabButtons[i]);
      if (!shown.length) return;
      var at = shown.indexOf(button);
      if (e.key === "Home") at = 0;
      else if (e.key === "End") at = shown.length - 1;
      else at = (at + (e.key === "ArrowRight" ? 1 : -1) + shown.length) % shown.length;
      e.preventDefault();
      shown[at].focus();
      shown[at].click();
    });
  });

  var layoutSelect = document.getElementById("layoutSelect");
  if (layoutSelect) {
    layoutSelect.value = layoutMode;
    layoutSelect.addEventListener("change", function () {
      // Read the target once. refreshLayoutToggleUI writes the select back on
      // every click, so reading it inside the loop would make the destination
      // chase the current value and stop one step short.
      var want = layoutSelect.value, guard = 0;
      while (layoutMode !== want && guard++ < LAYOUT_ORDER.length) layoutToggle.click();
      layoutSelect.value = layoutMode;
    });
  }

  // keep both selects honest if the value changes from anywhere else
  var _origApplyLang = applyShellLanguage;
  applyShellLanguage = function () {
    _origApplyLang();
    if (langSelect) langSelect.value = lang;
    if (toolViewSelect) toolViewSelect.value = toolViewMode;
  };
  var _origRefreshLayout = refreshLayoutToggleUI;
  refreshLayoutToggleUI = function () {
    _origRefreshLayout();
    if (layoutSelect) layoutSelect.value = layoutMode;
  };

  var setTabs = document.querySelectorAll(".set-tab");
  function openSettingsPane(target) {
    Array.prototype.forEach.call(setTabs, function (tab) {
      tab.classList.toggle("active", tab.getAttribute("data-pane") === target);
    });
    Array.prototype.forEach.call(document.querySelectorAll(".set-pane"), function (pane) {
      pane.hidden = pane.getAttribute("data-set-pane") !== target;
    });
  }

  Array.prototype.forEach.call(setTabs, function (tab) {
    tab.addEventListener("click", function () {
      openSettingsPane(tab.getAttribute("data-pane"));
    });
  });

  [["communityDiscordCard", "discord"], ["communityTelegramCard", "telegram"]].forEach(function (pair) {
    var card = document.getElementById(pair[0]);
    var url = COMMUNITY_LINKS[pair[1]];
    if (card && url) card.setAttribute("data-ek-url", url);
  });

  var suggestionsBtn = document.getElementById("setAboutSuggestions");
  if (suggestionsBtn) suggestionsBtn.addEventListener("click", function () {
    openSettingsPane("community");
    if (window.EditKitFeedback) window.EditKitFeedback.focusMessage();
  });

  // keep the gear in step when the sheet is closed by its ✕, by Escape or by
  // clicking the scrim — all of which live in backdrop.js
  /* ----------------------------------------------------------------
     AlignIt is After Effects only: it drives layers, anchor points and
     comp-relative alignment, none of which Premiere has. It used to load in
     Premiere anyway and sit there taking half the panel while answering
     nothing, so there it is not shown at all and EaseIt gets the whole width.

     Done here rather than by hiding it inside its own iframe: the pane, the
     splitter and the layout maths all live in this document, and leaving an
     empty pane in the flex row would still reserve its space.
     ---------------------------------------------------------------- */
  function hostApp() {
    try { return String(new CSInterface().getHostEnvironment().appName || ""); }
    catch (e) { return ""; }
  }

  function applyHostScope() {
    if (hostApp() !== "PPRO") return;
    document.body.classList.add("host-ppro");
    paneAlignIt.hidden = true;
    splitter.hidden = true;
    // Las herramientas de la ventana del medio son de After Effects, como
    // AlignIt: en Premiere se va con el, y su interruptor con ella.
    paneQuickIt.hidden = true;
    splitter2.hidden = true;
    /* En Premiere solo hay EaseIt, asi que los tres interruptores de
       visibilidad no tienen nada que gobernar: se van los tres, no solo el de
       QuickIt. Dejar dos casillas que no hacen nada es peor que no tenerlas. */
    var ids = ["easeitToggle", "quickitToggle", "alignitToggle"];
    for (var vi = 0; vi < ids.length; vi++) {
      var f = document.getElementById(ids[vi]);
      if (f && f.parentNode) f.parentNode.hidden = true;
    }
    var panesBox = document.getElementById("setPanesBox");
    if (panesBox) panesBox.hidden = true;
    if (panelVisibilityBtn) panelVisibilityBtn.hidden = true;
    if (panelVisibilityPopover) panelVisibilityPopover.hidden = true;
    paneEaseIt.style.flex = "1 1 auto";
    // the orientation control has nothing left to orient
    var field = document.getElementById("layoutField");
    if (field) field.hidden = true;
    var viewField = document.getElementById("toolViewField");
    if (viewField) viewField.hidden = true;
    applyToolView(false);
  }
  applyHostScope();

  /* ----------------------------------------------------------------
     Easter egg: tres toques sobre el nombre revelan el logo, centrado en la
     barra, y se desvanece solo. La cuenta se reinicia si pasa demasiado
     tiempo entre toques, para que no se dispare por tres clics sueltos a lo
     largo de una sesion.
     ---------------------------------------------------------------- */
  var shellTitle = document.getElementById("shellTitle");
  var shellBrand = document.getElementById("shellBrand");
  if (shellTitle && shellBrand) {
    var taps = 0, lastTap = 0, hideTimer = null;
    var TAP_WINDOW = 600;   // ms como maximo entre toque y toque
    var SHOW_MS = 2600;     // cuanto se queda el logo a la vista

    shellTitle.addEventListener("click", function () {
      /* Tres clics seguidos es tambien el gesto con el que el navegador
         selecciona un parrafo: sin esto la seleccion se pintaba de azul sobre
         medio panel. El CSS ya impide seleccionar, esto limpia lo que hubiera
         quedado de un gesto que empezo fuera del encabezado. */
      try {
        var sel = window.getSelection();
        if (sel && sel.removeAllRanges) sel.removeAllRanges();
      } catch (e) {}

      var now = Date.now();
      taps = (now - lastTap < TAP_WINDOW) ? taps + 1 : 1;
      lastTap = now;
      if (taps < 3) return;
      taps = 0;

      // Queda anotado en el tablero de secretos de la bitacora.
      try { if (window.EditKitLog) window.EditKitLog.found("q3"); } catch (e2) {}

      shellBrand.classList.add("revealed");
      if (hideTimer) clearTimeout(hideTimer);
      hideTimer = setTimeout(function () {
        shellBrand.classList.remove("revealed");
        hideTimer = null;
      }, SHOW_MS);
    });
  }

  var bdOverlayEl = document.getElementById("bdOverlay");
  if (bdOverlayEl && window.MutationObserver && settingsBtn) {
    new MutationObserver(function () {
      settingsBtn.classList.toggle("active", !bdOverlayEl.hidden);
    }).observe(bdOverlayEl, { attributes: true, attributeFilter: ["hidden"] });
  }

})();
