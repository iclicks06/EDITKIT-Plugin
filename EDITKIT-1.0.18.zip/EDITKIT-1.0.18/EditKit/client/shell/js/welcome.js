/* ============================================================================
   EDITKIT — BIENVENIDA Y RECORRIDO INICIAL

   La bienvenida aparece una sola vez. Desde ella se puede iniciar un recorrido
   corto por los controles reales del panel u omitirlo. El recorrido no pulsa
   botones ni modifica el proyecto: solo desplaza, enfoca y explica. También se
   puede repetir desde Ajustes > Acerca de y desde el menú del panel.

   Todo ocurre localmente. No hay analítica, identificadores ni peticiones de red.
   ============================================================================ */
(function () {
    "use strict";

    var WELCOME_KEY = "editkit_welcomed";
    var TOUR_KEY = "editkit_tour_done_v1";

    var T = {
        es: {
            title: "Bienvenido a EDITKIT",
            leadAE: "Tres herramientas en un solo panel para animar más rápido en After Effects.",
            leadPR: "Curvas de animación para Premiere Pro, en un solo panel.",
            compat: "Premiere Pro: EaseIt · After Effects: EaseIt, AlignIt y QuickIt.",
            easeit: "Da forma a la curva de tus fotogramas clave, o elige un preset, y aplícala a todas las capas seleccionadas de una vez.",
            easeitPR: "Da forma a la curva de tus fotogramas clave, o elige un preset, y aplícala al clip seleccionado.",
            quickit: "Acciones de un clic para el tiempo, las expresiones, el texto y la entrega. La rejilla de botones la armas a tu gusto.",
            alignit: "Alinea, ancla y distribuye capas respecto a la composición o a la selección.",
            note: "El recorrido dura menos de dos minutos y no hará cambios en tu proyecto.",
            free: "Gratis, sin cuenta y sin conexión: todo se queda en tu equipo.",
            start: "Iniciar recorrido",
            skipWelcome: "Omitir por ahora",
            back: "Atrás",
            next: "Siguiente",
            finish: "Terminar",
            skip: "Salir del recorrido",
            progress: "Paso %n de %total",
            repeat: "Repetir recorrido inicial",
            repeatTitle: "Explora nuevamente las funciones principales de EditKit",
            stepsAE: [
                ["Tu espacio de trabajo", "EaseIt, QuickIt y AlignIt comparten el panel. El engranaje superior abre los ajustes generales; el engranaje de cada herramienta abre únicamente sus propios ajustes."],
                ["EaseIt: diseña el movimiento", "Arrastra los puntos de la curva para crear el easing. También puedes leer una curva existente, invertirla, guardarla o aplicarla a varios fotogramas clave."],
                ["Presets de EaseIt", "Elige una curva lista para usar, guarda las tuyas y arrastra cualquier preset para reorganizarlo. El botón ? explica el flujo completo y el engranaje abre sus ajustes."],
                ["Organiza cada herramienta", "Desde el engranaje de cada herramienta puedes ocultar y reordenar sus secciones. En el encabezado de EditKit también puedes decidir qué herramientas mostrar y arrastrar sus cabeceras para cambiar su posición."],
                ["QuickIt: tu rejilla de acciones", "Arrastra los botones para reorganizarlos, usa la pequeña muesca para cambiar su tamaño y haz clic derecho para modificar su función, nombre, color o icono."],
                ["Acciones con opciones", "Algunas acciones tienen parámetros adicionales aquí. Cambia de categoría para descubrir herramientas de tiempo, expresiones, texto, capas y exportación."],
                ["AlignIt: modo y referencia", "Alterna entre alinear capas y mover su punto de anclaje. Después elige si la referencia es la composición o las propias capas seleccionadas."],
                ["Alineación rápida", "La retícula reúne las nueve posiciones principales y sus atajos. Debajo encontrarás distribución y transformaciones para operaciones más precisas."],
                ["Ajustes generales", "Las pestañas superiores separan Personalizar, Perfiles, Comunidad y Acerca de. Aquí también puedes cambiar el idioma; la elección se aplica a los tres paneles."],
                ["Enviar sugerencias", "En Ajustes > Comunidad puedes enviar ideas, informar de un problema o contar qué mejorarías. Tus comentarios ayudan a decidir las próximas funciones de EditKit."]
            ],
            stepsPR: [
                ["EaseIt en Premiere Pro", "En Premiere, EditKit muestra únicamente EaseIt: una herramienta compacta para dar forma al movimiento del clip seleccionado."],
                ["Diseña la curva", "Arrastra los puntos, escribe valores precisos o elige una fórmula. Puedes leer, invertir, guardar y reutilizar curvas."],
                ["Aplicación en Premiere", "Elige la propiedad y la calidad antes de aplicar. True Handles puede escribir manejadores Bézier reales cuando el flujo lo requiere."],
                ["Presets de EaseIt", "Usa las curvas incluidas o guarda las tuyas en colecciones. Arrástralas para reorganizarlas; también puedes importarlas y exportarlas sin perder el orden."],
                ["Organiza EaseIt", "Desde el engranaje de EaseIt puedes ocultar y reordenar sus secciones para dejar visibles únicamente las que utilizas."],
                ["Ajustes generales", "Las pestañas superiores separan Personalizar, Perfiles, Comunidad y Acerca de. Aquí también puedes cambiar el idioma de todo EditKit."],
                ["Enviar sugerencias", "En Ajustes > Comunidad puedes enviar ideas, informar de un problema o contar qué mejorarías. Tus comentarios ayudan a decidir las próximas funciones de EditKit."]
            ]
        },
        en: {
            title: "Welcome to EDITKIT",
            leadAE: "Three tools in one panel to animate faster in After Effects.",
            leadPR: "Animation curves for Premiere Pro, in one panel.",
            compat: "Premiere Pro: EaseIt · After Effects: EaseIt, AlignIt and QuickIt.",
            easeit: "Shape the curve of your keyframes, or pick a preset, and apply it to every selected layer at once.",
            easeitPR: "Shape the curve of your keyframes, or pick a preset, and apply it to the selected clip.",
            quickit: "One-click actions for timing, expressions, text and delivery. You build the button grid your way.",
            alignit: "Align, anchor and distribute layers against the composition or the selection.",
            note: "The tour takes less than two minutes and will not change your project.",
            free: "Free, no account and no connection: everything stays on your computer.",
            start: "Start tour",
            skipWelcome: "Skip for now",
            back: "Back",
            next: "Next",
            finish: "Finish",
            skip: "Exit tour",
            progress: "Step %n of %total",
            repeat: "Replay initial tour",
            repeatTitle: "Explore EditKit's main features again",
            stepsAE: [
                ["Your workspace", "EaseIt, QuickIt and AlignIt share the panel. The top gear opens general settings; each tool's gear opens settings for that tool only."],
                ["EaseIt: shape the motion", "Drag the curve points to create easing. You can also read an existing curve, invert it, save it or apply it to several keyframes."],
                ["EaseIt presets", "Pick a ready-made curve, save your own and drag any preset to reorder it. The ? button explains the full workflow and the gear opens its settings."],
                ["Organise each tool", "Each tool's gear lets you hide and reorder its sections. In the EditKit header you can also choose which tools are visible and drag their headers to rearrange them."],
                ["QuickIt: your action grid", "Drag buttons to reorder them, use the small handle to resize them, and right-click to change their function, name, colour or icon."],
                ["Actions with options", "Some actions expose extra parameters here. Switch categories to find timing, expression, text, layer and delivery tools."],
                ["AlignIt: mode and target", "Switch between aligning layers and moving their anchor point. Then choose whether the reference is the composition or the selected layers."],
                ["Fast alignment", "The reticle groups the nine main positions and their shortcuts. Distribution and transform tools live just below it."],
                ["General settings", "The top tabs separate Customise, Profiles, Community and About. You can also change the language here; the choice applies to all three tools."],
                ["Send suggestions", "In Settings > Community you can share ideas, report a problem or explain what you would improve. Your feedback helps shape EditKit's next features."]
            ],
            stepsPR: [
                ["EaseIt in Premiere Pro", "In Premiere, EditKit shows EaseIt only: a compact tool for shaping the motion of the selected clip."],
                ["Shape the curve", "Drag the points, enter precise values or choose a formula. You can read, invert, save and reuse curves."],
                ["Apply in Premiere", "Choose the property and quality before applying. True Handles can write real Bézier handles when your workflow needs them."],
                ["EaseIt presets", "Use the included curves or save yours in collections. Drag them to reorder them, and import or export them without losing that order."],
                ["Organise EaseIt", "EaseIt's gear lets you hide and reorder its sections so only the controls you use remain visible."],
                ["General settings", "The top tabs separate Customise, Profiles, Community and About. You can also change the language for all of EditKit here."],
                ["Send suggestions", "In Settings > Community you can share ideas, report a problem or explain what you would improve. Your feedback helps shape EditKit's next features."]
            ]
        }
    };

    var ICONS = window.EditKitToolIcons || {};
    var welcome = null, tour = null, stepIndex = 0, lastFocus = null;
    var tourOpenedSettings = false;
    var savedScroll = {};

    var AE_TARGETS = [
        { shell: "#shellBody" },
        { frame: "frameEaseIt", selector: ".graph-box", fallback: "#paneEaseIt" },
        { frame: "frameEaseIt", selector: "#presetsSection", fallback: "#paneEaseIt" },
        { frame: "frameEaseIt", selector: "#settingsBtn", fallback: "#paneEaseIt" },
        { frame: "frameQuickIt", selector: "#qiGrid", fallback: "#paneQuickIt" },
        { frame: "frameQuickIt", selector: "#qiZone", fallback: "#paneQuickIt" },
        { frame: "frameAlignIt", selector: ".mode-bar", fallback: "#paneAlignIt" },
        { frame: "frameAlignIt", selector: ".reticle-card", fallback: "#paneAlignIt" },
        { shell: "#shellSettingsBtn" },
        { shell: "#feedbackForm .feedback-panel-head", settingsPane: "community" }
    ];
    var PR_TARGETS = [
        { shell: "#paneEaseIt" },
        { frame: "frameEaseIt", selector: ".graph-box", fallback: "#paneEaseIt" },
        { frame: "frameEaseIt", selector: "#applySection", fallback: "#paneEaseIt" },
        { frame: "frameEaseIt", selector: "#presetsSection", fallback: "#paneEaseIt" },
        { frame: "frameEaseIt", selector: "#settingsBtn", fallback: "#paneEaseIt" },
        { shell: "#shellSettingsBtn" },
        { shell: "#feedbackForm .feedback-panel-head", settingsPane: "community" }
    ];

    function lang() {
        var l = "es";
        try { l = localStorage.getItem("editkit_lang") || "es"; } catch (e) {}
        return T[l] ? l : "es";
    }
    function text() { return T[lang()]; }
    function isPremiere() { return document.body.classList.contains("host-ppro"); }
    function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }
    function tool(id, name, copy) {
        return '<li class="ek-welcome-tool"><span class="ek-welcome-ico" aria-hidden="true">' +
            '<svg viewBox="0 0 24 24" width="16" height="16">' + (ICONS[id] || "") + '</svg></span>' +
            '<span class="ek-welcome-txt"><b>' + name + '</b><span>' + esc(copy) + '</span></span></li>';
    }
    function accent() {
        try { if (window.EditKitAccent && window.EditKitAccent.get) return window.EditKitAccent.get(); } catch (e) {}
        return "#49c9bd";
    }
    function inkOn(hex) {
        var h = String(hex || "").replace("#", "");
        if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
        var r = parseInt(h.substring(0, 2), 16), g = parseInt(h.substring(2, 4), 16), b = parseInt(h.substring(4, 6), 16);
        if (h.length !== 6 || !isFinite(r) || !isFinite(g) || !isFinite(b)) return "#0e1413";
        return (0.299 * r + 0.587 * g + 0.114 * b) > 150 ? "#0e1413" : "#ffffff";
    }

    function welcomeMarkup() {
        var t = text(), ppro = isPremiere();
        var tools = tool("easeit", "EaseIt", ppro ? t.easeitPR : t.easeit);
        if (!ppro) tools += tool("quickit", "QuickIt", t.quickit) + tool("alignit", "AlignIt", t.alignit);
        return '<div class="ek-welcome-card" role="dialog" aria-modal="true" aria-labelledby="ekWelcomeTitle">' +
            '<div class="ek-welcome-mark">EDITKIT</div><h2 class="ek-welcome-title" id="ekWelcomeTitle">' + esc(t.title) + '</h2>' +
            '<p class="ek-welcome-lead">' + esc(ppro ? t.leadPR : t.leadAE) + '</p><p class="ek-welcome-note">' + esc(t.compat) + '</p><ul class="ek-welcome-tools">' + tools + '</ul>' +
            '<p class="ek-welcome-note">' + esc(t.note) + '</p><p class="ek-welcome-note ek-welcome-free">' + esc(t.free) + '</p>' +
            '<div class="ek-welcome-actions"><button type="button" class="ek-welcome-skip">' + esc(t.skipWelcome) + '</button>' +
            '<button type="button" class="ek-welcome-go">' + esc(t.start) + '</button></div></div>';
    }

    function rememberWelcome() { try { localStorage.setItem(WELCOME_KEY, "1"); } catch (e) {} }
    function removeWelcome(restoreFocus) {
        if (!welcome) return;
        var node = welcome;
        welcome = null;
        document.removeEventListener("keydown", onWelcomeKey, true);
        node.classList.add("out");
        setTimeout(function () { if (node.parentNode) node.parentNode.removeChild(node); }, 160);
        if (restoreFocus) try { if (lastFocus && lastFocus.focus) lastFocus.focus(); } catch (e) {}
    }
    function skipWelcome() { rememberWelcome(); removeWelcome(true); }
    function startFromWelcome() { rememberWelcome(); removeWelcome(false); setTimeout(startTour, 180); }
    function bindWelcome() {
        if (!welcome) return;
        welcome.querySelector(".ek-welcome-go").addEventListener("click", startFromWelcome);
        welcome.querySelector(".ek-welcome-skip").addEventListener("click", skipWelcome);
        try { welcome.querySelector(".ek-welcome-go").focus(); } catch (e) {}
    }
    function onWelcomeKey(e) {
        if (!welcome) return;
        if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); skipWelcome(); return; }
        if (e.key === "Enter") { e.preventDefault(); e.stopPropagation(); startFromWelcome(); return; }
        if (e.key === "Tab") {
            var buttons = welcome.querySelectorAll("button"), first = buttons[0], last = buttons[buttons.length - 1];
            if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
            else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
        }
    }
    function show() {
        if (welcome || tour) return;
        try { if (window.EditKitTip) window.EditKitTip.hide(); } catch (e) {}
        lastFocus = document.activeElement;
        welcome = document.createElement("div");
        welcome.className = "ek-welcome";
        welcome.style.setProperty("--ek-welcome-ink", inkOn(accent()));
        welcome.innerHTML = welcomeMarkup();
        document.body.appendChild(welcome);
        bindWelcome();
        document.addEventListener("keydown", onWelcomeKey, true);
    }

    function targets() { return isPremiere() ? PR_TARGETS : AE_TARGETS; }
    function copies() { return isPremiere() ? text().stepsPR : text().stepsAE; }
    function frameDocument(id) {
        var frame = document.getElementById(id);
        try { return frame && frame.contentDocument ? frame.contentDocument : null; } catch (e) { return null; }
    }
    function rememberFrameScroll(id, doc) {
        if (savedScroll[id]) return;
        var root = doc.scrollingElement || doc.documentElement || doc.body;
        savedScroll[id] = { doc: doc, left: root ? root.scrollLeft : 0, top: root ? root.scrollTop : 0 };
    }
    function prepareTarget(spec) {
        if (spec && spec.settingsPane) {
            if (window.EditKitBackdrop && window.EditKitBackdrop.open) window.EditKitBackdrop.open();
            var tab = document.querySelector('.set-tab[data-pane="' + spec.settingsPane + '"]');
            if (tab) tab.click();
            tourOpenedSettings = true;
            return;
        }
        // Al volver desde el último paso, la ventana abierta por el recorrido
        // no debe cubrir el control explicado en el paso anterior.
        if (tourOpenedSettings && window.EditKitBackdrop && window.EditKitBackdrop.close) {
            window.EditKitBackdrop.close();
            tourOpenedSettings = false;
        }
    }
    function locate(spec) {
        var el, rect, frame, doc, inner;
        prepareTarget(spec);
        if (spec.shell) {
            el = document.querySelector(spec.shell);
            if (!el || el.hidden || getComputedStyle(el).display === "none") return null;
            if (spec.settingsPane) {
                try { el.scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" }); }
                catch (e0) { try { el.scrollIntoView(false); } catch (e1) {} }
            }
            rect = el.getBoundingClientRect();
        } else {
            frame = document.getElementById(spec.frame);
            doc = frameDocument(spec.frame);
            if (!frame || !doc || frame.closest("[hidden]") || getComputedStyle(frame).display === "none") {
                el = spec.fallback ? document.querySelector(spec.fallback) : null;
                rect = el ? el.getBoundingClientRect() : null;
            } else {
                inner = doc.querySelector(spec.selector);
                if (!inner) {
                    el = spec.fallback ? document.querySelector(spec.fallback) : frame;
                    rect = el ? el.getBoundingClientRect() : null;
                } else {
                    rememberFrameScroll(spec.frame, doc);
                    try { inner.scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" }); }
                    catch (e) { try { inner.scrollIntoView(false); } catch (e2) {} }
                    var fr = frame.getBoundingClientRect(), ir = inner.getBoundingClientRect();
                    rect = { left: Math.max(fr.left, fr.left + ir.left), top: Math.max(fr.top, fr.top + ir.top),
                             right: Math.min(fr.right, fr.left + ir.right), bottom: Math.min(fr.bottom, fr.top + ir.bottom) };
                    rect.width = rect.right - rect.left;
                    rect.height = rect.bottom - rect.top;
                }
            }
        }
        if (!rect || rect.width <= 0 || rect.height <= 0) return null;
        return rect;
    }
    function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
    function positionCard(rect) {
        if (!tour) return;
        var card = tour.querySelector(".ek-tour-card"), gap = 12, edge = 10;
        var cw = card.offsetWidth, ch = card.offsetHeight, vw = window.innerWidth, vh = window.innerHeight;
        var left = clamp(rect.left + (rect.width - cw) / 2, edge, Math.max(edge, vw - cw - edge));
        var top;
        if (vh - rect.bottom >= ch + gap + edge) top = rect.bottom + gap;
        else if (rect.top >= ch + gap + edge) top = rect.top - ch - gap;
        else top = clamp(vh - ch - edge, edge, Math.max(edge, vh - ch - edge));
        card.style.left = Math.round(left) + "px";
        card.style.top = Math.round(top) + "px";
    }
    function paintStep() {
        if (!tour) return;
        var list = targets(), copy = copies(), total = Math.min(list.length, copy.length);
        stepIndex = clamp(stepIndex, 0, Math.max(0, total - 1));
        var c = copy[stepIndex], t = text();
        tour.querySelector(".ek-tour-progress").textContent = t.progress.replace("%n", String(stepIndex + 1)).replace("%total", String(total));
        tour.querySelector(".ek-tour-title").textContent = c[0];
        tour.querySelector(".ek-tour-copy").textContent = c[1];
        tour.querySelector(".ek-tour-back").textContent = t.back;
        tour.querySelector(".ek-tour-back").disabled = stepIndex === 0;
        tour.querySelector(".ek-tour-next").textContent = stepIndex === total - 1 ? t.finish : t.next;
        tour.querySelector(".ek-tour-skip").textContent = t.skip;
        var rect = locate(list[stepIndex]);
        if (!rect) {
            if (stepIndex < total - 1) { stepIndex++; paintStep(); } else finishTour();
            return;
        }
        var pad = 6, focus = tour.querySelector(".ek-tour-focus");
        var left = clamp(rect.left - pad, 5, window.innerWidth - 10), top = clamp(rect.top - pad, 5, window.innerHeight - 10);
        var right = clamp(rect.right + pad, 10, window.innerWidth - 5), bottom = clamp(rect.bottom + pad, 10, window.innerHeight - 5);
        focus.style.left = Math.round(left) + "px"; focus.style.top = Math.round(top) + "px";
        focus.style.width = Math.max(6, Math.round(right - left)) + "px"; focus.style.height = Math.max(6, Math.round(bottom - top)) + "px";
        requestAnimationFrame(function () { positionCard({ left: left, top: top, right: right, bottom: bottom, width: right-left, height: bottom-top }); });
    }
    function tourMarkup() {
        return '<div class="ek-tour-focus" aria-hidden="true"></div><section class="ek-tour-card" role="dialog" aria-modal="true" aria-labelledby="ekTourTitle" aria-describedby="ekTourCopy">' +
            '<div class="ek-tour-progress" aria-live="polite"></div><h2 class="ek-tour-title" id="ekTourTitle"></h2><p class="ek-tour-copy" id="ekTourCopy"></p>' +
            '<div class="ek-tour-nav"><button type="button" class="ek-tour-skip"></button><span class="ek-tour-spacer"></span>' +
            '<button type="button" class="ek-tour-back"></button><button type="button" class="ek-tour-next"></button></div></section>';
    }
    function nextStep() {
        var total = Math.min(targets().length, copies().length);
        if (stepIndex >= total - 1) finishTour(); else { stepIndex++; paintStep(); }
    }
    function previousStep() { if (stepIndex > 0) { stepIndex--; paintStep(); } }
    function restoreScrolls() {
        Object.keys(savedScroll).forEach(function (id) {
            var s = savedScroll[id], root = s.doc && (s.doc.scrollingElement || s.doc.documentElement || s.doc.body);
            if (root) { root.scrollLeft = s.left; root.scrollTop = s.top; }
        });
        savedScroll = {};
    }
    function finishTour() {
        if (!tour) return;
        try { localStorage.setItem(TOUR_KEY, "1"); } catch (e) {}
        var node = tour;
        tour = null;
        document.removeEventListener("keydown", onTourKey, true);
        window.removeEventListener("resize", paintStep);
        node.classList.add("out");
        setTimeout(function () { if (node.parentNode) node.parentNode.removeChild(node); restoreScrolls(); }, 150);
        try { if (lastFocus && lastFocus.focus) lastFocus.focus(); } catch (e2) {}
    }
    function onTourKey(e) {
        if (!tour) return;
        if (e.key === "Escape") { e.preventDefault(); finishTour(); return; }
        if (e.key === "ArrowLeft") { e.preventDefault(); previousStep(); return; }
        if (e.key === "ArrowRight" || e.key === "Enter") { e.preventDefault(); nextStep(); return; }
        if (e.key === "Tab") {
            var buttons = tour.querySelectorAll("button:not([disabled])"), first = buttons[0], last = buttons[buttons.length - 1];
            if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
            else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
        }
    }
    function closeSettingsIfOpen() {
        var overlay = document.getElementById("bdOverlay"), close = document.getElementById("bdClose");
        if (overlay && !overlay.hidden && close) close.click();
    }
    function startTour() {
        if (tour) return;
        if (welcome) { rememberWelcome(); removeWelcome(false); }
        closeSettingsIfOpen();
        try { if (window.EditKitTip) window.EditKitTip.hide(); } catch (e) {}
        lastFocus = document.activeElement;
        stepIndex = 0;
        tourOpenedSettings = false;
        tour = document.createElement("div");
        tour.className = "ek-tour";
        tour.style.setProperty("--ek-welcome-ink", inkOn(accent()));
        tour.innerHTML = tourMarkup();
        document.body.appendChild(tour);
        tour.querySelector(".ek-tour-next").addEventListener("click", nextStep);
        tour.querySelector(".ek-tour-back").addEventListener("click", previousStep);
        tour.querySelector(".ek-tour-skip").addEventListener("click", finishTour);
        document.addEventListener("keydown", onTourKey, true);
        window.addEventListener("resize", paintStep);
        setTimeout(function () { paintStep(); try { tour.querySelector(".ek-tour-next").focus(); } catch (e2) {} }, 80);
    }
    function localizeRepeatButton() {
        var button = document.getElementById("setAboutTour");
        if (!button) return;
        button.textContent = text().repeat;
        button.title = text().repeatTitle;
        button.setAttribute("aria-label", text().repeatTitle);
    }
    function setLanguage() {
        localizeRepeatButton();
        if (welcome) { welcome.innerHTML = welcomeMarkup(); bindWelcome(); }
        if (tour) paintStep();
    }

    window.EditKitWelcome = { show: show, start: startTour, setLanguage: setLanguage };
    var repeat = document.getElementById("setAboutTour");
    if (repeat) repeat.addEventListener("click", startTour);
    localizeRepeatButton();

    var seen = false;
    try { seen = localStorage.getItem(WELCOME_KEY) === "1"; } catch (e) { seen = true; }
    if (!seen) setTimeout(show, 350);
})();
