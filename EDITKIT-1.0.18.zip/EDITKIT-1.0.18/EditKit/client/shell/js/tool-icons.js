/* ============================================================================
   EDITKIT — LOS TRES DIBUJOS

   Los mismos trazos que usa la bienvenida (shell/js/welcome.js) para EaseIt,
   QuickIt y AlignIt, pero desde un sitio que los tres paneles pueden cargar:
   la bienvenida vive solo en el documento del shell, y ahora cada ventana de
   ajustes -en su propio documento- tambien quiere el suyo, en la cabecera.

   Una sola copia de los trazos: cambiar un dibujo es cambiarlo aqui, y la
   bienvenida y las tres cabeceras de ajustes se enteran solas.
   ============================================================================ */
(function () {
    "use strict";

    window.EditKitToolIcons = {
        easeit: '<path d="M4 20 C 12 20, 12 4, 20 4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>' +
                '<circle cx="4" cy="20" r="1.8" fill="currentColor"/><circle cx="20" cy="4" r="1.8" fill="currentColor"/>',
        quickit: '<rect x="3.5" y="3.5" width="7" height="7" rx="1.6" fill="none" stroke="currentColor" stroke-width="1.8"/>' +
                 '<rect x="13.5" y="3.5" width="7" height="7" rx="1.6" fill="none" stroke="currentColor" stroke-width="1.8"/>' +
                 '<rect x="3.5" y="13.5" width="7" height="7" rx="1.6" fill="none" stroke="currentColor" stroke-width="1.8"/>' +
                 '<rect x="13.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor"/>',
        alignit: '<line x1="12" y1="2.5" x2="12" y2="21.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>' +
                 '<rect x="5" y="5" width="14" height="5" rx="1.4" fill="none" stroke="currentColor" stroke-width="1.8"/>' +
                 '<rect x="7.5" y="14" width="9" height="5" rx="1.4" fill="none" stroke="currentColor" stroke-width="1.8"/>'
    };

    /* El SVG entero, listo para meter en una cabecera de ajustes con
       innerHTML/insertAdjacentHTML. La bienvenida sigue armando el suyo a
       mano porque ademas necesita el envoltorio .ek-welcome-ico; esto es para
       quien solo quiere el icono. */
    window.EditKitToolIconSvg = function (id) {
        var paths = window.EditKitToolIcons[id];
        if (!paths) return "";
        return '<svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true">' + paths + '</svg>';
    };

    /* Lo cuelga delante del titulo de la cabecera de ajustes, la marca comun a
       las tres ventanas (ver shell/css/sheet.css). QuickIt y AlignIt la tienen
       en la pagina desde el principio y llaman esto una vez al arrancar; la de
       EaseIt se construye de cero cada vez que se abre, asi que la llama ella
       misma justo despues de armar su cabecera. Sin efecto si ya tiene uno o
       si esta ventana no lleva icono de herramienta. */
    window.EditKitMountToolIcon = function (id) {
        var head = document.querySelector(".ek-sheet-head");
        if (!head || head.querySelector(".ek-sheet-icon")) return;
        var svg = window.EditKitToolIconSvg(id);
        if (!svg) return;
        var span = document.createElement("span");
        span.className = "ek-sheet-icon";
        span.setAttribute("aria-hidden", "true");
        span.innerHTML = svg;
        head.insertBefore(span, head.firstChild);
    };
})();
