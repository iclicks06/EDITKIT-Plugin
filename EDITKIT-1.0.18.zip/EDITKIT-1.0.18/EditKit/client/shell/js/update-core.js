/* EditKit update validation helpers. Kept independent so they can be tested in Node. */
(function (root, factory) {
    "use strict";
    var api = factory();
    if (root) root.EditKitUpdateCore = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : null, function () {
    "use strict";

    var VERSION_RE = /^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$/;
    var SHA256_RE = /^[a-f0-9]{64}$/i;
    var EXPECTED_PRODUCT = "com.zick.editkit.panel";
    var EXPECTED_BUNDLE = "zickfx.com.editkit";

    function fail(code, message) {
        var error = new Error(message || code);
        error.code = code;
        throw error;
    }

    function parseVersion(value) {
        var match = VERSION_RE.exec(String(value || ""));
        if (!match) fail("badVersion", "Invalid stable version");
        return [parseInt(match[1], 10), parseInt(match[2], 10), parseInt(match[3], 10)];
    }

    function compareVersions(a, b) {
        var pa = parseVersion(a), pb = parseVersion(b), i;
        for (i = 0; i < 3; i++) {
            if (pa[i] !== pb[i]) return pa[i] < pb[i] ? -1 : 1;
        }
        return 0;
    }

    function releaseVersion(info) {
        if (!info || typeof info !== "object") fail("badManifest", "Manifest must be an object");
        if (info.schema !== undefined && info.schema !== 1) fail("badSchema", "Unsupported manifest schema");
        if (info.product !== undefined && info.product !== EXPECTED_PRODUCT) fail("badProduct", "Unexpected product id");
        if (info.channel !== undefined && info.channel !== "stable") fail("badChannel", "Unexpected release channel");
        parseVersion(info.version);
        return String(info.version);
    }

    function localizedReleaseNotes(info, language) {
        var source = info && info.releaseNotes;
        var exact = String(language || "").toLowerCase().replace(/_/g, "-");
        var base = exact.split("-")[0];

        if (typeof source === "string") return source;
        if (source && typeof source === "object") {
            if (exact && typeof source[exact] === "string") return source[exact];
            if (base && typeof source[base] === "string") return source[base];
            if (typeof source.en === "string") return source.en;
            if (typeof source.es === "string") return source.es;
        }
        return info && typeof info.notes === "string" ? info.notes : "";
    }

    function normalizeRelease(info, language) {
        var version = releaseVersion(info);
        var pkg = info.package && typeof info.package === "object" ? info.package : {};
        var url = pkg.url || info.url || "";
        var sha256 = pkg.sha256 || info.sha256 || "";
        var bytes = pkg.bytes !== undefined ? Number(pkg.bytes) : Number(info.bytes);

        if (!url || typeof url !== "string") fail("badUrl", "Package URL is required");
        if (!SHA256_RE.test(String(sha256))) fail("badChecksum", "A SHA-256 checksum is required");
        if (!isFinite(bytes) || bytes < 1 || Math.floor(bytes) !== bytes) fail("badSize", "Package byte size is required");

        return {
            version: version,
            url: url,
            sha256: String(sha256).toLowerCase(),
            bytes: bytes,
            notes: localizedReleaseNotes(info, language),
            releasePage: typeof info.releasePage === "string" ? info.releasePage : ""
        };
    }

    function safeZipPath(value) {
        var raw = String(value || "").replace(/\\/g, "/");
        var parts, i;
        if (!raw || /[\x00-\x1f<>:"|?*]/.test(raw) || raw.charAt(0) === "/" || /^[A-Za-z]:/.test(raw)) {
            fail("unsafeArchive", "Unsafe archive path");
        }
        parts = raw.split("/");
        for (i = 0; i < parts.length; i++) {
            if (!parts[i] || parts[i] === "." || parts[i] === "..") fail("unsafeArchive", "Unsafe archive path");
            if (/[. ]$/.test(parts[i]) || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(parts[i])) {
                fail("unsafeArchive", "Unsafe Windows archive path");
            }
        }
        return parts.join("/");
    }

    function attribute(xml, tagPattern, name) {
        var tag = tagPattern.exec(xml || "");
        var match;
        if (!tag) return "";
        match = new RegExp("\\b" + name + "=\"([^\"]+)\"").exec(tag[0]);
        return match && match[1] ? match[1] : "";
    }

    function validateBundleManifest(xml, expectedVersion) {
        xml = String(xml || "").replace(/<!--[\s\S]*?-->/g, "");
        var bundleTag = /<ExtensionManifest\b[^>]*>/i;
        var extensionTag = /<Extension\b[^>]*\bId="com\.zick\.editkit\.panel"[^>]*>/i;
        var bundleId = attribute(xml, bundleTag, "ExtensionBundleId");
        var bundleVersion = attribute(xml, bundleTag, "ExtensionBundleVersion");
        var extensionVersion = attribute(xml, extensionTag, "Version");

        if (bundleId !== EXPECTED_BUNDLE) fail("wrongBundle", "Unexpected bundle id");
        if (bundleVersion !== expectedVersion || extensionVersion !== expectedVersion) {
            fail("wrongVersion", "Package version does not match release");
        }
        return true;
    }

    return {
        EXPECTED_PRODUCT: EXPECTED_PRODUCT,
        EXPECTED_BUNDLE: EXPECTED_BUNDLE,
        parseVersion: parseVersion,
        compareVersions: compareVersions,
        releaseVersion: releaseVersion,
        localizedReleaseNotes: localizedReleaseNotes,
        normalizeRelease: normalizeRelease,
        safeZipPath: safeZipPath,
        validateBundleManifest: validateBundleManifest
    };
});
