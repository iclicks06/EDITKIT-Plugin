/* ============================================================================
   EDITKIT — EL GLOBO DE AYUDA, UNO PARA LOS TRES

   Nacio en EaseIt y se queda aqui, en el shell, porque los tres paneles lo
   necesitan igual. Lo que se ve lo describe shell/css/tooltip.css; esto solo
   decide cuando sale y donde.

   DOS MANERAS DE PEDIR UN GLOBO, Y NINGUNA HAY QUE REESCRIBIR

   EaseIt marca sus disparadores con `data-tip`. QuickIt y AlignIt llevan
   `title`, que es lo que se escribe cuando no hay nada mejor y lo que ademas
   leen los lectores de pantalla. Reescribir un centenar de atributos para
   unificarlos seria trabajo sin beneficio y una ocasion de olvidarse de uno.

   Asi que se atienden los dos. Y con `title` hay un detalle: mientras el
   atributo siga puesto, el sistema ensena TAMBIEN su propio globo un segundo
   despues, y salen dos. La solucion es copiar el texto a `data-tip` y dejar el
   `title` vacio —vacio no dispara el del sistema, pero el atributo sigue ahi
   para quien lo lea—.

   Y se vuelve a mirar cada vez, no una sola al arrancar: el diccionario
   reescribe los `title` al cambiar de idioma, y si solo se copiara una vez el
   globo se quedaria hablando en el idioma anterior. En cuanto el `title` tiene
   texto otra vez, se vuelve a copiar. Se cura solo.
   ============================================================================ */
(function () {
    "use strict";

    var MARGIN = 6;      // lo que se separa del disparador
    var EDGE = 4;        // lo que se separa del borde de la ventana

    /* CUANTO SE ESPERA ANTES DE ENSENAR NADA

       Salia al instante, y al instante es demasiado pronto. Pasar el cursor por
       encima de algo no es preguntar por ello: en una rejilla de treinta
       botones, cruzarla de un lado a otro encendia seis globos seguidos. El
       globo tiene que aparecer cuando alguien se DETIENE, que es cuando de
       verdad esta preguntando.

       Y una vez que hay uno abierto, el siguiente sale casi enseguida: quien ya
       esta leyendo descripciones esta comparando botones, y hacerle esperar otra
       vez por cada uno convierte el recorrido en una sucesion de pausas. Es el
       comportamiento de cualquier barra de herramientas decente, y se nota
       cuando no esta.

       El retardo lo elige el usuario —incluido apagarlos— y se lee del
       almacenamiento en cada gesto, no una vez al arrancar: son tres ventanas
       distintas y el ajuste vive en una cuarta. Leerlo cuesta microsegundos y
       ahorra tener que avisar a nadie. */
    var KEY = "editkit_tips";
    var DEFAULT_MS = 900;       // "Lenta": el globo no salta al cruzar la rejilla con el cursor
    var CHAIN_MS = 90;          // ya hay uno abierto: el siguiente casi no espera

    function delay() {
        var v = null;
        try { v = localStorage.getItem(KEY); } catch (e) { v = null; }
        if (v === "off") return -1;                 // apagados
        var n = parseInt(v, 10);
        if (!isFinite(n) || n < 0 || n > 4000) return DEFAULT_MS;
        return n;
    }

    /* Y cuanto dura el "ya estabas leyendo". Salir de un boton cierra el globo
       —el raton dispara `mouseout` de A antes de `mouseover` de B, siempre—,
       asi que preguntar si hay uno ABIERTO no sirve para saber si el usuario
       viene de leer otro: cuando llega a B ya no hay ninguno. Lo que se guarda
       es CUANDO se cerro el ultimo, y dentro de este margen se considera que
       sigue recorriendo la fila. */
    var GRACE_MS = 400;

    var tip = null;
    var current = null;
    var timer = null;
    var open = false;           // hay un globo a la vista ahora mismo
    var closedAt = 0;           // cuando se cerro el ultimo

    function reading() {
        return open || (Date.now() - closedAt < GRACE_MS);
    }

    function cancel() {
        if (timer) { clearTimeout(timer); timer = null; }
    }

    function ensure() {
        if (tip && tip.parentNode) return tip;
        tip = document.createElement("div");
        tip.className = "ek-tip";
        tip.setAttribute("aria-hidden", "true");
        (document.body || document.documentElement).appendChild(tip);
        return tip;
    }

    /* El texto de un disparador, venga de donde venga. Devuelve "" si no hay
       nada que ensenar. */
    function textOf(el) {
        var t = "";
        try { t = el.getAttribute("title") || ""; } catch (e) { t = ""; }
        if (t) {
            /* Llega por title: se pasa a data-tip y se calla al del sistema.

               Y se deja una copia en data-base-title porque no somos los unicos
               que leen ese atributo: commands.js compone "nombre - atajo" y,
               cuando no encuentra nada mejor, se conforma con el title. Si lo
               vaciaramos sin dejar copia, el primer globo que se ensenara
               borraria el nombre del siguiente. */
            try {
                el.setAttribute("data-tip", t);
                if (!el.getAttribute("data-base-title")) {
                    el.setAttribute("data-base-title", t);
                }
                el.setAttribute("title", "");
            } catch (e2) {}
            return t;
        }
        try { return el.getAttribute("data-tip") || ""; } catch (e3) { return ""; }
    }

    function triggerOf(node) {
        while (node && node.nodeType === 1) {
            if (node.getAttribute) {
                if (node.hasAttribute("data-tip")) return node;
                // Un title con texto tambien cuenta; uno vacio ya se paso a
                // data-tip y se habra encontrado por la rama de arriba.
                var t = node.getAttribute("title");
                if (t) return node;
            }
            node = node.parentNode;
        }
        return null;
    }

    /* data-no-tip en un antepasado: el globo no sale, pero el title nativo se
       blanquea igual —ver schedule()—, porque de eso siguen viviendo el
       buscador de comandos y la ensenanza de atajos de cada plugin. Quitar el
       globo no tiene por que quitarles el texto a ellos. */
    function noTip(node) {
        while (node && node.nodeType === 1) {
            if (node.getAttribute && node.hasAttribute("data-no-tip")) return true;
            node = node.parentNode;
        }
        return false;
    }

    /* Se agenda; no se pinta. Lo que decide si el globo sale es que el cursor
       siga ahi cuando venza el plazo. */
    function schedule(el) {
        var ms = delay();
        if (ms < 0) return;                 // apagados: no se agenda nada
        var has = !!textOf(el);             // blanquea el title nativo de paso, haya o no globo
        if (noTip(el)) return;
        if (!has) return;                   // nada que ensenar, nada que esperar
        cancel();
        current = el;
        var wait = reading() ? Math.min(ms, CHAIN_MS) : ms;
        timer = setTimeout(function () {
            timer = null;
            // Entre el gesto y el plazo el elemento puede haberse ido: la
            // rejilla se redibuja entera al cambiar de idioma o de ajuste.
            if (current !== el || !el.parentNode) return;
            paint(el);
        }, wait);
    }

    function paint(el) {
        var text = textOf(el);
        if (!text) return;

        var t = ensure();
        t.textContent = text;
        t.classList.remove("show");
        t.style.left = "-9999px";
        t.style.top = "-9999px";

        var tw = t.offsetWidth, th = t.offsetHeight;
        var r = el.getBoundingClientRect();
        var vw = window.innerWidth, vh = window.innerHeight;

        /* Debajo del disparador, que es donde no tapa lo que se acaba de
           senalar. Si abajo no cabe se pasa arriba, y si arriba tampoco se
           queda donde quepa: en un panel de 190 px de ancho eso pasa mas de lo
           que parece. `tip-up` lo pide al reves desde el HTML. */
        var up = false;
        try { up = el.classList.contains("tip-up"); } catch (e) { up = false; }

        var top = up ? (r.top - th - MARGIN) : (r.bottom + MARGIN);
        if (!up && top + th > vh - EDGE) top = r.top - th - MARGIN;
        if (up && top < EDGE) top = r.bottom + MARGIN;
        top = Math.max(EDGE, Math.min(vh - th - EDGE, top));

        // Alineado por la derecha del disparador: los botones de estos paneles
        // viven pegados al borde derecho, y asi el globo entra hacia dentro.
        var left = r.right - tw;
        left = Math.max(EDGE, Math.min(vw - tw - EDGE, left));

        t.style.top = Math.round(top) + "px";
        t.style.left = Math.round(left) + "px";
        t.classList.add("show");
        open = true;
        current = el;
    }

    function hide() {
        cancel();
        if (open) closedAt = Date.now();
        if (tip) {
            tip.classList.remove("show");
            tip.style.left = "-9999px";
            tip.style.top = "-9999px";
        }
        open = false;
        current = null;
    }

    document.addEventListener("mouseover", function (e) {
        /* El globo abierto puede haberse quedado huerfano: la rejilla de
           QuickIt, la fila de temas y la lista de presets se rehacen enteras
           al cambiar cualquier cosa, y al elemento que lo pidio no le llega
           ningun `mouseout` porque ya no esta en la pagina. Sin esto, el
           globo se queda flotando describiendo un boton que ya no existe. */
        if (current && document.contains && !document.contains(current)) hide();

        var el = triggerOf(e.target);
        if (!el) return;
        if (el === current && (open || timer)) return;
        schedule(el);
    }, true);

    document.addEventListener("mouseout", function (e) {
        var el = triggerOf(e.target);
        if (!el || el !== current) return;
        // Moverse dentro del mismo disparador no lo abandona.
        var to = e.relatedTarget;
        if (to && el.contains && el.contains(to)) return;
        hide();
    }, true);

    /* Con el teclado no se espera: llegar a algo tabulando ya es pararse en
       ello, y ahi el retardo solo seria un retardo.

       Pero un clic TAMBIEN deja el foco puesto —es como funciona un boton—, y
       eso no es "llegar tabulando": es justo el gesto de elegir algo y seguir
       con lo de siempre. Sin distinguir los dos, el globo del interruptor de
       modo de AlignIt (y cualquier boton con ayuda) volvia a salir en el
       instante de pulsarlo y se quedaba ahi indefinidamente, porque un boton no
       pierde el foco solo — hacia falta pulsar otra cosa para que se fuera.
       `:focus-visible` es la manera estandar de saber si el foco vino de verdad
       del teclado; el piso de Chromium de este panel (88) ya lo trae. */
    document.addEventListener("focus", function (e) {
        var el = triggerOf(e.target);
        if (!el || delay() < 0) return;
        textOf(el);              // blanquea el title nativo de paso, haya o no globo
        if (noTip(el)) return;
        var byKeyboard = true;
        try { byKeyboard = el.matches(":focus-visible"); } catch (e2) { byKeyboard = true; }
        if (!byKeyboard) return;
        cancel();
        current = el;
        paint(el);
    }, true);

    document.addEventListener("blur", hide, true);
    document.addEventListener("mousedown", hide, true);
    window.addEventListener("resize", hide);
    window.addEventListener("scroll", hide, true);

    // Una puerta minuscula, por si alguna vez hay que cerrarlo desde fuera.
    window.EditKitTip = { hide: hide };
})();
