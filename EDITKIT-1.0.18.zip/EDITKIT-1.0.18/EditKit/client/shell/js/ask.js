/* ============================================================================
   EDITKIT — PREGUNTAR SIN SALIR DEL PANEL

   Queda una sola cosa en el plugin que dibujaba el sistema operativo y no
   nosotros: el cuadro de `window.confirm()`. Salia en el centro de la pantalla
   en lugar del panel, con la tipografia de Windows, con el titulo puesto por
   el navegador —la ruta del HTML— y con los botones en el idioma del sistema
   aunque el plugin estuviera en el otro. Ademas BLOQUEA el hilo: mientras ese
   cuadro esta abierto no corre ni un temporizador de la pagina.

   Esto lo sustituye, y por eso es asincrono: no se puede devolver la respuesta
   desde la llamada, se entrega por funcion.

       EditKitAsk.confirm({
           text: "¿Restaurar todos los ajustes?",   // el enunciado
           list: ["Remapeo de tiempo", "Mascaras"], // opcional, los detalles
           go:   "Restaurar",                       // el boton que sigue
           keep: "Cancelar",                        // el que no
           danger: true                             // no se puede deshacer
       }, function (si) { if (si) hazlo(); });

   Quien llama pasa los textos ya traducidos: este archivo no conoce el
   diccionario, y asi sirve igual en las cuatro superficies.

   ── DE QUE LADO SE EQUIVOCA ────────────────────────────────────────────────
   El foco entra en CANCELAR, no en continuar. Una pregunta solo existe cuando
   la respuesta puede estropear algo; si alguien llega aqui pulsando Enter de
   corrido, que se cancele. Por lo mismo no hay un Enter global que confirme:
   Enter pulsa el boton que este enfocado, como en cualquier sitio, y Escape
   cancela.
   ============================================================================ */
(function () {
    "use strict";

    var box = null;      // el cuadro abierto ahora mismo, si hay alguno
    var answer = null;   // a quien hay que contestarle
    var before = null;   // donde estaba el foco antes de abrir

    function done(yes) {
        var fn = answer;
        answer = null;

        if (box && box.parentNode) box.parentNode.removeChild(box);
        box = null;

        /* El foco vuelve de donde vino. Cerrar un cuadro y dejar el foco en la
           nada manda al usuario al principio de la pagina en el siguiente
           tabulador. */
        try { if (before && before.focus) before.focus(); } catch (e) {}
        before = null;

        if (fn) fn(!!yes);
    }

    function onKey(e) {
        if (!box) return;
        var k = e.key || "";
        if (k === "Escape" || e.keyCode === 27) {
            e.preventDefault();
            e.stopPropagation();
            done(false);
            return;
        }
        /* El tabulador no sale del cuadro. Mientras hay una pregunta abierta lo
           de detras no se puede tocar, asi que tampoco tiene sentido poder
           llegar tabulando. */
        if (k === "Tab" || e.keyCode === 9) {
            var btns = box.querySelectorAll(".ek-ask-btn");
            if (!btns.length) return;
            var i = -1, j;
            for (j = 0; j < btns.length; j++) {
                if (btns[j] === document.activeElement) i = j;
            }
            e.preventDefault();
            var next = e.shiftKey ? (i <= 0 ? btns.length - 1 : i - 1)
                                  : (i < 0 || i === btns.length - 1 ? 0 : i + 1);
            try { btns[next].focus(); } catch (e2) {}
        }
    }

    function confirm(opt, cb) {
        opt = opt || {};

        // Ya habia una pregunta abierta: se cierra en negativo antes de abrir
        // la nueva. Dos cuadros apilados no los quiere nadie.
        if (box) done(false);

        try { before = document.activeElement; } catch (e) { before = null; }

        box = document.createElement("div");
        box.className = "ek-ask";
        box.setAttribute("role", "dialog");
        box.setAttribute("aria-modal", "true");

        var inner = document.createElement("div");
        inner.className = "ek-ask-box";

        var p = document.createElement("p");
        p.className = "ek-ask-text";
        p.textContent = String(opt.text || "");
        inner.appendChild(p);

        // La lista se arma con nodos y textContent, no con HTML: son nombres de
        // capas y de efectos del proyecto del usuario, y ahi puede haber un
        // "<" perfectamente legitimo.
        if (opt.list && opt.list.length) {
            var ul = document.createElement("ul");
            ul.className = "ek-ask-list";
            for (var i = 0; i < opt.list.length; i++) {
                var li = document.createElement("li");
                li.textContent = String(opt.list[i]);
                ul.appendChild(li);
            }
            inner.appendChild(ul);
        }

        var row = document.createElement("div");
        row.className = "ek-ask-row";

        var no = document.createElement("button");
        no.type = "button";
        no.className = "ek-ask-btn";
        no.textContent = String(opt.keep || "Cancelar");
        no.addEventListener("click", function () { done(false); });

        var si = document.createElement("button");
        si.type = "button";
        si.className = "ek-ask-btn " + (opt.danger ? "danger" : "go");
        si.textContent = String(opt.go || "Continuar");
        si.addEventListener("click", function () { done(true); });

        /* Cancelar a la izquierda y continuar a la derecha: el orden que ya
           usan la ventana de ajustes y el nombrador de perfiles de este mismo
           plugin. Que sea el mismo en todas partes importa mas que cual de los
           dos ordenes es el bueno. */
        row.appendChild(no);
        row.appendChild(si);
        inner.appendChild(row);
        box.appendChild(inner);

        // Pulsar fuera del cuadro cancela; dentro, no. `mousedown` y no
        // `click`: un arrastre que empieza dentro del cuadro y termina fuera no
        // es un clic fuera.
        box.addEventListener("mousedown", function (e) {
            if (e.target === box) done(false);
        });

        (document.body || document.documentElement).appendChild(box);
        answer = (typeof cb === "function") ? cb : null;

        try { no.focus(); } catch (e3) {}
    }

    document.addEventListener("keydown", onKey, true);

    window.EditKitAsk = {
        confirm: confirm,
        open: function () { return !!box; },
        close: function () { if (box) done(false); }
    };
})();
