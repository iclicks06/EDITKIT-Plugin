/* ============================================================================
   EDITKIT — SECRETOS (shell)

   Tres cosas escondidas en la barra y en Ajustes. Ninguna cambia nada de lo
   que el panel hace: son de adorno, se deshacen solas y no tocan el proyecto
   abierto en After Effects ni en Premiere.

     · CÓDIGO       ↑ ↑ ↓ ↓ ← → ← → B A sobre el shell — un barrido de color
                    por todo el plugin que vuelve al acento del usuario.
     · LATIDO       Alt + clic en el corazón de apoyar.
     · ÁUREA        doble clic en el divisor — reparte 61,8 / 38,2.
     · NOCHE        se desbloquea solo, de madrugada.
     · SIETE TOQUES sobre el número de versión.

   El logo de Zick tras tres toques en el nombre vive en shell.js porque
   comparte el DOM del título; aquí solo se registra.

   ── LA BITÁCORA NO ES UN SECRETO ─────────────────────────────────
   Lo era: hacían falta siete toques sobre la versión para verla. Estaba mal
   pensado. Un tablero de secretos escondido detrás de un secreto no incentiva
   a nadie, porque nadie busca lo que no sabe que existe, y el recuento de uso
   —los días, las curvas, la racha— no tiene por qué esconderse de su dueno.

   Ahora vive en Ajustes > Acerca de, siempre a la vista, y cada secreto que
   falta dice "por encontrar" con una pista corta al pasar el cursor. La idea es
   que se vea cuántos hay y que ninguno haga falta: quien quiera, mira; quien
   no, tiene delante los días que lleva y las curvas que aplicó.

   Los siete toques siguen valiendo —siguen siendo un secreto, con su nombre en
   la lista—, pero ya no son la puerta: ahora llevan a la bitácora y la marcan.

   Dificultad, a propósito, escalonada: el latido y los toques se encuentran
   toqueteando la interfaz, el código hay que sabérselo.
   ============================================================================ */
(function () {
    "use strict";

    var log = window.EditKitLog;
    if (!log) return;   // sin bitácora no hay nada que registrar

    var lang = "es";
    try { lang = localStorage.getItem("editkit_lang") || "es"; } catch (e) {}

    var T = {
        es: {
            thanks: "gracias",
            logTitle: "Bitácora",
            logHint: "Solo tuya y solo aquí: nada de esto sale de tu equipo.",
            days: "días con EditKit",
            sessions: "veces abierto",
            curves: "curvas aplicadas",
            aligns: "alineaciones",
            streak: "días seguidos",
            best: "mejor racha",
            secrets: "Secretos",
            secretsFound: "encontrados",
            tools: "herramientas usadas",
            keeps: "Sobrevive a desinstalar: hay una copia en Documentos › EditKit.",
            phi: "\u03c6",
            wipe: "Borrar la bitácora",
            wiped: "Bitácora borrada.",
            unknown: "por encontrar",
            noRush: "Ninguno hace falta para nada. Están para quien mire.",
            hintTip: "Pista",
        },
        en: {
            thanks: "thank you",
            logTitle: "Logbook",
            logHint: "Yours alone, and only here: none of this leaves your machine.",
            days: "days with EditKit",
            sessions: "times opened",
            curves: "curves applied",
            aligns: "alignments",
            streak: "day streak",
            best: "best streak",
            secrets: "Secrets",
            secretsFound: "found",
            tools: "tools used",
            keeps: "Survives an uninstall: there is a copy in Documents › EditKit.",
            phi: "\u03c6",
            wipe: "Erase the logbook",
            wiped: "Logbook erased.",
            unknown: "still hidden",
            noRush: "None of them is needed for anything. They are there for whoever looks.",
            hintTip: "Hint",
        }
    };
    function t(k) { return (T[lang] || T.es)[k] || (T.es[k] || k); }

    /* ====================================================================
       LOS NOMBRES Y LAS PISTAS, GUARDADOS BAJO LLAVE

       Estaban aqui, en texto plano, y eso era regalar el juego: abrir este
       archivo en el plugin instalado y buscar "Pista" daba la lista entera
       con las diecinueve soluciones. Y la llamada que anota un hallazgo
       contaba el resto, porque llevaba dentro el nombre del secreto.

       Ahora los identificadores no significan nada —"z7", "b5", "t9"— y las
       dos tablas viajan cifradas: JSON, a ASCII, XOR contra una clave, y
       base64. Se descifran una sola vez, la primera vez que se pinta la
       bitacora, y se quedan en memoria.

       Esto NO las hace indescifrables, y conviene decirlo: quien se ponga
       con las herramientas de desarrollo y paciencia va a llegar. Lo que se
       corta es el camino facil —buscar texto—, que es el unico que recorre
       quien solo queria curiosear un rato. Contra un depurador no hay
       defensa posible en codigo que corre en la maquina del usuario, y
       fingir que si la hay seria peor que no ponerla.
       ==================================================================== */
    var K = "editkit-1.0";

    var SEALED = {
        es: "QFMrUVlbBR4UHAJAVyhRXitRHwNrXEBWWRgEDhsIAx5VFgcGGg8AEEIUHAJAVipRWVs9Q0JHQxEBTEZbChtDFBwAAAhMRlsHG0BTXFVAVlkQDkxGHVBcQgwGCFpOW0YIBGoVVydMRlkBTAgDHBVWJUxBKUxGH31PQ0BWWRgOHQZMQgsCVRUcEU5bRF9UTF8RBQdRWVtRH3ILAlchBVFZWQAIch0VJCAdAQcGUR8BSlVAVlkxChoRZEULAlUFDgEKBwBMFBwACEEqR04oRV4UHAARCxgBDhpaCAMcFVAgTEYoTEYfRxwVV1ZMRypMQW8UHAIgCExGWxsRWRRtA0AlLRceBRsIAx5ZCxUcHQ4dGwgDHBVXJ0xGWSwYCAMeXgoJCwYOTEYdVUsVV1QoGAIOGmRFCwImQVtEBB0GTEILAlUQCBofCAcIAx5GAAcMB0VMRh8UG3RAVipRWVsOGhQcAkBXKFFeK1EfA2tcQFZZF04qRwhzHVQMAwZRWVtRH3ILAlcgABERTEYdRUtTCQUaUVlZBVhUCwJVHQhRWVkASBQcABYFCxEYR1EfAwsFIUFbN05bRk8ECwJXQVo1Tlw2CAMcfAQQABAETEYfFBxzQFZbNQdMRh1SQUIEHkw3WEw2Hl8LAiZBW0QIBhoIAx5xCRBMRlsZAUFCT1QKSkxGWUxBaRQcc0BWWxpaTEYfFB1xQFErUVlbOEJCCwJVFwARHwxRHwFaXxQRDAdOW0YIA20VV1Y6HQ4dEQgDHkYABwwHTltEXl5MQgBBW0QHCFEfAVhVFxcAUShaUW8CQB5AVltRXi1RH3ILAlcQUFFZW1EecAsFJ0FbRicIUR8BXkIKFAYGCABRbgILclYKTEZbTDceFG8BEBYMFU5bRggDbRVXVi0bCQURCAMeUwkNClFZWR5YQlpfQFZZEQVMRh1UQhVXVA0dHQAHQkMAFVdWTEEvTEZuFBwCAVBMRllMR2wUG3JAVlsxB0xGHUVbQgsLTEZbDREIAx5eCgcBEU5bRggDbRVXViwHHwxRHwFPQAQWDBcOTEYdQkFcCkFbN05bRElUCwJVCQgQGRwTTFVPHkBWW1FeLVEfcgsCVw9fUVlbUR5wCwUnQVtGJggGSlRAFVdUBxtOW0RIX01fCxAbFQ8GUR8DCwImQVtGPgdRHwFDURcDDBpOW0RJVAsCVQccFR8bGwgDHlMMAhsVGExGHVxbSUBWWRIKBBteXgAVV1ZMQS9MRm4UHAISVExGWUxHbBQbckBWWzgEGlEfAUFEFwsaUVlZB1hTWhUmV0w1Lx0BQV5dFVdWTEYoTEYffUEVV1QYAQ5MRh1VR1MAQVtELggHSHhaFVdUDREJCB5CFBwAAQFMRlsaAQgDHl4KCQsGDkdRHwMLBSFBWzdOW0ZfCQsCV0FaNU5cNggDHHwEQVtEGwgYTFNcUUBWWREFTEYdXU8VV1QZFQcMAEwUHAJAVipRWVskX1RJFSZXTDYqBwBMXUsVV1QIUVlZGEwUHAAVBQURHwhRHwFeXxdBW0QOBVEfAV5cEAMAGkVMRh8UG3RAVipRWVsZHxQcAkBXKFFeK1EfA2JRQFZZGwcIUR8DCwImQVtGLgVRHwFAXwgGGxFOW0RJVAsCVTUcHQgCPVkUHHNAVlkNTltEQFhcUUBWWRgKTEYdQ0taDAgFFUVMRh8UG3RAVipRWVseGBQcAkBXKFFeK1EfA2deFg0aAA4HF0RQCwJXQVs3TltGaF0LAlUJAAcGBlEfAUxfEUEqR04rR0MUHHNAVlkBBQhRHwFXFVdUBgAZCFEfAVhVH0pMRllMQWkUHHNAVlsSXExGHxQdcUBRK1FZWzhMFBwAExEMGB8IUR8BS14RARsVTltGCANtFVdWOxEIBgZfVAsCVQgIB05bRE5QWlUCCxtRKFpRbHVPQ0BWKlFZWQJYVEJEBEFbRB8bFV4UHAATEQwYHwhaCAMcFVAgTEYoTEYfUh0VV1ZMRypMQW8UHAIpBRpRWVkAX1RdFVdUChUZCAcIAxwVVydMRlk5BlhUTFFAVlkYBBpRHwFaQgAXTEZbHRFAUF0VV1QNEU5bREtQTEIMBwhaTltGCARqFVcnTEZZEUUIAxwVViVMQSlMRh99TxVXVAoVGR0VCAMeVwwWCBAKTEYfFBxzQFZbJgQNEUwUHAAQCghRWVkXTENaUUBWWRAOTEYdRUtdBEFbRAgGGggDHlUJQVtECBwGXl5cHkBWW1FeLVEfcgsCVwNQUVlbUR5wCwUnQVtGPgcbCAMeQwoIBlFZW1EfcgsCVyAMHgpMRh1EQBVXVBobBwZRHwFeUQsBBVFZWRUIAx5cBEFbRB0AB1lQABVXVkxBL0xGbhQcAhVQTEZZTEdsFBtyQFZbJwIHUR8BWFUJC0xGWUxGbhQcAiAITEZbHxFBXgsCVRcGFhkMUR8BQl8WQVtEGwgaSF1LQ0BWKlFZWRBIXQsCVRAGEARMRh1QTFEPC0dRWVtRGHULAiZBW0YSX1EfAwsDJEFcNk5bRmFUWkIAFgZRWVkQSBQcAAYNBxFOW0YIA20VV1YlFRhMRh1dS0QXBRpRWVkQSBQcAAkLGlFZWRZCRUFeABdMRihMRh1QQFMNBRpRWVkNCAMeVQtBW0QGCA1YQk1FCQUaWk5bRggEahVSIA==",
        en: "QFMrUVlbBR4UHAJAVyhRXitRHwN6WABBW0QDABBJVEAVV1QFGwwGUR8DCwImQVtGIAwRXRQcABEFGQQCBxMIAx5EDQFMRlsHFUBUCwJVERlRWVkAQkEAFVdWTEEvTEZuFBwCDVxMRllMR2wUG3JAVlsgAwxRHwFCVREQDAYYTEYdRUZREUFbRAkGAUNSSxVXVkxGKExGH3RPQwAtHVFZXgcIAx5EDBAFEU5bRFlQRVUWQVtEBgYGSBQcABEFGQdFTEYfFBt0QFYqUVlbAh8UHAJAVyhRXitRHwN6WABBW0QZDAdZXUtDFkFbRBkMAERSQlVAVltRWSpRHwNvXAwDBz0fTEYaQgsCVQoIGQ5MRm4UHAAPERoATltETEILAlUJCBoSTEYdRUddABdHUVlbURh1CwImQVtGEV5RHwMLAyRBXDZOW0Z5WUsVV1QKGw8MUR8DCwImQVtGPwwaCAMeWwAdGlFZWQ1CRAsCVQUFBg4IEFQUHAAOCgYDRUxGHxQbdEBWKlFZWxYYFBwCQFcoUV4rUR8DZlUEFh0WDggACAMcFVcnTEZZPRxIFBwADQEIBh9MRm4UHAASDR0cTltEbF1aFVdUAREHDVEfAUpfEgpHUVlbURh1CwImQVtGBVhRHwMLAyRBXDZOW0Z5WUsVV1QaER0MGggDHkQEFBpRWVtRH3ILAlc3DAIOB1EfAVpZCAEaUVlZG0MUHAARDAxRWVkCSENdWQoKR1FZW1EYdQsCJkFbRh9QUR8DCwMkQVw2TltGeVlLFVdUDhsHDRFDFBwAFwUdHQRMRh8UHHNAVlswBBwWQVQDUwkNCh9OW0RfWElYEUFbRAQHUR8BWlgAQVtEDwACRFVLQktBW0ZOXDAIA20VV1YNQE5bRggCbxVQJkxGWT0cSBQcAAsNDhwfTEYdQkZZAxBMRllMRm4UHAIxDAAHTltEQl9LFVdUHQEZBwcIAx5FFUFbRAQHUR8BR0QWQVtEBB4aCANtFVdUBRUfDFEfAU9EQFZZGgIOHFkfCwJXQVwwTls3CAMcW1NBW0ZOWjUIBGwVV1YkFRkOHUMUHAALCx1RWVkSQkRAVEBWW1FZKlEfA28VV1QfERkQUR8BSFEICxwHTltES15bQkgAABMCHVEfAUNRFwMAGkVMRh8UG3RAVipRWVsDHRQcAkBXKFFeK1EfA3pYAEFbRAQdHEhDCwJVFxwWHwAAQVRdFVdWTEYoTEYfZkZREUFbRC4IB0h4WhVXVBoVEhpRHwFbXgEBG1FZWR1ZQgsCVQoIGQ5HUR8DCwUhQVs3TltGXwkLAldBWjVOXDYIAxxkDQFMRlseG19VCwJVDQdRWVkARVQLAlUUCBgOHQBIFBwCQFYqUVlbNV5aCwJVEAERTltEXVBCVREQDFFZWRVPXltEQFZZAAMMUR8BXlwQAwAaRUxGHxQbdEBWKlFZWxkfFBwCQFcoUV4rUR8DelgAQVtEHAgCSBQcAkBWKlFZWyVYWE1bLBBMRlwaUR8BQFEIAUxGW0wxHxQWAEBdXVFZWRVDVQsCVRMIAAgBUR8BWlgAQVtEDBsdSR8LAldBXDBOWzcIAxxaUEFbRk5aNQgEbBVXVjkRGRodXkVLXgYBTEZZTEZuFBwCMQwMUVlZB0xcSxVXVAsBHx0bQxQcc0BWWRUMCB1DFBwABAoNUVlZFUpQR15LQVtGTlwwCANtFVdWD0NOW0YIAm8VUCZMRlk9HEgUHAADEQUYTltEQVBeFVdWTEYoTEYfdkEVV1QbGx4HEAgDHkQNAUxGWwoVWVRJXxcNDAdFTEYfFBt0QFYqUVlbFx4UHAJAVyhRXitRHwN6WABBW0QfAQZIVAsCVQIIFw4aUR8DCwImQVtGPxsNCAMeUQkITEZbHRxfVEsVV1QLAQIFAABYQBVXVB0cDgQRXh8LAldBXDBOWzcIAxxIVEFbRk5aNQgEbBVXVj0cDkxGHVJPQgFBWzdOW0RZRFxeAABMRllMRm4UHAIxBQIRTltEWVlLFVdUCgEZGhtfFBwABAgFUVlZAEVUCwJVEwgNTltEX15bXgFBW0QKTEYdRUZVCAFMRlsKFV9VABVXVkxBL0xGbhQcAgJdTEZZTEdsFBtyQFZbOwUMUR8BQV5AVlkdHxpRHwFBRwtBW0ZOWzcIAxx8AAUfEU5bREwUHAAWDQcTBwxRHwFeUQsBBVFZWQdFXllZCwNHUVlbURh1CwImQVtGG11RHwMLAyRBXDZOW0ZjXgsCVRIMHQdMRh8UHHNAVlsgAwxRHwFYVQwITEZbBgJIQwsCVRABEU5bRF1QQFUJF0xGKExGHVBCXEBWWQADDFEfAVlRHEFbRA8GA0MfCwJXQVwwTls3CAMcSVNBW0ZOWjUIBGwVV1YqHQUMGUwUHAAIBRsFHgwRCAMcFVcnTEZZPRxIFBwABxEdAAQHUR8BQlUREAwGGExGbhQcABINDRFOW0RMX0oVV1QAGk5bRE5QXlkRBQUHRUxGHxQbdEBTLQ=="
    };

    var opened = {};

    function open_(l) {
        if (opened[l]) return opened[l];
        var out = {};
        try {
            var raw = atob(SEALED[l] || SEALED.es), i, s2 = "";
            for (i = 0; i < raw.length; i++) {
                s2 += String.fromCharCode(raw.charCodeAt(i) ^ K.charCodeAt(i % K.length));
            }
            out = JSON.parse(decodeURIComponent(s2)) || {};
        } catch (e) { out = {}; }
        opened[l] = out;
        return out;
    }

    // [0] es el nombre, [1] es la pista. Dos campos y sin nombres de campo:
    // un objeto con "name" y "hint" dentro del blob seria una pista de por
    // donde empezar a mirar.
    function eggText(id, which) {
        var a = open_(lang)[id] || open_("es")[id];
        return (a && a[which]) || "";
    }
    function eggName(id) { return eggText(id, 0) || id; }
    function eggHint(id) { return eggText(id, 1); }

    /* El orden no es el de dificultad ni el alfabético: es el de sitio. Los del
       shell primero, luego los de cada panel, y los tres últimos son de cosas
       que se acaban de anadir —los temas, las cartas, ocultar paneles— para que
       quien mire la lista vea que hay novedades al final. */
    var ALL_EGGS = ["q3", "h8", "v2", "z7", "b5", "n1", "t9", "d4", "k6", 
                    "w0", "r8", "m2", "j5", "f7", "c3", "x1", "g9", "p4", 
                    "y6"];

    // Una sesión por carga del shell; los paneles no cuentan (se recargan solos).
    try { log.startSession(); } catch (e) {}

    // ========================================================================
    // 1. EL CÓDIGO — barrido de color
    // ========================================================================
    /* El acento del usuario se guarda antes de empezar y se repone al terminar,
       incluso si algo revienta a mitad: el barrido es un préstamo, no un
       cambio de preferencia. Se apoya en el mismo puente que usa el selector
       de color, así que los dos paneles barren a la vez. */
    var SEQ = ["ArrowUp", "ArrowUp", "ArrowDown", "ArrowDown",
               "ArrowLeft", "ArrowRight", "ArrowLeft", "ArrowRight", "b", "a"];
    var at = 0;
    var sweeping = false;

    function hsl2hex(h, s, l) {
        h = ((h % 360) + 360) % 360; s /= 100; l /= 100;
        var c = (1 - Math.abs(2 * l - 1)) * s;
        var x = c * (1 - Math.abs(((h / 60) % 2) - 1));
        var m = l - c / 2, r = 0, g = 0, b = 0;
        if (h < 60) { r = c; g = x; }
        else if (h < 120) { r = x; g = c; }
        else if (h < 180) { g = c; b = x; }
        else if (h < 240) { g = x; b = c; }
        else if (h < 300) { r = x; b = c; }
        else { r = c; b = x; }
        function hx(v) { var s2 = Math.round((v + m) * 255).toString(16); return s2.length < 2 ? "0" + s2 : s2; }
        return "#" + hx(r) + hx(g) + hx(b);
    }

    function sweep() {
        var A = window.EditKitAccent;
        if (!A || sweeping) return;
        var keep = A.get();
        sweeping = true;
        var t0 = Date.now(), DUR = 2200;
        var timer = setInterval(function () {
            var p = (Date.now() - t0) / DUR;
            if (p >= 1) {
                clearInterval(timer);
                sweeping = false;
                A.set(keep, { force: true });
                return;
            }
            /* Un solo giro completo del círculo de color. El puente ya espacia
               las aplicaciones a 60ms, así que pedirle más cuadros no acelera
               nada: solo le da trabajo de más. */
            A.set(hsl2hex(p * 360, 62, 55), { force: true });
        }, 70);
    }

    document.addEventListener("keydown", function (e) {
        var k = e.key;
        if (!k) return;
        var want = SEQ[at];
        var hit = (want.length === 1) ? (String(k).toLowerCase() === want) : (k === want);
        at = hit ? at + 1 : (String(k).toLowerCase() === SEQ[0].toLowerCase() || k === SEQ[0] ? 1 : 0);
        if (at < SEQ.length) return;
        at = 0;
        log.found("z7");
        sweep();
    });

    // ========================================================================
    // 2. LATIDO — Alt + clic en el corazón
    // ========================================================================
    var donateBtn = document.getElementById("donateBtn");
    if (donateBtn) {
        donateBtn.addEventListener("click", function (e) {
            if (!e.altKey) return;
            // Con Alt no se abre el menú de apoyo: el gesto es otro.
            e.preventDefault();
            e.stopPropagation();
            log.found("b5");
            donateBtn.classList.remove("egg-beat");
            void donateBtn.offsetWidth;         // reinicia la animación
            donateBtn.classList.add("egg-beat");
            setTimeout(function () { donateBtn.classList.remove("egg-beat"); }, 1500);

            var note = document.createElement("div");
            note.className = "egg-float";
            note.textContent = t("thanks");
            var r = donateBtn.getBoundingClientRect();
            note.style.left = (r.left + r.width / 2) + "px";
            note.style.top = (r.bottom + 2) + "px";
            document.body.appendChild(note);
            setTimeout(function () { if (note.parentNode) note.parentNode.removeChild(note); }, 1600);
        }, true);
    }

    var vers = document.getElementById("setAboutVersionValue");
    var box = document.getElementById("eggLogHome");

    function row(label, value) {
        return '<div class="egg-log-row"><span>' + label + '</span><b>' + value + '</b></div>';
    }

    // Los nombres y las pistas son nuestros, pero van a un atributo entre
    // comillas: una comilla o un "&" sin escapar romperia el marcado.
    function esc(v) {
        return String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;")
                        .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }

    function render() {
        if (!box) return;

        /* El idioma, releido en cada pintada. Este archivo lo tomaba una sola
           vez al arrancar, y mientras la bitacora estaba escondida detras de
           siete toques daba igual: se abria despues de cambiarlo. Ahora esta
           siempre puesta, y el usuario puede cambiar de idioma con ella
           delante. Leer una clave cuesta microsegundos y ahorra tener que
           avisar a nadie. */
        try { lang = localStorage.getItem("editkit_lang") || "es"; } catch (e0) {}
        if (!T[lang]) lang = "es";

        var d = log.read();
        var found = log.eggs();
        var nFound = 0, i;
        for (i = 0; i < ALL_EGGS.length; i++) if (found[ALL_EGGS[i]]) nFound++;

        var days = Math.max(1, log.daysBetween(d.first, log.today()) + 1);
        var pct = Math.round((nFound / ALL_EGGS.length) * 100);

        var html = '<div class="egg-log-title">' + t("logTitle") + '</div>' +
            row(t("days"), days) +
            row(t("sessions"), d.sessions) +
            row(t("curves"), d.curves) +
            row(t("aligns"), d.aligns) +
            row(t("tools"), d.tools || 0) +
            row(t("streak"), d.streak) +
            row(t("best"), d.best) +
            '<div class="egg-log-sub">' + t("secrets") + ' — ' + nFound + '/' + ALL_EGGS.length + ' ' + t("secretsFound") + '</div>' +

            /* La barra dice de un vistazo cuanto queda, que es lo que hace que
               apetezca buscar otro. Los numeros ya estan encima; esto es para
               no tener que leerlos. */
            '<div class="egg-log-bar"><i style="width:' + pct + '%"></i></div>' +
            '<div class="egg-log-eggs">';

        for (i = 0; i < ALL_EGGS.length; i++) {
            var id = ALL_EGGS[i];
            var hint = eggHint(id);
            if (found[id]) {
                /* Encontrado: el nombre, y la pista sigue siendo el globo. No
                   es redundante —sirve para volver a hacerlo dentro de un mes,
                   cuando ya no se acuerde de como fue—. */
                html += '<div class="egg-found" data-tip="' + esc(hint) + '">' +
                        esc(eggName(id)) + '</div>';
            } else {
                /* Por encontrar: el texto no dice cual es, y la interrogacion
                   aparece al pasar el cursor. Dos pasos a proposito: el primero
                   avisa de que hay algo que leer, el segundo lo lee. Y el globo
                   respeta el retardo que el usuario haya puesto, incluido
                   apagarlo del todo. */
                html += '<div class="egg-locked" data-tip="' + esc(t("hintTip") + ": " + hint) + '">' +
                        t("unknown") + '</div>';
            }
        }

        html += '</div>' +
            '<div class="egg-log-hint">' + t("noRush") + '<br>' + t("logHint") +
            '<br>' + t("keeps") + '</div>' +
            '<button type="button" class="egg-log-wipe">' + t("wipe") + '</button>';
        box.innerHTML = html;

        box.querySelector(".egg-log-wipe").addEventListener("click", function () {
            log.reset();
            box.innerHTML = '<div class="egg-log-title">' + t("logTitle") + '</div>' +
                            '<div class="egg-log-hint">' + t("wiped") + '</div>';
        });
    }

    /* Se repinta al abrir los ajustes y al entrar en "Acerca de". Hace falta:
       los secretos de los tres paneles se anotan desde sus propias ventanas, y
       esta lista se pinto cuando el shell arranco. Sin esto, encontrar algo en
       QuickIt no aparecia aqui hasta reiniciar el panel. */
    function refresh() { try { render(); } catch (e) {} }

    /* La misma puerta que tienen el fondo, los perfiles y los temas, para que
       el shell pueda avisar en el momento del cambio y no en la pintada
       siguiente. */
    window.EditKitEggs = { setLanguage: refresh, refresh: refresh };

    render();
    (function () {
        var open = document.getElementById("shellSettingsBtn");
        var tab = document.getElementById("setTabAbout");
        if (open) open.addEventListener("click", refresh);
        if (tab) tab.addEventListener("click", refresh);
        document.addEventListener("editkit-log-synced", refresh);
    })();

    // ========================================================================
    // 4. LA PROPORCION AUREA — doble clic en el divisor
    // ========================================================================
    /* Doble clic en un separador es un gesto que casi todo el mundo prueba
       alguna vez, y en casi todos los programas hace algo. Aqui reparte el
       espacio en 61,8 / 38,2 en lugar de por la mitad. Es un secreto que
       ademas sirve para algo, que es la unica clase que merece la pena. */
    var splitter = document.getElementById("shellSplitter");
    if (splitter) {
        splitter.addEventListener("dblclick", function () {
            var S = window.EditKitShell;
            if (!S || !S.setSplit) return;
            log.found("t9");

            var to = 0.618, from = S.getSplit(), t0 = Date.now(), DUR = 320;
            var tick = setInterval(function () {
                var p = (Date.now() - t0) / DUR;
                if (p >= 1) { clearInterval(tick); S.setSplit(to); flash(splitter, t("phi")); return; }
                // Suavizado corto: un salto seco pareceria un fallo del arrastre.
                S.setSplit(from + (to - from) * (1 - Math.pow(1 - p, 3)));
            }, 16);
        });
    }

    function flash(near, text) {
        var note = document.createElement("div");
        note.className = "egg-float";
        note.textContent = text;
        var r = near.getBoundingClientRect();
        note.style.left = (r.left + r.width / 2) + "px";
        note.style.top = (r.top + 24) + "px";
        document.body.appendChild(note);
        setTimeout(function () { if (note.parentNode) note.parentNode.removeChild(note); }, 1600);
    }

    // ========================================================================
    // 5. EL TURNO DE NOCHE
    // ========================================================================
    /* No hay nada que pulsar: se desbloquea solo, la tercera vez que el panel
       se abre entre medianoche y las cinco. Es el unico de la lista que
       encuentra al usuario en vez de al reves, y por eso no dice nada cuando
       pasa: aparece en la bitacora la proxima vez que se mire. */
    (function () {
        var h = new Date().getHours();
        if (h >= 5) return;
        var K = "editkit_owl";
        var n = 0;
        try { n = parseInt(localStorage.getItem(K) || "0", 10) || 0; } catch (e) {}
        n += 1;
        try { localStorage.setItem(K, String(n)); } catch (e2) {}
        if (n >= 3) log.found("d4");
    })();

    // ========================================================================
    // 6. LOS SIETE TOQUES — sobre el numero de version
    // ========================================================================
    /* Esto abria la bitacora. Ya no hace falta abrirla —esta ahi debajo, a la
       vista—, asi que el gesto se queda con lo unico que le corresponde: ser un
       secreto. Lleva a la bitacora, la marca un momento y se anota en ella.

       Podria haberse quitado. Pero un gesto que alguien ya encontro y que un
       dia deja de hacer nada es peor que un gesto que nunca existio. */
    if (vers) {
        var taps = 0, last = 0;
        vers.style.cursor = "default";
        vers.addEventListener("click", function () {
            var now = Date.now();
            taps = (now - last < 700) ? taps + 1 : 1;
            last = now;
            if (taps < 7) return;
            taps = 0;
            log.found("n1");
            render();
            if (!box) return;
            box.classList.remove("pulse");
            void box.offsetWidth;              // reinicia la animacion
            box.classList.add("pulse");
            setTimeout(function () { box.classList.remove("pulse"); }, 1200);
            try { box.scrollIntoView({ block: "nearest" }); } catch (e2) {}
        });
    }

    // ========================================================================
    // 7. LAS TRES CARAS — los tres temas de fabrica, del tirón
    // ========================================================================
    /* Lo dispara themes.js al aplicar el tercero distinto seguido; aqui solo se
       deja dicho para que el nombre y la pista vivan con los demas. */

    /* Y los dos ultimos —la carta girada y dejar un solo panel— los anotan
       themes.js y shell.js, que son quienes saben cuando pasan. Ninguno de los
       tres necesita codigo aqui: la bitacora solo los lee. */
})();
