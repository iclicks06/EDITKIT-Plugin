/* ============================================================================
   EDITKIT — REPAINT GUARD (loaded by the shell and by both panes)

   Switching to another extension panel and back can leave the whole panel
   painted flat grey. It is not the panel's markup: the DOM is intact and the
   scripts are still running. CEP's webview loses its compositing surface while
   it is hidden behind another panel's tab, and coming back does not always
   trigger a fresh paint — so whatever the compositor last had (nothing) is what
   stays on screen.

   Nothing in the page can ask CEP to re-composite directly, so this asks the
   only way a page can: it invalidates the layer the panel is drawn on and makes
   the browser rebuild it. Promoting <body> to its own compositing layer,
   reading a geometry property to force the work to happen synchronously, then
   dropping the promotion, is enough to get a real paint out of it.

   Cheap and idempotent: it runs on the events that mark "the user is looking at
   this again" and does nothing else the rest of the time. The panes run it too,
   because each iframe is its own compositing surface and the shell repainting
   does not necessarily bring them back.
   ============================================================================ */
(function () {
    "use strict";

    /* ====================================================================
       ¿SE ESTA VIENDO ESTE PANEL?

       La pregunta la contesta `document.hidden`, y sirve para no trabajar de
       balde: un panel de CEP no se descarga al cambiar de pestana —se queda
       cargado y corriendo detras del que el usuario haya puesto delante—, asi
       que los vigilantes que miden cada medio segundo pueden dormir mientras
       nadie los mira.

       Pero no se le hace caso a ciegas, y esto no es precaucion de manual: en
       algunos entornos de prueba embebidos el documento dice "oculto" SIEMPRE,
       incluso mientras se esta pintando en pantalla. Si se le creyera, los
       vigilantes no correrian nunca y la barra de desplazamiento no se
       redibujaria jamas —un ahorro perfecto a cambio de que nada funcione—.

       De ahi la regla: solo se cree que "oculto" significa oculto si alguna vez
       dijo "visible". Mientras no lo diga, se trabaja como siempre. En el peor
       caso se gasta lo que se gastaba antes; nunca menos de lo que hace falta.
       ==================================================================== */
    var everVisible = false;

    function note() {
        if (!document.hidden) everVisible = true;
    }
    note();
    document.addEventListener("visibilitychange", note);

    /* Y por encima de todo eso, la palabra de CEP. El programa anfitrion avisa
       cuando muestra u oculta el panel, y ese aviso es mas de fiar que el del
       documento: si alguna version de CEP dejara el documento en "oculto"
       mientras el panel se ve —que es justo el fallo que este archivo existe
       para arreglar—, los vigilantes se dormirian con el panel delante. Cuando
       CEP dice que se ve, se trabaja, y se acabo la discusion.

       Empieza en null y no en true: "no ha dicho nada" no es "esta oculto". */
    var cepVisible = null;
    var paneVisible = true;
    var performanceMode = false;
    var wakeListeners = [];

    var last = 0;

    function forceRepaint() {
        // several of these events fire together on a single panel switch
        var now = Date.now();
        if (now - last < 120) return;
        last = now;

        var b = document.body;
        if (!b) return;
        try {
            var prev = b.style.transform;
            b.style.transform = "translateZ(0)";
            // reading layout is what makes the change take effect now, not at
            // some later frame that may never come while the surface is stale
            void b.offsetHeight;
            b.style.transform = prev || "";
            void b.offsetHeight;
        } catch (e) {}

        // Canvases keep their own backing store: the aura and EaseIt's graph
        // redraw themselves on the next frame anyway, but only if their loop is
        // still turning. Nudging resize restarts the ones that idle when hidden.
        try { window.dispatchEvent(new Event("resize")); } catch (e2) {}
    }

    document.addEventListener("visibilitychange", function () {
        var wasIdle = idle();
        note();
        notifyRuntime(wasIdle);
        if (!document.hidden) forceRepaint();
    });

    /* Y se abre al resto del panel. Lo usan los vigilantes con intervalo:
       thin-scroll, el que mide la forma de QuickIt, el de las pestanas de
       AlignIt y el que vigila las colecciones de EaseIt.

       `onWake` es el compañero obligatorio de `idle`: quien deja de mirar
       mientras el panel no se ve tiene que mirar en cuanto vuelve, o se queda
       con la medida de hace media hora.

       Devuelve un "date de baja": los vigilantes de siempre (uno por panel,
       enganchado al arrancar) no lo necesitan y lo ignoran sin problema, pero
       los que se crean y se destruyen muchas veces en la misma sesion —una
       hoja modal que se abre y se cierra— sin el se quedarian acumulando un
       oyente de `visibilitychange` por cada apertura, para siempre. */
    function idle() {
        if (!paneVisible) return true;
        if (cepVisible === true) return false;    // CEP manda
        if (cepVisible === false) return true;
        return everVisible && document.hidden;
    }

    function updateClasses() {
        if (!document.body) return;
        document.body.classList.toggle("ek-pane-idle", idle());
        document.body.classList.toggle("ek-performance", performanceMode);
    }

    function pauseVideos() {
        if (!document.querySelectorAll) return;
        var videos = document.querySelectorAll("video");
        for (var i = 0; i < videos.length; i++) {
            try { videos[i].pause(); } catch (e) {}
        }
    }

    function notifyRuntime(previousIdle) {
        updateClasses();
        if (idle() || performanceMode) pauseVideos();
        try { window.dispatchEvent(new CustomEvent("editkit-runtimechange", {
            detail: { idle: idle(), performance: performanceMode }
        })); } catch (e) {}
        if (previousIdle && !idle()) {
            for (var i = 0; i < wakeListeners.length; i++) {
                try { wakeListeners[i](); } catch (e2) {}
            }
            forceRepaint();
        }
    }

    function setRuntime(value) {
        value = value || {};
        var wasIdle = idle();
        var wasPerformance = performanceMode;
        if (typeof value.paneVisible === "boolean") paneVisible = value.paneVisible;
        if (typeof value.performance === "boolean") performanceMode = value.performance;
        notifyRuntime(wasIdle);
        if (wasPerformance && !performanceMode && !idle()) {
            for (var i = 0; i < wakeListeners.length; i++) {
                try { wakeListeners[i](); } catch (e) {}
            }
            forceRepaint();
        }
    }

    window.EditKitAwake = {
        idle: idle,
        performance: function () { return performanceMode; },
        setRuntime: setRuntime,
        onWake: function (fn) {
            if (typeof fn !== "function") return function () {};
            wakeListeners.push(fn);
            return function () {
                var at = wakeListeners.indexOf(fn);
                if (at >= 0) wakeListeners.splice(at, 1);
            };
        }
    };
    window.addEventListener("message", function (event) {
        var data = event && event.data;
        if (!data || data.__editkit !== "runtime") return;
        setRuntime(data);
    });
    updateClasses();
    window.addEventListener("focus", forceRepaint);
    window.addEventListener("pageshow", forceRepaint);

    /* CEP tells an extension when its panel is shown again. The event name
       differs by host version, so all the known ones are wired and the ones
       that do not exist simply never fire. */
    try {
        var cs = new CSInterface();
        var events = [
            "com.adobe.csxs.events.WindowVisibilityChanged",
            "applicationActivate",
            "com.adobe.csxs.events.ApplicationActivate"
        ];
        for (var i = 0; i < events.length; i++) {
            try { cs.addEventListener(events[i], forceRepaint); } catch (e3) {}
        }

        /* El mismo aviso, leido ahora por su contenido: "true" cuando el panel
           pasa a verse. Lo manda CEP como texto, no como booleano. */
        try {
            cs.addEventListener("com.adobe.csxs.events.WindowVisibilityChanged", function (ev) {
                var d = ev && ev.data;
                var wasIdle = idle();
                cepVisible = (d === undefined || d === null) ? true
                           : (d === true || d === "true");
                notifyRuntime(wasIdle);
            });
        } catch (e5) {}
    } catch (e4) {}
})();
