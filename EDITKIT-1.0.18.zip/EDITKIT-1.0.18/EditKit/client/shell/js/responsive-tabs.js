/* ============================================================================
   EDITKIT — TEXT OR ICONS, NEVER BOTH

   Settings tabs use their names while those names genuinely fit. If any label
   is clipped, the whole row switches to icons. Measuring the rendered labels
   avoids a guessed breakpoint: different languages, fonts and panel widths
   all make the decision from the same rule.
   ============================================================================ */
(function () {
    "use strict";

    var pending = false;

    function labelOf(button, nav) {
        if (nav.classList.contains("set-tabs")) return button.querySelector(".set-tab-label");
        if (nav.classList.contains("settings-nav")) return button.querySelector(".settings-nav-label");
        return button.querySelector("span");
    }

    function buttonsOf(nav) {
        if (nav.classList.contains("set-tabs")) return nav.querySelectorAll(".set-tab");
        if (nav.classList.contains("settings-nav")) return nav.querySelectorAll(".settings-nav-btn");
        return nav.querySelectorAll(".qi-sheet-tab");
    }

    function measure(nav) {
        if (!nav || nav.offsetWidth < 1) return;
        nav.classList.remove("tabs-icon-only");

        var buttons = buttonsOf(nav);
        var clipped = false;
        for (var i = 0; i < buttons.length; i++) {
            var label = labelOf(buttons[i], nav);
            if (!label) continue;
            var name = String(label.textContent || "").replace(/^\s+|\s+$/g, "");
            if (name) {
                buttons[i].title = name;
                buttons[i].setAttribute("aria-label", name);
            }
            if (label.scrollWidth > label.clientWidth + 1) clipped = true;
        }
        nav.classList.toggle("tabs-icon-only", clipped);
    }

    function scanNow() {
        pending = false;
        var rows = document.querySelectorAll(".set-tabs, .ek-sheet .settings-nav, .ek-sheet .qi-sheet-tabs");
        for (var i = 0; i < rows.length; i++) measure(rows[i]);
    }

    function scan() {
        if (pending) return;
        pending = true;
        if (window.requestAnimationFrame) window.requestAnimationFrame(scanNow);
        else setTimeout(scanNow, 0);
    }

    window.addEventListener("resize", scan);
    window.addEventListener("load", scan);
    document.addEventListener("DOMContentLoaded", scan);

    if (window.MutationObserver) {
        new MutationObserver(scan).observe(document.documentElement, {
            childList: true,
            characterData: true,
            subtree: true,
            attributes: true,
            attributeFilter: ["hidden"]
        });
    }

    window.EditKitResponsiveTabs = { refresh: scan };
    scan();
    setTimeout(scan, 80);
    setTimeout(scan, 260);
})();
