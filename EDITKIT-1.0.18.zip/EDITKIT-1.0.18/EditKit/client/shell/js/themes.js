/* ============================================================================
   EDITKIT — TEMAS

   Un tema es el aspecto entero en una sola pulsacion: el acento, el fondo y el
   velo que los paneles echan por encima. Nada mas, y eso es lo importante.

   ── QUE ES UN TEMA Y QUE ES UN PERFIL ──────────────────────────────────────
   Las dos cosas guardan ajustes, y por eso hay que decir en voz alta donde
   esta la linea o acabarian pisandose:

     · un TEMA guarda como SE VE el panel — tres cosas, ninguna funcional;
     · un PERFIL guarda como TRABAJA — la rejilla, los presets, el idioma, las
       preferencias, todo.

   De ahi que un tema se cambie sin pensarlo y un perfil pida confirmacion y
   deje copia de seguridad. Cambiar de tema no puede estropear nada: lo peor
   que pasa es que no guste, y el de antes sigue en la lista.

   ── LOS TRES DE FABRICA ────────────────────────────────────────────────────
   No son tres variaciones del mismo gris: son tres maneras distintas de querer
   trabajar, y por eso el fondo cambia de modo y no solo de color.

     · SOBRIO    color plano y velo alto. Un panel acoplado al lado de una
                 linea de tiempo no tiene por que llamar la atencion, y este es
                 el que viene puesto.
     · AURA      el fondo animado, que reacciona al cursor. Para quien tiene
                 sitio de sobra y le gusta que el panel este vivo.
     · TINTA     casi negro, acento frio y velo bajo. Para trabajar de noche o
                 con material oscuro, donde un panel gris claro deslumbra.

   ── COMO SE APLICA ─────────────────────────────────────────────────────────
   Escribiendo en los mismos sitios donde escriben los ajustes de siempre, y
   avisando a quien pinta. Nada de una capa aparte que "recuerde" el tema: si
   el usuario toca un deslizador despues de aplicar uno, lo que queda es lo que
   toco, y el tema deja de estar marcado. Un tema no es un modo del que haya
   que salir; es un punto de partida.
   ============================================================================ */
(function () {
    "use strict";

    var K_MINE = "editkit_themes";     // los que guarda el usuario
    var K_LAST = "editkit_theme_last"; // el ultimo aplicado, para marcarlo
    var BD_KEY = "editkit_backdrop";   // donde vive el fondo

    // ---------------------------------------------------------------------
    // Los tres de fabrica
    // ---------------------------------------------------------------------
    /* Solo se nombra lo que el tema decide. Lo que no esta aqui no se toca:
       un tema que fijara los catorce campos del fondo le borraria al usuario
       la imagen que tiene puesta por cambiar de acento. */
    var BUILT_IN = [
        {
            id: "sober",
            accent: "#49c9bd",
            bd: { mode: "color", color: "#1d1d1d", scrim: 62, grain: 5 }
        },
        {
            id: "aura",
            accent: "#7c9cff",
            /* El aura lleva su propio color de base: es lo que se ve por
               debajo del humo, y sin nombrarlo heredaria el del tema anterior
               —aplicar Tinta y despues Aura dejaba el aura sobre el negro de
               Tinta—. Un tema tiene que ser el mismo viniendo de donde venga. */
            bd: { mode: "aura", color: "#16181d", preset: "nebula",
                  intensity: 70, reactivity: 65, softness: 18,
                  scrim: 58, grain: 6, opacity: 85, fps: 30 }
        },
        {
            id: "ink",
            accent: "#8ad7c8",
            bd: { mode: "color", color: "#101012", scrim: 78, grain: 3 }
        }
    ];

    // ---------------------------------------------------------------------
    // Idioma
    // ---------------------------------------------------------------------
    var DICT = {
        es: {
            section: "Temas",
            save: "Guardar el aspecto de ahora",
            hint: "Un tema guarda el acento, el fondo y el velo. No toca los botones, los presets ni las preferencias: eso son los perfiles.",
            sober: "Sobrio",
            aura: "Aura",
            ink: "Tinta",
            soberTip: "Color plano y velo alto. El que viene puesto.",
            auraTip: "El fondo animado, que reacciona al cursor.",
            inkTip: "Casi negro y velo bajo, para trabajar de noche.",
            mineTip: "Tuyo, guardado desde el aspecto que tenias puesto.",
            kill: "Quitar este tema",
            namePh: "Nombre del tema",
            ok: "Guardar",
            cancel: "Cancelar",
            saved: "Tema guardado",
            gone: "Tema eliminado",
            full: "Caben cinco temas propios. Quita uno antes de guardar otro.",
            dup: "Ya tienes un tema con ese nombre."
        },
        en: {
            section: "Themes",
            save: "Save the current look",
            hint: "A theme saves the accent, the backdrop and the veil. It does not touch buttons, presets or preferences: those are profiles.",
            sober: "Sober",
            aura: "Aura",
            ink: "Ink",
            soberTip: "Flat colour and a high veil. The one it ships with.",
            auraTip: "The animated backdrop that reacts to the cursor.",
            inkTip: "Almost black with a low veil, for working at night.",
            mineTip: "Yours, saved from the look you had at the time.",
            kill: "Remove this theme",
            namePh: "Theme name",
            ok: "Save",
            cancel: "Cancel",
            saved: "Theme saved",
            gone: "Theme removed",
            full: "Five of your own fit. Remove one before saving another.",
            dup: "You already have a theme with that name."
        }
    };

    var lang = "es";
    try { lang = localStorage.getItem("editkit_lang") || "es"; } catch (e) {}
    if (!DICT[lang]) lang = "es";
    function t(k) { return (DICT[lang] && DICT[lang][k]) || DICT.es[k] || k; }

    function $(id) { return document.getElementById(id); }

    function readJson(key, dflt) {
        try {
            var raw = localStorage.getItem(key);
            if (!raw) return dflt;
            var v = JSON.parse(raw);
            return (v && typeof v === "object") ? v : dflt;
        } catch (e) { return dflt; }
    }

    function mine() {
        var a = readJson(K_MINE, null);
        return (a && a.length) ? a : [];
    }

    // ---------------------------------------------------------------------
    // Leer y escribir el aspecto
    // ---------------------------------------------------------------------
    function accentNow() {
        try {
            if (window.EditKitAccent && window.EditKitAccent.get) return window.EditKitAccent.get();
        } catch (e) {}
        try { return localStorage.getItem("easeit_accent") || "#49c9bd"; } catch (e2) { return "#49c9bd"; }
    }

    function backdropNow() {
        return readJson(BD_KEY, {}) || {};
    }

    /* Lo que se guarda de un tema propio: el acento y solo los campos del fondo
       que un tema decide. La imagen queda fuera a proposito, igual que en los
       perfiles: es un archivo del usuario y pesa lo que pesa. */
    var BD_FIELDS = ["mode", "preset", "color", "scrim", "grain",
                     "intensity", "reactivity", "softness", "opacity", "fps"];

    function snapshot() {
        var src = backdropNow(), bd = {}, i;
        for (i = 0; i < BD_FIELDS.length; i++) {
            if (src[BD_FIELDS[i]] !== undefined) bd[BD_FIELDS[i]] = src[BD_FIELDS[i]];
        }
        return { accent: accentNow(), bd: bd };
    }

    /* Aplicar es escribir donde escriben los ajustes de siempre y avisar a
       quien pinta. El fondo se funde con lo que ya hubiera: un tema que solo
       nombra el color no tiene por que llevarse por delante la reactividad. */
    function apply(theme) {
        if (!theme) return;

        if (theme.bd) {
            var cur = backdropNow(), k;
            for (k in theme.bd) {
                if (theme.bd.hasOwnProperty(k)) cur[k] = theme.bd[k];
            }
            try { localStorage.setItem(BD_KEY, JSON.stringify(cur)); } catch (e) {}
            try {
                if (window.EditKitBackdrop && window.EditKitBackdrop.reload) {
                    window.EditKitBackdrop.reload();
                }
            } catch (e2) {}
        }

        /* El acento va DESPUES del fondo. El fondo no depende del acento, pero
           el aura lo usa para tenir sus lobulos: al reves, el primer repintado
           saldria con el color anterior y habria un parpadeo. */
        if (theme.accent) {
            try {
                if (window.EditKitAccent && window.EditKitAccent.set) {
                    window.EditKitAccent.set(theme.accent);
                } else {
                    localStorage.setItem("easeit_accent", theme.accent);
                }
            } catch (e3) {}
        }

        try { localStorage.setItem(K_LAST, theme.id || theme.name || ""); } catch (e4) {}
        faces(theme.id);
        render();
    }

    /* ------------------------------------------------------------------
       SECRETO: LAS TRES CARAS

       Probar los tres temas de fabrica seguidos. No hay nada que adivinar —es
       exactamente lo que hace cualquiera que abra esta seccion por primera
       vez— y esa es la idea: el primer secreto que encuentra el usuario tiene
       que encontrarlo sin buscarlo, para que se entere de que hay mas.

       Se cuentan los distintos, no las pulsaciones, y no hace falta que sea
       del tiron ni en orden: apretar Sobrio seis veces no vale, y volver
       manana a por el tercero, si.
       ------------------------------------------------------------------ */
    var seen = {};
    function faces(id) {
        if (id !== "sober" && id !== "aura" && id !== "ink") return;
        seen[id] = 1;
        var n = 0, k;
        for (k in seen) { if (seen.hasOwnProperty(k)) n++; }
        if (n < 3) return;
        try { if (window.EditKitLog) window.EditKitLog.found("c3"); } catch (e) {}
    }

    // ---------------------------------------------------------------------
    // La fila de temas
    // ---------------------------------------------------------------------
    function last() {
        try { return localStorage.getItem(K_LAST) || ""; } catch (e) { return ""; }
    }

    /* ------------------------------------------------------------------
       LA CARTA

       Una muestra de tema no es un boton con el nombre del tema: es el tema,
       en pequeno. Dentro va una maqueta del panel con el fondo de verdad, el
       velo de verdad, la curva de EaseIt y la rejilla de QuickIt tenidas con
       su acento. "Tinta" no significa nada hasta que se ve, y una fila de
       nombres obliga a aplicarlos uno a uno para saber cual se queria.

       El marcado de dentro es siempre el mismo y no depende de nada del
       usuario, asi que se escribe de una vez. Lo unico que viene de fuera es
       el nombre, y ese se pone con textContent: un tema se puede llamar como
       su dueno quiera, incluso con un `<` en medio.
       ------------------------------------------------------------------ */
    var GUTS =
        '<span class="thm-bg"></span>' +
        '<span class="thm-mock">' +
            '<span class="thm-mock-bar"><i class="thm-mock-dot"></i><i></i><i></i></span>' +
            '<span class="thm-mock-curve">' +
                '<svg viewBox="0 0 44 14" preserveAspectRatio="none" aria-hidden="true">' +
                '<path d="M1 13 C 13 13 15 1 43 1" fill="none" stroke="currentColor" ' +
                'stroke-width="1.4" stroke-linecap="round"/></svg>' +
            '</span>' +
            '<span class="thm-mock-grid"><i></i><i></i><i></i><i></i><i></i><i></i></span>' +
        '</span>' +
        '<span class="thm-sheen"></span>';

    // Un acento con transparencia pegada detras solo vale si el acento es un
    // hex de seis digitos, que es lo que escribe el selector de color. Si
    // alguien guardo otra cosa, se usa tal cual y el degradado sale opaco:
    // peor, pero no roto.
    function tint(acc) {
        return /^#[0-9a-f]{6}$/i.test(acc) ? acc + "55" : acc;
    }

    /* El velo solo existe cuando hay algo que velar. En modo color el panel
       pinta el color elegido tal cual —backdrop.js informa velo cero— y la
       muestra tiene que ensenar eso mismo, no un gris por encima. */
    function veilOf(bd) {
        if (!bd || !bd.mode || bd.mode === "color") return "transparent";
        var n = (typeof bd.scrim === "number") ? bd.scrim : 62;
        if (n < 0) n = 0;
        if (n > 100) n = 100;
        return "rgba(26, 26, 26, " + (n / 100).toFixed(2) + ")";
    }

    /* El fondo de la carta. En aura —y en imagen, cuya foto no se guarda— se
       insinua con un resplandor del acento sobre el color base, y ese
       resplandor se coloca en --thm-light-x/y: el mismo sitio donde esta el
       cursor. La muestra del fondo que reacciona al cursor reacciona al
       cursor. */
    function paintBg(el, theme) {
        var bd = theme.bd || {};
        var base = bd.color || "#1d1d1d";
        if (bd.mode === "aura" || bd.mode === "image") {
            el.style.background = "radial-gradient(circle at var(--thm-light-x) " +
                "var(--thm-light-y), " + tint(theme.accent || "#49c9bd") +
                ", " + base + " 72%)";
        } else {
            el.style.background = base;
        }
    }

    function card(theme, label, tip) {
        var b = document.createElement("button");
        var acc = theme.accent || "#49c9bd";
        b.type = "button";
        b.className = "thm-card" + (last() === (theme.id || theme.name) ? " on" : "");
        b.title = tip || "";
        b.style.setProperty("--thm-accent", acc);
        b.style.setProperty("--thm-veil", veilOf(theme.bd));

        var stage = document.createElement("span");
        stage.className = "thm-stage";
        stage.innerHTML = GUTS;
        paintBg(stage.firstChild, theme);
        b.appendChild(stage);

        var foot = document.createElement("span");
        foot.className = "thm-foot";
        var name = document.createElement("span");
        name.className = "thm-name";
        name.textContent = label;
        var tick = document.createElement("span");
        tick.className = "thm-tick";
        foot.appendChild(name);
        foot.appendChild(tick);
        b.appendChild(foot);

        b.addEventListener("click", function () { apply(theme); });
        return b;
    }

    /* La casilla. El boton de quitar va FUERA de la carta y no dentro: un
       boton dentro de otro boton no es marcado valido y el navegador decide
       por su cuenta cual de los dos recibe el clic.

       Antes el segundo clic sobre un tema propio lo borraba. Eso era una
       trampa: nada en pantalla lo decia, y el gesto para volver a aplicar un
       tema es exactamente el mismo que para perderlo. */
    function slot(node, killName) {
        var d = document.createElement("div");
        d.className = "thm-slot";
        d.appendChild(node);
        if (killName !== null && killName !== undefined) {
            var x = document.createElement("button");
            x.type = "button";
            x.className = "thm-kill";
            x.title = t("kill");
            x.setAttribute("aria-label", t("kill"));
            x.innerHTML = '<svg class="ms" viewBox="0 -960 960 960" width="9" height="9" ' +
                'fill="currentColor" aria-hidden="true"><path d="m256-200-56-56 224-224-224-224 ' +
                '56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg>';
            x.addEventListener("click", function (ev) {
                ev.stopPropagation();
                remove(killName);
            });
            d.appendChild(x);
        }
        return d;
    }

    /* ------------------------------------------------------------------
       EL RELIEVE

       Seis variables y nada mas: el giro en dos ejes, el desplazamiento de
       las capas de dentro y donde cae la luz. Quien las usa es el CSS; aqui
       solo se calcula donde esta el cursor dentro de la carta, de -1 a 1.

       Todo pasa por un requestAnimationFrame. Un mousemove puede llegar
       cientos de veces por segundo y la pantalla solo se pinta sesenta: sin
       agrupar, se estarian calculando estilos que nadie llega a ver, y en un
       panel acoplado dentro de After Effects esos ciclos se los quita a la
       linea de tiempo.
       ------------------------------------------------------------------ */
    var MAX_TILT = 7;    // grados de giro en el borde
    var MAX_SHIFT = 5;   // px que recorre la maqueta; el fondo hace un tercio

    var still = false;
    try { still = window.matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) {}

    var hot = null, pend = null, frame = 0;

    function paintTilt() {
        frame = 0;
        if (!pend) return;
        var c = pend.c, nx = pend.nx, ny = pend.ny;
        pend = null;
        /* El signo: con el cursor arriba, el borde de arriba se va hacia
           atras. La carta se aparta de donde se la empuja, que es lo que hace
           cualquier cosa apoyada en una mesa. */
        c.style.setProperty("--thm-tilt-x", (-ny * MAX_TILT).toFixed(2) + "deg");
        c.style.setProperty("--thm-tilt-y", (nx * MAX_TILT).toFixed(2) + "deg");
        c.style.setProperty("--thm-shift-x", (nx * MAX_SHIFT).toFixed(2) + "px");
        c.style.setProperty("--thm-shift-y", (ny * MAX_SHIFT).toFixed(2) + "px");
        c.style.setProperty("--thm-light-x", (50 + nx * 45).toFixed(1) + "%");
        c.style.setProperty("--thm-light-y", (50 + ny * 45).toFixed(1) + "%");
    }

    function ask() {
        if (frame) return;
        if (window.requestAnimationFrame) frame = window.requestAnimationFrame(paintTilt);
        else paintTilt();
    }

    /* Volver al reposo se hace quitando las variables, no poniendolas a cero:
       lo que queda es el valor que declara el CSS, y asi el reposo se cambia
       en la hoja de estilos y no aqui. */
    var VARS = ["--thm-tilt-x", "--thm-tilt-y", "--thm-shift-x",
                "--thm-shift-y", "--thm-light-x", "--thm-light-y"];

    function cool() {
        if (!hot) return;
        var c = hot;
        hot = null;
        pend = null;
        quad = -1;          // media vuelta a una carta y media a otra no es una vuelta
        dir = 0;
        steps = 0;
        c.classList.remove("tracking");
        for (var i = 0; i < VARS.length; i++) c.style.removeProperty(VARS[i]);
    }

    function cardOf(node) {
        while (node && node.nodeType === 1) {
            if (node.classList && node.classList.contains("thm-card")) return node;
            if (node.classList && node.classList.contains("thm-row")) return null;
            node = node.parentNode;
        }
        return null;
    }

    function clamp(v) { return v < -1 ? -1 : (v > 1 ? 1 : v); }

    /* ------------------------------------------------------------------
       SECRETO: LA CARTA GIRADA

       Rodear una carta con el cursor, una vuelta entera. Se lleva la cuenta de
       por que cuadrante va pasando y hace falta pisar los cuatro en orden, sin
       saltarse ninguno: cruzar la carta de lado a lado no vale, hay que darle
       la vuelta de verdad.

       Va aqui y no en easter-eggs.js porque el unico que sabe donde esta el
       cursor dentro de una carta es esto.
       ------------------------------------------------------------------ */
    var quad = -1;   // en que cuarto de la carta esta el cursor
    var dir = 0;     // 1 con las agujas del reloj, -1 al contrario
    var steps = 0;   // cuartos seguidos en ese mismo sentido

    function spin(nx, ny) {
        // 0 arriba-izq, 1 arriba-der, 2 abajo-der, 3 abajo-izq: en el orden de
        // las agujas del reloj, para que "el siguiente" sea siempre +1.
        var q = (ny < 0) ? (nx < 0 ? 0 : 1) : (nx < 0 ? 3 : 2);
        if (q === quad) return;
        if (quad < 0) { quad = q; dir = 0; steps = 0; return; }

        var step = (q - quad + 4) % 4;
        quad = q;

        // Ha saltado al cuarto de enfrente: ha cruzado la carta por el medio,
        // que es lo que hace cualquiera al ir a pulsarla. No es una vuelta.
        if (step === 2) { dir = 0; steps = 0; return; }

        /* Y las dos vueltas valen, en un sentido y en el otro. Se cuentan los
           cuartos seguidos en el MISMO sentido; cambiar de sentido empieza de
           nuevo, asi que ir y volver por el mismo lado nunca suma. */
        var d = (step === 1) ? 1 : -1;
        if (d !== dir) { dir = d; steps = 1; return; }

        steps++;
        if (steps < 4) return;             // cuatro cuartos: la vuelta entera
        steps = 0;
        try { if (window.EditKitLog) window.EditKitLog.found("x1"); } catch (e) {}
    }

    function track(ev) {
        var awake = window.EditKitAwake;
        if (awake && (awake.idle() || awake.performance())) { cool(); return; }
        var c = cardOf(ev.target);
        if (!c) { cool(); return; }
        if (hot !== c) {
            cool();
            hot = c;
            c.classList.add("tracking");
        }
        var r = c.getBoundingClientRect();
        if (!r.width || !r.height) return;
        var nx = clamp(((ev.clientX - r.left) / r.width) * 2 - 1);
        var ny = clamp(((ev.clientY - r.top) / r.height) * 2 - 1);
        pend = { c: c, nx: nx, ny: ny };
        spin(nx, ny);
        ask();
    }

    /* Un solo par de oyentes en la fila, no dos por carta. Las cartas se
       vuelven a crear cada vez que se aplica un tema, y enganchar en cada
       una significa enganchar de nuevo en cada repintado. */
    function wireTilt() {
        var row = $("thmRow");
        if (!row || still || row.getAttribute("data-tilt") === "1") return;
        row.setAttribute("data-tilt", "1");
        row.addEventListener("mousemove", track);
        row.addEventListener("mouseleave", cool);
    }

    function render() {
        var row = $("thmRow");
        if (!row) return;
        row.innerHTML = "";

        /* La carta que se estaba siguiendo acaba de desaparecer del arbol, y
           con ella el globo que estuviera describiendola. */
        cool();
        try { if (window.EditKitTip) window.EditKitTip.hide(); } catch (e0) {}

        var i;
        for (i = 0; i < BUILT_IN.length; i++) {
            row.appendChild(slot(
                card(BUILT_IN[i], t(BUILT_IN[i].id), t(BUILT_IN[i].id + "Tip")), null));
        }
        var own = mine();
        for (i = 0; i < own.length; i++) {
            row.appendChild(slot(
                card(own[i], own[i].name, t("mineTip")), own[i].name));
        }

        var btn = $("thmSave");
        if (btn) btn.textContent = t("save");
        var hint = $("thmHint");
        if (hint) hint.textContent = t("hint");
        var sec = $("setSectionThemes");
        if (sec) sec.textContent = t("section");
    }

    function say(msg) {
        var hint = $("thmHint");
        if (!hint) return;
        hint.textContent = msg;
        setTimeout(function () { if (hint) hint.textContent = t("hint"); }, 3000);
    }

    function remove(name) {
        var own = mine(), out = [], i;
        for (i = 0; i < own.length; i++) { if (own[i].name !== name) out.push(own[i]); }
        try { localStorage.setItem(K_MINE, JSON.stringify(out)); } catch (e) {}
        try { localStorage.removeItem(K_LAST); } catch (e2) {}
        render();
        say(t("gone"));
    }

    // ---------------------------------------------------------------------
    // Guardar el aspecto de ahora
    // ---------------------------------------------------------------------
    /* El campo del nombre se arma al pulsar y se va al terminar, igual que en
       los perfiles: un campo de texto permanente en una ventana de ajustes se
       lee como algo que hay que rellenar. */
    function askName() {
        var row = $("thmRow");
        if (!row || $("thmNamer")) return;

        var box = document.createElement("div");
        box.className = "prof-namer";
        box.id = "thmNamer";

        var inp = document.createElement("input");
        inp.type = "text";
        inp.className = "bd-input";
        inp.maxLength = 24;
        inp.placeholder = t("namePh");

        var ok = document.createElement("button");
        ok.type = "button";
        ok.className = "bd-btn";
        ok.textContent = t("ok");

        var no = document.createElement("button");
        no.type = "button";
        no.className = "bd-btn ghost";
        no.textContent = t("cancel");

        function close() { if (box.parentNode) box.parentNode.removeChild(box); }

        function commit() {
            var v = inp.value.replace(/^\s+|\s+$/g, "");
            if (!v) { inp.focus(); return; }
            var own = mine(), i;
            for (i = 0; i < own.length; i++) {
                if (own[i].name === v) { say(t("dup")); return; }
            }
            if (own.length >= 5) { say(t("full")); return; }

            var snap = snapshot();
            snap.name = v;
            snap.id = v;
            own.push(snap);
            try { localStorage.setItem(K_MINE, JSON.stringify(own)); } catch (e) {}
            try { localStorage.setItem(K_LAST, v); } catch (e2) {}
            close();
            render();
            say(t("saved"));
        }

        ok.addEventListener("click", commit);
        no.addEventListener("click", close);
        inp.addEventListener("keydown", function (e) {
            if (e.key === "Enter" || e.keyCode === 13) { e.preventDefault(); commit(); }
            else if (e.key === "Escape" || e.keyCode === 27) { e.preventDefault(); close(); }
        });

        box.appendChild(inp);
        box.appendChild(ok);
        box.appendChild(no);
        row.parentNode.insertBefore(box, row.nextSibling);
        inp.focus();
    }

    // ---------------------------------------------------------------------
    // Arranque
    // ---------------------------------------------------------------------
    function boot() {
        var btn = $("thmSave");
        if (btn) btn.addEventListener("click", askName);
        wireTilt();

        /* Tocar un deslizador del fondo o el acento a mano desmarca el tema:
           lo que hay puesto ya no es el tema, es lo que el usuario dejo. */
        try {
            if (window.EditKitAccent && window.EditKitAccent.onChange) {
                var first = true;
                window.EditKitAccent.onChange(function () {
                    if (first) { first = false; return; }   // la llamada de cortesia
                    render();
                });
            }
        } catch (e) {}

        render();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }

    window.EditKitThemes = {
        setLanguage: function (l) { lang = DICT[l] ? l : "es"; render(); },
        apply: apply,
        refresh: render
    };
})();
