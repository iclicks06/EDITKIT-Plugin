/* ============================================================================
   EDITKIT — MEDIA FOR THE EASEIT / ALIGNIT WORK AREAS

   Each work area owns its mode, source, fit, blur and opacity. The editor is
   mounted inside the settings window of the tool it changes. Video is an
   expert opt-in: its tab stays visible but locked until that same tab is
   clicked seven times. Its tooltip explains the risk, gesture and progress.
   ============================================================================ */
(function () {
    "use strict";

    var KEY = "editkit_work_media";
    var TAG = "surface-media";
    var TOOLS = ["ease", "align"];
    var isShell = window.parent === window;
    var unlockClicks = { ease: 0, align: 0 };
    var previewToken = { ease: 0, align: 0 };
    var surfaceSyncBound = false;

    function defaults() {
        return { mode: "color", image: "", video: "", fit: "cover", blur: 0, opacity: 100, videoUnlocked: false };
    }

    function bounded(value, fallback, min, max) {
        var n = parseInt(value, 10);
        if (!isFinite(n)) n = fallback;
        return Math.max(min, Math.min(max, n));
    }

    function cleanOne(value) {
        value = value || {};
        var out = defaults();
        out.videoUnlocked = value.videoUnlocked === true;
        out.mode = /^(color|image|video)$/.test(value.mode) ? value.mode : "color";
        if (out.mode === "video" && !out.videoUnlocked) out.mode = "color";
        out.image = typeof value.image === "string" ? value.image : "";
        out.video = typeof value.video === "string" ? value.video : "";
        out.fit = /^(cover|contain|tile|center)$/.test(value.fit) ? value.fit : "cover";
        out.blur = bounded(value.blur, 0, 0, 30);
        out.opacity = bounded(value.opacity, 100, 0, 100);
        return out;
    }

    function clean(value) {
        value = value || {};
        return { ease: cleanOne(value.ease), align: cleanOne(value.align) };
    }

    function read() {
        try { return clean(JSON.parse(localStorage.getItem(KEY) || "{}")); }
        catch (e) { return clean({}); }
    }

    function write(value) {
        try { localStorage.setItem(KEY, JSON.stringify(value)); } catch (e) {}
    }

    function same(a, b) {
        try { return JSON.stringify(a) === JSON.stringify(b); } catch (e) { return false; }
    }

    function mediaUrl(src) {
        if (!src) return "";
        var s = String(src).replace(/^\s+|\s+$/g, "");
        if (/^(data:|https?:|file:|blob:)/i.test(s)) return s;
        var win = /^[A-Za-z]:[\\/]/.test(s), unc = /^\\\\/.test(s), posix = /^\//.test(s);
        if (/^[a-z][a-z0-9+.-]*:/i.test(s) && !win) return "";
        if (!win && !unc && !posix) return encodeURI(s.replace(/\\/g, "/"));
        var p = s.replace(/\\/g, "/");
        if (unc) return "file:" + encodeURI(p);
        if (!posix) p = "/" + p;
        return "file://" + encodeURI(p);
    }

    function sourceOf(media) { return media.mode === "video" ? media.video : media.image; }

    function setFit(image, video, fit) {
        image.style.backgroundPosition = "center";
        if (fit === "tile") {
            image.style.backgroundSize = "auto";
            image.style.backgroundRepeat = "repeat";
        } else if (fit === "center") {
            image.style.backgroundSize = "auto";
            image.style.backgroundRepeat = "no-repeat";
        } else {
            image.style.backgroundSize = fit;
            image.style.backgroundRepeat = "no-repeat";
        }
        video.style.objectFit = (fit === "contain" || fit === "center") ? "contain" : "cover";
    }

    function safePlay(video) {
        var awake = window.EditKitAwake;
        if (!video || document.hidden || (awake && (awake.idle() || awake.performance()))) return;
        try {
            var result = video.play();
            if (result && result.catch) result.catch(function () {});
        } catch (e) {}
    }

    function paneTarget() {
        var graph = document.querySelector && document.querySelector(".graph-box");
        if (graph) return { tool: "ease", node: graph };
        var reticle = document.querySelector && document.querySelector(".reticle-card");
        return reticle ? { tool: "align", node: reticle } : null;
    }

    function paintPane() {
        var found = paneTarget();
        if (!found) return;
        var media = state[found.tool];
        var layer = found.node.querySelector(".ek-work-media");
        if (!layer) return;
        var image = layer.querySelector(".ek-work-media-image");
        var video = layer.querySelector(".ek-work-media-video");
        var url = mediaUrl(sourceOf(media));
        var awake = window.EditKitAwake;
        var suspended = !!(awake && (awake.idle() || awake.performance()));
        var active = !suspended && media.mode !== "color" && !!url;

        found.node.classList.toggle("ek-has-media", active);
        layer.style.display = active ? "block" : "none";
        layer.style.opacity = String(media.opacity / 100);
        layer.style.filter = media.blur ? "blur(" + media.blur + "px)" : "none";
        setFit(image, video, media.fit);

        image.style.display = active && media.mode === "image" ? "block" : "none";
        image.style.backgroundImage = active && media.mode === "image"
            ? 'url("' + url.replace(/"/g, '\\"') + '")' : "none";

        if (active && media.mode === "video") {
            video.style.display = "block";
            video.muted = true;
            video.loop = true;
            if (video.getAttribute("src") !== url) video.setAttribute("src", url);
            safePlay(video);
        } else {
            video.style.display = "none";
            try { video.pause(); } catch (e2) {}
        }
    }

    function relay(exceptWindow) {
        var message = { __editkit: TAG, value: state };
        if (isShell) {
            var frames = document.querySelectorAll("iframe");
            for (var i = 0; i < frames.length; i++) {
                var target = null;
                try { target = frames[i].contentWindow; } catch (e) { continue; }
                if (!target || target === exceptWindow) continue;
                try { target.postMessage(message, "*"); } catch (e2) {}
            }
        } else if (exceptWindow !== window.parent) {
            try { window.parent.postMessage(message, "*"); } catch (e3) {}
        }
    }

    var state = read();

    function set(next, from, force) {
        next = clean(next);
        if (same(state, next) && !force) return;
        state = next;
        write(state);
        paintPane();
        syncAll();
        relay(from || null);
    }

    function change(tool, fn) {
        var next = clean(state);
        fn(next[tool]);
        set(next);
    }

    window.addEventListener("message", function (event) {
        var data = event.data;
        if (!data || data.__editkit !== TAG) return;
        if (data.request) {
            if (isShell && event.source) {
                try { event.source.postMessage({ __editkit: TAG, value: state }, "*"); } catch (e) {}
            }
            return;
        }
        set(data.value, event.source);
    });

    var DICT = {
        es: {
            titleEase: "Recuadro de EaseIt", titleAlign: "Recuadro de AlignIt",
            noteEase: "Fondo del editor de curvas.", noteAlign: "Fondo del visor de alineación.",
            color: "Color", image: "Imagen / GIF", video: "Video",
            colorField: "Color del recuadro",
            none: "Sin archivo seleccionado.", pickImage: "Elegir imagen…", pickVideo: "Elegir video…", clear: "Quitar",
            pathImage: "…o pega una ruta o URL de imagen", pathVideo: "…o pega una ruta o URL de video",
            fit: "Ajuste", cover: "Rellenar", contain: "Contener", tile: "Mosaico", center: "Centrar",
            blur: "Desenfoque", opacity: "Opacidad",
            imageHint: "Las imágenes y los GIF pueden ser locales o usar una URL.",
            videoHint: "El video se reproduce sin sonido y se pausa cuando el panel no está visible.",
            loadFail: "No se pudo cargar el archivo. Revisa la ruta o el formato.",
            tooLarge: "El archivo incrustado es muy pesado y puede volver inestable el panel. Usa una ruta local o un archivo más ligero.",
            videoLock: "Bloqueado por estabilidad: el video puede aumentar el consumo o causar inestabilidad. Haz clic 7 veces en esta pestaña para activarlo.",
            videoProgress: "Bloqueado por estabilidad. Haz clic 7 veces en esta pestaña para activarlo (%n/7).",
            videoOpen: "Video activado para este recuadro. Úsalo sin sonido y con archivos ligeros.",
            videoInfo: "Información sobre video", reset: "Restablecer este recuadro"
        },
        en: {
            titleEase: "EaseIt work area", titleAlign: "AlignIt work area",
            noteEase: "Background of the curve editor.", noteAlign: "Background of the alignment viewfinder.",
            color: "Color", image: "Image / GIF", video: "Video",
            colorField: "Work-area colour",
            none: "No file selected.", pickImage: "Choose image…", pickVideo: "Choose video…", clear: "Remove",
            pathImage: "…or paste an image path or URL", pathVideo: "…or paste a video path or URL",
            fit: "Fit", cover: "Cover", contain: "Contain", tile: "Tile", center: "Center",
            blur: "Blur", opacity: "Opacity",
            imageHint: "Images and GIFs can be local or use a URL.",
            videoHint: "Video plays muted and pauses while the panel is not visible.",
            loadFail: "The file could not be loaded. Check its path or format.",
            tooLarge: "The embedded file is very large and may make the panel unstable. Use a local path or a lighter file.",
            videoLock: "Locked for stability: video can increase resource use or cause instability. Click this tab 7 times to enable it.",
            videoProgress: "Locked for stability. Click this tab 7 times to enable it (%n/7).",
            videoOpen: "Video is enabled for this work area. Keep it muted and use lightweight files.",
            videoInfo: "Video information", reset: "Reset this work area"
        }
    };

    var lang = "es";
    try { lang = localStorage.getItem("editkit_lang") || "es"; } catch (e4) {}
    if (!DICT[lang]) lang = "es";
    function t(key) { return DICT[lang][key] || DICT.es[key] || key; }
    function byId(id) { return document.getElementById(id); }
    function text(id, key) { var el = byId(id); if (el) el.textContent = t(key); }
    function modeButton(tool, mode) { return document.querySelector('[data-surface-tool="' + tool + '"][data-surface-mode="' + mode + '"]'); }

    function cardHtml(tool) {
        return '' +
            '<div class="surface-media-card" data-surface-tool-card="' + tool + '">' +
              '<div class="surface-media-head">' +
                '<div><div class="surface-media-title" id="' + tool + 'MediaTitle"></div>' +
                '<p class="surface-media-note" id="' + tool + 'MediaNote"></p></div>' +
              '</div>' +
              '<div class="surface-mode-tabs" role="tablist">' +
                '<button class="surface-mode-tab active" data-surface-tool="' + tool + '" data-surface-mode="color" type="button"><span id="' + tool + 'ColorTabLabel"></span></button>' +
                '<button class="surface-mode-tab" data-surface-tool="' + tool + '" data-surface-mode="image" type="button"><span id="' + tool + 'ImageTabLabel"></span></button>' +
                '<button class="surface-mode-tab is-locked" id="' + tool + 'VideoTab" data-surface-tool="' + tool + '" data-surface-mode="video" type="button" aria-disabled="true">' +
                  '<svg class="surface-video-lock" viewBox="0 -960 960 960" aria-hidden="true"><path d="M240-80q-33 0-56.5-23.5T160-160v-400q0-33 23.5-56.5T240-640h40v-80q0-83 58.5-141.5T480-920q83 0 141.5 58.5T680-720v80h40q33 0 56.5 23.5T800-560v400q0 33-23.5 56.5T720-80H240Zm120-560h240v-80q0-50-35-85t-85-35q-50 0-85 35t-35 85v80Z"/></svg>' +
                  '<span id="' + tool + 'VideoTabLabel"></span>' +
                '</button>' +
              '</div>' +
              '<section class="surface-color-pane" id="' + tool + 'ColorPane">' +
                '<input class="surface-color-input" id="' + tool + 'SurfaceInput" type="color" value="#232323" />' +
                '<label class="surface-color-label" id="' + tool + 'SurfaceColorLabel" for="' + tool + 'SurfaceInput"></label>' +
              '</section>' +
              '<section class="surface-media-pane" id="' + tool + 'MediaPane" hidden>' +
                '<div class="surface-media-preview" id="' + tool + 'MediaPreview"></div>' +
                '<p class="surface-media-hint" id="' + tool + 'MediaNone"></p>' +
                '<div class="surface-media-row"><button class="surface-media-button" id="' + tool + 'MediaPick" type="button"></button>' +
                '<button class="surface-media-button ghost" id="' + tool + 'MediaClear" type="button"></button></div>' +
                '<input id="' + tool + 'MediaFile" type="file" accept="image/*" hidden />' +
                '<input class="surface-media-input" id="' + tool + 'MediaPath" type="text" />' +
                '<div class="surface-media-row"><span class="surface-media-label" id="' + tool + 'MediaFitLabel"></span>' +
                '<select class="surface-media-input" id="' + tool + 'MediaFit"><option value="cover"></option><option value="contain"></option><option value="tile"></option><option value="center"></option></select></div>' +
                '<div><div class="surface-slider-head"><span class="surface-media-label" id="' + tool + 'MediaBlurLabel"></span><span id="' + tool + 'MediaBlurVal">0px</span></div>' +
                '<input class="surface-media-range" id="' + tool + 'MediaBlur" type="range" min="0" max="30" step="1" value="0" /></div>' +
                '<div><div class="surface-slider-head"><span class="surface-media-label" id="' + tool + 'MediaOpacityLabel"></span><span id="' + tool + 'MediaOpacityVal">100%</span></div>' +
                '<input class="surface-media-range" id="' + tool + 'MediaOpacity" type="range" min="0" max="100" step="1" value="100" /></div>' +
                '<p class="surface-media-hint" id="' + tool + 'MediaHint"></p>' +
                '<p class="surface-media-hint warn" id="' + tool + 'MediaWarn" hidden></p>' +
              '</section>' +
              '<button class="surface-media-reset" id="' + tool + 'MediaReset" type="button"></button>' +
            '</div>';
    }

    function bindSurfaceSync() {
        if (surfaceSyncBound || !window.EditKitSurfaces || !window.EditKitSurfaces.onChange) return;
        surfaceSyncBound = true;
        window.EditKitSurfaces.onChange(function () { syncAll(); });
    }

    function mount(tool, container) {
        if (TOOLS.indexOf(tool) < 0 || !container) return false;
        if (container.getAttribute("data-surface-media-ready") === "1") {
            syncTool(tool);
            return true;
        }
        container.setAttribute("data-surface-media-ready", "1");
        container.innerHTML = cardHtml(tool);
        bind(tool);
        bindSurfaceSync();
        applyLanguage(lang);
        syncTool(tool);
        return true;
    }

    function preview(tool, media) {
        var box = byId(tool + "MediaPreview");
        if (!box) return;
        var url = mediaUrl(sourceOf(media));
        var video = box.querySelector("video");
        var warning = byId(tool + "MediaWarn");
        var token = ++previewToken[tool];
        var oversize = /^data:/i.test(url) && url.length > 3500000;
        if (warning) {
            warning.textContent = t(oversize ? "tooLarge" : "loadFail");
            warning.hidden = !oversize;
        }
        box.style.opacity = String(media.opacity / 100);
        box.style.filter = media.blur ? "blur(" + media.blur + "px)" : "none";
        if (media.mode === "image" && url) {
            if (video) { try { video.pause(); } catch (e) {} video.parentNode.removeChild(video); }
            box.style.backgroundImage = 'url("' + url.replace(/"/g, '\\"') + '")';
            if (media.fit === "tile") { box.style.backgroundSize = "auto"; box.style.backgroundRepeat = "repeat"; }
            else if (media.fit === "center") { box.style.backgroundSize = "auto"; box.style.backgroundRepeat = "no-repeat"; }
            else { box.style.backgroundSize = media.fit; box.style.backgroundRepeat = "no-repeat"; }
            box.style.backgroundPosition = "center";
            try {
                var probe = new Image();
                probe.onload = function () {
                    if (warning && previewToken[tool] === token && !oversize) warning.hidden = true;
                };
                probe.onerror = function () {
                    if (warning && previewToken[tool] === token) {
                        warning.textContent = t("loadFail");
                        warning.hidden = false;
                    }
                };
                probe.src = url;
            } catch (e3) {}
        } else if (media.mode === "video" && url) {
            box.style.backgroundImage = "none";
            video = video || document.createElement("video");
            if (!video.parentNode) { video.muted = true; video.loop = true; video.setAttribute("playsinline", ""); box.appendChild(video); }
            video.onloadeddata = function () {
                if (warning && previewToken[tool] === token && !oversize) warning.hidden = true;
            };
            video.onerror = function () {
                if (warning && previewToken[tool] === token) {
                    warning.textContent = t("loadFail");
                    warning.hidden = false;
                }
            };
            video.style.objectFit = (media.fit === "contain" || media.fit === "center") ? "contain" : "cover";
            if (video.getAttribute("src") !== url) video.setAttribute("src", url);
            safePlay(video);
        } else {
            box.style.backgroundImage = "none";
            if (warning) warning.hidden = true;
            if (video) { try { video.pause(); } catch (e2) {} video.parentNode.removeChild(video); }
        }
    }

    function unlockTip(tool, media) {
        var button = byId(tool + "VideoTab");
        if (!button) return;
        var key = media.videoUnlocked ? "videoOpen" : (unlockClicks[tool] ? "videoProgress" : "videoLock");
        var explanation = t(key).replace("%n", String(unlockClicks[tool]));
        button.setAttribute("data-tip", explanation);
        button.setAttribute("title", explanation);
        button.setAttribute("aria-label", t("video") + ". " + explanation);
        button.setAttribute("aria-disabled", media.videoUnlocked ? "false" : "true");
        button.classList.toggle("is-locked", !media.videoUnlocked);
    }

    function syncTool(tool) {
        var media = state[tool];
        var modes = ["color", "image", "video"];
        for (var i = 0; i < modes.length; i++) {
            var button = modeButton(tool, modes[i]);
            if (button) button.classList.toggle("active", media.mode === modes[i]);
        }
        var colorPane = byId(tool + "ColorPane"), mediaPane = byId(tool + "MediaPane");
        if (colorPane) colorPane.hidden = media.mode !== "color";
        if (mediaPane) mediaPane.hidden = media.mode === "color";
        var source = sourceOf(media);
        var path = byId(tool + "MediaPath");
        if (path) { path.value = /^(data:|blob:)/i.test(source) ? "" : source; path.placeholder = t(media.mode === "video" ? "pathVideo" : "pathImage"); }
        var fit = byId(tool + "MediaFit"); if (fit) fit.value = media.fit;
        var blur = byId(tool + "MediaBlur"); if (blur) blur.value = media.blur;
        var opacity = byId(tool + "MediaOpacity"); if (opacity) opacity.value = media.opacity;
        if (byId(tool + "MediaBlurVal")) byId(tool + "MediaBlurVal").textContent = media.blur + "px";
        if (byId(tool + "MediaOpacityVal")) byId(tool + "MediaOpacityVal").textContent = media.opacity + "%";
        var none = byId(tool + "MediaNone"); if (none) none.hidden = !!source;
        var clear = byId(tool + "MediaClear"); if (clear) clear.disabled = !source;
        var pick = byId(tool + "MediaPick"); if (pick) pick.textContent = t(media.mode === "video" ? "pickVideo" : "pickImage");
        var hint = byId(tool + "MediaHint"); if (hint) hint.textContent = t(media.mode === "video" ? "videoHint" : "imageHint");
        var file = byId(tool + "MediaFile"); if (file) file.accept = media.mode === "video" ? "video/mp4,video/webm,video/ogg" : "image/*";
        var surface = byId(tool + "SurfaceInput");
        if (surface && window.EditKitSurfaces) {
            var colours = window.EditKitSurfaces.get();
            if (colours && colours[tool]) surface.value = colours[tool];
        }
        unlockTip(tool, media);
        preview(tool, media);
    }

    function syncAll() {
        for (var i = 0; i < TOOLS.length; i++) syncTool(TOOLS[i]);
    }

    function applyLanguage(next) {
        lang = DICT[next] ? next : "es";
        for (var i = 0; i < TOOLS.length; i++) {
            var tool = TOOLS[i];
            text(tool + "MediaTitle", tool === "ease" ? "titleEase" : "titleAlign");
            text(tool + "MediaNote", tool === "ease" ? "noteEase" : "noteAlign");
            text(tool + "ColorTabLabel", "color"); text(tool + "ImageTabLabel", "image"); text(tool + "VideoTabLabel", "video");
            text(tool + "SurfaceColorLabel", "colorField");
            text(tool + "MediaNone", "none"); text(tool + "MediaClear", "clear");
            text(tool + "MediaFitLabel", "fit"); text(tool + "MediaBlurLabel", "blur"); text(tool + "MediaOpacityLabel", "opacity");
            text(tool + "MediaReset", "reset");
            var fit = byId(tool + "MediaFit");
            if (fit) {
                var labels = { cover: "cover", contain: "contain", tile: "tile", center: "center" };
                for (var oi = 0; oi < fit.options.length; oi++) fit.options[oi].textContent = t(labels[fit.options[oi].value]);
            }
        }
        syncAll();
    }

    function setSource(tool, source) {
        change(tool, function (media) {
            if (media.mode === "video") media.video = source;
            else media.image = source;
        });
    }

    function fallbackFile(tool, file) {
        if (!file) return;
        if (file.path) { setSource(tool, file.path); return; }
        if (state[tool].mode === "video") {
            var warning = byId(tool + "MediaWarn");
            if (warning) { warning.textContent = t("loadFail"); warning.hidden = false; }
            return;
        }
        var reader = new FileReader();
        reader.onload = function () { setSource(tool, String(reader.result || "")); };
        reader.readAsDataURL(file);
    }

    function pick(tool) {
        var kind = state[tool].mode === "video" ? "video" : "image";
        var input = byId(tool + "MediaFile"), handled = false;
        try {
            var cs = new CSInterface();
            if (cs && cs.hostEnvironment) {
                handled = true;
                cs.evalScript('editkit_pickWorkMedia("' + kind + '")', function (raw) {
                    var result = null;
                    try { result = JSON.parse(raw); } catch (e) {}
                    if (result && result.success && result.path) setSource(tool, result.path);
                    else if (!result || (!result.canceled && !result.success)) { if (input) input.click(); }
                });
            }
        } catch (e2) { handled = false; }
        if (!handled && input) input.click();
    }

    function resetTool(tool) {
        var next = clean(state);
        next[tool] = defaults();
        unlockClicks[tool] = 0;
        set(next, null, true);
        if (window.EditKitSurfaces) {
            var colours = window.EditKitSurfaces.get();
            colours[tool] = "#232323";
            window.EditKitSurfaces.set(colours);
        }
    }

    function bind(tool) {
        var modes = ["color", "image", "video"];
        for (var i = 0; i < modes.length; i++) {
            (function (mode, button) {
                if (!button) return;
                button.addEventListener("click", function () {
                    if (mode === "video" && !state[tool].videoUnlocked) {
                        unlockClicks[tool]++;
                        if (unlockClicks[tool] >= 7) {
                            change(tool, function (media) { media.videoUnlocked = true; media.mode = "video"; });
                        } else {
                            unlockTip(tool, state[tool]);
                        }
                        return;
                    }
                    change(tool, function (media) { media.mode = mode; });
                });
            })(modes[i], modeButton(tool, modes[i]));
        }
        var surface = byId(tool + "SurfaceInput");
        if (surface) surface.addEventListener("input", function () {
            if (!window.EditKitSurfaces) return;
            var colours = window.EditKitSurfaces.get();
            colours[tool] = surface.value;
            window.EditKitSurfaces.set(colours);
        });
        var path = byId(tool + "MediaPath"); if (path) path.addEventListener("change", function () { setSource(tool, path.value.replace(/^\s+|\s+$/g, "")); });
        var clear = byId(tool + "MediaClear"); if (clear) clear.addEventListener("click", function () { setSource(tool, ""); });
        var choose = byId(tool + "MediaPick"); if (choose) choose.addEventListener("click", function () { pick(tool); });
        var input = byId(tool + "MediaFile"); if (input) input.addEventListener("change", function () { fallbackFile(tool, input.files && input.files[0]); });
        var fit = byId(tool + "MediaFit"); if (fit) fit.addEventListener("change", function () { change(tool, function (media) { media.fit = fit.value; }); });
        var blur = byId(tool + "MediaBlur"); if (blur) blur.addEventListener("input", function () { change(tool, function (media) { media.blur = bounded(blur.value, 0, 0, 30); }); });
        var opacity = byId(tool + "MediaOpacity"); if (opacity) opacity.addEventListener("input", function () { change(tool, function (media) { media.opacity = bounded(opacity.value, 100, 0, 100); }); });
        var reset = byId(tool + "MediaReset"); if (reset) reset.addEventListener("click", function () { resetTool(tool); });
    }

    window.EditKitSurfaceMedia = {
        get: function () { return clean(state); },
        set: function (value) { set(value); },
        reset: function () { set({}, null, true); },
        resetTool: resetTool,
        mount: mount,
        setLanguage: applyLanguage
    };

    paintPane();
    var mounts = document.querySelectorAll ? document.querySelectorAll("[data-surface-media-mount]") : [];
    for (var mi = 0; mi < mounts.length; mi++) mount(mounts[mi].getAttribute("data-surface-media-mount"), mounts[mi]);
    applyLanguage(lang);
    if (!isShell) {
        function askHub() { try { window.parent.postMessage({ __editkit: TAG, request: true }, "*"); } catch (e) {} }
        askHub();
        window.addEventListener("load", function () { paintPane(); askHub(); });
    }
    document.addEventListener("visibilitychange", paintPane);
    window.addEventListener("editkit-runtimechange", paintPane);
})();
