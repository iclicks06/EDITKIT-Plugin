/* ============================================================================
   EDITKIT — ACTUALIZACIONES

   - Comprueba el manifiesto como máximo una vez cada 24 horas, salvo que el
     usuario pulse "Buscar actualización".
   - Nunca descarga ni instala un paquete sin una acción explícita del usuario.
   - Exige HTTPS, tamaño exacto y SHA-256.
   - Valida todas las rutas del ZIP y la identidad/versión del manifiesto CEP.
   - Prepara la copia fuera de las carpetas que CEP escanea y conserva un backup.
   ============================================================================ */
(function () {
    "use strict";

    var VERSION_URL = "https://raw.githubusercontent.com/zickfx/editkit-updates/main/version.json";
    var CHECK_INTERVAL_MS = 24 * 60 * 60 * 1000;
    var REQUEST_TIMEOUT_MS = 20000;
    var MAX_MANIFEST_BYTES = 64 * 1024;
    var MAX_PACKAGE_BYTES = 64 * 1024 * 1024;
    var MAX_UNPACKED_BYTES = 256 * 1024 * 1024;
    var MAX_ARCHIVE_FILES = 5000;
    var STORE_AUTO = "editkit_update_auto";
    var STORE_LAST_CHECK = "editkit_update_last_check";
    var STORE_ALERTS = "editkit_update_alerts";

    var core = window.EditKitUpdateCore;
    var pending = null;
    var checking = false;
    var applying = false;

    var T = {
        es: {
            checking: "Comprobando…",
            noCheck: "No se pudo comprobar la actualización. Puedes usar el enlace de descargas.",
            invalidManifest: "El canal de actualización respondió con datos no válidos.",
            upToDate: "Ya tienes la última versión (%v).",
            available: "Hay una versión nueva: %v.",
            goBtn: "Actualizar a la %v",
            autoLabel: "Buscar actualizaciones automáticamente",
            autoNote: "Solo comprueba la versión una vez al día. No descarga nada hasta que tú lo pidas.",
            alertsLabel: "Mostrar avisos visuales de actualización",
            alertsNote: "Controla el encabezado y el pulso del icono de Ajustes; no desactiva la comprobación automática.",
            banner: "Hay una nueva versión disponible, actualizar no tarda más de 30 segundos.",
            review: "Revisar",
            preserveNote: "Tus configuraciones, perfiles y presets se guardan por separado de los archivos del plugin y no se perderán al actualizar.",
            noNode: "La actualización solo se puede instalar dentro de After Effects o Premiere.",
            noWrite: "Esta instalación no se puede modificar. Usa el enlace de descargas para actualizarla.",
            downloading: "Descargando la actualización…",
            badChecksum: "La descarga no coincide con el SHA-256 publicado. No se aplicó nada.",
            badPackage: "El paquete no pertenece a EditKit, tiene otra versión o contiene rutas inseguras.",
            tooLarge: "El paquete supera el tamaño permitido. No se aplicó nada.",
            extracting: "Validando y descomprimiendo…",
            applying: "Aplicando la actualización…",
            done: "Actualizado a la versión %v. Cierra y vuelve a abrir After Effects o Premiere.",
            failed: "No se pudo aplicar la actualización. La versión instalada sigue intacta.",
            failedDownload: "No se pudo descargar la actualización. Comprueba tu conexión e inténtalo de nuevo.",
            failedTimeout: "La descarga tardó demasiado y fue cancelada. Inténtalo de nuevo.",
            failedPermission: "El sistema no permitió modificar la instalación. La versión instalada sigue intacta.",
            failedStorage: "No hay espacio suficiente para preparar la actualización. La versión instalada sigue intacta.",
            failedLocked: "After Effects o CEP está usando los archivos de EDITKIT. La versión instalada sigue intacta. Cierra las aplicaciones de Adobe y usa la descarga manual.",
            failedSwap: "No se pudo sustituir la instalación. La versión instalada sigue intacta.",
            supportCode: "Código de diagnóstico: %c",
            manualBtn: "Abrir descarga manual"
        },
        en: {
            checking: "Checking…",
            noCheck: "The update could not be checked. You can use the downloads link.",
            invalidManifest: "The update channel returned invalid data.",
            upToDate: "You already have the latest version (%v).",
            available: "A new version is available: %v.",
            goBtn: "Update to %v",
            autoLabel: "Check for updates automatically",
            autoNote: "Only checks the version once a day. Nothing is downloaded until you ask.",
            alertsLabel: "Show visual update alerts",
            alertsNote: "Controls the banner and Settings icon pulse; it does not disable automatic update checks.",
            banner: "A new version is available; updating takes less than 30 seconds.",
            review: "Review",
            preserveNote: "Your settings, profiles, and presets are stored separately from the plugin files and will not be lost when you update.",
            noNode: "Updates can only be installed from inside After Effects or Premiere.",
            noWrite: "This installation cannot be modified. Use the downloads link to update it.",
            downloading: "Downloading the update…",
            badChecksum: "The download does not match the published SHA-256. Nothing was applied.",
            badPackage: "The package is not EditKit, has another version, or contains unsafe paths.",
            tooLarge: "The package exceeds the allowed size. Nothing was applied.",
            extracting: "Validating and unpacking…",
            applying: "Applying the update…",
            done: "Updated to version %v. Close and reopen After Effects or Premiere.",
            failed: "The update could not be applied. The installed version is still intact.",
            failedDownload: "The update could not be downloaded. Check your connection and try again.",
            failedTimeout: "The download took too long and was cancelled. Try again.",
            failedPermission: "The system did not allow the installation to be modified. The installed version is still intact.",
            failedStorage: "There is not enough free space to prepare the update. The installed version is still intact.",
            failedLocked: "After Effects or CEP is using the EDITKIT files. The installed version is still intact. Close Adobe applications and use the manual download.",
            failedSwap: "The installation could not be replaced. The installed version is still intact.",
            supportCode: "Diagnostic code: %c",
            manualBtn: "Open manual download"
        }
    };

    function lang() {
        var value = "es";
        try { value = localStorage.getItem("editkit_lang") || "es"; } catch (e) {}
        return T[value] ? value : "es";
    }

    function t(key) { return T[lang()][key] || T.es[key] || key; }
    function $(id) { return document.getElementById(id); }

    function say(message, kind) {
        var element = $("setAboutUpdateStatus");
        if (!element) return;
        element.textContent = message;
        element.className = "bd-hint prof-msg" + (kind ? " " + kind : "");
        element.hidden = false;
    }

    function hideStatus() {
        var element = $("setAboutUpdateStatus");
        if (element) element.hidden = true;
    }

    function setCheckEnabled(enabled) {
        var button = $("setAboutCheckUpdate");
        if (button) button.disabled = !enabled;
    }

    function bridge() {
        try { return window.__adobe_cep__; } catch (e) { return null; }
    }

    function nodeRequire(name) {
        try {
            if (window.cep_node && window.cep_node.require) return window.cep_node.require(name);
        } catch (e) {}
        return null;
    }

    function extensionRoot() {
        var cepBridge = bridge(), value = "";
        if (!cepBridge || !cepBridge.getSystemPath) return "";
        try { value = decodeURI(cepBridge.getSystemPath("extension")) || ""; } catch (e) { return ""; }
        return /^Win/i.test(navigator.platform) ? value.replace("file:///", "") : value.replace("file://", "");
    }

    function autoEnabled() {
        try { return localStorage.getItem(STORE_AUTO) !== "0"; } catch (e) { return true; }
    }

    function setAutoEnabled(enabled) {
        try { localStorage.setItem(STORE_AUTO, enabled ? "1" : "0"); } catch (e) {}
    }

    function alertsEnabled() {
        try { return localStorage.getItem(STORE_ALERTS) !== "0"; } catch (e) { return true; }
    }

    function setAlertsEnabled(enabled) {
        try { localStorage.setItem(STORE_ALERTS, enabled ? "1" : "0"); } catch (e) {}
    }

    function paintAvailableAlert() {
        var visible = !!pending && alertsEnabled();
        var settings = $("shellSettingsBtn");
        var banner = $("updateAvailableBanner");
        var action = $("setAboutUpdateGo");
        if (settings) settings.classList.toggle("update-available", visible);
        if (banner) banner.hidden = !visible;
        /* The install action follows availability, not the alert preference:
           disabling the pulse/banner must not hide a real update, while an
           empty pending state must never leave an inert button on screen. */
        if (action) action.hidden = !pending;
    }

    function autoCheckDue() {
        var last = 0;
        try { last = parseInt(localStorage.getItem(STORE_LAST_CHECK), 10) || 0; } catch (e) {}
        return Date.now() - last >= CHECK_INTERVAL_MS;
    }

    function markCheckAttempt() {
        try { localStorage.setItem(STORE_LAST_CHECK, String(Date.now())); } catch (e) {}
    }

    function endsWith(value, suffix) {
        return value.length >= suffix.length && value.slice(value.length - suffix.length) === suffix;
    }

    function codedError(code, message) {
        var error = new Error(message || code);
        error.code = code;
        return error;
    }

    function classifyApplyError(error, phase) {
        var raw = String(error && error.code ? error.code : "");
        if (raw === "timeout" || raw === "ETIMEDOUT") return { key: "failedTimeout", code: "EK-UPD-TIMEOUT" };
        if (/^(http|redirects|ENOTFOUND|EAI_AGAIN|ECONNRESET|ECONNREFUSED|ENETDOWN|ENETUNREACH|EHOSTUNREACH)$/.test(raw)) {
            return { key: "failedDownload", code: "EK-UPD-DOWNLOAD" };
        }
        if (raw === "checksum" || raw === "badSize") return { key: "badChecksum", code: "EK-UPD-CHECKSUM" };
        if (raw === "tooLarge") return { key: "tooLarge", code: "EK-UPD-SIZE" };
        if (raw === "noWrite") return { key: "failedPermission", code: "EK-UPD-PERMISSION" };
        if (raw === "filesLocked" || (/^(EBUSY|EPERM|EACCES|ENOTEMPTY)$/.test(raw) && phase === "swap")) {
            return { key: "failedLocked", code: "EK-UPD-LOCKED" };
        }
        if (raw === "ENOSPC") return { key: "failedStorage", code: "EK-UPD-STORAGE" };
        if (/^(EPERM|EACCES|EROFS)$/.test(raw)) return { key: "failedPermission", code: "EK-UPD-PERMISSION" };
        if (/^(badArchive|unsafeArchive|wrongBundle|wrongVersion|signatureMissing)$/.test(raw)) {
            return { key: "badPackage", code: "EK-UPD-PACKAGE" };
        }
        if (raw === "swapFailed" || phase === "swap") return { key: "failedSwap", code: "EK-UPD-SWAP" };
        if (phase === "download") return { key: "failedDownload", code: "EK-UPD-DOWNLOAD" };
        return { key: "failed", code: "EK-UPD-UNKNOWN" };
    }

    function showManualDownload(show) {
        var button = $("setAboutUpdateManual");
        if (button) button.hidden = !show;
    }

    function openManualDownload() {
        try {
            if (window.EditKitShell && window.EditKitShell.openURL) {
                window.EditKitShell.openURL("https://zickfx.com/b/editkit/");
            }
        } catch (e) {}
    }

    function urlAllowed(raw, purpose) {
        var urlModule = nodeRequire("url"), parsed, host;
        if (!urlModule || !urlModule.URL) throw codedError("noNode");
        try { parsed = new urlModule.URL(raw); } catch (e) { throw codedError("badUrl"); }
        if (parsed.protocol !== "https:") throw codedError("badUrl");
        host = parsed.hostname.toLowerCase();

        if (purpose === "manifest") {
            if (host !== "raw.githubusercontent.com" && host !== "updates.zickfx.com") throw codedError("badUrl");
        } else if (
            host !== "github.com" &&
            host !== "zickfx.com" &&
            !endsWith(host, ".zickfx.com") &&
            !endsWith(host, ".githubusercontent.com")
        ) {
            throw codedError("badUrl");
        }
        return parsed.href;
    }

    function requestBuffer(rawUrl, purpose, maxBytes, redirectsLeft) {
        var https = nodeRequire("https"), bufferModule = nodeRequire("buffer");
        if (!https || !bufferModule || !bufferModule.Buffer) return Promise.reject(codedError("noNode"));

        return new Promise(function (resolve, reject) {
            var safeUrl;
            try { safeUrl = urlAllowed(rawUrl, purpose); } catch (e) { reject(e); return; }

            var request = https.get(safeUrl, {
                headers: { "User-Agent": "EditKit-Updater/" + (window.EditKitVersion || "0") }
            }, function (response) {
                var status = response.statusCode || 0;
                var location = response.headers && response.headers.location;
                var declared = parseInt(response.headers && response.headers["content-length"], 10) || 0;
                var chunks = [], total = 0;

                if (status >= 300 && status < 400 && location) {
                    response.resume();
                    if (redirectsLeft <= 0) { reject(codedError("redirects")); return; }
                    try { location = new (nodeRequire("url").URL)(location, safeUrl).href; } catch (e) { reject(codedError("badUrl")); return; }
                    requestBuffer(location, purpose, maxBytes, redirectsLeft - 1).then(resolve, reject);
                    return;
                }
                if (status !== 200) {
                    response.resume();
                    reject(codedError("http", "HTTP " + status));
                    return;
                }
                if (declared > maxBytes) {
                    response.resume();
                    reject(codedError("tooLarge"));
                    return;
                }

                response.on("data", function (chunk) {
                    total += chunk.length;
                    if (total > maxBytes) {
                        response.destroy(codedError("tooLarge"));
                        return;
                    }
                    chunks.push(chunk);
                });
                response.on("end", function () {
                    if (total <= maxBytes) resolve(bufferModule.Buffer.concat(chunks, total));
                });
                response.on("error", reject);
            });

            request.setTimeout(REQUEST_TIMEOUT_MS, function () {
                request.destroy(codedError("timeout"));
            });
            request.on("error", reject);
        });
    }

    function loadRemoteManifest() {
        return requestBuffer(VERSION_URL, "manifest", MAX_MANIFEST_BYTES, 3).then(function (buffer) {
            try { return JSON.parse(buffer.toString("utf8")); } catch (e) { throw codedError("badManifest"); }
        });
    }

    function checkForUpdate(manual) {
        var go = $("setAboutUpdateGo");
        if (checking || applying || !core) return;
        checking = true;
        pending = null;
        showManualDownload(false);
        paintAvailableAlert();
        if (go) go.hidden = true;
        setCheckEnabled(false);
        markCheckAttempt();
        if (manual) say(t("checking"));

        loadRemoteManifest().then(function (info) {
            var remoteVersion = core.releaseVersion(info);
            var here = window.EditKitVersion || "0.0.0";
            if (core.compareVersions(remoteVersion, here) <= 0) {
                if (manual) say(t("upToDate").replace("%v", here), "ok");
                else hideStatus();
                paintAvailableAlert();
                return;
            }

            pending = core.normalizeRelease(info, lang());
            if (pending.bytes > MAX_PACKAGE_BYTES) throw codedError("tooLarge");
            urlAllowed(pending.url, "package");
            say(t("available").replace("%v", pending.version) + (pending.notes ? " " + pending.notes : ""), "ok");
            if (go) {
                go.hidden = false;
                go.disabled = false;
                go.textContent = t("goBtn").replace("%v", pending.version);
            }
            paintAvailableAlert();
        }).catch(function (error) {
            var invalid = error && /^(badManifest|badSchema|badProduct|badChannel|badVersion|badUrl|badChecksum|badSize)$/.test(error.code || "");
            if (manual) say(t(invalid ? "invalidManifest" : (error && error.code === "tooLarge" ? "tooLarge" : "noCheck")), "warn");
        }).then(function () {
            checking = false;
            setCheckEnabled(true);
        });
    }

    function assertWritable(fs, path, root) {
        var parent = path.dirname(root);
        var probe = path.join(parent, ".editkit-write-test-" + Date.now());
        try {
            fs.writeFileSync(probe, "");
            fs.unlinkSync(probe);
        } catch (e) {
            try { if (fs.existsSync(probe)) fs.unlinkSync(probe); } catch (ignore) {}
            throw codedError("noWrite");
        }
    }

    function removeTree(fs, path, base, target) {
        var resolvedBase = path.resolve(base);
        var resolvedTarget = path.resolve(target);
        var prefix = resolvedBase + path.sep;
        if (resolvedTarget === resolvedBase || resolvedTarget.indexOf(prefix) !== 0) throw codedError("unsafePath");
        if (!fs.existsSync(resolvedTarget)) return;
        if (fs.rmSync) fs.rmSync(resolvedTarget, { recursive: true, force: true });
        else removeTreeLegacy(fs, path, resolvedTarget);
    }

    function removeTreeLegacy(fs, path, target) {
        var stat, children, i;
        if (!fs.existsSync(target)) return;
        stat = fs.statSync(target);
        if (!stat.isDirectory()) { fs.unlinkSync(target); return; }
        children = fs.readdirSync(target);
        for (i = 0; i < children.length; i++) removeTreeLegacy(fs, path, path.join(target, children[i]));
        fs.rmdirSync(target);
    }

    function verifyAndExtract(buffer, release, fs, path, root, staging) {
        var files, names, total = 0, declaredTotal = 0, declaredFiles = 0;
        var prepared = [], i, name, safeName, bytes, dest;
        try {
            files = fflate.unzipSync(new Uint8Array(buffer), {
                filter: function (entry) {
                    var entryName = String(entry.name || "");
                    var isDirectory = entryName.charAt(entryName.length - 1) === "/";
                    declaredFiles += 1;
                    if (declaredFiles > MAX_ARCHIVE_FILES) throw codedError("tooLarge");
                    core.safeZipPath(isDirectory ? entryName.slice(0, -1) : entryName);
                    declaredTotal += Number(entry.originalSize) || 0;
                    if (declaredTotal > MAX_UNPACKED_BYTES) throw codedError("tooLarge");
                    return !isDirectory;
                }
            });
        } catch (e) {
            if (e && /^(unsafeArchive|tooLarge)$/.test(e.code || "")) throw e;
            throw codedError("badArchive");
        }
        names = Object.keys(files);
        if (!names.length || names.length > MAX_ARCHIVE_FILES) throw codedError("badArchive");

        for (i = 0; i < names.length; i++) {
            name = names[i];
            if (name.charAt(name.length - 1) === "/") continue;
            safeName = core.safeZipPath(name);
            bytes = files[name];
            total += bytes.length;
            if (total > MAX_UNPACKED_BYTES) throw codedError("tooLarge");
            dest = path.resolve(staging, safeName);
            if (dest.indexOf(path.resolve(staging) + path.sep) !== 0) throw codedError("unsafeArchive");
            prepared.push({ bytes: bytes, dest: dest });
        }

        for (i = 0; i < prepared.length; i++) {
            fs.mkdirSync(path.dirname(prepared[i].dest), { recursive: true });
            fs.writeFileSync(prepared[i].dest, prepared[i].bytes);
        }

        var manifestPath = path.join(staging, "CSXS", "manifest.xml");
        if (!fs.existsSync(manifestPath)) throw codedError("badArchive");
        core.validateBundleManifest(fs.readFileSync(manifestPath, "utf8"), release.version);

        var oldSignature = path.join(root, "META-INF", "signatures.xml");
        var newSignature = path.join(staging, "META-INF", "signatures.xml");
        if (fs.existsSync(oldSignature) && !fs.existsSync(newSignature)) throw codedError("signatureMissing");
    }

    function applyUpdate(release) {
        var fs = nodeRequire("fs"), path = nodeRequire("path"), crypto = nodeRequire("crypto");
        var root = extensionRoot(), go = $("setAboutUpdateGo");
        var phase = "download";
        if (!fs || !path || !crypto || !root) {
            say(t("noNode") + " " + t("supportCode").replace("%c", "EK-UPD-RUNTIME"), "warn");
            showManualDownload(true);
            return;
        }

        /* La copia normal espera un momento para agrupar cambios. Una
           actualización no debe ganarle esa carrera: se fuerza un punto de
           guardado antes de descargar o sustituir cualquier archivo. */
        try {
            if (window.EditKitPersist && window.EditKitPersist.checkpoint) {
                window.EditKitPersist.checkpoint();
            }
        } catch (persistError) {}

        applying = true;
        showManualDownload(false);
        if (go) go.disabled = true;
        say(t("downloading"));

        requestBuffer(release.url, "package", MAX_PACKAGE_BYTES, 5).then(function (buffer) {
            phase = "verify";
            if (buffer.length !== release.bytes) throw codedError("badSize");
            var digest = crypto.createHash("sha256").update(buffer).digest("hex");
            if (digest.toLowerCase() !== release.sha256) throw codedError("checksum");

            assertWritable(fs, path, root);
            say(t("extracting"));
            phase = "extract";

            var parent = path.dirname(root);
            var updateBase = path.join(parent, ".editkit-updater");
            var staging = path.join(updateBase, "staging");
            var backup = path.join(updateBase, "backup");
            fs.mkdirSync(updateBase, { recursive: true });
            removeTree(fs, path, updateBase, staging);
            fs.mkdirSync(staging, { recursive: true });

            try {
                verifyAndExtract(buffer, release, fs, path, root, staging);
            } catch (validationError) {
                removeTree(fs, path, updateBase, staging);
                throw validationError;
            }

            say(t("applying"));
            phase = "swap";
            removeTree(fs, path, updateBase, backup);
            try {
                fs.renameSync(root, backup);
            } catch (moveCurrentError) {
                if (/^(EBUSY|EPERM|EACCES|ENOTEMPTY)$/.test(String(moveCurrentError && moveCurrentError.code || ""))) {
                    throw codedError("filesLocked");
                }
                throw codedError("swapFailed");
            }
            try {
                fs.renameSync(staging, root);
            } catch (swapError) {
                try { fs.renameSync(backup, root); } catch (rollbackError) {}
                if (/^(EBUSY|EPERM|EACCES|ENOTEMPTY)$/.test(String(swapError && swapError.code || ""))) {
                    throw codedError("filesLocked");
                }
                throw codedError("swapFailed");
            }

            pending = null;
            paintAvailableAlert();
            say(t("done").replace("%v", release.version), "ok");
            showManualDownload(false);
            if (go) go.hidden = true;
        }).catch(function (error) {
            var failure = classifyApplyError(error, phase);
            say(t(failure.key) + " " + t("supportCode").replace("%c", failure.code), "warn");
            showManualDownload(true);
            if (go) go.disabled = false;
        }).then(function () {
            applying = false;
            setCheckEnabled(true);
        });
    }

    function refreshAutoLabels() {
        var label = $("setAboutAutoUpdateLabel");
        var note = $("setAboutAutoUpdateNote");
        var preserve = $("setAboutUpdatePreserveNote");
        var alertsLabel = $("setAboutUpdateAlertsLabel");
        var alertsNote = $("setAboutUpdateAlertsNote");
        var bannerCopy = $("updateAvailableCopy");
        var review = $("updateAvailableReview");
        var manual = $("setAboutUpdateManual");
        if (label) label.textContent = t("autoLabel");
        if (note) note.textContent = t("autoNote");
        if (preserve) preserve.textContent = t("preserveNote");
        if (alertsLabel) alertsLabel.textContent = t("alertsLabel");
        if (alertsNote) alertsNote.textContent = t("alertsNote");
        if (bannerCopy) bannerCopy.textContent = t("banner");
        if (review) review.textContent = t("review");
        if (manual) manual.textContent = t("manualBtn");
        paintAvailableAlert();
    }

    function reviewUpdate() {
        var tab = $("setTabAbout");
        if (tab) tab.click();
        setTimeout(function () {
            var target = $("setAboutUpdateStatus");
            var action = $("setAboutUpdateGo");
            try { if (target) target.scrollIntoView({ block: "center", behavior: "smooth" }); }
            catch (e) { try { if (target) target.scrollIntoView(false); } catch (ignore) {} }
            try { if (action && !action.hidden) action.focus(); } catch (e2) {}
        }, 40);
    }

    function boot() {
        var checkButton = $("setAboutCheckUpdate");
        var go = $("setAboutUpdateGo");
        var automatic = $("setAboutAutoUpdate");
        var alerts = $("setAboutUpdateAlerts");
        var review = $("updateAvailableReview");
        var manual = $("setAboutUpdateManual");

        /* Defensive first paint. The markup is hidden too, but .bd-btn has an
           author display rule and older CEP Chromium does not always let the
           user-agent [hidden] rule win. */
        paintAvailableAlert();

        if (!core) {
            if (checkButton) checkButton.disabled = true;
            return;
        }
        if (checkButton) checkButton.addEventListener("click", function () { checkForUpdate(true); });
        if (go) go.addEventListener("click", function () { if (pending) applyUpdate(pending); });
        if (automatic) {
            automatic.checked = autoEnabled();
            automatic.addEventListener("change", function () {
                setAutoEnabled(automatic.checked);
                if (automatic.checked && autoCheckDue()) checkForUpdate(false);
            });
        }
        if (alerts) {
            alerts.checked = alertsEnabled();
            alerts.addEventListener("change", function () {
                setAlertsEnabled(alerts.checked);
                paintAvailableAlert();
            });
        }
        if (review) review.addEventListener("click", reviewUpdate);
        if (manual) manual.addEventListener("click", openManualDownload);
        refreshAutoLabels();
        window.addEventListener("storage", refreshAutoLabels);

        if (autoEnabled() && autoCheckDue()) setTimeout(function () { checkForUpdate(false); }, 3000);
    }

    window.EditKitUpdater = { setLanguage: refreshAutoLabels };

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
    else boot();
})();
