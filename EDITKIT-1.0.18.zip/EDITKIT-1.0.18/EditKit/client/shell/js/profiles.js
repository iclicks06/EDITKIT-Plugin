/* ============================================================================
   EDITKIT — PERFILES

   QUE ES UN PERFIL

   Todo lo que el usuario configura —la rejilla de botones de QuickIt, las
   colecciones y los presets de EaseIt, las secciones de AlignIt, el acento, el
   fondo y el tamano de los paneles— vive en el almacenamiento del
   panel. Es un sitio que funciona muy bien y que tiene tres problemas: no se
   ve, no se copia y no se comparte. Se pierde al cambiar de equipo, y la unica
   manera de volver a una configuracion anterior es rehacerla a mano.

   Un perfil es ese mismo estado sacado a un archivo de texto. Se guarda, se
   cambia, se exporta, se manda y se vuelve a meter.

   COMO SE ARMA

   No hay una lista de "cosas que guardar" escrita a mano. Eso seria una lista
   que se queda corta cada vez que se anade una preferencia, y nadie se entera
   hasta que a alguien le falta algo en su perfil. Lo que hay es al reves: se
   guarda TODO lo que el panel tiene guardado, y una lista corta y explicita de
   lo que NO viaja. Anadir una preferencia nueva la mete en los perfiles sola;
   dejarla fuera hay que escribirlo, que es como tiene que ser.

   Lo que no viaja, y por que:

     - las banderas internas y el propio almacen de perfiles, que se anidarian;
     - el recuento de uso, que es de este equipo y de esta persona;
     - los secretos, que se descubren, no se heredan;
     - la carpeta de salida, que es una ruta de este disco;
     - los archivos personales cuando la exportacion privada esta activa. Las
       imagenes se empaquetan solo en el archivo exportado, nunca dentro del
       perfil que vive en el almacenamiento del panel.

   LA RED DE SEGURIDAD

   Aplicar un perfil reemplaza la configuracion entera, y la primera vez eso da
   miedo con razon. Antes de reemplazar nada se guarda una copia de lo que
   habia, y hay un boton para volver. Sin eso, "probar un perfil de alguien" es
   una decision, y con eso es una prueba.
   ============================================================================ */
(function () {
    "use strict";

    // ---------------------------------------------------------------------
    // Claves
    // ---------------------------------------------------------------------
    var K_LIST = "editkit_profiles";       // los perfiles guardados
    var K_LAST = "editkit_profile_last";   // el ultimo que se aplico
    var K_UNDO = "editkit_profile_undo";   // la copia previa a la ultima aplicacion
    var K_SAFE_SHARE = "editkit_profile_safe_share";
    var K_FACTORY = "editkit_profile_factory_v1";

    // Un perfil recoge lo que empieza por uno de estos.
    var PREFIXES = ["editkit_", "easeit_", "alignAnchor"];

    // Y nunca lo que este aqui.
    var SKIP = {
        "editkit_profiles": 1,
        "editkit_profile_last": 1,
        "editkit_profile_undo": 1,
        "editkit_profile_safe_share": 1,
        "editkit_profile_factory_v1": 1,
        /* El idioma pertenece a esta instalación, no al trabajo. Un perfil
           compartido nunca debe cambiar el idioma que eligió su destinatario. */
        "editkit_lang": 1,
        /* La herramienta que estaba abierta es estado momentaneo de la
           ventana, no parte del aspecto o del flujo que se comparte. */
        "editkit_active_tool": 1,
        /* Depende del equipo que recibe el perfil, no del espacio de trabajo
           de quien lo comparte. */
        "editkit_performance_mode": 1,
        /* Las pistas recuerdan lo que ya aprendio la persona en este equipo;
           no forman parte de un espacio de trabajo y no deben viajar en un
           perfil compartido. */
        "editkit_context_hints": 1,
        "editkit_context_hints_state_v1": 1,
        /* La marca de la copia en Documentos (persist.js): dice que este
           almacenamiento no llego vacio. Un perfil no la trae ni la quita. */
        "editkit_persist": 1,
        "editkit_storage_migrated_v1": 1,
        "editkit_log": 1,
        "editkit_log_wrapped": 1,
        "editkit_logRead": 1,
        "editkit_logWrite": 1,
        "editkit_logErase": 1,
        "editkit_cmd_uses": 1,
        "editkit_eggs": 1,
        "editkit_owl": 1,
        "editkit_out_folder": 1,
        "editkit_qi_last_error": 1,
        "editkit_qi_fresh_intro_seen_v1": 1,
        "editkit_qi_style_soft3d_v1": 1,
        "editkit_qi_native_styles_v1": 1,
        "editkit_update_last_check": 1,
        "editkit_easeit_seen_collections": 1,
        "alignAnchorAccentMigrated": 1,
        /* Dos listas que este equipo se hizo solo y que en otro no significan
           nada: el escaneo de la carpeta de presets del usuario y la lista de
           efectos instalados. Se rehacen en cuanto hacen falta, y metidas en
           un perfil solo servirian para prometer cosas que en el otro equipo
           no estan. */
        "editkit_qi_presets": 1,
        "editkit_qi_presets_ask": 1,
        "editkit_qi_effects": 1,
        /* "Ya viste esto". No se hereda: quien estrena el plugin con el perfil
           de otro tiene derecho a la bienvenida y a las explicaciones de
           primera vez. */
        "editkit_welcomed": 1,
        "easeit_welcomed": 1,
        "easeit_seen_collections": 1,
        "easeit_th_explained": 1,
        "editkit_easeit_welcomed": 1,
        /* La memoria de punto de anclaje por capa. Va con el NOMBRE de la capa
           por clave —de un proyecto real, no un ajuste—, y en un proyecto
           nuevo ese nombre no va a existir de todas formas. */
        "easeit_anchors": 1,
        // Cuanto tiempo llevas usando EaseIt en ESTE equipo. No es tuyo para
        // llevar a otro lado, es de esta instalacion.
        "easeit_usage_ms": 1
    };

    /* El perfil de fabrica vive en un archivo de datos independiente. Asi las
       pruebas pueden garantizar que no contiene rutas, imagenes, presets,
       scripts ni referencias a efectos de terceros. */
    var FACTORY = window.EditKitFactoryProfile || {
        id: "builtin-basic", name: "Basic", builtin: true, keys: {}
    };
    var BUILTIN_ID = FACTORY.id;
    var BUILT_IN = [FACTORY];

    // Los ajustes visuales y sus referencias multimedia forman parte del
    // perfil. Al exportar, los archivos de imagen locales se empaquetan para
    // que no dependan de una ruta privada de este equipo.
    var BACKDROP_KEY = "editkit_backdrop";
    var SURFACE_MEDIA_KEY = "editkit_work_media";

    var FILE_TAG = "editkit-profile";
    var FILE_VER = 1;

    // ---------------------------------------------------------------------
    // Idioma
    // ---------------------------------------------------------------------
    var DICT = {
        es: {
            tab: "Perfiles",
            section: "Perfiles",
            intro: "Un perfil guarda de una vez todo lo que has configurado en EditKit, EaseIt, QuickIt y AlignIt: tu rejilla de botones, tus presets y colecciones, el acento, el fondo, el tamaño de los paneles y el resto de preferencias de trabajo. El idioma siempre se conserva en este equipo.",
            note: "Los perfiles pueden incluir imágenes, GIF, iconos y URLs multimedia. La opción de privacidad decide si también viajan tus presets y scripts personales.",
            safeShare: "Compartir sin archivos personales",
            safeShareHint: "Al exportar, excluye tus colecciones de presets, archivos .ffx, scripts .jsx y sus rutas. Las imágenes, GIF, iconos y URLs multimedia sí se incluyen.",
            safeShareDone: " · sin presets ni scripts personales",
            packedOne: " · 1 archivo dentro",
            packedMany: " · %n archivos dentro",
            missingFiles: "%n archivo(s) del disco no se encontraron: esos botones viajan sin su archivo.",
            tooBig: "Algún archivo no cabe (el límite son 20 MB por perfil) y se quedó fuera.",
            unpacked: "%n archivo(s) guardados en ",
            noBinary: "Fuera de After Effects no se pueden meter los archivos dentro del perfil. Se exporta sin ellos.",
            empty: "Todavía no has guardado ningún perfil. Guarda el primero con lo que tienes puesto ahora mismo: no cambia nada, solo deja por dónde vas.",
            save: "Guardar la configuración actual…",
            importBtn: "Importar…",
            namePh: "Nombre del perfil",
            nameOk: "Guardar",
            nameCancel: "Cancelar",
            apply: "Aplicar",
            update: "Actualizar",
            exportBtn: "Exportar",
            rename: "Renombrar",
            remove: "Eliminar",
            sure: "¿Seguro?",
            lastUsed: "Último aplicado",
            undo: "Deshacer: volver a como estaba",
            savedAs: "Perfil guardado: ",
            applied: "Perfil aplicado. El panel se recarga…",
            undone: "Se restauró la configuración anterior. El panel se recarga…",
            removed: "Perfil eliminado.",
            renamed: "Perfil renombrado.",
            exported: "Perfil exportado a ",
            imported: "Perfil importado: ",
            needName: "Ponle un nombre al perfil.",
            dupName: "Ya tienes un perfil con ese nombre.",
            noRoom: "No cabe: el almacenamiento del panel está lleno. Elimina algún perfil o alguna imagen de fondo.",
            badFile: "Ese archivo no es un perfil de EditKit.",
            noFile: "No se pudo leer el archivo.",
            noSave: "No se pudo guardar el archivo.",
            newer: "Ese perfil lo hizo una versión más nueva de EditKit. Se importa igual, pero puede que falte algo.",
            confirmApply: "Aplicar reemplaza toda tu configuración actual. Se guarda una copia para poder volver. Pulsa otra vez para confirmar.",
            confirmUpdate: "Actualizar sobreescribe este perfil con la configuración actual, sin poder deshacerlo. Pulsa otra vez para confirmar.",
            updated: "Perfil actualizado: ",
            backupTip: "Guardar una copia de seguridad de tus perfiles en Documentos/EditKit/Perfiles",
            backupOk: "Copia de seguridad guardada: ",
            backupEmpty: "Todavía no hay ningún perfil que copiar.",
            backupNoHost: "La copia de seguridad solo se puede guardar en el disco desde dentro de After Effects.",
            keys: " ajustes",
            builtin: "De fábrica",
            builtinTip: "La configuración inicial de EditKit. No contiene presets, scripts, efectos de terceros, rutas personales ni imágenes."
        },
        en: {
            tab: "Profiles",
            section: "Profiles",
            intro: "A profile saves your EditKit, EaseIt, QuickIt and AlignIt work setup in one go: your button grid, presets and collections, accent, backdrop, panel sizes and the rest of your workflow preferences. Language always remains local to this computer.",
            note: "Profiles can include images, GIFs, icons and media URLs. The privacy option decides whether your personal presets and scripts travel too.",
            safeShare: "Share without personal files",
            safeShareHint: "When exporting, excludes your preset collections, .ffx files, .jsx scripts and their paths. Images, GIFs, icons and media URLs are still included.",
            safeShareDone: " · without personal presets or scripts",
            packedOne: " · 1 file inside",
            packedMany: " · %n files inside",
            missingFiles: "%n file(s) were not found on disk: those buttons travel without their file.",
            tooBig: "A file does not fit (the limit is 20 MB per profile) and was left out.",
            unpacked: "%n file(s) saved to ",
            noBinary: "Outside After Effects the files cannot be packed into the profile. It exports without them.",
            empty: "You have not saved a profile yet. Save the first one with what you have right now: it changes nothing, it just marks where you are.",
            save: "Save the current setup…",
            importBtn: "Import…",
            namePh: "Profile name",
            nameOk: "Save",
            nameCancel: "Cancel",
            apply: "Apply",
            update: "Update",
            exportBtn: "Export",
            rename: "Rename",
            remove: "Delete",
            sure: "Sure?",
            lastUsed: "Last applied",
            undo: "Undo: back to how it was",
            savedAs: "Profile saved: ",
            applied: "Profile applied. Reloading the panel…",
            undone: "Previous setup restored. Reloading the panel…",
            removed: "Profile deleted.",
            renamed: "Profile renamed.",
            exported: "Profile exported to ",
            imported: "Profile imported: ",
            needName: "Give the profile a name.",
            dupName: "You already have a profile with that name.",
            noRoom: "No room: the panel's storage is full. Delete a profile or a backdrop image.",
            badFile: "That file is not an EditKit profile.",
            noFile: "The file could not be read.",
            noSave: "The file could not be saved.",
            newer: "That profile was made by a newer version of EditKit. It imports anyway, but something may be missing.",
            confirmApply: "Applying replaces your whole current setup. A copy is kept so you can go back. Press again to confirm.",
            confirmUpdate: "Updating overwrites this profile with your current setup, and it cannot be undone. Press again to confirm.",
            updated: "Profile updated: ",
            backupTip: "Save a backup of your profiles to Documents/EditKit/Perfiles",
            backupOk: "Backup saved: ",
            backupEmpty: "There are no profiles to back up yet.",
            backupNoHost: "A backup can only be saved to disk from inside After Effects.",
            keys: " settings",
            builtin: "Built-in",
            builtinTip: "EditKit's initial configuration. It contains no presets, scripts, third-party effects, personal paths, or images."
        }
    };

    var lang = "es";
    try { lang = localStorage.getItem("editkit_lang") || "es"; } catch (e) {}
    if (!DICT[lang]) lang = "es";

    function t(k) { return (DICT[lang] && DICT[lang][k]) || DICT.es[k] || k; }

    function $(id) { return document.getElementById(id); }

    // ---------------------------------------------------------------------
    // El almacen
    // ---------------------------------------------------------------------
    function readJson(key, fallback) {
        try {
            var raw = localStorage.getItem(key);
            if (!raw) return fallback;
            var v = JSON.parse(raw);
            return (v === null || v === undefined) ? fallback : v;
        } catch (e) { return fallback; }
    }

    function writeJson(key, value) {
        try { localStorage.setItem(key, JSON.stringify(value)); return true; }
        catch (e) { return false; }   // cupo lleno
    }

    function list() {
        var a = readJson(K_LIST, []);
        return (a && a.length) ? a : [];
    }

    function saveList(a) { return writeJson(K_LIST, a); }

    function safeShareEnabled() {
        try { return localStorage.getItem(K_SAFE_SHARE) !== "0"; }
        catch (e) { return true; }
    }

    function saveSafeShare(value) {
        try { localStorage.setItem(K_SAFE_SHARE, value ? "1" : "0"); }
        catch (e) {}
    }

    /* La privacidad se aplica a la COPIA que sale del equipo, nunca al perfil
       guardado. Asi el autor conserva sus presets y scripts para trabajar, pero
       puede compartir la apariencia y la organizacion sin regalar archivos ni
       filtrar rutas personales. */
    function keysForShare(keys, safe) {
        var out = {}, k;
        for (k in keys) { if (keys.hasOwnProperty(k)) out[k] = keys[k]; }
        if (!safe) return out;

        delete out.easeit_collections;
        delete out.easeit_library;

        var grid = parseGrid(out[GRID_KEY]);
        if (grid) {
            for (var i = 0; i < grid.length; i++) {
                var entry = grid[i];
                if (!entry || typeof entry !== "object") continue;
                if (entry.kind === "preset" || entry.kind === "script") {
                    entry.value = "";
                }
            }
            out[GRID_KEY] = JSON.stringify(grid);
        }
        return out;
    }

    function travels(key) {
        if (!key || SKIP[key]) return false;
        for (var i = 0; i < PREFIXES.length; i++) {
            if (key.indexOf(PREFIXES[i]) === 0) return true;
        }
        return false;
    }

    // Lo que hay puesto ahora mismo, listo para meter en un perfil.
    function snapshot() {
        var out = {}, i, k, v;
        var names = [];
        try {
            for (i = 0; i < localStorage.length; i++) {
                k = localStorage.key(i);
                if (k) names.push(k);
            }
        } catch (e) { return out; }

        for (i = 0; i < names.length; i++) {
            k = names[i];
            if (!travels(k)) continue;
            try { v = localStorage.getItem(k); } catch (e2) { continue; }
            if (v === null) continue;
            out[k] = v;
        }
        return out;
    }

    /* Poner un perfil: se escribe lo que trae y se borra lo que ya no esta.
       Sin lo segundo quedaria una mezcla —los ajustes del perfil encima de los
       tuyos— que no es la configuracion de nadie. */
    function restore(keys) {
        var i, k;
        var have = [];
        try {
            for (i = 0; i < localStorage.length; i++) {
                k = localStorage.key(i);
                if (k && travels(k)) have.push(k);
            }
        } catch (e) {}

        for (i = 0; i < have.length; i++) {
            if (!keys.hasOwnProperty(have[i])) {
                try { localStorage.removeItem(have[i]); } catch (e2) {}
            }
        }
        for (k in keys) {
            if (!keys.hasOwnProperty(k)) continue;
            if (!travels(k)) continue;   // un archivo de fuera no manda aqui
            try { localStorage.setItem(k, String(keys[k])); } catch (e3) {}
        }
    }

    /* Basic es el punto de partida real, no solo una tarjeta para aplicar a
       mano. Se instala una unica vez y solo cuando no hay señales de una
       instalacion usada. Una actualizacion nunca sustituye la configuracion ni
       los perfiles de quien ya trabaja con EditKit. */
    function seedFactoryDefault() {
        try {
            if (localStorage.getItem(K_FACTORY) === "1") return false;

            var hasProfiles = localStorage.getItem(K_LIST) !== null;
            var hasBeenUsed = localStorage.getItem("editkit_welcomed") === "1";
            localStorage.setItem(K_FACTORY, "1");

            if (hasProfiles || hasBeenUsed) return false;
            restore(FACTORY.keys || {});
            localStorage.setItem(K_LAST, BUILTIN_ID);
            return true;
        } catch (e) {
            return false;
        }
    }

    function countOf(p) {
        var n = 0, k;
        for (k in p.keys) { if (p.keys.hasOwnProperty(k)) n++; }
        return n;
    }

    function stamp() {
        var d = new Date();
        function two(n) { return (n < 10 ? "0" : "") + n; }
        return d.getFullYear() + "-" + two(d.getMonth() + 1) + "-" + two(d.getDate()) +
               " " + two(d.getHours()) + ":" + two(d.getMinutes());
    }

    function newId() {
        return "p" + String(Date.now()) + String(Math.floor(Math.random() * 1000));
    }

    // ---------------------------------------------------------------------
    // Mensajes
    // ---------------------------------------------------------------------
    var msgTimer = null;

    function say(text, kind) {
        var el = $("profMsg");
        if (!el) return;
        el.textContent = text;
        el.className = "prof-msg" + (kind ? " " + kind : "");
        el.hidden = false;
        if (msgTimer) clearTimeout(msgTimer);
        msgTimer = setTimeout(function () {
            msgTimer = null;
            if (el) el.hidden = true;
        }, 7000);
    }

    // ---------------------------------------------------------------------
    // La lista
    // ---------------------------------------------------------------------
    var armed = null;   // id + accion esperando la segunda pulsacion
    var armTimer = null;

    function disarm() {
        armed = null;
        if (armTimer) { clearTimeout(armTimer); armTimer = null; }
    }

    /* Confirmar sin sacar una ventana encima de otra ventana: el boton se
       queda preguntando unos segundos y luego se olvida. Dos pulsaciones
       seguidas hacen la cosa; una pulsacion y esperar, no. */
    function arm(id, what, btn, label) {
        if (armed && armed.id === id && armed.what === what) return true;
        disarm();
        armed = { id: id, what: what };
        var old = btn.textContent;
        btn.textContent = label;
        btn.classList.add("danger");
        armTimer = setTimeout(function () {
            armTimer = null; armed = null;
            btn.textContent = old;
            btn.classList.remove("danger");
        }, 4000);
        return false;
    }

    function mkBtn(cls, label, title) {
        var b = document.createElement("button");
        b.type = "button";
        b.className = cls;
        b.textContent = label;
        if (title) b.title = title;
        return b;
    }

    // ---------------------------------------------------------------------
    // La tarjeta: acento, curva y rejilla de ese perfil, con el mismo
    // relieve que las cartas de Temas (shell/js/themes.js)
    // ---------------------------------------------------------------------
    function accentOf(p) {
        var v = p.keys && p.keys.easeit_accent;
        return (v && /^#[0-9a-f]{3,6}$/i.test(v)) ? v : "#49c9bd";
    }
    function gridOf(p) {
        try {
            var g = p.keys && p.keys.editkit_qi_grid;
            var arr = g ? JSON.parse(g) : [];
            return (arr && arr.length) ? arr : [];
        } catch (e) { return []; }
    }
    function gradCss(type, angle, c1, c2) {
        if (type === "radial") return "radial-gradient(circle at 30% 20%, " + c1 + ", " + c2 + ")";
        if (type === "conic") return "conic-gradient(from " + angle + "deg, " + c1 + ", " + c2 + ", " + c1 + ")";
        return "linear-gradient(" + angle + "deg, " + c1 + ", " + c2 + ")";
    }
    function cellBg(e) {
        if (e.bgType === "gradient" && e.color && e.bg2) {
            return gradCss(e.gradType || "linear", (typeof e.gradAngle === "number") ? e.gradAngle : 135, e.color, e.bg2);
        }
        return e.color || "";
    }

    var MOCK_CELLS = 12;

    // La rejilla de la maqueta es de verdad: los colores y degradados de cada
    // perfil, no un color generico repetido. Es lo que hace que una tarjeta
    // de perfil diga mas que una de tema —un tema es tres cosas, un perfil es
    // como quedo organizada toda la rejilla—.
    function paintCard(el, p) {
        el.style.setProperty("--prof-accent", accentOf(p));
        var grid = el.querySelector(".prof-mock-grid");
        grid.innerHTML = "";
        var entries = gridOf(p);
        for (var i = 0; i < MOCK_CELLS; i++) {
            var cell = document.createElement("i");
            var e = entries[i];
            if (e) {
                var bg = cellBg(e);
                if (bg) cell.style.background = bg;
                if (e.border) cell.style.borderColor = e.border;
            }
            grid.appendChild(cell);
        }
    }

    var CARD_GUTS =
        '<span class="prof-bg"></span>' +
        '<span class="prof-mock">' +
            '<span class="prof-mock-bar"><i class="prof-mock-dot"></i><i></i><i></i></span>' +
            '<span class="prof-mock-curve">' +
                '<svg viewBox="0 0 44 14" preserveAspectRatio="none" aria-hidden="true">' +
                '<path d="M1 13 C 13 13 15 1 43 1" fill="none" stroke="currentColor" ' +
                'stroke-width="1.4" stroke-linecap="round"/></svg>' +
            '</span>' +
            '<span class="prof-mock-grid"></span>' +
        '</span>' +
        '<span class="prof-sheen"></span>';

    function render() {
        var box = $("profList");
        if (!box) return;
        coolProf();
        box.innerHTML = "";

        var all = BUILT_IN.concat(list());
        var last = "";
        try { last = localStorage.getItem(K_LAST) || ""; } catch (e) {}

        for (var i = 0; i < all.length; i++) {
            box.appendChild(card(all[i], all[i].id === last));
        }

        var undo = $("profUndo");
        if (undo) {
            var has = false;
            try { has = !!localStorage.getItem(K_UNDO); } catch (e2) {}
            undo.hidden = !has;
            undo.textContent = t("undo");
        }
        wireTilt();
    }

    function card(p, isLast) {
        var el = document.createElement("div");
        el.className = "prof-card" + (isLast ? " last" : "");

        var stage = document.createElement("div");
        stage.className = "prof-stage";
        stage.innerHTML = CARD_GUTS;
        el.appendChild(stage);
        paintCard(el, p);

        var foot = document.createElement("div");
        foot.className = "prof-foot";
        var name = document.createElement("span");
        name.className = "prof-name";
        name.textContent = p.name;
        foot.appendChild(name);

        if (p.builtin) {
            var btag = document.createElement("span");
            btag.className = "prof-tag builtin";
            btag.textContent = t("builtin");
            btag.title = t("builtinTip");
            foot.appendChild(btag);
        } else if (isLast) {
            var tag = document.createElement("span");
            tag.className = "prof-tag";
            tag.textContent = t("lastUsed");
            foot.appendChild(tag);
        }
        el.appendChild(foot);

        var meta = document.createElement("div");
        meta.className = "prof-meta";
        meta.textContent = p.builtin
            ? (countOf(p) + t("keys"))
            : ((p.updated || p.created || "") + " · " + countOf(p) + t("keys"));
        el.appendChild(meta);

        var acts = document.createElement("div");
        acts.className = "prof-acts";

        var bApply = mkBtn("prof-btn primary", t("apply"));
        bApply.addEventListener("click", function () {
            if (!arm(p.id, "apply", bApply, t("sure"))) { say(t("confirmApply")); return; }
            disarm();
            applyProfile(p);
        });
        acts.appendChild(bApply);

        /* Actualizar, renombrar y eliminar no significan nada sobre el de
           fabrica: no tiene un "antes" propio que sobreescribir, ni un
           nombre que sea suyo para cambiar. Solo se ofrecen en los que el
           usuario guardo. */
        if (!p.builtin) {
            var bUpdate = mkBtn("prof-btn", t("update"));
            bUpdate.addEventListener("click", function () {
                if (!arm(p.id, "update", bUpdate, t("sure"))) { say(t("confirmUpdate")); return; }
                disarm();
                updateProfile(p.id);
            });
            acts.appendChild(bUpdate);
        }

        var bExport = mkBtn("prof-btn", t("exportBtn"));
        bExport.addEventListener("click", function () { exportProfile(p); });
        acts.appendChild(bExport);

        if (!p.builtin) {
            var bRename = mkBtn("prof-btn", t("rename"));
            bRename.addEventListener("click", function () { startRename(el, name, p); });
            acts.appendChild(bRename);

            var bDel = mkBtn("prof-btn", t("remove"));
            bDel.addEventListener("click", function () {
                if (!arm(p.id, "del", bDel, t("sure"))) return;
                disarm();
                removeProfile(p.id);
            });
            acts.appendChild(bDel);
        }

        el.appendChild(acts);
        return el;
    }

    /* ------------------------------------------------------------------
       EL RELIEVE

       Lo mismo que las cartas de Temas: un giro en dos ejes y un brillo que
       sigue al cursor, con la maqueta de dentro moviendose un poco mas que
       la carta misma. Una copia propia y no una llamada a themes.js a
       proposito: son archivos que se cargan por separado, y una tarjeta de
       perfil no tiene por que depender de que el de temas exista o se cargue
       primero.
       ------------------------------------------------------------------ */
    var MAX_TILT_P = 7, MAX_SHIFT_P = 5;
    var stillProf = false;
    try { stillProf = window.matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (eM) {}

    var hotStage = null, pendStage = null, frameProf = 0;

    function paintTiltProf() {
        frameProf = 0;
        if (!pendStage) return;
        var c = pendStage.c, nx = pendStage.nx, ny = pendStage.ny;
        pendStage = null;
        c.style.setProperty("--prof-tilt-x", (-ny * MAX_TILT_P).toFixed(2) + "deg");
        c.style.setProperty("--prof-tilt-y", (nx * MAX_TILT_P).toFixed(2) + "deg");
        c.style.setProperty("--prof-shift-x", (nx * MAX_SHIFT_P).toFixed(2) + "px");
        c.style.setProperty("--prof-shift-y", (ny * MAX_SHIFT_P).toFixed(2) + "px");
        c.style.setProperty("--prof-light-x", (50 + nx * 45).toFixed(1) + "%");
        c.style.setProperty("--prof-light-y", (50 + ny * 45).toFixed(1) + "%");
    }
    function askProf() {
        if (frameProf) return;
        if (window.requestAnimationFrame) frameProf = window.requestAnimationFrame(paintTiltProf);
        else paintTiltProf();
    }
    var PROF_VARS = ["--prof-tilt-x", "--prof-tilt-y", "--prof-shift-x",
                      "--prof-shift-y", "--prof-light-x", "--prof-light-y"];
    function coolProf() {
        if (!hotStage) return;
        var c = hotStage;
        hotStage = null;
        pendStage = null;
        c.classList.remove("tracking");
        for (var i = 0; i < PROF_VARS.length; i++) c.style.removeProperty(PROF_VARS[i]);
    }
    function stageOf(node) {
        while (node && node.nodeType === 1) {
            if (node.classList && node.classList.contains("prof-stage")) return node;
            if (node.id === "profList") return null;
            node = node.parentNode;
        }
        return null;
    }
    function clampProf(v) { return v < -1 ? -1 : (v > 1 ? 1 : v); }
    function trackProf(ev) {
        var awake = window.EditKitAwake;
        if (awake && (awake.idle() || awake.performance())) { coolProf(); return; }
        var c = stageOf(ev.target);
        if (!c) { coolProf(); return; }
        if (hotStage !== c) {
            coolProf();
            hotStage = c;
            c.classList.add("tracking");
        }
        var r = c.getBoundingClientRect();
        if (!r.width || !r.height) return;
        var nx = clampProf(((ev.clientX - r.left) / r.width) * 2 - 1);
        var ny = clampProf(((ev.clientY - r.top) / r.height) * 2 - 1);
        pendStage = { c: c, nx: nx, ny: ny };
        askProf();
    }
    function wireTilt() {
        var box = $("profList");
        if (!box || stillProf || box.getAttribute("data-tilt") === "1") return;
        box.setAttribute("data-tilt", "1");
        box.addEventListener("mousemove", trackProf);
        box.addEventListener("mouseleave", coolProf);
    }

    /* Renombrar en el sitio. El nombre se convierte en un campo y vuelve a ser
       un nombre: no hace falta una ventana para cambiar una palabra. */
    function startRename(el, nameEl, p) {
        if (el.querySelector(".prof-rename")) return;
        var inp = document.createElement("input");
        inp.type = "text";
        inp.className = "bd-input prof-rename";
        inp.maxLength = 60;
        inp.value = p.name;
        nameEl.style.display = "none";
        nameEl.parentNode.insertBefore(inp, nameEl);
        inp.focus();
        inp.select();

        function close(commit) {
            var v = inp.value.replace(/^\s+|\s+$/g, "");
            if (inp.parentNode) inp.parentNode.removeChild(inp);
            nameEl.style.display = "";
            if (!commit || !v || v === p.name) return;
            var all = list();
            for (var i = 0; i < all.length; i++) {
                if (all[i].name === v && all[i].id !== p.id) { say(t("dupName"), "warn"); return; }
            }
            for (i = 0; i < all.length; i++) {
                if (all[i].id === p.id) { all[i].name = v; all[i].updated = stamp(); }
            }
            if (!saveList(all)) { say(t("noRoom"), "warn"); return; }
            say(t("renamed"), "ok");
            render();
        }

        inp.addEventListener("keydown", function (e) {
            if (e.key === "Enter" || e.keyCode === 13) { e.preventDefault(); close(true); }
            else if (e.key === "Escape" || e.keyCode === 27) { e.preventDefault(); close(false); }
        });
        inp.addEventListener("blur", function () { close(true); });
    }

    // ---------------------------------------------------------------------
    // Las acciones
    // ---------------------------------------------------------------------
    function saveCurrent(name) {
        var all = list();
        for (var i = 0; i < all.length; i++) {
            if (all[i].name === name) { say(t("dupName"), "warn"); return false; }
        }
        all.push({
            id: newId(),
            name: name,
            created: stamp(),
            updated: stamp(),
            keys: snapshot()
        });
        if (!saveList(all)) { say(t("noRoom"), "warn"); return false; }
        say(t("savedAs") + name, "ok");
        render();
        return true;
    }

    /* Actualizar: el perfil se queda con lo que hay puesto ahora mismo, con su
       fecha de creacion intacta y la de actualizacion al dia. No toca la
       configuracion de nadie —al reves que Aplicar—, asi que no hace falta
       copia de seguridad ni recargar el panel. */
    function updateProfile(id) {
        var all = list(), i;
        for (i = 0; i < all.length; i++) {
            if (all[i].id === id) {
                all[i].keys = snapshot();
                all[i].updated = stamp();
                break;
            }
        }
        if (!saveList(all)) { say(t("noRoom"), "warn"); return; }
        say(t("updated") + all[i].name, "ok");
        render();
    }

    function removeProfile(id) {
        var all = list(), out = [];
        for (var i = 0; i < all.length; i++) {
            if (all[i].id !== id) out.push(all[i]);
        }
        saveList(out);
        say(t("removed"), "ok");
        render();
    }

    function applyProfile(p) {
        /* La copia de seguridad primero y con lo que hay AHORA, no con lo que
           habia al abrir la ventana. */
        writeJson(K_UNDO, { at: stamp(), keys: snapshot() });
        restore(p.keys || {});
        try { localStorage.setItem(K_LAST, p.id); } catch (e) {}
        say(t("applied"), "ok");
        reload();
    }

    function undo() {
        var u = readJson(K_UNDO, null);
        if (!u || !u.keys) return;
        restore(u.keys);
        try { localStorage.removeItem(K_UNDO); } catch (e) {}
        try { localStorage.removeItem(K_LAST); } catch (e2) {}
        say(t("undone"), "ok");
        reload();
    }

    /* Recargar y no repintar. Los tres plugins leen su configuracion una vez,
       al arrancar, y montan media ventana con ella: la rejilla de QuickIt, las
       colecciones de EaseIt, las secciones de AlignIt. Avisarles uno por uno
       de que todo cambio seria escribir tres veces el mismo arranque y que se
       separen. La pagina entera vuelve a empezar, los tres marcos con ella, y
       lo que sale es exactamente lo que saldria al abrir el panel. */
    function reload() {
        setTimeout(function () {
            try { location.reload(); } catch (e) {}
        }, 450);
    }

    // ---------------------------------------------------------------------
    // El archivo
    // ---------------------------------------------------------------------
    /* TRES CAMINOS PARA UN ARCHIVO, Y EL ORDEN IMPORTA

       1. La propia capa de CEP: `window.cep.fs`. Es la buena. Abre el dialogo
          del sistema y escribe el archivo sin que el texto tenga que pasar por
          ningun sitio mas.

       2. ExtendScript, si el dialogo de CEP no esta. Funciona, pero el perfil
          entero viaja dentro de una linea de codigo hasta el interprete del
          programa, y un perfil con una libreria de presets grande son cientos
          de miles de caracteres. Sirve de suplente, no de titular.

       3. Un enlace de descarga, que solo existe fuera de After Effects —
          mirando el panel en un navegador. Dentro no hace nada, y por eso es
          el ultimo. */

    /* Se pregunta por el puente que inyecta el programa, no por lo que
       CSInterface haya podido leer de el. `hostEnvironment` se calcula una
       sola vez, cuando se carga ese archivo, y si algo llega tarde se queda
       vacio para siempre — con lo cual el panel decidiria que no esta dentro
       de After Effects estandolo. El puente, en cambio, esta o no esta. */
    function host() {
        try {
            if (!window.__adobe_cep__) return null;
            return new CSInterface();
        } catch (e) { return null; }
    }

    function cepFs() {
        try {
            if (window.cep && window.cep.fs && window.cep.fs.writeFile) return window.cep.fs;
        } catch (e) {}
        return null;
    }

    /* Donde se abren los dialogos: Documentos/EditKit/Perfiles, creada al vuelo
       la primera vez. Es la misma carpeta que usa el host para la bitacora, y la
       misma a la que el host se trae los perfiles de la carpeta vieja al
       arrancar (ver _ekHome en host/index.jsx). */
    function profileDir() {
        var cs = host();
        if (!cs) return "";
        var base = "";
        try { base = cs.getSystemPath(SystemPath.MY_DOCUMENTS) || ""; } catch (e) { return ""; }
        if (!base) return "";
        var dir = base + "/EditKit/Perfiles";
        var fs = cepFs();
        if (fs && fs.makedir) {
            try { fs.makedir(base + "/EditKit"); } catch (e2) {}
            try { fs.makedir(dir); } catch (e3) {}
        }
        return dir;
    }

    /* Un icono, sin dialogo de por medio: un volcado de TODOS los perfiles tal
       como estan ahora mismo, con la fecha en el nombre, a la misma carpeta
       donde ya se abren los dialogos de Exportar e Importar. No sustituye a
       Exportar —esa elige sitio y nombre, y solo lleva un perfil—; esta es la
       copia de "por si acaso", de todos a la vez, permanente en el disco y sin
       que el usuario tenga que elegir nada. */
    function backupProfiles() {
        var fs = cepFs();
        var dir = profileDir();
        if (!fs || !dir) { say(t("backupNoHost"), "warn"); return; }
        var all = list();
        if (!all.length) { say(t("backupEmpty"), "warn"); return; }

        var body = JSON.stringify({
            tag: "editkit-profiles-backup",
            ver: FILE_VER,
            saved: new Date().toISOString(),
            profiles: all
        });
        var name = safeFileName("Copia de seguridad " + stamp().replace(/:/g, "-")) + ".json";
        var w = null;
        /* UTF-8 is CEP's default text mode. Passing the string "utf-8" here
           looks harmless but it is not one of the native encoding constants
           and some CEP builds return success from the dialog, then reject the
           write. Adobe's own sample deliberately omits this third argument. */
        try { w = fs.writeFile(dir + "/" + name, body); } catch (e) { w = null; }
        if (!w || w.err !== 0) { say(t("noSave"), "warn"); return; }
        say(t("backupOk") + name, "ok");
    }

    /* ====================================================================
       LOS ARCHIVOS QUE EL PERFIL LLEVA DENTRO

       Un boton de QuickIt puede apuntar a tres cosas que estan en el disco y
       no en el panel: un preset .ffx, un script .jsx y el icono propio del
       boton. Guardados como ruta, un perfil compartido llega al otro equipo
       con botones que apuntan a carpetas que no existen — funcionan en la
       maquina de quien lo hizo y en ninguna mas.

       Asi que el archivo del perfil los lleva dentro. Al exportar se leen del
       disco y se meten en el propio archivo; al importar se dejan en una
       carpeta del equipo y los botones se apuntan solos ahi.

       DOS COSAS QUE NO SON OBVIAS:

       Solo van dentro del ARCHIVO, no del perfil guardado en el panel. Un
       perfil que vive aqui no necesita copias: los archivos ya estan en este
       disco, en su sitio, y meter copias en el almacenamiento del panel lo
       llenaria por gusto.

       Y los archivos se leen y se escriben con la capa del propio CEP, que es
       la unica de las dos que sabe de bytes. Sin ella —mirando el panel fuera
       de After Effects— el perfil se exporta igual, pero con las rutas de
       siempre y avisando de ello.
       ==================================================================== */

    var GRID_KEY = "editkit_qi_grid";
    var TOKEN = "editkit:archivo/";
    var MAX_PACK = 20 * 1024 * 1024;   // en base64, que es lo que ocupa de verdad

    function encoding(name, dflt) {
        try {
            if (window.cep && window.cep.encoding && window.cep.encoding[name]) {
                return window.cep.encoding[name];
            }
        } catch (e) {}
        var fs = cepFs();
        if (fs && fs[name]) return fs[name];
        return dflt;
    }

    function baseName(path) {
        var s2 = String(path).replace(/\\/g, "/");
        var i = s2.lastIndexOf("/");
        return (i >= 0) ? s2.substring(i + 1) : s2;
    }

    /* Los tres sitios de la rejilla que guardan una ruta. `visit` devuelve lo
       que hay que poner en su lugar, o null para dejarlo como esta. */
    function walkGridFiles(grid, visit) {
        for (var i = 0; i < grid.length; i++) {
            var e = grid[i];
            if (!e || typeof e !== "object") continue;
            if ((e.kind === "preset" || e.kind === "script") && e.value) {
                var a = visit(String(e.value), e.kind);
                if (a !== null) e.value = a;
            }
            if (e.icon) {
                var b = visit(String(e.icon), "image");
                if (b !== null) e.icon = b;
            }
        }
    }

    /* Fondo general y recuadros de EaseIt/AlignIt. Solo se empaquetan las
       imagenes: los videos siguen siendo una opcion avanzada y pueden superar
       con facilidad el limite de un perfil. Las URL y los data URL ya son
       portables y se conservan tal cual. */
    function walkMediaImages(keys, visit) {
        var backdrop = null;
        try { backdrop = JSON.parse(keys[BACKDROP_KEY]); } catch (e) { backdrop = null; }
        if (backdrop && typeof backdrop.image === "string" && backdrop.image) {
            var nextBackdrop = visit(backdrop.image, "image");
            if (nextBackdrop !== null) backdrop.image = nextBackdrop;
            keys[BACKDROP_KEY] = JSON.stringify(backdrop);
        }

        var surfaces = null;
        try { surfaces = JSON.parse(keys[SURFACE_MEDIA_KEY]); } catch (e2) { surfaces = null; }
        if (surfaces) {
            var tools = ["ease", "align"];
            var changed = false;
            for (var i = 0; i < tools.length; i++) {
                var media = surfaces[tools[i]];
                if (!media || typeof media.image !== "string" || !media.image) continue;
                var nextImage = visit(media.image, "image");
                if (nextImage !== null) { media.image = nextImage; changed = true; }
            }
            if (changed) keys[SURFACE_MEDIA_KEY] = JSON.stringify(surfaces);
        }
    }

    function parseGrid(raw) {
        var g = null;
        try { g = JSON.parse(raw); } catch (e) { g = null; }
        return (g && g.length) ? g : null;
    }

    function portableReference(path) {
        return /^(https?:|data:)/i.test(path);
    }

    // Al exportar: leer los archivos y cambiar cada ruta por su vale.
    function packFiles(keys, safe) {
        var out = keysForShare(keys, safe);
        var grid = parseGrid(out[GRID_KEY]);

        var fs = cepFs();
        if (!fs || !fs.readFile) {
            var any = false;
            function withoutDisk(path, kind) {
                if (path.indexOf(TOKEN) === 0 || portableReference(path)) return null;
                any = true;
                return safe && kind === "image" ? "" : null;
            }
            if (grid) {
                walkGridFiles(grid, withoutDisk);
                out[GRID_KEY] = JSON.stringify(grid);
            }
            walkMediaImages(out, withoutDisk);
            return { keys: out, files: null, count: 0, noBinary: any, safe: safe };
        }

        var B64 = encoding("Base64", "Base64");
        var files = {}, seen = {}, n = 0, bytes = 0, missing = 0, big = 0;

        function packPath(path, kind) {
            if (path.indexOf(TOKEN) === 0) return null;   // ya empaquetado
            if (portableReference(path)) return null;
            if (/^blob:/i.test(path)) return safe && kind === "image" ? "" : null;
            var key = path.toLowerCase();
            if (seen.hasOwnProperty(key)) return seen[key];

            var got = null;
            try { got = fs.readFile(path, B64); } catch (e) { got = null; }
            if (!got || got.err !== 0 || !got.data) {
                missing++;
                seen[key] = safe && kind === "image" ? "" : null;
                return seen[key];
            }
            if (bytes + got.data.length > MAX_PACK) {
                big++;
                seen[key] = safe && kind === "image" ? "" : null;
                return seen[key];
            }

            bytes += got.data.length;
            n++;
            var id = "f" + n;
            files[id] = { n: baseName(path), d: got.data };
            seen[key] = TOKEN + id;
            return seen[key];
        }

        if (grid) {
            walkGridFiles(grid, packPath);
            out[GRID_KEY] = JSON.stringify(grid);
        }
        walkMediaImages(out, packPath);
        return { keys: out, files: n ? files : null, count: n, missing: missing, big: big, safe: safe };
    }

    // Donde aterrizan al importar: una carpeta por perfil, para que borrar un
    // perfil no se lleve por delante los archivos de otro.
    function filesDir(name) {
        var base = profileDir();
        if (!base) return "";
        var fs = cepFs();
        var dir = base + "/Archivos";
        if (fs && fs.makedir) {
            try { fs.makedir(dir); } catch (e) {}
            dir += "/" + safeFileName(name);
            try { fs.makedir(dir); } catch (e2) {}
        } else {
            dir += "/" + safeFileName(name);
        }
        return dir;
    }

    // Al importar: dejar los archivos en el disco y cambiar cada vale por su
    // ruta nueva.
    function unpackFiles(keys, files, name) {
        var res = { written: 0, failed: 0, dir: "" };
        var grid = parseGrid(keys[GRID_KEY]);

        var fs = cepFs();
        var dir = (fs && fs.writeFile) ? filesDir(name) : "";
        res.dir = dir;

        var B64 = encoding("Base64", "Base64");
        var map = {}, used = {};

        for (var id in files) {
            if (!files.hasOwnProperty(id)) continue;
            var f = files[id];
            if (!f || !f.d) continue;

            // Dos archivos distintos pueden llamarse igual y venir de carpetas
            // distintas. El segundo se numera en lugar de pisar al primero.
            var fname = safeFileName(f.n || id);
            if (used[fname.toLowerCase()]) {
                var dot = fname.lastIndexOf(".");
                var stem = (dot > 0) ? fname.substring(0, dot) : fname;
                var ext = (dot > 0) ? fname.substring(dot) : "";
                fname = stem + " (" + id + ")" + ext;
            }
            used[fname.toLowerCase()] = 1;

            if (!dir) continue;
            var w = null;
            try { w = fs.writeFile(dir + "/" + fname, f.d, B64); } catch (e) { w = null; }
            if (w && w.err === 0) { map[id] = dir + "/" + fname; res.written++; }
            else res.failed++;
        }

        if (grid) {
            walkGridFiles(grid, function (v) {
                if (v.indexOf(TOKEN) !== 0) return null;
                var id = v.substring(TOKEN.length);
                if (map[id]) return map[id];
                /* No se pudo dejar en el disco. Se deja el nombre del archivo a
                   secas: el boton sigue ahi y falla al pulsarlo diciendo que no
                   encuentra ese archivo, que es una queja que se entiende. Un vale
                   interno en pantalla no lo es. */
                return (files[id] && files[id].n) ? String(files[id].n) : "";
            });
            keys[GRID_KEY] = JSON.stringify(grid);
        }
        walkMediaImages(keys, function (v) {
            if (v.indexOf(TOKEN) !== 0) return null;
            var id = v.substring(TOKEN.length);
            if (map[id]) return map[id];
            return "";
        });
        return res;
    }

    function fileBody(p, packed) {
        return JSON.stringify({
            tag: FILE_TAG,
            v: FILE_VER,
            name: p.name,
            created: p.created || "",
            exported: stamp(),
            keys: packed.keys,
            files: packed.files || undefined
        }, null, 1);
    }

    // Lo que se le cuenta al usuario de un empaquetado, en una linea.
    function packNote(packed) {
        var msg = "";
        if (packed.count === 1) msg += t("packedOne");
        else if (packed.count > 1) msg += t("packedMany").replace("%n", String(packed.count));
        if (packed.safe) msg += t("safeShareDone");
        return msg;
    }

    /* El aviso va PEGADO al mensaje de exito, no detras. Hay un solo sitio
       donde se escribe, asi que un segundo say() borraria el primero antes de
       que nadie lo hubiera leido. */
    function packWarn(packed) {
        if (packed.noBinary) return " — " + t("noBinary");
        if (packed.big) return " — " + t("tooBig");
        if (packed.missing) return " — " + t("missingFiles").replace("%n", String(packed.missing));
        return "";
    }

    function safeFileName(n) {
        return String(n || "Perfil").replace(/[\\\/:*?"<>|]/g, " ").replace(/\s+/g, " ");
    }

    /* CEP normally returns the complete destination file. A few host/OS
       combinations return the directory the user just entered instead. That
       must not be treated as a writable file: detect it and put the suggested
       profile name inside. */
    function profileSavePath(fs, raw, name) {
        if (raw && typeof raw !== "string" && raw.length) raw = raw[0];
        var path = String(raw || "");
        if (!path) return "";

        var isDir = /[\\\/]$/.test(path);
        if (!isDir && fs && fs.stat) {
            try {
                var info = fs.stat(path);
                if (info && info.err === 0 && info.data) {
                    isDir = typeof info.data.isDirectory === "function"
                        ? !!info.data.isDirectory()
                        : !!info.data.isDirectory;
                }
            } catch (e) {}
        }
        if (isDir) path = path.replace(/[\\\/]+$/, "") + "/" + name;
        if (!/\.json$/i.test(path)) path += ".json";
        return path;
    }

    function writeTextFile(fs, path, body) {
        var wrote = null;
        try { wrote = fs.writeFile(path, body); } catch (e) { wrote = null; }
        if (!wrote || wrote.err !== 0) return false;

        /* Do not claim success merely because writeFile returned: verify the
           path now exists. stat is part of the same CEP filesystem API. */
        if (fs.stat) {
            try {
                var info = fs.stat(path);
                if (!info || info.err !== 0) return false;
                if (info.data) {
                    var isDir = typeof info.data.isDirectory === "function"
                        ? !!info.data.isDirectory()
                        : !!info.data.isDirectory;
                    if (isDir) return false;
                }
            } catch (e2) { return false; }
        }
        return true;
    }

    // Un perfil escrito a mano y un perfil escrito por el panel se leen igual,
    // asi que el archivo lleva el nombre del perfil y nada mas.
    function exportProfile(p) {
        var packed = packFiles(p.keys || {}, safeShareEnabled());
        var body = fileBody(p, packed);
        var extra = packNote(packed);
        var name = safeFileName(p.name) + ".json";

        var fs = cepFs();
        if (fs && fs.showSaveDialogEx) {
            var r = null;
            try {
                r = fs.showSaveDialogEx("Guardar el perfil", profileDir(),
                                        ["json"], name, "Perfiles de EditKit");
            } catch (e) { r = null; }
            if (r && r.data) {
                var path = profileSavePath(fs, r.data, name);
                if (path && writeTextFile(fs, path, body)) {
                    say(t("exported") + path + extra + packWarn(packed), "ok");
                    return;
                }
                say(t("noSave"), "warn");
                return;
            }
            if (r && r.err === 0) return;   // cancelado
        }

        var cs = host();
        if (cs) {
            var arg = JSON.stringify({ name: p.name, data: body })
                        .replace(/\\/g, "\\\\").replace(/'/g, "\\'");
            cs.evalScript("ek_profileSave('" + arg + "')", function (res) {
                var out = null;
                try { out = JSON.parse(res); } catch (e) {}
                if (out && (out.ok || out.success) && out.path) { say(t("exported") + out.path + extra + packWarn(packed), "ok"); return; }
                if (out && out.code === "canceled") return;
                say(t("noSave"), "warn");
            });
            return;
        }

        try {
            var a = document.createElement("a");
            a.href = "data:application/json;charset=utf-8," + encodeURIComponent(body);
            a.download = name;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            // Aqui no hay ruta que ensenar —la elige el navegador—, asi que se
            // dice el nombre. El aviso de los archivos sigue haciendo falta.
            say(t("exported") + name + extra + packWarn(packed), "ok");
        } catch (e3) { say(t("noSave"), "warn"); }
    }

    function ingest(text) {
        var o = null;
        try { o = JSON.parse(text); } catch (e) { o = null; }
        if (!o || o.tag !== FILE_TAG || !o.keys) { say(t("badFile"), "warn"); return; }
        if (Number(o.v) > FILE_VER) say(t("newer"), "warn");

        var name = String(o.name || "Perfil");
        var all = list();
        /* Dos perfiles con el mismo nombre son dos perfiles que no se
           distinguen. Al que llega se le pone un numero, y no se reemplaza al
           que ya estaba: nadie pidio perder el suyo por importar otro. */
        var base = name, n = 2, i;
        for (;;) {
            var clash = false;
            for (i = 0; i < all.length; i++) { if (all[i].name === name) { clash = true; break; } }
            if (!clash) break;
            name = base + " (" + n + ")";
            n++;
        }

        // Solo lo que este panel reconoce: un archivo de fuera no escribe
        // claves que no sean suyas.
        var keys = {}, k;
        for (k in o.keys) {
            if (!o.keys.hasOwnProperty(k)) continue;
            if (!travels(k)) continue;
            keys[k] = String(o.keys[k]);
        }

        /* Los archivos que venian dentro se dejan en el disco AHORA, antes de
           guardar el perfil: lo que se guarda en el panel son ya las rutas
           nuevas, no los vales. Un perfil guardado aqui no lleva copias. */
        var unpacked = null;
        if (o.files) unpacked = unpackFiles(keys, o.files, name);

        all.push({
            id: newId(),
            name: name,
            created: String(o.created || stamp()),
            updated: stamp(),
            keys: keys
        });
        if (!saveList(all)) { say(t("noRoom"), "warn"); return; }

        var msg = t("imported") + name;
        if (unpacked && unpacked.written) {
            msg += " — " + t("unpacked").replace("%n", String(unpacked.written)) + unpacked.dir;
        }
        say(msg, "ok");
        render();
    }

    function importProfile() {
        var input = $("profFileInput");

        var fs = cepFs();
        if (fs && fs.showOpenDialogEx) {
            var r = null;
            try {
                r = fs.showOpenDialogEx(false, false, "Abrir un perfil",
                                        profileDir(), ["json"], "Perfiles de EditKit");
            } catch (e) { r = null; }
            if (r && r.data && r.data.length) {
                var path = String(r.data[0]);
                var got = null;
                try { got = fs.readFile(path); } catch (e2) { got = null; }
                if (got && got.err === 0 && got.data) { ingest(String(got.data)); return; }
                say(t("noFile"), "warn");
                return;
            }
            if (r && r.err === 0) return;   // cancelado
        }

        var cs = host();
        if (cs) {
            cs.evalScript("ek_profileOpen()", function (res) {
                var out = null;
                try { out = JSON.parse(res); } catch (e) {}
                if (out && (out.ok || out.success) && out.data) { ingest(out.data); return; }
                if (out && out.code === "canceled") return;
                if (input) input.click(); else say(t("noFile"), "warn");
            });
            return;
        }

        if (input) input.click();
    }

    // ---------------------------------------------------------------------
    // Enganches
    // ---------------------------------------------------------------------
    function showNamer(on) {
        var box = $("profNamer");
        if (!box) return;
        box.hidden = !on;
        if (on) {
            var inp = $("profName");
            if (inp) { inp.value = ""; inp.focus(); }
        }
    }

    function commitName() {
        var inp = $("profName");
        if (!inp) return;
        var v = inp.value.replace(/^\s+|\s+$/g, "");
        if (!v) { say(t("needName"), "warn"); inp.focus(); return; }
        if (saveCurrent(v)) showNamer(false);
    }

    function applyLanguage() {
        var map = {
            setTabProfilesLabel: "tab",
            setSectionProfiles: "section",
            profIntro: "intro",
            profNote: "note",
            profSafeShareLabel: "safeShare",
            profSafeShareHint: "safeShareHint",
            profSave: "save",
            profImport: "importBtn",
            profNameOk: "nameOk",
            profNameCancel: "nameCancel",
            profUndo: "undo"
        };
        for (var id in map) {
            if (!map.hasOwnProperty(id)) continue;
            var el = $(id);
            if (el) el.textContent = t(map[id]);
        }
        var inp = $("profName");
        if (inp) inp.placeholder = t("namePh");
        var profileTab = $("setTabProfiles");
        var profileLabel = $("setTabProfilesLabel");
        if (profileTab && profileLabel) {
            profileTab.title = profileLabel.textContent;
            profileTab.setAttribute("aria-label", profileLabel.textContent);
        }
        // Aparte del mapa: es un boton de un solo icono, sin texto que pisar.
        var backup = $("profBackup");
        if (backup) { backup.title = t("backupTip"); backup.setAttribute("aria-label", t("backupTip")); }
        var safeShare = $("profSafeShare");
        if (safeShare) {
            safeShare.title = t("safeShareHint");
            safeShare.setAttribute("aria-label", t("safeShare") + ". " + t("safeShareHint"));
        }
        render();
    }

    function boot() {
        if (seedFactoryDefault()) {
            reload();
            return;
        }
        if ($("profSave")) {
            $("profSave").addEventListener("click", function () { showNamer(true); });
        }
        if ($("profNameOk")) $("profNameOk").addEventListener("click", commitName);
        if ($("profNameCancel")) $("profNameCancel").addEventListener("click", function () { showNamer(false); });
        if ($("profName")) {
            $("profName").addEventListener("keydown", function (e) {
                if (e.key === "Enter" || e.keyCode === 13) { e.preventDefault(); commitName(); }
                else if (e.key === "Escape" || e.keyCode === 27) { e.preventDefault(); showNamer(false); }
            });
        }
        if ($("profImport")) $("profImport").addEventListener("click", importProfile);
        if ($("profBackup")) $("profBackup").addEventListener("click", backupProfiles);
        if ($("profUndo")) $("profUndo").addEventListener("click", undo);
        if ($("profSafeShare")) {
            $("profSafeShare").checked = safeShareEnabled();
            $("profSafeShare").addEventListener("change", function () {
                saveSafeShare($("profSafeShare").checked);
            });
        }

        var input = $("profFileInput");
        if (input) {
            input.addEventListener("change", function () {
                var f = input.files && input.files[0];
                input.value = "";
                if (!f) return;
                var r = new FileReader();
                r.onload = function () { ingest(String(r.result || "")); };
                r.onerror = function () { say(t("noFile"), "warn"); };
                r.readAsText(f);
            });
        }

        applyLanguage();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }

    // El interruptor de idioma del shell avisa por aqui.
    window.EditKitProfiles = {
        setLanguage: function (l) {
            lang = DICT[l] ? l : "es";
            applyLanguage();
        },
        refresh: render
    };
})();
