/* ============================================================================
   EDITKIT — PISTAS CONTEXTUALES ACCIONABLES

   Reglas de convivencia:
   - nacen de una accion o un problema observable, nunca de un temporizador;
   - como maximo aparece una por sesion;
   - no se superponen a recorridos, novedades, ajustes ni otros popovers;
   - si hay una solucion segura, el boton la aplica en el acto;
   - dos cierres explicitos silencian esa pista hasta que el usuario restablece.
   ============================================================================ */
(function () {
    "use strict";

    var ENABLED_KEY = "editkit_context_hints";
    var STATE_KEY = "editkit_context_hints_state_v1";
    var LANG_KEY = "editkit_lang";
    var MAX_DISMISSALS = 2;
    var shownThisSession = false;
    var active = null;
    var autoTimer = null;
    var resizeTimer = null;
    var settingsChanged = {};
    var settingsWasOpen = false;
    var quickScroll = { count: 0, distance: 0, since: 0 };

    var COPY = {
        es: {
            close: "Cerrar",
            later: "Ahora no",
            reset: "Restablecer pistas descartadas",
            resetDone: "Pistas restablecidas",
            narrowTabs: {
                title: "Hay poco espacio para tres paneles",
                copy: "El modo Pestañas deja visible una herramienta a la vez y conserva todo su contenido.",
                action: "Usar Pestañas"
            },
            balance: {
                title: "Un panel quedó con muy poco espacio",
                copy: "EDITKIT puede volver a repartir el área de forma inteligente sin cambiar el orden ni ocultar herramientas.",
                action: "Equilibrar paneles"
            },
            reorder: {
                title: "También puedes cambiar el orden",
                copy: "Arrastra la cabecera de EaseIt, QuickIt o AlignIt para colocarlos como prefieras.",
                action: "Mostrar cabeceras"
            },
            restore: {
                title: "{tool} quedó oculto",
                copy: "Puedes recuperarlo ahora sin volver a abrir los ajustes.",
                action: "Deshacer"
            },
            search: {
                title: "¿Buscas un botón o preset?",
                copy: "El buscador de QuickIt encuentra efectos y presets sin recorrer toda la rejilla.",
                action: "Abrir buscador"
            },
            profile: {
                title: "Has personalizado bastante EDITKIT",
                copy: "Guarda este estado como perfil para recuperarlo con un clic o llevarlo a otro equipo.",
                action: "Guardar perfil"
            }
        },
        en: {
            close: "Close",
            later: "Not now",
            reset: "Reset dismissed hints",
            resetDone: "Hints reset",
            narrowTabs: {
                title: "Three panels have very little room",
                copy: "Tabs mode shows one tool at a time while keeping all of its content available.",
                action: "Use Tabs"
            },
            balance: {
                title: "One panel has very little room",
                copy: "EDITKIT can balance the workspace again without changing the order or hiding tools.",
                action: "Balance panels"
            },
            reorder: {
                title: "You can also change the order",
                copy: "Drag the EaseIt, QuickIt or AlignIt header to place the tools wherever you prefer.",
                action: "Show headers"
            },
            restore: {
                title: "{tool} is now hidden",
                copy: "You can bring it back now without reopening Settings.",
                action: "Undo"
            },
            search: {
                title: "Looking for a button or preset?",
                copy: "QuickIt's search finds effects and presets without scrolling through the whole grid.",
                action: "Open search"
            },
            profile: {
                title: "You have customised EDITKIT quite a bit",
                copy: "Save this state as a profile to restore it in one click or move it to another computer.",
                action: "Save profile"
            }
        }
    };

    function lang() {
        var value = "es";
        try { value = localStorage.getItem(LANG_KEY) || "es"; } catch (e) {}
        return COPY[value] ? value : "es";
    }
    function text() { return COPY[lang()]; }
    function enabled() {
        try { return localStorage.getItem(ENABLED_KEY) !== "0"; } catch (e) { return true; }
    }
    function readState() {
        var value = null;
        try { value = JSON.parse(localStorage.getItem(STATE_KEY) || "null"); } catch (e) {}
        if (!value || typeof value !== "object") value = {};
        if (!value.dismissed || typeof value.dismissed !== "object") value.dismissed = {};
        if (!value.solved || typeof value.solved !== "object") value.solved = {};
        return value;
    }
    function writeState(value) {
        try { localStorage.setItem(STATE_KEY, JSON.stringify(value)); } catch (e) {}
    }
    function markSolved(id) {
        var state = readState();
        state.solved[id] = 1;
        writeState(state);
    }
    function markDismissed(id) {
        var state = readState();
        state.dismissed[id] = (Number(state.dismissed[id]) || 0) + 1;
        writeState(state);
    }
    function eligible(id) {
        if (!enabled() || shownThisSession || active || document.hidden) return false;
        var state = readState();
        return !state.solved[id] && (Number(state.dismissed[id]) || 0) < MAX_DISMISSALS;
    }
    function interfaceBusy() {
        var selectors = [
            ".ek-welcome", ".ek-tour", ".ek-whats-new", ".ek-ask",
            ".cmd-overlay", ".bd-overlay:not([hidden])",
            ".donate-popover:not([hidden])"
        ];
        return !!document.querySelector(selectors.join(","));
    }
    function esc(value) {
        return String(value == null ? "" : value).replace(/[&<>\"]/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;" }[c];
        });
    }
    function replaceTool(value, tool) { return String(value).replace("{tool}", tool || ""); }

    function place(node, anchor) {
        var margin = 8, gap = 8;
        var width = node.offsetWidth || Math.min(292, window.innerWidth - margin * 2);
        var height = node.offsetHeight || 110;
        var rect = anchor && anchor.getBoundingClientRect ? anchor.getBoundingClientRect() : null;
        var left, top, below;
        if (!rect || !rect.width || !rect.height) {
            left = window.innerWidth - width - margin;
            top = window.innerHeight - height - margin;
            below = false;
        } else {
            left = rect.left + rect.width / 2 - width / 2;
            left = Math.max(margin, Math.min(left, window.innerWidth - width - margin));
            below = rect.bottom + gap + height <= window.innerHeight - margin;
            top = below ? rect.bottom + gap : rect.top - height - gap;
            top = Math.max(margin, Math.min(top, window.innerHeight - height - margin));
            node.style.setProperty("--ek-hint-origin-x", Math.round(rect.left + rect.width / 2 - left) + "px");
            node.style.setProperty("--ek-hint-origin-y", below ? "0px" : height + "px");
        }
        node.style.left = Math.round(left) + "px";
        node.style.top = Math.round(top) + "px";
    }

    function removeActive(reason) {
        if (!active) return;
        var node = active.node;
        var id = active.id;
        active = null;
        clearTimeout(autoTimer);
        autoTimer = null;
        if (reason === "dismiss") markDismissed(id);
        node.classList.add("out");
        setTimeout(function () { if (node.parentNode) node.parentNode.removeChild(node); }, 170);
    }

    function show(id, key, anchor, action, tool) {
        if (!eligible(id) || interfaceBusy()) return false;
        var copy = text()[key];
        if (!copy) return false;

        var node = document.createElement("aside");
        node.className = "ek-context-hint";
        node.setAttribute("role", "status");
        node.setAttribute("aria-live", "polite");
        node.innerHTML =
            '<button class="ek-context-hint-close" type="button" aria-label="' + esc(text().close) + '">×</button>' +
            '<strong class="ek-context-hint-title">' + esc(replaceTool(copy.title, tool)) + '</strong>' +
            '<p class="ek-context-hint-copy">' + esc(replaceTool(copy.copy, tool)) + '</p>' +
            '<div class="ek-context-hint-actions">' +
                '<button class="ek-context-hint-action" type="button">' + esc(copy.action) + '</button>' +
                '<button class="ek-context-hint-secondary" type="button">' + esc(text().later) + '</button>' +
            '</div>';
        document.body.appendChild(node);
        active = { id: id, node: node, anchor: anchor };
        shownThisSession = true;
        place(node, anchor);

        node.querySelector(".ek-context-hint-close").addEventListener("click", function () { removeActive("dismiss"); });
        node.querySelector(".ek-context-hint-secondary").addEventListener("click", function () { removeActive("dismiss"); });
        node.querySelector(".ek-context-hint-action").addEventListener("click", function () {
            removeActive("action");
            markSolved(id);
            setTimeout(function () { try { action(); } catch (e) {} }, 20);
        });
        autoTimer = setTimeout(function () { removeActive("timeout"); }, 12000);
        return true;
    }

    function shell() { return window.EditKitShell || {}; }

    function checkNarrowWorkspace() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function () {
            var select = document.getElementById("toolViewSelect");
            var panes = document.querySelectorAll(".pane:not([hidden])");
            if (!select || select.value !== "all" || panes.length < 2 || window.innerWidth >= 520) return;
            show("narrow-tabs", "narrowTabs", document.getElementById("panelVisibilityBtn"), function () {
                if (shell().setToolView) shell().setToolView("tabs");
            });
        }, 900);
    }

    function wireSplitters() {
        var dragging = false;
        var splitters = [document.getElementById("shellSplitter"), document.getElementById("shellSplitter2")];
        splitters.forEach(function (splitter) {
            if (!splitter) return;
            splitter.addEventListener("mousedown", function (e) { if (e.detail < 2) dragging = true; });
            splitter.addEventListener("dblclick", function () { markSolved("balance-panels"); });
        });
        document.addEventListener("mouseup", function () {
            if (!dragging) return;
            dragging = false;
            setTimeout(function () {
                var body = document.getElementById("shellBody");
                var panes = Array.prototype.slice.call(document.querySelectorAll(".pane:not([hidden]):not(.view-hidden)"));
                if (!body || panes.length < 2) return;
                var base = body.classList.contains("stacked") ? body.clientHeight : body.clientWidth;
                if (!base) return;
                var cramped = panes.some(function (pane) {
                    var rect = pane.getBoundingClientRect();
                    var size = body.classList.contains("stacked") ? rect.height : rect.width;
                    return size / base < .19;
                });
                if (cramped) show("balance-panels", "balance", splitters[0], function () {
                    if (shell().balancePanels) shell().balancePanels();
                });
            }, 180);
        });
    }

    function wirePanelVisibility() {
        var button = document.getElementById("panelVisibilityBtn");
        if (button) button.addEventListener("click", function () {
            setTimeout(function () {
                var popover = document.getElementById("panelVisibilityPopover");
                if (!popover || popover.hidden) return;
                show("reorder-panels", "reorder", popover, function () {
                    if (shell().highlightPaneHeaders) shell().highlightPaneHeaders();
                });
            }, 520);
        });

        ["easeit", "quickit", "alignit"].forEach(function (id) {
            var ids = {
                easeit: ["easeitToggle", "menuEaseItToggle", "EaseIt"],
                quickit: ["quickitToggle", "menuQuickItToggle", "QuickIt"],
                alignit: ["alignitToggle", "menuAlignItToggle", "AlignIt"]
            }[id];
            ids.slice(0, 2).forEach(function (controlId) {
                var control = document.getElementById(controlId);
                if (!control) return;
                control.addEventListener("change", function () {
                    if (control.checked) {
                        markSolved("restore-" + id);
                        return;
                    }
                    setTimeout(function () {
                        show("restore-" + id, "restore", document.getElementById("panelVisibilityBtn"), function () {
                            if (shell().setPaneVisible) shell().setPaneVisible(id, true);
                        }, ids[2]);
                    }, 420);
                });
            });
        });
        window.addEventListener("message", function (e) {
            var data = e.data;
            if (data && data.__editkit === "pane" && data.type === "end") markSolved("reorder-panels");
        });
    }

    function quickDocument() {
        var frame = document.getElementById("frameQuickIt");
        try { return frame && frame.contentDocument; } catch (e) { return null; }
    }
    function wireQuickItScroll() {
        var frame = document.getElementById("frameQuickIt");
        if (!frame) return;
        function attach() {
            var doc = quickDocument();
            if (!doc || doc.__editkitContextScroll) return;
            doc.__editkitContextScroll = true;
            doc.addEventListener("wheel", function (e) {
                var input = doc.getElementById("qiLibraryInput");
                var library = doc.getElementById("qiLibrary");
                if (!input || !library || library.offsetParent === null || input.value) return;
                var now = Date.now();
                if (!quickScroll.since || now - quickScroll.since > 12000) quickScroll = { count: 0, distance: 0, since: now };
                quickScroll.count++;
                quickScroll.distance += Math.abs(Number(e.deltaY || 0));
                if (quickScroll.count >= 6 && quickScroll.distance >= 520) {
                    show("quickit-search", "search", frame, function () {
                        if (shell().focusQuickItSearch) shell().focusQuickItSearch();
                    });
                    quickScroll = { count: 0, distance: 0, since: now };
                }
            }, true);
            var input = doc.getElementById("qiLibraryInput");
            if (input) input.addEventListener("focus", function () { markSolved("quickit-search"); });
        }
        frame.addEventListener("load", function () { setTimeout(attach, 250); });
        setTimeout(attach, 600);
    }

    function wireProfileSuggestion() {
        var overlay = document.getElementById("bdOverlay");
        if (!overlay || !window.MutationObserver) return;
        var ignored = {
            settingsSearch: 1, profName: 1, profSafeShare: 1,
            setAboutAutoUpdate: 1, feedbackMessage: 1, feedbackContact: 1
        };
        overlay.addEventListener("change", function (e) {
            var id = e.target && e.target.id;
            if (id && !ignored[id] && id !== "contextHintsToggle") settingsChanged[id] = 1;
        }, true);
        overlay.addEventListener("input", function (e) {
            var id = e.target && e.target.id;
            if (id && !ignored[id] && id !== "settingsSearch") settingsChanged[id] = 1;
        }, true);
        new MutationObserver(function () {
            var open = !overlay.hidden;
            if (settingsWasOpen && !open && Object.keys(settingsChanged).length >= 4) {
                setTimeout(function () {
                    show("save-profile", "profile", document.getElementById("shellSettingsBtn"), function () {
                        if (shell().beginProfileSave) shell().beginProfileSave();
                    });
                }, 420);
            }
            settingsWasOpen = open;
        }).observe(overlay, { attributes: true, attributeFilter: ["hidden"] });
        var save = document.getElementById("profSave");
        if (save) save.addEventListener("click", function () { markSolved("save-profile"); });
    }

    function wireSettings() {
        var toggle = document.getElementById("contextHintsToggle");
        var reset = document.getElementById("contextHintsReset");
        if (toggle) {
            toggle.checked = enabled();
            toggle.addEventListener("change", function () {
                try { localStorage.setItem(ENABLED_KEY, toggle.checked ? "1" : "0"); } catch (e) {}
                if (!toggle.checked) removeActive("disabled");
            });
        }
        if (reset) reset.addEventListener("click", function () {
            try { localStorage.removeItem(STATE_KEY); } catch (e) {}
            shownThisSession = false;
            reset.textContent = text().resetDone;
            reset.classList.add("confirmed");
            setTimeout(function () {
                reset.textContent = text().reset;
                reset.classList.remove("confirmed");
            }, 1800);
        });
        window.addEventListener("editkit:language", function () {
            if (reset && !reset.classList.contains("confirmed")) reset.textContent = text().reset;
        });
        var toolView = document.getElementById("toolViewSelect");
        if (toolView) toolView.addEventListener("change", function () {
            if (toolView.value === "tabs") markSolved("narrow-tabs");
        });
    }

    function boot() {
        wireSettings();
        wireSplitters();
        wirePanelVisibility();
        wireQuickItScroll();
        wireProfileSuggestion();
        window.addEventListener("resize", checkNarrowWorkspace);
        checkNarrowWorkspace();
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
    else boot();

    window.EditKitContextHints = {
        reset: function () {
            try { localStorage.removeItem(STATE_KEY); } catch (e) {}
            shownThisSession = false;
        },
        hide: function () { removeActive("external"); }
    };
}());
