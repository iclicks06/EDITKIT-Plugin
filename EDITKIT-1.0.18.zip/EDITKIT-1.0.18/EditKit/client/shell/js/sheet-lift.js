/* ============================================================================
   EDITKIT — LEVANTAR LOS AJUSTES DE UN PLUGIN POR ENCIMA DE TODO (lado del panel)

   Los ajustes de EaseIt, QuickIt y AlignIt son hojas a pantalla completa dentro
   de su propio <iframe>. "Pantalla completa" para un iframe es el iframe, y no
   el plugin entero: en un panel de 190 px de ancho la hoja salia aplastada,
   con cada frase en cinco lineas, mientras al lado sobraba sitio de sobra.

   Los ajustes de EditKit no tienen ese problema porque los dibuja el shell, que
   es duenno de toda la superficie. Esto le da lo mismo a los tres plugins sin
   mover una sola linea de su hoja: se le pide al shell que estire este iframe
   hasta cubrir el panel entero mientras la hoja este abierta, y se vuelve a lo
   de siempre al cerrarla.

   El detalle que hace que no se note: al estirar el iframe, lo que hay debajo
   de la hoja —la herramienta— tambien se estiraria, y volveria a encogerse al
   cerrar. Dos saltos de maquetacion por cada visita a los ajustes, y en EaseIt
   ademas la curva se queda con el tamano viejo porque el nucleo mide el lienzo
   una sola vez. Asi que la raiz del documento se clava, con posicion y medidas
   en pixeles, en el sitio exacto que ocupaba antes de estirar. El iframe crece;
   la herramienta no se entera.

   Sin shell —el panel abierto suelto— no hay a quien pedirselo y todo sigue
   como estaba: la hoja se abre dentro de su ventana, que es lo unico que hay.
   ============================================================================ */
(function () {
    "use strict";

    var TAG = "lift";

    var PANEL = (function () {
        if (window.EDITKIT_PANEL) return window.EDITKIT_PANEL;
        var p = String(location.pathname || "");
        if (p.indexOf("easeit") >= 0) return "easeit";
        if (p.indexOf("alignit") >= 0) return "alignit";
        if (p.indexOf("quickit") >= 0) return "quickit";
        return "shell";
    })();

    var EMBEDDED = (function () {
        try { return window.parent !== window; } catch (e) { return false; }
    })();

    /* La raiz de cada herramienta. Es lo unico que este archivo sabe de los tres
       paneles, y a proposito: todo lo demas que hay en el documento —la hoja, el
       aviso, el menu— es posicion fija y no le afecta que el iframe cambie de
       tamano. */
    function root() {
        return document.getElementById("wrapper") ||
               document.querySelector(".app") ||
               null;
    }

    var lifted = false;
    var box = null;         // {w, h} de antes de estirar
    var saved = null;       // los estilos que tenia la raiz, para devolverlos
    var atX = 0, atY = 0;   // donde esta el hueco, lo ultimo que dijo el shell

    /* Una caja de menos de esto no es un hueco: es una medida tomada antes de
       que maquetaran el marco. Clavar el contenido a 0x0 lo hace desaparecer,
       asi que mas vale no clavarlo: sin clavar, la herramienta se estira y se
       encoge —feo— pero se ve. */
    var MIN_BOX = 40;

    function sane(w, h) {
        return isFinite(w) && isFinite(h) && w >= MIN_BOX && h >= MIN_BOX;
    }

    function pin(x, y, w, h) {
        atX = x;
        atY = y;
        // La medida del shell manda sobre la propia: la de el es de fuera y no
        // depende de que este marco ya tenga tamano.
        if (sane(w, h)) box = { w: w, h: h };
        var el = root();
        if (!el || !box) return;
        if (!saved) {
            saved = {
                position: el.style.position, left: el.style.left, top: el.style.top,
                width: el.style.width, height: el.style.height
            };
        }
        el.style.position = "absolute";
        el.style.left = x + "px";
        el.style.top = y + "px";
        el.style.width = box.w + "px";
        el.style.height = box.h + "px";
    }

    function unpin() {
        var el = root();
        if (el && saved) {
            el.style.position = saved.position;
            el.style.left = saved.left;
            el.style.top = saved.top;
            el.style.width = saved.width;
            el.style.height = saved.height;
        }
        saved = null;
        box = null;
    }

    function send(type) {
        try {
            window.parent.postMessage({ __editkit: TAG, panel: PANEL, type: type }, "*");
        } catch (e) {}
    }

    function on() {
        if (!EMBEDDED || lifted) return;
        /* Las medidas se toman ahora, antes de pedir nada: en cuanto el shell
           estire el iframe, innerWidth ya es el del panel entero y la caja que
           se quiere conservar habria desaparecido.

           Salvo que se este devolviendo el marco justo en este momento y se
           vuelva a pedir antes de que termine —pasa al encadenar dos pantallas,
           como el "indexar" que abre el buscador—. Ahi la ventana todavia mide
           lo estirado y medirla daria una caja que no es la del hueco: la de
           antes, que sigue guardada, es la buena. */
        if (!box) {
            var w = window.innerWidth, h = window.innerHeight;
            // Si la medida propia no vale nada, no se inventa: la buena llega
            // con la respuesta del shell, que mide el hueco desde fuera.
            if (sane(w, h)) box = { w: w, h: h };
        }
        lifted = true;
        /* No se clava nada todavia. Clavar aqui, con el marco aun sin estirar,
           es lo que producia el salto: la primera vez ni siquiera se sabe donde
           esta el hueco y se iba a 0,0. Se pide y se espera: si el shell puede
           clavarlo el —lo normal— llegara ya hecho y sin fotograma de por
           medio; si no puede, llegara la geometria y se clava aqui. */
        send("on");
    }

    function off() {
        if (!EMBEDDED || !lifted) return;
        lifted = false;
        /* Se sigue clavada hasta que el shell confirme que ha encogido el
           iframe. Soltarla antes deja un fotograma con el contenido corrido
           hacia la izquierda, que es justo el salto que esto viene a evitar. */
        send("off");
    }

    /* Cuando el shell dice `pinned`, ya ha escrito el estilo el mismo y en el
       mismo bloque en que estiro el marco — que es la unica manera de que no se
       vea el salto; la explicacion larga esta en shell.js. Aqui no hay nada que
       hacer entonces, y hacerlo seria peor: `pin` guardaria como "estilo
       original" el que acaba de escribir el shell, y al soltar lo devolveria
       en lugar de quitarlo.

       Todo lo de abajo se queda igualmente. Es el camino de siempre para
       cuando el marco no se deja tocar por dentro. */
    window.addEventListener("message", function (e) {
        var d = e.data;
        if (!d || d.__editkit !== TAG) return;
        if (d.pinned) {
            // Solo se apunta la geometria, por si luego hace falta medir.
            if (d.type === "geom") { atX = d.x || 0; atY = d.y || 0; }
            else if (d.type === "down") { saved = null; box = null; }
            return;
        }
        if (d.type === "geom" && lifted) pin(d.x || 0, d.y || 0, d.w, d.h);
        /* Solo se suelta si de verdad no hay nada levantado. Si entre el "ya
           puedes encoger" y esta respuesta alguien volvio a pedir el marco,
           este mensaje es de la vez anterior y soltar ahora dejaria la
           herramienta sin clavar y estirada a todo lo ancho. */
        else if (d.type === "down" && !lifted) unpin();
    });

    window.EditKitLift = {
        available: EMBEDDED,
        on: on,
        off: off,
        isOn: function () { return lifted; }
    };
})();
