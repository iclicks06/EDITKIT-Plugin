/*
 * EditKit community links.
 *
 * Keep every frequently changing community URL in this file. The settings UI
 * reads these variables at runtime, so no link is duplicated in the markup or
 * in the interaction code.
 */
(function (root) {
  "use strict";

  // Use the public invite, not an internal channel URL. The latter only works
  // for people who already belong to the server.
  var DISCORD_URL = "https://discord.com/invite/9at5ZfsySH";
  var TELEGRAM_URL = "https://t.me/zickhub/7077";

  var links = {
    discord: DISCORD_URL,
    telegram: TELEGRAM_URL
  };

  if (typeof Object.freeze === "function") Object.freeze(links);
  root.EditKitCommunityLinks = links;
}(window));
