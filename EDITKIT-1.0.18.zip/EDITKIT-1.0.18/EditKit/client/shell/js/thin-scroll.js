/* ============================================================================
   EDITKIT — LA BARRA DE DESPLAZAMIENTO FINA

   Los tres paneles llevaban la barra del navegador a cero de ancho, y por una
   razon buena: un panel de CEP cambia de tamano constantemente, y una barra que
   aparece en cuanto el contenido pasa de largo se lleva unos pixeles de ANCHO
   justo a mitad de maquetacion. En un panel corto eso bastaba para empujar una
   fila de botones a una segunda linea. Se podia desplazar con la rueda, pero no
   habia forma de ver que quedaba algo mas abajo.

   Esto lo devuelve sin volver a aquel problema: la barra la dibuja el propio
   panel, encima del contenido y no al lado, asi que no reserva ni un pixel. Es
   fina, no esta cuando no hace falta, aparece al desplazar o al pasar el mouse
   por encima y se va sola al rato. Y se puede arrastrar, que para eso tiene
   forma de deslizador.

   Se marca lo que la lleva con data-ek-scroll; sin marca no pasa nada. La
   propia barra queda fuera de la navegacion por teclado y del lector: lo que
   informa es el contenido, y este es un adorno que se puede arrastrar.
   ============================================================================ */
(function () {
    "use strict";

    var FADE_MS = 900;       // lo que tarda en irse despues del ultimo empujon
    var MIN_THUMB = 22;      // por debajo de esto ya no parece un deslizador

    var CSS =
        '.ek-scroll-host { position: relative; }' +
        '.ek-scroll-rail {' +
        '  position: absolute; top: 0; right: 1px; width: 3px;' +
        '  border-radius: 3px; background: currentColor;' +
        '  opacity: 0; pointer-events: none;' +
        '  transition: opacity .22s ease, width .12s ease;' +
        '  z-index: 5;' +
        '}' +
        '.ek-scroll-rail.on { opacity: .38; pointer-events: auto; }' +
        '.ek-scroll-rail:hover, .ek-scroll-rail.held { opacity: .72; width: 5px; }' +
        '@media (prefers-reduced-motion: reduce) {' +
        '  .ek-scroll-rail { transition: none; }' +
        '}';

    function style() {
        if (document.getElementById("ekScrollCss")) return;
        var el = document.createElement("style");
        el.id = "ekScrollCss";
        el.appendChild(document.createTextNode(CSS));
        (document.head || document.documentElement).appendChild(el);
    }

    function attach(box) {
        if (!box || box.getAttribute("data-ek-scrolled") === "1") return;
        box.setAttribute("data-ek-scrolled", "1");

        /* El carril se cuelga del propio elemento que se desplaza y no de un
           envoltorio: envolver obliga a copiar la maquetacion del original
           —flex, grid, el hueco que ocupa— y cualquier descuido ahi mueve de
           sitio lo que se queria dejar igual. */
        if (!box.classList.contains("ek-scroll-host")) box.classList.add("ek-scroll-host");

        var rail = document.createElement("div");
        rail.className = "ek-scroll-rail";
        rail.setAttribute("aria-hidden", "true");
        box.appendChild(rail);

        var timer = null, held = false, hover = false;

        function show() {
            rail.classList.add("on");
            if (timer) clearTimeout(timer);
            // Mientras se arrastra o el cursor esta encima, no se va: quitarle
            // el asidero a alguien que lo tiene cogido no tiene defensa.
            timer = setTimeout(function () {
                if (!held && !hover) rail.classList.remove("on");
            }, FADE_MS);
        }

        function draw() {
            /* La rejilla de QuickIt se redibuja entera —innerHTML a cero— cada
               vez que cambia un boton, y se lleva el carril por delante. En
               lugar de pedirle a cada panel que avise, se comprueba aqui: es un
               nodo y una comparacion, y funciona con cualquiera que reconstruya
               lo suyo sin saber nada de esto. */
            if (rail.parentNode !== box) box.appendChild(rail);

            var h = box.clientHeight, total = box.scrollHeight;
            // Sin nada que desplazar no hay barra. Y el uno de margen es por el
            // redondeo de los navegadores: un pixel de diferencia no es
            // contenido que sobra.
            if (total <= h + 1) { rail.style.display = "none"; return; }
            rail.style.display = "";

            var track = h - 4;
            var size = Math.max(MIN_THUMB, Math.round(track * h / total));
            var max = track - size;
            var pos = max <= 0 ? 0 : Math.round(max * box.scrollTop / (total - h));
            rail.style.height = size + "px";
            /* El carril cuelga del propio elemento que se desplaza, asi que se
               iria hacia arriba con el contenido. Se le suma lo desplazado para
               que se quede quieto donde se ve: es lo que cuesta no envolver el
               elemento en otro, y sale mas barato que copiar su maquetacion. */
            rail.style.top = (box.scrollTop + 2 + pos) + "px";
        }

        box.addEventListener("scroll", function () { draw(); show(); });
        box.addEventListener("mouseenter", function () { draw(); show(); });

        rail.addEventListener("mouseenter", function () { hover = true; });
        rail.addEventListener("mouseleave", function () { hover = false; show(); });

        // ---- arrastrar el deslizador ----
        var from = 0, fromTop = 0;

        function move(e) {
            var h = box.clientHeight, total = box.scrollHeight;
            var track = h - 4;
            var size = Math.max(MIN_THUMB, Math.round(track * h / total));
            var max = track - size;
            if (max <= 0) return;
            box.scrollTop = fromTop + (e.clientY - from) * (total - h) / max;
        }

        function drop() {
            held = false;
            rail.classList.remove("held");
            document.removeEventListener("mousemove", move, true);
            document.removeEventListener("mouseup", drop, true);
            show();
        }

        rail.addEventListener("mousedown", function (e) {
            e.preventDefault();
            held = true;
            from = e.clientY;
            fromTop = box.scrollTop;
            rail.classList.add("held");
            document.addEventListener("mousemove", move, true);
            document.addEventListener("mouseup", drop, true);
        });

        /* El contenido cambia sin que nadie se desplace: se anade un boton, se
           cambia de idioma y una frase pasa a ocupar dos lineas. El vigilante
           con intervalo no es plan B de ResizeObserver: el Chromium de CEP 9 es
           anterior a el, y donde si existe no dispara mientras el panel no se
           esta dibujando. Medir dos numeros es barato. */
        var ro = null;
        if (window.ResizeObserver) {
            try { ro = new ResizeObserver(draw); ro.observe(box); } catch (e) { ro = null; }
        }

        /* Esta caja puede ser la de una hoja modal, que se crea entera cada vez
           que se abre y se tira entera al cerrarla (EaseIt reconstruye sus
           ajustes y su ayuda de atajos asi, y EDITKIT_SCROLL_EXTRA hace que
           cualquier ".modal" pase por aqui). Sin este vigilante, el intervalo,
           el ResizeObserver y el oyente de EditKitAwake.onWake se quedarian
           corriendo para siempre sobre un nodo que ya nadie ve, y cada
           apertura sumaria uno mas: la bolsa de "modales fantasma" que de
           verdad se nota en la memoria tras una sesion larga. En cuanto la
           caja sale del documento, todo esto se apaga solo. */
        var A = window.EditKitAwake;
        var offWake = (A && A.onWake) ? A.onWake(function () { if (box.isConnected) draw(); }) : null;
        var watchId = setInterval(function () {
            if (!box.isConnected) {
                clearInterval(watchId);
                if (ro) ro.disconnect();
                if (offWake) offWake();
                return;
            }
            if (A && A.idle()) return;
            draw();
        }, 500);

        draw();
    }

    /* ------------------------------------------------------------------
       UN VIGILANTE QUE DUERME CUANDO NO SE LE VE

       Un panel de CEP no se descarga al cambiar de pestana: se queda cargado y
       corriendo detras del que el usuario haya puesto delante. Un intervalo que
       mide y escribe cada medio segundo sigue haciendolo durante horas para
       nadie, y en cuatro documentos a la vez.

       Quien decide si se esta viendo es repaint-guard.js, y lo decide con
       cuidado: hay entornos que dicen "oculto" siempre, y creerselos dejaria a
       este vigilante sin correr nunca. Si no esta cargado, se trabaja como
       siempre.
       ------------------------------------------------------------------ */
    function awake(fn, ms) {
        var A = window.EditKitAwake;
        var id = setInterval(function () {
            if (A && A.idle()) return;
            fn();
        }, ms);
        if (A && A.onWake) A.onWake(fn);   // al volver, una pasada en el acto
        return id;
    }

    /* Lo normal es marcar el elemento en el HTML. EDITKIT_SCROLL_EXTRA existe
       para lo que no se puede marcar: los modales de EaseIt los construye su
       nucleo, que es codigo compilado. Cada panel declara lo suyo antes de
       cargar esto; aqui no hay una lista de selectores de nadie. */
    function scan() {
        var sel = "[data-ek-scroll]";
        if (window.EDITKIT_SCROLL_EXTRA) sel += "," + window.EDITKIT_SCROLL_EXTRA;
        var list;
        try { list = document.querySelectorAll(sel); } catch (e) { return; }
        for (var i = 0; i < list.length; i++) attach(list[i]);
    }

    function boot() {
        style();
        scan();
        // Las hojas de ajustes de EaseIt se construyen al abrirlas, asi que lo
        // que hay que mirar no esta todo en el primer barrido.
        awake(scan, 800);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }

    window.EditKitThinScroll = { scan: scan };
})();
