/* ============================================================================
   EDITKIT — FACTORY PROFILE

   "Basic" is the clean starting point for a new installation. It mirrors the
   author's chosen panel layout and appearance, but deliberately contains no
   presets, scripts, third-party effects, local paths, icons, images or video.
   Keeping the data separate makes that promise easy to test before release.
   ============================================================================ */
(function () {
    "use strict";

    var GRID = [
        { id: "comp.precompose" },
        { id: "comp.extract" },
        { id: "layer.solid" },
        { id: "time.reverse" },
        { id: "time.reverseCopy" },
        { id: "expr.loop" },
        { id: "order.reverse" },
        { id: "layer.adjustment" },
        { id: "layer.parentNull" },
        {},
        { color: "#292929", hover: "#303030", fg: "#b8b8b8", border: "#3a3a3a", sweep: true },
        { color: "#173532", hover: "#1f4541", fg: "#7fded3", border: "#2f6f69", sweep: true,
          bg2: "#2f6f69", bgType: "gradient", gradType: "linear" },
        { id: "time.gotoPrev" },
        { id: "time.bake" },
        { id: "time.gotoNext" },
        { id: "time.easeIn" },
        { id: "time.ease" },
        { id: "time.hold" },
        { id: "time.easeOut" },
        { id: "time.scaleDouble" },
        { id: "time.scaleHalf" },
        { id: "expr.wiggle" },
        { id: "expr.inertia" },
        { id: "quick.stackHorizontal" },
        { id: "order.selection" },
        { id: "order.name" },
        { id: "order.random" },
        { id: "order.inPoint" },
        { id: "order.outPoint" },
        {},
        { id: "comp.precomposeAll" },
        { id: "layer.shape" },
        { id: "layer.camera" },
        { id: "comp.deepClone", fresh: true },
        { id: "comp.f916", fresh: true },
        { id: "comp.f11", fresh: true },
        { id: "comp.f169", fresh: true },
        { id: "comp.f45", fresh: true },
        { id: "comp.organizeProject", fresh: true, w: 3, h: 1 },
        { id: "time.capturePasteFit", fresh: true, w: 1, h: 1 },
        { id: "time.pasteFit", fresh: true, w: 1, h: 1 }
    ];

    var STYLES = [
        { bg: "#173532", hover: "#1f4541", fg: "#7fded3", border: "#2f6f69", bg2: "#2f6f69", bgType: "gradient", gradType: "linear", sweep: true, nativeId: "teal" },
        { bg: "#382b16", hover: "#48381d", fg: "#f0c77f", border: "#79592a", bg2: "#806333", bgType: "gradient", gradType: "linear", gradAngle: 122, sweep: true, nativeId: "amber" },
        { bg: "#3a1d1b", hover: "#4b2623", fg: "#f19a90", border: "#7c3b35", nativeId: "coral" },
        { bg: "#292929", hover: "#303030", fg: "#b8b8b8", border: "#3a3a3a", bg2: "#303030", bgType: "gradient", gradType: "radial", gradAngle: 116, sweep: true },
        { bg: "#0d0e0e", hover: "#161818", fg: "#989a9a", border: "#292b2b", effect: "soft3d", nativeId: "soft3d" }
    ];

    var BACKDROP = {
        mode: "color", preset: "graphite", intensity: 45, reactivity: 100, softness: 0,
        scrim: 0, grain: 15, fps: 30, color: "#0d0d0d", image: "",
        imageFit: "cover", blur: 40, opacity: 64
    };

    var ALIGN_SETTINGS = {
        padding: 0,
        stackSpacing: 10,
        createUndo: true,
        animateFeedback: true,
        defaultMode: "align",
        defaultTarget: "comp",
        rememberLastMode: false,
        showToasts: false,
        toastDuration: 2000,
        accentTheme: "editkit",
        customAccentColor: "#14ffe8",
        defaultPanelSize: "auto",
        density: "normal",
        reticleMax: "330",
        showShortcutBadges: false,
        showTextLabels: true,
        shortcutsEnabled: true,
        sectionOrder: ["align", "tools", "quick", "status"],
        sectionVisibility: { align: true, tools: true, quick: true, status: true }
    };

    window.EditKitFactoryProfile = {
        id: "builtin-basic",
        name: "Basic",
        builtin: true,
        keys: {
            easeit_accent: "#ffffff",
            easeit_preset_size: "30",
            easeit_collections: JSON.stringify({
                active: "default",
                items: [{ id: "default", name: "My Presets" }],
                libs: { "default": [] }
            }),
            editkit_backdrop: JSON.stringify(BACKDROP),
            editkit_easeit_hide_presets: "1",
            editkit_easeit_hide_status: "1",
            editkit_easeit_presets_place: "bottom",
            editkit_easeit_presets_title: "0",
            editkit_easeit_section_hidden: JSON.stringify({ previewSection: false }),
            editkit_layout_mode: "horizontal",
            editkit_tool_view: "smart",
            editkit_pane_order: JSON.stringify(["easeit", "alignit", "quickit"]),
            editkit_qi_cat: "expr",
            editkit_qi_grid: JSON.stringify(GRID),
            editkit_qi_grid_ver: "9",
            editkit_qi_styles: JSON.stringify(STYLES),
            editkit_qi_view: "btns",
            editkit_quickit_w: "172",
            editkit_split_h: "0.3826086956521739",
            editkit_surfaces: JSON.stringify({ surface: "#262626", ease: "#232323", align: "#232323" }),
            alignAnchorLastLayout: "compact",
            alignAnchorSettings: JSON.stringify(ALIGN_SETTINGS)
        }
    };
})();
