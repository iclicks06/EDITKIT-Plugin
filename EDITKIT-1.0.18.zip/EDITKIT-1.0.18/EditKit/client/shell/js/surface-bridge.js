/* ============================================================================
   EDITKIT — SHARED SURFACES

   The three tools live in separate iframe documents, so CSS variables do not
   cross their boundaries. This bridge keeps one neutral surface colour for the
   whole plugin, derives the related panel/button/border tones, and relays the
   result to every pane. EaseIt and AlignIt also get their own work-area colour.

   Everything is stored under one editkit_* key so profiles and the persistent
   settings backup include it automatically.
   ============================================================================ */
(function () {
    "use strict";

    var KEY = "editkit_surfaces";
    var TAG = "surfaces";
    var DEFAULTS = { surface: "#292929", ease: "#232323", align: "#232323" };
    var isShell = (window.parent === window);
    var current = null;
    var painters = [];

    function normalize(hex, fallback) {
        var h = String(hex || "").replace(/^\s+|\s+$/g, "").replace(/^#/, "");
        if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
        return /^[0-9a-f]{6}$/i.test(h) ? "#" + h.toLowerCase() : fallback;
    }

    function clean(value) {
        value = value || {};
        return {
            surface: normalize(value.surface, DEFAULTS.surface),
            ease: normalize(value.ease, DEFAULTS.ease),
            align: normalize(value.align, DEFAULTS.align)
        };
    }

    function same(a, b) {
        return !!a && !!b && a.surface === b.surface && a.ease === b.ease && a.align === b.align;
    }

    function rgb(hex) {
        return {
            r: parseInt(hex.substr(1, 2), 16),
            g: parseInt(hex.substr(3, 2), 16),
            b: parseInt(hex.substr(5, 2), 16)
        };
    }

    function byte(n) {
        n = Math.max(0, Math.min(255, Math.round(n)));
        var h = n.toString(16);
        return h.length === 1 ? "0" + h : h;
    }

    /* Keep `amount` of the first colour and fill the rest with the second.
       This replaces CSS color-mix(), which is unavailable in CEP Chromium. */
    function mix(a, b, amount) {
        var x = rgb(a), y = rgb(b);
        return "#" + byte(x.r * amount + y.r * (1 - amount)) +
                     byte(x.g * amount + y.g * (1 - amount)) +
                     byte(x.b * amount + y.b * (1 - amount));
    }

    function luminance(hex) {
        var c = rgb(hex);
        return c.r * 0.299 + c.g * 0.587 + c.b * 0.114;
    }

    function palette(base) {
        var light = luminance(base) > 155;
        return {
            bg: mix(base, "#000000", 0.72),
            dark: mix(base, "#000000", 0.63),
            panel: mix(base, "#000000", 0.86),
            surface: base,
            surface2: mix(base, "#ffffff", 0.965),
            border: mix(base, "#ffffff", 0.94),
            strong: mix(base, "#ffffff", 0.86),
            text: light ? "#202020" : "#d7d7d7",
            bright: light ? "#080808" : "#f3f3f3",
            dim: light ? "#505050" : "#9d9d9d",
            faint: light ? "#707070" : "#6e6e6e"
        };
    }

    function read() {
        try { return clean(JSON.parse(localStorage.getItem(KEY) || "{}")); }
        catch (e) { return clean(DEFAULTS); }
    }

    function write(value) {
        try { localStorage.setItem(KEY, JSON.stringify(value)); } catch (e) {}
    }

    function applyVariables(value) {
        var p = palette(value.surface);
        var s = document.documentElement.style;
        s.setProperty("--ek-bg", p.bg);
        s.setProperty("--ek-bg-dark", p.dark);
        s.setProperty("--ek-panel", p.panel);
        s.setProperty("--ek-surface", p.surface);
        s.setProperty("--ek-surface-2", p.surface2);
        s.setProperty("--ek-border", p.border);
        s.setProperty("--ek-border-strong", p.strong);
        s.setProperty("--ek-footer-glass", rgba(p.dark, 0.52));
        s.setProperty("--ek-ease-workspace", value.ease);
        s.setProperty("--ek-align-workspace", value.align);

        /* Names used by the individual tools. Inline custom properties win
           over the host-colour probe that EaseIt runs during boot. */
        s.setProperty("--bg", p.bg);
        s.setProperty("--bg-dark", p.dark);
        s.setProperty("--panel", p.panel);
        s.setProperty("--card", p.panel);
        s.setProperty("--raised", p.surface);
        s.setProperty("--surface", p.surface);
        s.setProperty("--surface-2", p.surface2);
        s.setProperty("--border", p.border);
        s.setProperty("--border-hover", p.strong);
        s.setProperty("--border-strong", p.strong);
        s.setProperty("--text", p.text);
        s.setProperty("--text-bright", p.bright);
        s.setProperty("--text-dim", p.dim);
        s.setProperty("--text-faint", p.faint);

        /* The shell and all three headers deliberately keep their original
           neutral chrome. Surface customisation starts below those bars. */
    }

    function rgba(hex, alpha) {
        var c = rgb(hex);
        return "rgba(" + c.r + "," + c.g + "," + c.b + "," + alpha + ")";
    }

    function paint(value) {
        applyVariables(value);
        for (var i = 0; i < painters.length; i++) {
            try { painters[i](value); } catch (e) {}
        }
    }

    function relay(value, exceptWindow) {
        var msg = { __editkit: TAG, value: value };
        if (isShell) {
            var frames = document.querySelectorAll("iframe");
            for (var i = 0; i < frames.length; i++) {
                var target = null;
                try { target = frames[i].contentWindow; } catch (e) { continue; }
                if (!target || target === exceptWindow) continue;
                try { target.postMessage(msg, "*"); } catch (e2) {}
            }
        } else if (exceptWindow !== window.parent) {
            try { window.parent.postMessage(msg, "*"); } catch (e3) {}
        }
    }

    function set(next, opts) {
        next = clean(next);
        opts = opts || {};
        if (same(current, next) && !opts.force) return;
        current = next;
        write(current);
        paint(current);
        relay(current, opts.from || null);
    }

    window.addEventListener("message", function (event) {
        var data = event.data;
        if (!data || data.__editkit !== TAG) return;
        if (data.request) {
            if (isShell && event.source) {
                try { event.source.postMessage({ __editkit: TAG, value: current }, "*"); } catch (e) {}
            }
            return;
        }
        set(data.value, { from: event.source });
    });

    current = read();
    paint(current);

    var DICT = {
        es: {
            section: "Superficies",
            intro: "Cambia el gris base del plugin; los tonos de botones, tarjetas, hover y bordes se calculan automáticamente.",
            surface: "Botones y fondos de los paneles",
            surfaceNote: "Se aplica a EaseIt, QuickIt, AlignIt y a sus controles; no modifica las cabeceras.",
            ease: "Recuadro de EaseIt",
            easeNote: "Fondo del editor de curvas.",
            align: "Recuadro de AlignIt",
            alignNote: "Fondo del visor de alineación.",
            reset: "Restablecer color general"
        },
        en: {
            section: "Surfaces",
            intro: "Change the plugin's base grey; button, card, hover, and border tones are generated automatically.",
            surface: "Panel buttons and backgrounds",
            surfaceNote: "Applies to EaseIt, QuickIt, AlignIt, and their controls; headers are not changed.",
            ease: "EaseIt work area",
            easeNote: "Background of the curve editor.",
            align: "AlignIt work area",
            alignNote: "Background of the alignment viewfinder.",
            reset: "Reset general colour"
        }
    };
    var lang = "es";
    try { lang = localStorage.getItem("editkit_lang") || "es"; } catch (e4) {}
    if (!DICT[lang]) lang = "es";

    function text(id, key) {
        var el = document.getElementById(id);
        if (el) el.textContent = DICT[lang][key];
    }

    function syncControls() {
        var surface = document.getElementById("surfaceColorInput");
        var ease = document.getElementById("easeSurfaceInput");
        var align = document.getElementById("alignSurfaceInput");
        if (surface) surface.value = current.surface;
        if (ease) ease.value = current.ease;
        if (align) align.value = current.align;
    }

    function applyLanguage(next) {
        lang = DICT[next] ? next : "es";
        text("setSectionSurfaces", "section");
        text("setSurfacesIntro", "intro");
        text("setSurfaceLabel", "surface");
        text("setSurfaceNote", "surfaceNote");
        text("setEaseSurfaceLabel", "ease");
        text("setEaseSurfaceNote", "easeNote");
        text("setAlignSurfaceLabel", "align");
        text("setAlignSurfaceNote", "alignNote");
        text("surfaceReset", "reset");
    }

    function bindShellControls() {
        if (!isShell) return;
        var ids = {
            surfaceColorInput: "surface",
            easeSurfaceInput: "ease",
            alignSurfaceInput: "align"
        };
        for (var id in ids) {
            if (!ids.hasOwnProperty(id)) continue;
            (function (el, field) {
                if (!el) return;
                el.addEventListener("input", function () {
                    var next = clean(current);
                    next[field] = normalize(el.value, DEFAULTS[field]);
                    set(next);
                });
            })(document.getElementById(id), ids[id]);
        }
        var reset = document.getElementById("surfaceReset");
        if (reset) reset.addEventListener("click", function () {
            var next = clean(current);
            next.surface = DEFAULTS.surface;
            set(next, { force: true });
        });
        syncControls();
        applyLanguage(lang);
    }

    window.EditKitSurfaces = {
        get: function () { return clean(current); },
        set: set,
        reset: function () { set(DEFAULTS, { force: true }); },
        setLanguage: applyLanguage,
        onChange: function (fn) {
            if (typeof fn !== "function") return;
            painters.push(fn);
            try { fn(clean(current)); } catch (e) {}
        }
    };

    bindShellControls();

    if (!isShell) {
        function askHub() {
            try { window.parent.postMessage({ __editkit: TAG, request: true }, "*"); } catch (e) {}
        }
        askHub();
        window.addEventListener("load", function () { paint(current); askHub(); });
    }
})();
