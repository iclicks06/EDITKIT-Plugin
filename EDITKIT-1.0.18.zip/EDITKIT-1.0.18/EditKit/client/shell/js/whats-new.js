/* ============================================================================
   EDITKIT — NOVEDADES DE LA VERSION

   Un recorrido breve, independiente de la bienvenida. Ya no interrumpe el
   arranque: un aviso pequeno permanece junto al boton Donar hasta que el
   usuario abre las novedades o lo descarta. El recorrido sigue disponible
   siempre desde el menu nativo y termina con el inventario completo.
   ============================================================================ */
(function () {
    "use strict";

    var VERSION = "1.0.18";
    var SEEN_KEY = "editkit_whats_new_" + VERSION.replace(/\./g, "_");
    var overlay = null, notice = null, step = 0, screen = "tour", lastFocus = null;

    var T = {
        es: {
            eyebrow: "NOVEDADES · VERSIÓN " + VERSION,
            title: "Nuevas funciones de EDITKIT",
            lead: "La 1.0.18 incorpora EaseCopy, nuevos flujos de QuickIt y una interfaz más útil sin ocupar más espacio.",
            notice: "Nuevas funciones",
            noticeOpen: "Ver novedades",
            noticeDismiss: "Cerrar aviso",
            progress: "%n de %total",
            back: "Atrás", next: "Siguiente", finish: "Finalizar", close: "Cerrar",
            exit: "Ver después", viewList: "Ver lista completa", listTitle: "Todas las funciones nuevas",
            listLead: "Resumen en formato de texto, organizado por herramienta.",
            tour: [
                { plugin: "EaseIt", title: "EaseCopy: copia la curva o el valor", points: [
                    "Captura los keyframes una sola vez y decide después qué parte pegar.",
                    "Pegar Curva conserva los valores del destino y adapta la velocidad a la nueva propiedad.",
                    "Pegar Valor conserva el easing; Continuidad iguala la entrada y salida de keyframes intermedios."
                ]},
                { plugin: "QuickIt", title: "Más tareas completas en menos pasos", points: [
                    "Nueva capa de texto nativa, centrada y lista para editar con un clic.",
                    "Pegar y ajustar captura animaciones y las adapta a la duración de las capas seleccionadas.",
                    "El flujo de Audio prepara clips y recupera el resultado procesado sin desarmar la edición.",
                    "La búsqueda reúne efectos y presets; Parallax automático deja visibles sus controles."
                ]},
                { plugin: "EDITKIT", title: "Una interfaz que se adapta al espacio", points: [
                    "Los paneles pueden mostrarse, ocultarse y reordenarse; los controles estrechos conservan lo importante.",
                    "QuickIt alterna entre abreviaturas e iconos, con abreviaturas como modo predeterminado.",
                    "Las pistas contextuales detectan problemas concretos y pueden resolverlos con un clic."
                ]},
                { plugin: "EDITKIT · Instalación", title: "Instalación más predecible y verificable", points: [
                    "Windows prepara PlayerDebugMode para Adobe CEP 10 a 13 sin activar el modo desarrollador del sistema.",
                    "macOS incluye un instalador experimental; ambos son texto legible y no descargan componentes.",
                    "La instalación conserva ajustes y restaura la copia anterior si ocurre un error."
                ]}
            ],
            summary: [
                { plugin: "EaseIt", items: [
                    "EaseCopy: captura keyframes y pega solo su easing o solo sus valores.",
                    "Modo Continuidad para velocidades de entrada y salida en keyframes intermedios.",
                    "Aplicación manual de curvas como opción, sin perder el comportamiento de un toque en vista compacta."
                ]},
                { plugin: "QuickIt", items: [
                    "Nueva capa de texto centrada; con Control se recorta a la duración de la selección.",
                    "Pegar y ajustar animaciones a la duración de las capas seleccionadas.",
                    "Flujo de audio para preparar clips e importar el resultado procesado.",
                    "Buscador de efectos y presets, reindexado y creación de botones.",
                    "Parallax automático con sus propiedades de control visibles al terminar.",
                    "Botones en modo abreviatura o icono; abreviaturas de forma predeterminada."
                ]},
                { plugin: "AlignIt", items: [
                    "Distribución más compacta y adaptable a paneles estrechos.",
                    "Controles visibles y ordenables desde el selector de paneles de EDITKIT."
                ]},
                { plugin: "EDITKIT", items: [
                    "Paneles visibles, ocultables y reordenables desde una sola vista.",
                    "Pistas contextuales con soluciones de un clic cuando existe una corrección segura.",
                    "Búsqueda dentro de Ajustes y mejoras de rendimiento y distribución responsiva.",
                    "Aviso discreto de novedades en lugar de una ventana automática.",
                    "Configuración automática y limitada de PlayerDebugMode para Adobe CEP 10 a 13 en Windows.",
                    "Instalador automático experimental para macOS, incluido Apple Silicon.",
                    "Instalaciones transaccionales con restauración ante errores.",
                    "Guía manual conservada como alternativa.",
                    "Documento de seguridad, hashes y nomenclatura de paquetes unificada."
                ]}
            ]
        },
        en: {
            eyebrow: "WHAT'S NEW · VERSION " + VERSION,
            title: "New EDITKIT features",
            lead: "Version 1.0.18 adds EaseCopy, new QuickIt workflows, and a more useful interface without taking extra space.",
            notice: "New features",
            noticeOpen: "View what's new",
            noticeDismiss: "Dismiss notice",
            progress: "%n of %total",
            back: "Back", next: "Next", finish: "Finish", close: "Close",
            exit: "View later", viewList: "View full list", listTitle: "All new features",
            listLead: "A text summary organised by tool.",
            tour: [
                { plugin: "EaseIt", title: "EaseCopy: copy the curve or the value", points: [
                    "Capture the keyframes once, then choose which part to paste.",
                    "Paste Ease keeps destination values and scales velocity for the new property.",
                    "Paste Value keeps easing; Pass-through matches incoming and outgoing velocity on intermediate keys."
                ]},
                { plugin: "QuickIt", title: "Complete more jobs in fewer steps", points: [
                    "Create a native, centred text layer ready to edit with one click.",
                    "Paste & Fit captures animations and adapts them to the selected layer durations.",
                    "The Audio workflow prepares clips and brings back the processed result without dismantling the edit.",
                    "Search combines effects and presets; Automatic Parallax leaves its controls visible."
                ]},
                { plugin: "EDITKIT", title: "An interface that adapts to the available space", points: [
                    "Panels can be shown, hidden, and reordered; narrow layouts keep essential controls accessible.",
                    "QuickIt can switch between abbreviations and icons, with abbreviations as the default.",
                    "Contextual hints detect concrete problems and can fix them with one click."
                ]},
                { plugin: "EDITKIT · Installation", title: "More predictable and verifiable installation", points: [
                    "Windows prepares PlayerDebugMode for Adobe CEP 10 through 13 without enabling system Developer Mode.",
                    "macOS includes an experimental installer; both are readable text and download no components.",
                    "Installation preserves user data and restores the previous copy if an error occurs."
                ]}
            ],
            summary: [
                { plugin: "EaseIt", items: [
                    "EaseCopy captures keyframes and pastes only their easing or only their values.",
                    "Pass-through mode for matching incoming and outgoing velocity on intermediate keys.",
                    "Optional manual curve application while compact view keeps its one-tap behaviour."
                ]},
                { plugin: "QuickIt", items: [
                    "New centred text layer; hold Control to trim it to the selection's duration.",
                    "Paste & Fit animations to the duration of selected layers.",
                    "Audio workflow to prepare clips and import the processed result.",
                    "Effects and presets search, reindexing, and button creation.",
                    "Automatic Parallax with its control properties visible when finished.",
                    "Buttons can use abbreviations or icons; abbreviations remain the default."
                ]},
                { plugin: "AlignIt", items: [
                    "A more compact layout that adapts to narrow panels.",
                    "Visibility and order controls in EDITKIT's panel selector."
                ]},
                { plugin: "EDITKIT", items: [
                    "Panels can be shown, hidden, and reordered from one view.",
                    "Contextual hints with one-click fixes when a safe correction is available.",
                    "Settings search plus performance and responsive-layout improvements.",
                    "A discreet what's-new notice instead of an automatic full window.",
                    "Automatic, limited PlayerDebugMode setup for Adobe CEP 10 through 13 on Windows.",
                    "Experimental automatic macOS installer, including Apple Silicon.",
                    "Transactional installation with rollback on failure.",
                    "Manual installation guide retained as a fallback.",
                    "Security document, hashes, and unified package naming."
                ]}
            ]
        }
    };

    function lang() {
        var value = "es";
        try { value = localStorage.getItem("editkit_lang") || "es"; } catch (e) {}
        return T[value] ? value : "es";
    }
    function text() { return T[lang()]; }
    function esc(value) {
        return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;")
            .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }
    function accent() {
        try { if (window.EditKitAccent && window.EditKitAccent.get) return window.EditKitAccent.get(); } catch (e) {}
        return "#49c9bd";
    }
    function inkOn(hex) {
        var h = String(hex || "").replace("#", "");
        if (h.length === 3) h = h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
        var r = parseInt(h.substr(0,2),16), g = parseInt(h.substr(2,2),16), b = parseInt(h.substr(4,2),16);
        return h.length === 6 && isFinite(r) && isFinite(g) && isFinite(b) && (r*.299+g*.587+b*.114) <= 150 ? "#fff" : "#0e1413";
    }
    function points(items) {
        var out = "<ul class=\"ek-new-points\">";
        for (var i = 0; i < items.length; i++) out += "<li>" + esc(items[i]) + "</li>";
        return out + "</ul>";
    }
    function summaryMarkup(t) {
        var out = '<div class="ek-new-summary" data-ek-scroll>';
        for (var i = 0; i < t.summary.length; i++) {
            out += '<section class="ek-new-summary-group"><h3>' + esc(t.summary[i].plugin) + '</h3>' + points(t.summary[i].items) + '</section>';
        }
        return out + "</div>";
    }
    function markup() {
        return '<section class="ek-new-card" role="dialog" aria-modal="true" aria-labelledby="ekNewTitle">' +
            '<div class="ek-new-eyebrow"></div><h2 class="ek-new-title" id="ekNewTitle"></h2>' +
            '<p class="ek-new-lead"></p><div class="ek-new-content"></div>' +
            '<div class="ek-new-actions"><button class="ek-new-exit" type="button"></button><span></span>' +
            '<button class="ek-new-back" type="button"></button><button class="ek-new-next" type="button"></button></div></section>';
    }
    function paint() {
        if (!overlay) return;
        var t = text(), content = overlay.querySelector(".ek-new-content");
        overlay.querySelector(".ek-new-eyebrow").textContent = t.eyebrow;
        var title = overlay.querySelector(".ek-new-title"), lead = overlay.querySelector(".ek-new-lead");
        var back = overlay.querySelector(".ek-new-back"), next = overlay.querySelector(".ek-new-next"), exit = overlay.querySelector(".ek-new-exit");
        if (screen === "tour") {
            var item = t.tour[step];
            title.textContent = item.title;
            lead.textContent = t.progress.replace("%n", String(step + 1)).replace("%total", String(t.tour.length)) + " · " + item.plugin;
            content.innerHTML = points(item.points);
            back.hidden = false; back.disabled = step === 0; back.textContent = t.back;
            next.textContent = step === t.tour.length - 1 ? t.finish : t.next;
            exit.textContent = t.exit;
        } else if (screen === "finish") {
            title.textContent = t.title;
            lead.textContent = t.lead;
            content.innerHTML = '<div class="ek-new-finish-mark" aria-hidden="true">✓</div>';
            back.hidden = true;
            next.textContent = t.viewList;
            exit.textContent = t.close;
        } else {
            title.textContent = t.listTitle;
            lead.textContent = t.listLead;
            content.innerHTML = summaryMarkup(t);
            back.hidden = false; back.disabled = false; back.textContent = t.back;
            next.textContent = t.close;
            exit.textContent = t.close;
        }
    }
    function close() {
        if (!overlay) return;
        var node = overlay;
        overlay = null;
        document.removeEventListener("keydown", onKey, true);
        node.classList.add("out");
        setTimeout(function () { if (node.parentNode) node.parentNode.removeChild(node); }, 160);
        try { if (lastFocus && lastFocus.focus) lastFocus.focus(); } catch (e) {}
    }
    function markSeen() {
        try { localStorage.setItem(SEEN_KEY, "1"); } catch (e) {}
    }
    function removeNotice(mark) {
        if (mark) markSeen();
        if (!notice) return;
        var node = notice;
        notice = null;
        node.classList.add("out");
        setTimeout(function () { if (node.parentNode) node.parentNode.removeChild(node); }, 140);
    }
    function paintNotice() {
        if (!notice) return;
        var t = text();
        notice.querySelector(".ek-new-notice-copy").textContent = t.notice;
        notice.querySelector(".ek-new-notice-open").setAttribute("aria-label", t.noticeOpen);
        notice.querySelector(".ek-new-notice-close").setAttribute("aria-label", t.noticeDismiss);
        notice.querySelector(".ek-new-notice-close").setAttribute("title", t.noticeDismiss);
    }
    function showNotice() {
        if (notice || overlay) return;
        notice = document.createElement("div");
        notice.className = "ek-new-notice";
        notice.innerHTML = '<button class="ek-new-notice-open" type="button"><span class="ek-new-notice-dot" aria-hidden="true"></span><span class="ek-new-notice-copy"></span></button>' +
            '<button class="ek-new-notice-close" type="button" aria-label="">×</button>';
        var target = document.querySelector(".shell-left") || document.body;
        target.appendChild(notice);
        notice.querySelector(".ek-new-notice-open").addEventListener("click", open);
        notice.querySelector(".ek-new-notice-close").addEventListener("click", function () { removeNotice(true); });
        paintNotice();
    }
    function next() {
        var total = text().tour.length;
        if (screen === "list") { close(); return; }
        if (screen === "finish") { screen = "list"; paint(); return; }
        if (step < total - 1) step++;
        else screen = "finish";
        paint();
    }
    function back() {
        if (screen === "list") { screen = "finish"; paint(); return; }
        if (screen === "finish") { screen = "tour"; step = Math.max(0, text().tour.length - 1); paint(); return; }
        if (step > 0) { step--; paint(); }
    }
    function onKey(e) {
        if (!overlay) return;
        if (e.key === "Escape") { e.preventDefault(); close(); }
        else if (e.key === "ArrowLeft") { e.preventDefault(); back(); }
        else if (e.key === "ArrowRight" || e.key === "Enter") { e.preventDefault(); next(); }
        else if (e.key === "Tab") {
            var buttons = overlay.querySelectorAll("button:not([hidden]):not([disabled])");
            if (!buttons.length) return;
            var first = buttons[0], last = buttons[buttons.length - 1];
            if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
            else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
        }
    }
    function open() {
        removeNotice(true);
        if (overlay) return;
        try { if (window.EditKitTip) window.EditKitTip.hide(); } catch (e) {}
        markSeen();
        lastFocus = document.activeElement;
        step = 0; screen = "tour";
        overlay = document.createElement("div");
        overlay.className = "ek-new";
        overlay.style.setProperty("--ek-new-ink", inkOn(accent()));
        overlay.innerHTML = markup();
        document.body.appendChild(overlay);
        overlay.querySelector(".ek-new-next").addEventListener("click", next);
        overlay.querySelector(".ek-new-back").addEventListener("click", back);
        overlay.querySelector(".ek-new-exit").addEventListener("click", close);
        document.addEventListener("keydown", onKey, true);
        paint();
        try { overlay.querySelector(".ek-new-next").focus(); } catch (e3) {}
    }
    function setLanguage() { if (overlay) paint(); if (notice) paintNotice(); }

    window.EditKitWhatsNew = { open: open, setLanguage: setLanguage };

    /* Los usuarios nuevos reciben primero la bienvenida normal. Las novedades
       aparecen una sola vez únicamente si EDITKIT ya había sido utilizado. */
    var welcomed = false, seen = false;
    try {
        welcomed = localStorage.getItem("editkit_welcomed") === "1";
        seen = localStorage.getItem(SEEN_KEY) === "1";
    } catch (e4) { seen = true; }
    if (welcomed && !seen) setTimeout(function waitForWelcome() {
        if (document.querySelector(".ek-welcome, .ek-tour")) { setTimeout(waitForWelcome, 600); return; }
        showNotice();
    }, 750);
}());
