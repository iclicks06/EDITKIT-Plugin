/* ============================================================================
   EDITKIT — COPIA DE LOS AJUSTES EN DOCUMENTOS
   (el primer script del shell y de las tres ventanas)

   POR QUE EXISTE

   Todo lo que el panel guarda —presets, colecciones, perfiles, colores,
   botones, la bitacora— vive en el almacenamiento del navegador que CEP lleva
   dentro. Y CEP pone ese almacenamiento en una carpeta TEMPORAL de Windows:

       AppData\Local\Temp\cep_cache\AEFT_<version>_com.zick.editkit.panel

   Esa carpeta la vacian la limpieza de archivos temporales de Windows, los
   programas de limpieza, y a veces el propio programa. Cuando pasa, el
   navegador encuentra la base de datos a medias, crea una nueva vacia y borra
   la vieja. El 13 de septiembre de 2026 le paso a todos los paneles de un
   After Effects a la vez, este incluido: al abrirlo, EditKit estaba como recien
   instalado.

   No se puede evitar desde aqui. Lo que si se puede es no depender solo de
   eso: cada vez que algo cambia, se guarda una copia de todo en

       Documentos\EditKit\ajustes.json

   junto a la bitacora y los perfiles, y al arrancar, si el almacenamiento llega
   vacio, se recupera de ahi.

   COMO SABE QUE HAY ALGO QUE RECUPERAR

   Con una marca: `editkit_persist`. Se pone la primera vez que este archivo
   corre, y solo desaparece si desaparece todo el almacenamiento. En cada
   arranque también se comparan las claves con la copia del disco: se recuperan
   únicamente las que falten y nunca se pisa un valor que ya exista. Esto cubre
   tanto una pérdida total como una pérdida parcial después de una actualización.

   QUIEN ESCRIBE

   Solo la ventana de arriba, el shell. Las otras tres cambian el mismo
   almacenamiento, y el navegador le avisa al shell con el evento `storage`
   cada vez que lo hacen. Una sola ventana escribiendo es un solo archivo
   coherente, no cuatro compitiendo por el mismo.

   Se escribe un segundo y medio despues del ultimo cambio —arrastrar un
   deslizador no son cien escrituras— y otra vez al cerrar el panel, por si
   quedaba algo pendiente. Primero a un archivo aparte y luego se renombra: un
   corte de luz a mitad no deja un ajustes.json roto. La version anterior se
   queda como ajustes.anterior.json, y se usa si la principal no se puede leer.

   LO QUE NUNCA HACE

   Copiar un almacenamiento vacio encima de la copia. Si el almacenamiento se
   vacia con el panel abierto, la marca desaparece con el, y en vez de guardar
   se recupera. Y si hay una copia que existe pero no se puede leer, no se
   escribe nada en toda la sesion: puede ser lo unico que quede.

   Fuera de CEP (en un navegador, para revisar la interfaz) no hay disco y esto
   no hace nada.
   ============================================================================ */
(function () {
    "use strict";

    var MARK = "editkit_persist";
    var NAME = "ajustes.json";
    var DELAY = 1500;

    var store;
    try { store = window.localStorage; if (!store) return; } catch (e) { return; }

    /* ---------------------------------------------------------------------
       El disco: la capa de archivos de CEP, y si no esta, la de Node
       --------------------------------------------------------------------- */
    function cepFs() {
        try { if (window.cep && window.cep.fs && window.cep.fs.readFile) return window.cep.fs; } catch (e) {}
        try { if (window.top.cep && window.top.cep.fs && window.top.cep.fs.readFile) return window.top.cep.fs; } catch (e2) {}
        return null;
    }
    function nodeFs() {
        try { if (window.cep_node && window.cep_node.require) return window.cep_node.require("fs"); } catch (e) {}
        return null;
    }

    var disk = (function () {
        var c = cepFs();
        if (c) {
            return {
                read: function (p) { var r = c.readFile(p); return (r && r.err === 0) ? r.data : null; },
                exists: function (p) { var r = c.stat(p); return !!(r && r.err === 0); },
                write: function (p, s) { var r = c.writeFile(p, s); return !!(r && r.err === 0); },
                rename: function (a, b) { var r = c.rename(a, b); return !!(r && r.err === 0); },
                remove: function (p) { try { c.deleteFile(p); } catch (e) {} },
                mkdir: function (p) { try { c.makedir(p); } catch (e) {} }
            };
        }
        var n = nodeFs();
        if (n) {
            return {
                read: function (p) { try { return n.readFileSync(p, "utf8"); } catch (e) { return null; } },
                exists: function (p) { try { return n.existsSync(p); } catch (e) { return false; } },
                write: function (p, s) { try { n.writeFileSync(p, s, "utf8"); return true; } catch (e) { return false; } },
                rename: function (a, b) { try { n.renameSync(a, b); return true; } catch (e) { return false; } },
                remove: function (p) { try { n.unlinkSync(p); } catch (e) {} },
                mkdir: function (p) { try { n.mkdirSync(p); } catch (e) {} }
            };
        }
        return null;
    })();

    function folder() {
        var bridge = null;
        try { bridge = window.__adobe_cep__ || window.top.__adobe_cep__; } catch (e) {}
        if (!bridge || !bridge.getSystemPath) return "";
        var p = "";
        try { p = decodeURI(bridge.getSystemPath("myDocuments")) || ""; } catch (e2) { return ""; }
        // Lo mismo que hace CSInterface.getSystemPath, que aun no esta cargado.
        p = /^Win/i.test(navigator.platform) ? p.replace("file:///", "") : p.replace("file://", "");
        return p ? p + "/EditKit" : "";
    }

    var DIR = disk ? folder() : "";
    if (!DIR) {
        window.EditKitPersist = { active: false, restored: 0 };
        return;
    }
    var FILE = DIR + "/" + NAME, TEMP = FILE + ".tmp", PREV = DIR + "/ajustes.anterior.json";

    /* ---------------------------------------------------------------------
       Leer una copia
       --------------------------------------------------------------------- */
    /* Tres respuestas y no dos: no hay copia (null), hay una y se lee (sus
       datos), o hay una y NO se lee (ROTA). La tercera importa: una copia que
       existe y no se entiende no se pisa nunca, porque puede ser lo unico que
       queda de los ajustes de alguien. */
    var ROTA = {};
    function readCopy(path) {
        if (!disk.exists(path)) return null;
        var raw = disk.read(path), saved = null;
        try { saved = raw ? JSON.parse(raw) : null; } catch (e) { saved = null; }
        return (saved && saved.data && typeof saved.data === "object") ? saved.data : ROTA;
    }
    function usable(d) { return d !== null && d !== ROTA; }

    var blocked = false;     // hay una copia que no se pudo leer: no se escribe encima
    var mainOk = false;      // ajustes.json se leyo bien, asi que se puede guardar como anterior

    /* ---------------------------------------------------------------------
       Recuperar: al arrancar sin marca, o si el almacenamiento se vacia con el
       panel abierto
       --------------------------------------------------------------------- */
    function restore() {
        var main = readCopy(FILE), prev = readCopy(PREV);
        mainOk = usable(main);
        var data = mainOk ? main : (usable(prev) ? prev : null);
        // La principal rota y sin anterior que la sustituya: no se toca nada.
        if (main === ROTA && !data) { blocked = true; return 0; }

        var n = 0;
        if (data) {
            for (var k in data) {
                if (!data.hasOwnProperty(k) || k === MARK) continue;
                if (store.getItem(k) !== null) continue;          // lo escrito manda
                try { store.setItem(k, String(data[k])); n++; } catch (eQ) { break; }  // cupo lleno
            }
        }
        store.setItem(MARK, "1");
        if (n && window.console && console.log) {
            console.log("[EditKit] " + n + " ajustes recuperados de " + (mainOk ? FILE : PREV));
        }
        return n;
    }

    var restored = 0;
    try {
        /* Restaurar siempre es deliberado: restore() solo completa claves
           ausentes, así que una elección actual nunca se sobrescribe. Antes se
           hacía únicamente cuando faltaba MARK y una pérdida parcial —por
           ejemplo solo las opciones de QuickIt— quedaba sin reparar. */
        restored = restore();
    } catch (eR) {}

    window.EditKitPersist = { active: true, restored: restored, file: FILE };

    /* ---------------------------------------------------------------------
       Guardar: solo el shell
       --------------------------------------------------------------------- */
    var isTop = false;
    try { isTop = (window.top === window); } catch (eT) { isTop = false; }
    if (!isTop) return;

    var timer = null, last = null;

    function snapshot() {
        var names = [], data = {}, i, key;
        for (i = 0; i < store.length; i++) {
            key = store.key(i);
            if (key && key !== MARK) names.push(key);
        }
        // En orden, para que el mismo contenido de siempre el mismo texto y
        // se pueda saber sin escribir si algo cambio.
        names.sort();
        for (i = 0; i < names.length; i++) data[names[i]] = store.getItem(names[i]);
        return data;
    }

    function save() {
        timer = null;
        if (blocked) return;
        try {
            /* Sin marca, el almacenamiento se vacio con el panel abierto. Guardar
               ahora seria copiar el vacio encima de lo bueno —y es justo lo que
               esto existe para evitar—, asi que se recupera en su lugar. */
            if (store.getItem(MARK) === null) { restore(); return; }

            var body = JSON.stringify(snapshot());
            if (body === last) return;
            disk.mkdir(DIR);
            var text = '{"app":"EditKit","version":1,"saved":' + JSON.stringify(new Date().toISOString()) +
                       ',"data":' + body + "}";
            if (!disk.write(TEMP, text)) return;
            // La que habia pasa a ser la anterior, si se podia leer; si no, se
            // quita y la anterior buena se queda donde esta.
            if (mainOk) { disk.remove(PREV); disk.rename(FILE, PREV); }
            else disk.remove(FILE);
            if (!disk.rename(TEMP, FILE)) {
                // Sin renombrar no se pierde nada: se escribe directo.
                disk.write(FILE, text);
                disk.remove(TEMP);
            }
            mainOk = true;
            last = body;
        } catch (e) {}
    }

    function later() {
        if (timer) clearTimeout(timer);
        timer = setTimeout(save, DELAY);
    }

    // Lo que cambia esta ventana
    var proto = window.Storage && window.Storage.prototype;
    if (proto) {
        ["setItem", "removeItem", "clear"].forEach(function (name) {
            var orig = proto[name];
            if (typeof orig !== "function") return;
            proto[name] = function () {
                var out = orig.apply(this, arguments);
                if (this === store) later();
                return out;
            };
        });
    }
    // Lo que cambian las otras tres
    window.addEventListener("storage", function (ev) {
        if (!ev || ev.storageArea === store || ev.storageArea === undefined) later();
    });
    // Y al cerrar, lo pendiente sin esperar
    function flush() { if (timer) { clearTimeout(timer); save(); } }
    function checkpoint() {
        if (timer) clearTimeout(timer);
        timer = null;
        save();
    }
    window.EditKitPersist.checkpoint = checkpoint;
    window.addEventListener("pagehide", flush);
    window.addEventListener("beforeunload", flush);

    // La primera copia, si aun no hay ninguna: quien actualiza con todo en su
    // sitio queda cubierto desde ya, no desde su primer cambio.
    if (!disk.exists(FILE)) later();
})();
