(function () {
  "use strict";

  /* La marca siempre se escribe EDITKIT, incluso en textos que se crean
     despues de cargar la interfaz (avisos, resultados, ajustes e i18n). */
  function branded(value) {
    return String(value == null ? "" : value).replace(/\bEditKit\b/g, "EDITKIT");
  }

  function fixText(node) {
    if (!node || node.nodeType !== 3 || !node.nodeValue) return;
    var parent = node.parentNode;
    if (parent && /^(SCRIPT|STYLE|TEXTAREA)$/i.test(parent.nodeName || "")) return;
    var next = branded(node.nodeValue);
    if (next !== node.nodeValue) node.nodeValue = next;
  }

  function fixElement(el) {
    if (!el || el.nodeType !== 1) return;
    var attrs = ["title", "aria-label", "placeholder", "alt"];
    for (var i = 0; i < attrs.length; i++) {
      var old = el.getAttribute(attrs[i]);
      if (old == null) continue;
      var next = branded(old);
      if (next !== old) el.setAttribute(attrs[i], next);
    }
  }

  function scan(root) {
    if (!root) return;
    if (root.nodeType === 3) { fixText(root); return; }
    if (root.nodeType === 1) fixElement(root);
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, null, false);
    var node;
    while ((node = walker.nextNode())) {
      if (node.nodeType === 3) fixText(node);
      else fixElement(node);
    }
  }

  function start() {
    scan(document.documentElement);
    if (!window.MutationObserver) return;
    new MutationObserver(function (changes) {
      for (var i = 0; i < changes.length; i++) {
        var change = changes[i];
        if (change.type === "characterData") fixText(change.target);
        else if (change.type === "attributes") fixElement(change.target);
        else for (var j = 0; j < change.addedNodes.length; j++) scan(change.addedNodes[j]);
      }
    }).observe(document.documentElement, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: ["title", "aria-label", "placeholder", "alt"]
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
}());
