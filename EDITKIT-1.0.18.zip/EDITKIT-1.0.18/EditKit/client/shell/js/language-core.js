/* EditKit — elección inicial de idioma, sin escribir almacenamiento.

   After Effects manda porque es la interfaz junto a la que vive el panel. Si
   Adobe no informa un idioma compatible, se prueba el del sistema/navegador.
   EditKit ofrece español e inglés; cualquier otro idioma cae a inglés. */
(function (root) {
    "use strict";

    function supported(value) {
        var code = String(value || "").replace(/^\s+|\s+$/g, "").toLowerCase();
        if (/^es(?:[-_]|$)/.test(code)) return "es";
        if (/^en(?:[-_]|$)/.test(code)) return "en";
        return "";
    }

    function detect(hostEnvironment, nav) {
        var env = hostEnvironment || {}, browser = nav || {}, candidates = [
            env.appUILocale,
            env.appLocale
        ];
        if (browser.languages && typeof browser.languages.length === "number") {
            for (var i = 0; i < browser.languages.length; i++) candidates.push(browser.languages[i]);
        }
        candidates.push(browser.language, browser.userLanguage);
        for (var j = 0; j < candidates.length; j++) {
            var found = supported(candidates[j]);
            if (found) return found;
        }
        return "en";
    }

    root.EditKitLanguage = { supported: supported, detect: detect };
})(typeof window !== "undefined" ? window : this);
