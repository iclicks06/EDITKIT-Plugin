/* ============================================================================
   EDITKIT — CONTEXT MENU (loaded by the shell and by both panes)

   Suppresses the browser context menu so a right click inside the panel does
   not offer "Inspect" / "View source" to whoever is using the plugin.

   Text fields are deliberately left alone: the menu there is how people paste
   a licence key, a preset path or a set of bezier values, and taking it away
   costs real usability for no gain — the code is not reachable through an
   <input>'s cut/copy/paste menu anyway.

   Worth being clear about what this is: it raises the bar for a casual right
   click, nothing more. The extension ships as plain files on disk and CEP can
   still attach a remote debugger, so this is not a protection mechanism.
   ============================================================================ */
(function () {
    "use strict";

    function isTextField(node) {
        while (node && node.nodeType === 1) {
            var tag = node.tagName;
            if (tag === "TEXTAREA") return true;
            if (tag === "INPUT") {
                var type = (node.getAttribute("type") || "text").toLowerCase();
                return type === "text" || type === "search" || type === "url" ||
                       type === "tel" || type === "email" || type === "password" ||
                       type === "number";
            }
            if (node.isContentEditable) return true;
            node = node.parentNode;
        }
        return false;
    }

    document.addEventListener("contextmenu", function (e) {
        if (isTextField(e.target)) return;
        e.preventDefault();
    });
})();
