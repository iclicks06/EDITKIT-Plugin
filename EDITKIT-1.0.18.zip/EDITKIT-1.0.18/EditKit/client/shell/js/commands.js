/* ============================================================================
   EDITKIT — REGISTRO DE COMANDOS, PALETA Y ATAJOS

   Treinta funciones no caben en un panel de 320 px sin convertirlo en un cajón
   de sastre. Este archivo es la respuesta: una sola lista de acciones que
   cualquiera de las tres superficies puede alimentar, y tres formas de llegar
   a ellas.

     · La paleta        Ctrl+K, se escriben tres letras y se ejecuta.
     · El atajo         uno por acción, reasignable, con aviso si dos chocan.
     · La fila fija     las seis que se usan de verdad, siempre a la vista.

   Y una cuarta, que no se pide: cuando una acción se ha usado varias veces con
   el ratón, su descripción empieza a enseñar el atajo. El usuario ocasional se
   vuelve rápido sin haber leído nada.

   El mismo archivo se carga en el shell y en los dos paneles. Cada uno registra
   lo suyo y lo anuncia al shell, que hace de central: así la paleta de EaseIt
   encuentra también las acciones de AlignIt y las manda ejecutar donde toca.
   ============================================================================ */
(function () {
    "use strict";

    if (window.EditKitCommands) return;

    var TAG = "cmd";
    var K_SHORTCUTS = "editkit_shortcuts";
    var K_USES = "editkit_cmd_uses";
    var COACH_AT = 4;          // usos con el ratón antes de enseñar el atajo

    // Quién soy. El shell no tiene padre; los paneles se identifican por su URL.
    var PANEL = (function () {
        if (window.EDITKIT_PANEL) return window.EDITKIT_PANEL;
        var p = String(location.pathname || "");
        if (p.indexOf("easeit") >= 0) return "easeit";
        if (p.indexOf("alignit") >= 0) return "alignit";
        if (p.indexOf("quickit") >= 0) return "quickit";
        return "shell";
    })();
    var IS_FRAME = (function () { try { return window.parent !== window; } catch (e) { return false; } })();

    // ------------------------------------------------------------------
    // Almacén
    // ------------------------------------------------------------------
    function readMap(key) {
        try {
            var s = localStorage.getItem(key);
            return s ? (JSON.parse(s) || {}) : {};
        } catch (e) { return {}; }
    }
    function writeMap(key, obj) {
        try { localStorage.setItem(key, JSON.stringify(obj)); } catch (e) {}
    }

    var custom = readMap(K_SHORTCUTS);
    var uses = readMap(K_USES);

    // ------------------------------------------------------------------
    // Combinaciones de teclas
    // ------------------------------------------------------------------
    /* Un atajo es una cadena en minúsculas con los modificadores por orden
       fijo: "ctrl+shift+k". El orden fijo es lo que permite comparar dos
       atajos con un ===, sin normalizar en cada pulsación. */
    function comboOf(e) {
        var k = e.key;
        if (!k) return "";
        if (k === "Control" || k === "Shift" || k === "Alt" || k === "Meta") return "";
        var parts = [];
        if (e.ctrlKey || e.metaKey) parts.push("ctrl");
        if (e.altKey) parts.push("alt");
        if (e.shiftKey) parts.push("shift");
        var name = String(k);
        if (name === " ") name = "space";
        else if (name.length === 1) name = name.toLowerCase();
        parts.push(name);
        return parts.join("+");
    }

    // Cómo se enseña: "Ctrl ⇧ K". Se dibuja, no se lee, así que va corto.
    function comboLabel(combo) {
        if (!combo) return "";
        var out = [], bits = String(combo).split("+");
        for (var i = 0; i < bits.length; i++) {
            var b = bits[i];
            if (b === "ctrl") out.push("Ctrl");
            else if (b === "alt") out.push("Alt");
            else if (b === "shift") out.push("⇧");
            else if (b === "space") out.push("Espacio");
            else if (b === "ArrowLeft") out.push("←");
            else if (b === "ArrowRight") out.push("→");
            else if (b === "ArrowUp") out.push("↑");
            else if (b === "ArrowDown") out.push("↓");
            else out.push(b.length === 1 ? b.toUpperCase() : b);
        }
        return out.join(" ");
    }

    // ------------------------------------------------------------------
    // Registro
    // ------------------------------------------------------------------
    var list = [];
    var byId = {};
    var announceTimer = null;

    function label(cmd) {
        try { return (typeof cmd.label === "function") ? cmd.label() : String(cmd.label || cmd.id); }
        catch (e) { return cmd.id; }
    }
    function groupName(cmd) {
        try { return (typeof cmd.group === "function") ? cmd.group() : String(cmd.group || ""); }
        catch (e) { return ""; }
    }

    function register(cmd) {
        if (!cmd || !cmd.id) return;
        if (byId[cmd.id]) {
            // Volver a registrar el mismo id sustituye: así un panel puede
            // recargarse sin duplicar su lista.
            for (var i = 0; i < list.length; i++) { if (list[i].id === cmd.id) { list.splice(i, 1); break; } }
        }
        byId[cmd.id] = cmd;
        list.push(cmd);
        scheduleAnnounce();
    }

    function shortcutFor(id) {
        if (Object.prototype.hasOwnProperty.call(custom, id)) return custom[id];   // "" = desactivado a mano
        var c = byId[id];
        return (c && c.keys) ? c.keys : "";
    }

    function setShortcut(id, combo) {
        if (!byId[id]) return;
        var def = byId[id].keys || "";
        if (combo === def) { delete custom[id]; }
        else { custom[id] = combo || ""; }
        writeMap(K_SHORTCUTS, custom);
        fire("editkit-shortcuts-changed");
    }

    function resetShortcuts() {
        custom = {};
        writeMap(K_SHORTCUTS, custom);
        fire("editkit-shortcuts-changed");
    }

    // Dos acciones con la misma tecla: devuelve el mapa de conflictos para que
    // el editor pueda pintarlos en rojo en lugar de dejar uno muerto.
    function conflicts() {
        var seen = {}, bad = {};
        for (var i = 0; i < list.length; i++) {
            var c = shortcutFor(list[i].id);
            if (!c) continue;
            if (seen[c]) { bad[c] = true; }
            seen[c] = true;
        }
        return bad;
    }

    function available(cmd) {
        if (!cmd.when) return true;
        try { return !!cmd.when(); } catch (e) { return true; }
    }

    function bump(id) {
        uses[id] = (uses[id] || 0) + 1;
        writeMap(K_USES, uses);
    }

    function run(id, viaMouse) {
        var c = byId[id];
        if (!c) return false;
        if (viaMouse) bump(id);
        try { c.run(); } catch (e) {}
        return true;
    }

    function fire(name) {
        try { document.dispatchEvent(new CustomEvent(name)); } catch (e) {}
    }

    // ------------------------------------------------------------------
    // El panel enseña sus atajos
    // ------------------------------------------------------------------
    /* Se cuenta cada vez que la acción se ejecuta con el ratón. Pasadas unas
       cuantas, la descripción de su botón empieza a llevar el atajo detrás.
       No hay aviso ni tutorial: aparece cuando ya se sabe para qué sirve el
       botón, que es el único momento en el que un atajo se recuerda. */
    function hint(id) {
        var c = shortcutFor(id);
        if (!c) return "";
        if ((uses[id] || 0) < COACH_AT) return "";
        return comboLabel(c);
    }

    function decorate(el, id, baseTitle) {
        if (!el) return;
        var h = hint(id);
        el.title = h ? (baseTitle + "  ·  " + h) : baseTitle;
    }

    // ------------------------------------------------------------------
    // Teclado
    // ------------------------------------------------------------------
    function editable(t) {
        if (!t) return false;
        var tag = t.tagName;
        return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || t.isContentEditable;
    }

    var enabled = true;
    function setEnabled(v) { enabled = !!v; }

    document.addEventListener("keydown", function (e) {
        if (paletteOpen) return;              // la paleta se gobierna sola
        if (recording) return;                // igual el editor de atajos
        var combo = comboOf(e);
        if (!combo) return;

        if (combo === "ctrl+k") { e.preventDefault(); openPalette(); return; }
        if (!enabled) return;
        if (editable(e.target)) return;

        for (var i = 0; i < list.length; i++) {
            if (shortcutFor(list[i].id) !== combo) continue;
            if (!available(list[i])) continue;
            e.preventDefault();
            run(list[i].id, false);
            return;
        }
    });

    // ------------------------------------------------------------------
    // Central entre superficies
    // ------------------------------------------------------------------
    /* Cada panel le cuenta al shell lo que sabe hacer. El shell no ejecuta
       nada: solo guarda las listas y las reparte, para que la paleta de
       cualquiera de los dos encuentre las acciones del otro. Ejecutar una
       ajena es mandar un mensaje; el panel dueño la corre en su propio
       contexto, que es el único que tiene su estado. */
    var foreign = [];        // [{panel, id, label, group}]

    function scheduleAnnounce() {
        if (!IS_FRAME) return;
        if (announceTimer) clearTimeout(announceTimer);
        announceTimer = setTimeout(announce, 120);
    }

    function announce() {
        announceTimer = null;
        var payload = [];
        for (var i = 0; i < list.length; i++) {
            if (list[i].local) continue;      // hay acciones que solo tienen sentido en casa
            payload.push({ id: list[i].id, label: label(list[i]), group: groupName(list[i]) });
        }
        try { window.parent.postMessage({ __editkit: TAG, from: PANEL, announce: payload }, "*"); } catch (e) {}
    }

    var hub = {};   // solo en el shell: panel -> lista

    window.addEventListener("message", function (e) {
        var d = e.data;
        if (!d || d.__editkit !== TAG) return;

        if (d.announce && !IS_FRAME) {
            hub[d.from] = d.announce;
            // Repartir a todos menos al que acaba de hablar.
            var frames = document.querySelectorAll("iframe");
            for (var i = 0; i < frames.length; i++) {
                var w = null;
                try { w = frames[i].contentWindow; } catch (e2) { w = null; }
                if (!w) continue;
                try { w.postMessage({ __editkit: TAG, hub: hub }, "*"); } catch (e3) {}
            }
            return;
        }

        if (d.hub) {
            foreign = [];
            for (var p in d.hub) {
                if (!d.hub.hasOwnProperty(p) || p === PANEL) continue;
                var arr = d.hub[p];
                for (var j = 0; j < arr.length; j++) {
                    foreign.push({ panel: p, id: arr[j].id, label: arr[j].label, group: arr[j].group });
                }
            }
            /* Quien dibuje algo con las acciones ajenas necesita saber cuando
               llegan: hasta este momento no se sabia ni como se llaman. */
            fire("editkit-foreign-changed");
            return;
        }

        if (d.relay && !IS_FRAME) {
            var fr = document.querySelectorAll("iframe");
            for (var k = 0; k < fr.length; k++) {
                var cw = null;
                try { cw = fr[k].contentWindow; } catch (e4) { cw = null; }
                if (!cw) continue;
                try { cw.postMessage({ __editkit: TAG, exec: d.relay.id, to: d.relay.panel }, "*"); } catch (e5) {}
            }
            return;
        }

        if (d.exec && d.to === PANEL) {
            try { window.focus(); } catch (e6) {}
            run(d.exec, true);
        }
    });

    function runForeign(panel, id) {
        try { window.parent.postMessage({ __editkit: TAG, relay: { panel: panel, id: id } }, "*"); } catch (e) {}
    }

    // ------------------------------------------------------------------
    // La paleta
    // ------------------------------------------------------------------
    var paletteOpen = false, root = null, input = null, listEl = null, rows = [], cursor = 0;

    var TXT = {
        es: { ph: "Buscar una acción…", none: "Nada con ese nombre.", other: "en el otro panel", hint: "↑↓ para moverse · Entrar para ejecutar · Esc para cerrar", egg: "Hecho por una persona. Sin cuenta, sin nube y sin fecha de caducidad." },
        en: { ph: "Search an action…", none: "Nothing by that name.", other: "in the other panel", hint: "↑↓ to move · Enter to run · Esc to close", egg: "Made by one person. No account, no cloud, no expiry date." }
    };
    function tx(k) {
        var lang = "es";
        try { lang = localStorage.getItem("editkit_lang") || "es"; } catch (e) {}
        return (TXT[lang] || TXT.es)[k];
    }

    function build() {
        root = document.createElement("div");
        root.className = "ek-palette";
        root.innerHTML =
            '<div class="ek-palette-box" role="dialog" aria-modal="true">' +
            '  <input class="ek-palette-input" type="text" spellcheck="false" autocomplete="off">' +
            '  <div class="ek-palette-list" role="listbox"></div>' +
            '  <div class="ek-palette-foot"></div>' +
            '</div>';
        document.body.appendChild(root);
        input = root.querySelector(".ek-palette-input");
        listEl = root.querySelector(".ek-palette-list");
        root.querySelector(".ek-palette-foot").textContent = tx("hint");

        root.addEventListener("mousedown", function (e) {
            if (e.target === root) closePalette();
        });
        input.addEventListener("input", render);
        input.addEventListener("keydown", onPaletteKey);
    }

    /* Coincidencia por letras sueltas y en orden: escribir "cmb" encuentra
       "Centrar ambos". Es lo que espera cualquiera que haya usado una paleta
       antes, y evita tener que acertar la palabra exacta. */
    function score(text, q) {
        if (!q) return 1;
        var t = text.toLowerCase(), n = q.toLowerCase();
        var direct = t.indexOf(n);
        if (direct === 0) return 1000;
        if (direct > 0) return 500 - direct;
        var ti = 0, hits = 0, gap = 0;
        for (var i = 0; i < n.length; i++) {
            var f = t.indexOf(n.charAt(i), ti);
            if (f < 0) return 0;
            gap += f - ti;
            ti = f + 1;
            hits++;
        }
        return hits ? Math.max(1, 100 - gap) : 0;
    }

    /* Escribir el nombre del propio plugin en su buscador es de las primeras
       cosas que se prueban, y hasta ahora no contestaba nada. Ahora aparece
       una linea de mas, que no ejecuta ninguna accion: solo saluda. */
    var EGG_WORDS = { editkit: 1, gracias: 1, "thank you": 1, zick: 1 };

    function candidates() {
        var out = [], i;
        var q = input ? String(input.value || "").toLowerCase() : "";
        if (EGG_WORDS[q]) {
            out.push({ id: "__egg", panel: null, text: "\u2665", group: "EditKit", keys: "" });
        }
        for (i = 0; i < list.length; i++) {
            if (!available(list[i])) continue;
            out.push({
                id: list[i].id, panel: null,
                text: label(list[i]), group: groupName(list[i]),
                keys: shortcutFor(list[i].id)
            });
        }
        for (i = 0; i < foreign.length; i++) {
            out.push({
                id: foreign[i].id, panel: foreign[i].panel,
                text: foreign[i].label, group: foreign[i].group, keys: ""
            });
        }
        return out;
    }

    function render() {
        var q = input.value, all = candidates(), scored = [], i;
        for (i = 0; i < all.length; i++) {
            var s = score(all[i].text + " " + all[i].group, q);
            if (s > 0) { all[i].s = s; scored.push(all[i]); }
        }
        scored.sort(function (a, b) {
            if (b.s !== a.s) return b.s - a.s;
            return a.text < b.text ? -1 : 1;
        });
        if (scored.length > 40) scored.length = 40;
        rows = scored;
        cursor = 0;

        if (!rows.length) {
            listEl.innerHTML = '<div class="ek-palette-empty">' + tx("none") + "</div>";
            return;
        }
        var html = "";
        for (i = 0; i < rows.length; i++) {
            var r = rows[i];
            html += '<div class="ek-palette-row' + (i === 0 ? " on" : "") + '" data-i="' + i + '" role="option">' +
                    '<span class="ek-palette-name">' + esc(r.text) + "</span>" +
                    (r.group ? '<span class="ek-palette-group">' + esc(r.group) + "</span>" : "") +
                    (r.panel ? '<span class="ek-palette-far">' + tx("other") + "</span>" : "") +
                    (r.keys ? '<span class="ek-palette-keys">' + esc(comboLabel(r.keys)) + "</span>" : "") +
                    "</div>";
        }
        listEl.innerHTML = html;

        var els = listEl.querySelectorAll(".ek-palette-row");
        for (i = 0; i < els.length; i++) {
            els[i].addEventListener("mouseenter", (function (n) {
                return function () { move(n - cursor); };
            })(i));
            els[i].addEventListener("click", (function (n) {
                return function () { cursor = n; accept(); };
            })(i));
        }
    }

    function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    function move(delta) {
        if (!rows.length) return;
        cursor = (cursor + delta + rows.length) % rows.length;
        var els = listEl.querySelectorAll(".ek-palette-row");
        for (var i = 0; i < els.length; i++) els[i].classList.toggle("on", i === cursor);
        if (els[cursor]) { try { els[cursor].scrollIntoView({ block: "nearest" }); } catch (e) {} }
    }

    function accept() {
        var r = rows[cursor];
        if (!r) return;
        if (r.id === "__egg") {
            try { if (window.EditKitLog) window.EditKitLog.found("r8"); } catch (e) {}
            input.value = "";
            listEl.innerHTML = '<div class="ek-palette-empty">' + esc(tx("egg")) + "</div>";
            rows = [];
            return;
        }
        closePalette();
        if (r.panel) runForeign(r.panel, r.id);
        else run(r.id, true);
    }

    function onPaletteKey(e) {
        if (e.key === "Escape") { e.preventDefault(); closePalette(); return; }
        if (e.key === "ArrowDown") { e.preventDefault(); move(1); return; }
        if (e.key === "ArrowUp") { e.preventDefault(); move(-1); return; }
        if (e.key === "Enter") { e.preventDefault(); accept(); return; }
    }

    function openPalette() {
        if (paletteOpen) return;
        if (!root) build();
        paletteOpen = true;
        root.classList.add("on");
        // El idioma se relee al abrir, no al construir: el cuadro se crea una
        // sola vez y sobrevive a todos los cambios de idioma de la sesion.
        input.placeholder = tx("ph");
        root.querySelector(".ek-palette-foot").textContent = tx("hint");
        input.value = "";
        render();
        setTimeout(function () { try { input.focus(); } catch (e) {} }, 0);
    }

    function closePalette() {
        if (!paletteOpen) return;
        paletteOpen = false;
        if (root) root.classList.remove("on");
    }

    // ------------------------------------------------------------------
    // Grabador de atajos, para el editor de ajustes
    // ------------------------------------------------------------------
    var recording = false;

    /* Solo puede haber una grabacion viva a la vez: pedir una segunda cancela
       la primera en vez de sumarse a ella. Eso es lo que hace que abandonar un
       intento —pulsar "grabar" en otro atajo, o simplemente irse del panel sin
       tocar ninguna tecla— no deje un oyente de teclado y un "recording"
       encallado en true para el resto de la sesion: sin el aviso de blur ni el
       cierre de la anterior al abrir una nueva, ese abandono era silencioso y
       apagaba TODOS los atajos globales del plugin hasta reiniciarlo, porque la
       linea 216 los corta entero mientras `recording` siga en true. */
    var active = null;

    function record(onDone) {
        if (active) active.cancel();
        recording = true;
        var self = {};
        function cleanup() {
            if (active === self) active = null;
            recording = false;
            document.removeEventListener("keydown", grab, true);
            window.removeEventListener("blur", onBlur);
        }
        function finish(value) { cleanup(); onDone(value); }
        function onBlur() { finish(null); }
        function grab(e) {
            e.preventDefault();
            e.stopPropagation();
            if (e.key === "Escape") { finish(null); return; }
            if (e.key === "Backspace" || e.key === "Delete") { finish(""); return; }
            var c = comboOf(e);
            if (!c) return;
            finish(c);
        }
        self.cancel = function () { finish(null); };
        document.addEventListener("keydown", grab, true);
        window.addEventListener("blur", onBlur);
        active = self;
        return cleanup;
    }

    window.EditKitCommands = {
        panel: PANEL,
        register: register,
        all: function () { return list.slice(); },
        get: function (id) { return byId[id] || null; },
        label: label,
        group: groupName,
        run: run,
        bump: bump,
        available: available,
        hint: hint,
        decorate: decorate,
        shortcutFor: shortcutFor,
        setShortcut: setShortcut,
        resetShortcuts: resetShortcuts,
        conflicts: conflicts,
        comboLabel: comboLabel,
        record: record,
        setEnabled: setEnabled,
        open: openPalette,
        close: closePalette,
        foreign: function () { return foreign.slice(); },
        runIn: runForeign
    };

    // Al arrancar, pedirle al shell la lista de los demás.
    if (IS_FRAME) {
        setTimeout(announce, 300);
        setTimeout(announce, 1500);
    }
})();
