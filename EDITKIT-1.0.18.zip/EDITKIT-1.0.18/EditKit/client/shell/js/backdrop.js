/* ============================================================================
   EDITKIT — BACKDROP ENGINE

   An animated aura/smoke gradient behind the whole plugin, reacting to the
   pointer and to clicks, plus custom color / image / GIF backdrops.

   Two constraints shaped every decision in here:

   1. This runs *inside* After Effects and Premiere. Anything that burns CPU
      is CPU the host doesn't have for previews and playback. So the aura is
      rendered to a tiny canvas (~240px on the long side) that the compositor
      stretches for free, using pre-rendered sprites instead of per-frame
      gradient objects, on a capped frame budget that drops further when the
      user isn't touching the panel and stops entirely when it's hidden.

   2. The plugin is four documents (this shell + three iframes). The aura is
      drawn once, here, and the three panes go transparent over it. The panes
      forward their pointer events up so the effect stays continuous when the
      cursor crosses into them — without that, the aura would freeze the
      moment you moved over either tool.
   ============================================================================ */
(function () {
    "use strict";

    var STORE_KEY = "editkit_backdrop";
    var TAU = Math.PI * 2;

    // ---------------------------------------------------------------------
    // Presets
    // ---------------------------------------------------------------------
    // Each is a base (the flat ground the smoke sits on) plus the colors the
    // drifting lobes get tinted with. They're all dark on purpose: this sits
    // behind a dense tool UI, so it has to read as atmosphere and never
    // compete with the controls in front of it.
    var PRESETS = [
        { id: "nebula",   name: { es: "Nebulosa", en: "Nebula" },   base: "#070b13", colors: ["#1b4f9e", "#2f83d6", "#0f2c58", "#3aa0e8"] },
        { id: "aurora",   name: { es: "Aurora",   en: "Aurora" },   base: "#061210", colors: ["#1f7a6a", "#49c9bd", "#1d4f7a", "#2fd2a8"] },
        { id: "violet",   name: { es: "Violeta",  en: "Violet" },   base: "#0b0714", colors: ["#5a2a9c", "#9b4fd8", "#2f1466", "#c46ae8"] },
        { id: "ember",    name: { es: "Brasa",    en: "Ember" },    base: "#120705", colors: ["#8c3a12", "#d4682a", "#571d0c", "#f0913f"] },
        { id: "solar",    name: { es: "Solar",    en: "Solar" },    base: "#100e08", colors: ["#8a6b1e", "#d9a83c", "#544010", "#f0c65a"] },
        // Graphite is the neutral one in the row, and it was the least neutral thing
        // in the panel: its lobes ran up to 26 points bluer than red, which is what
        // made "grey" still look blue. Same lightness, no hue.
        { id: "graphite", name: { es: "Grafito",  en: "Graphite" }, base: "#0d0d0d", colors: ["#323232", "#484848", "#222222", "#595959"] }
    ];

    // Two neutral greys, four deliberate tints, two near-blacks. The second slot
    // used to be #1b1c20 — a grey that is five points bluer than it is red. It
    // read as "grey" in the row and then tinted the whole panel blue, which is
    // exactly the complaint the rest of this palette was neutralised for.
    var COLOR_CHIPS = ["#1d1d1d", "#262626", "#0d1117", "#111b18", "#171320", "#1d1512", "#101010", "#0a0a0a"];

    var DEFAULTS = {
        // Ships on a plain solid colour, not the aura: a flat, quiet ground is
        // what a tool panel docked next to a timeline should look like out of
        // the box. The aura is one click away in the Fondo panel for anyone
        // who wants it.
        mode: "color",       // "aura" | "color" | "image"
        preset: "nebula",
        intensity: 70,       // motion amount + lobe brightness
        reactivity: 65,      // how hard the smoke chases the cursor
        softness: 18,        // CSS blur radius over the canvas, px
        scrim: 62,           // veil the panes lay over all of this, 0-100
        grain: 5,            // dither strength, 0-15
        fps: 30,
        color: "#1d1d1d",
        image: "",
        imageFit: "cover",
        blur: 10,
        opacity: 85
    };

    // ---------------------------------------------------------------------
    // i18n
    // ---------------------------------------------------------------------
    var DICT = {
        es: {
            btnTip: "Fondo del panel",
            title: "Ajustes de EditKit",
            tabCustom: "Personalizar",
            tabCommunity: "Comunidad",
            communitySection: "Comunidad",
            communityIntro: "Únete a la comunidad de EditKit para compartir ideas, solicitar mejoras y seguir las novedades.",
            communityDiscordNote: "Comparte ideas y solicitudes de mejora con la comunidad.",
            communityDiscordFixed: "Enlace corregido",
            communityTelegramNote: "Sigue el canal y participa en las conversaciones de EditKit.",
            communitySuggestionNote: "También puedes encontrarnos en",
            aboutSuggestions: "Enviar sugerencias",
            secBackdrop: "Fondo",
            secPanel: "Panel",
            noteLang: "La primera vez se detecta el idioma de After Effects o del sistema. Tu elección manual se recuerda.",
            navHint: "Estas pestañas controlan EditKit completo. El engranaje de EaseIt, QuickIt o AlignIt abre únicamente los ajustes de esa herramienta.",
            tabAbout: "Acerca de",
            aboutVersionLabel: "Versión",
            aboutCheck: "Buscar actualización",
            aboutAuto: "Buscar actualizaciones automáticamente",
            aboutAutoNote: "Solo comprueba la versión una vez al día. No descarga nada hasta que tú lo pidas.",
            aboutPreserve: "Tus configuraciones, perfiles y presets se guardan por separado de los archivos del plugin y no se perderán al actualizar.",
            aboutDocs: "Novedades y descargas:",
            aboutLead: "EDITKIT \u2014 EaseIt + QuickIt + AlignIt",
            aboutWhat: "Tres herramientas en un solo panel: <b>EaseIt</b> para curvas de easing \u2014 bezier, f\u00f3rmulas y presets, con True Handles en Premiere \u2014; <b>QuickIt</b> para el tiempo, las expresiones, el texto y la entrega, con una rejilla de botones de un clic; y <b>AlignIt</b> para alinear, anclar y distribuir capas en After Effects.",
            aboutFree: "Gratis y sin l\u00edmites: no hay licencias, ni versi\u00f3n Pro, ni funciones bloqueadas, ni nada que caduque. Tus presets y preferencias se quedan en tu equipo; la \u00fanica conexi\u00f3n autom\u00e1tica es una consulta diaria de versi\u00f3n, que puedes desactivar.",
            aboutCredit: "Hecho por <b>Zick</b>. Naci\u00f3 como un pu\u00f1ado de herramientas para uso propio; esta versi\u00f3n las junta y las abre a quien las necesite. Soporte: <a class='ek-link' href='#' data-ek-url='https://zickfx.com/help'>zickfx.com/help</a>",
            aboutThird: "Incluye los iconos <b>Material Symbols</b> de Google (licencia Apache 2.0) y la fuente <b>Montserrat</b> (SIL Open Font License 1.1). Sus licencias completas van dentro del plugin, en <i>client/shell/licenses</i>.",
            labelLang: "Idioma",
            hintLang: "Cambia el idioma de todo el plugin.",
            labelToolView: "Modo de visualización",
            hintToolView: "Muestra todo, una herramienta a la vez o cambia automáticamente según el ancho.",
            labelLayout: "Distribución de los paneles",
            hintLayout: "En vertical, arrastra los divisores para decidir cuánto contenido queda visible sin deformarlo.",
            labelEaseIt: "Mostrar EaseIt",
            hintEaseIt: "Las curvas de easing: bezier, fórmulas y presets.",
            labelAlignIt: "Mostrar AlignIt",
            hintAlignIt: "Alinear, anclar, distribuir y transformar capas.",
            labelTips: "Ayuda al pasar el cursor",
            hintTips: "El texto que explica cada botón cuando te detienes encima.",
            labelContextHints: "Pistas contextuales",
            hintContextHints: "Aparecen solo cuando una acción indica que pueden resolver algo. Como máximo se muestra una por sesión.",
            resetContextHints: "Restablecer pistas descartadas",
            labelPerformance: "Modo rendimiento",
            hintPerformance: "Reduce animaciones, desenfoques y actividad visual. No modifica las funciones ni los resultados.",
            tipsOff: "No mostrarla", tipsFast: "Rápida", tipsNormal: "Normal", tipsSlow: "Lenta",
            labelQuickIt: "Mostrar QuickIt",
            hintQuickIt: "El panel del medio: las opciones de la categoría abierta y la rejilla de botones de un clic.",
            close: "Cerrar",
            tabAura: "Aura", tabColor: "Color", tabImage: "Imagen",
            variation: "Variación",
            intensity: "Intensidad",
            reactivity: "Reacción al mouse",
            softness: "Suavizado",
            auraHint: "El aura sigue al cursor y se expande con cada clic, también dentro de los dos paneles.",
            colorLabel: "Color de fondo",
            imageFile: "Elegir archivo…",
            imageClear: "Quitar",
            imagePath: "…o pega una ruta o URL",
            imageNone: "Sin imagen seleccionada.",
            fit: "Ajuste",
            fitCover: "Rellenar", fitContain: "Contener", fitTile: "Mosaico", fitCenter: "Centrar",
            blur: "Desenfoque",
            opacity: "Opacidad",
            gifHint: "Los GIF se animan solos. Desenfocar un GIF cuesta más CPU: si notas tirones, baja el desenfoque a 0.",
            sizeWarn: "Archivo grande — puede no guardarse al reiniciar. Para GIF pesados conviene pegar la ruta en vez de importarlo.",
            loadFail: "No se pudo cargar esa imagen. Revisa que la ruta exista y que el archivo sea una imagen.",
            common: "Para todos los modos",
            veil: "Velo sobre los paneles",
            veilHint: "Cuánto tapan los paneles al fondo. Bájalo para ver más fondo, súbelo si te cuesta leer.",
            grain: "Grano",
            perf: "Fluidez",
            perfHint: "Menos cuadros por segundo = menos CPU para After Effects. Se pausa solo cuando el panel no está visible.",
            reset: "Restablecer todo"
        },
        en: {
            btnTip: "Panel backdrop",
            title: "EditKit Settings",
            tabCustom: "Customise",
            tabCommunity: "Community",
            communitySection: "Community",
            communityIntro: "Join the EditKit community to share ideas, request improvements, and follow the latest news.",
            communityDiscordNote: "Share ideas and improvement requests with the community.",
            communityDiscordFixed: "Link fixed",
            communityTelegramNote: "Follow the channel and join EditKit conversations.",
            communitySuggestionNote: "You can also find us on",
            aboutSuggestions: "Send suggestions",
            secBackdrop: "Backdrop",
            secPanel: "Panel",
            noteLang: "On first launch, the language is detected from After Effects or your system. Your manual choice is remembered.",
            navHint: "These tabs control EditKit as a whole. The EaseIt, QuickIt, or AlignIt gear opens settings for that tool only.",
            tabAbout: "About",
            aboutVersionLabel: "Version",
            aboutCheck: "Check for updates",
            aboutAuto: "Check for updates automatically",
            aboutAutoNote: "Only checks the version once a day. Nothing is downloaded until you ask.",
            aboutPreserve: "Your settings, profiles, and presets are stored separately from the plugin files and will not be lost when you update.",
            aboutDocs: "News and downloads:",
            aboutLead: "EDITKIT \u2014 EaseIt + QuickIt + AlignIt",
            aboutWhat: "Three tools in one panel: <b>EaseIt</b> for easing curves \u2014 bezier, formulas and presets, with True Handles in Premiere \u2014; <b>QuickIt</b> for timing, expressions, text and delivery, with a grid of one-click buttons; and <b>AlignIt</b> for aligning, anchoring and distributing layers in After Effects.",
            aboutFree: "Free and unlimited: no licences, no Pro edition, no locked features, nothing that expires. Your presets and preferences stay on your machine; the only automatic connection is a daily version check, which you can disable.",
            aboutCredit: "Made by <b>Zick</b>. It started as a handful of tools for personal use; this version puts them together and opens them up to anyone who needs them. Support: <a class='ek-link' href='#' data-ek-url='https://zickfx.com/help'>zickfx.com/help</a>",
            aboutThird: "Includes Google's <b>Material Symbols</b> icons (Apache License 2.0) and the <b>Montserrat</b> typeface (SIL Open Font License 1.1). Their full licences ship inside the plugin, in <i>client/shell/licenses</i>.",
            labelLang: "Language",
            hintLang: "Changes the language of the whole plugin.",
            labelToolView: "Display mode",
            hintToolView: "Show everything, one tool at a time, or switch automatically based on width.",
            labelLayout: "Panel arrangement",
            hintLayout: "Vertically, drag the dividers to choose how much content remains visible without distorting it.",
            labelEaseIt: "Show EaseIt",
            hintEaseIt: "The easing curves: bezier, formulas and presets.",
            labelAlignIt: "Show AlignIt",
            hintAlignIt: "Align, anchor, distribute and transform layers.",
            labelTips: "Hover help",
            hintTips: "The text that explains each button when you rest on it.",
            labelContextHints: "Contextual hints",
            hintContextHints: "They appear only when an action suggests they can solve something. At most one is shown per session.",
            resetContextHints: "Reset dismissed hints",
            labelPerformance: "Performance mode",
            hintPerformance: "Reduces animations, blur and visual activity. It does not change features or results.",
            tipsOff: "Do not show it", tipsFast: "Fast", tipsNormal: "Normal", tipsSlow: "Slow",
            labelQuickIt: "Show QuickIt",
            hintQuickIt: "The middle panel: the open category's options and the grid of one-click buttons.",
            close: "Close",
            tabAura: "Aura", tabColor: "Color", tabImage: "Image",
            variation: "Variation",
            intensity: "Intensity",
            reactivity: "Mouse reaction",
            softness: "Softness",
            auraHint: "The aura follows your cursor and blooms on every click, inside both tools too.",
            colorLabel: "Background color",
            imageFile: "Choose file…",
            imageClear: "Remove",
            imagePath: "…or paste a path or URL",
            imageNone: "No image selected.",
            fit: "Fit",
            fitCover: "Cover", fitContain: "Contain", fitTile: "Tile", fitCenter: "Center",
            blur: "Blur",
            opacity: "Opacity",
            gifHint: "GIFs animate on their own. Blurring a GIF costs more CPU: if it stutters, drop blur to 0.",
            sizeWarn: "Large file — it may not survive a restart. For heavy GIFs, paste the path instead of importing.",
            loadFail: "That image couldn't be loaded. Check the path exists and that the file is an image.",
            common: "All modes",
            veil: "Veil over panels",
            veilHint: "How much the panels cover the backdrop. Lower it to show more, raise it if text gets hard to read.",
            grain: "Grain",
            perf: "Smoothness",
            perfHint: "Fewer frames per second means more CPU left for After Effects. It pauses on its own when the panel isn't visible.",
            reset: "Reset everything"
        }
    };

    // Same key the shell and the three panes already share, read directly rather
    // than waiting to be told: this file runs after shell.js has already
    // applied the language once.
    var lang = "es";
    try { lang = localStorage.getItem("editkit_lang") || "es"; } catch (e) {}
    if (!DICT[lang]) lang = "es";

    function t(k) { return (DICT[lang] && DICT[lang][k]) || DICT.es[k] || k; }

    // ---------------------------------------------------------------------
    // State
    // ---------------------------------------------------------------------
    var state = {};
    for (var k in DEFAULTS) if (DEFAULTS.hasOwnProperty(k)) state[k] = DEFAULTS[k];

    function loadState() {
        var raw = null;
        try { raw = localStorage.getItem(STORE_KEY); } catch (e) {}
        if (!raw) return;
        var saved;
        try { saved = JSON.parse(raw); } catch (e) { return; }
        if (!saved || typeof saved !== "object") return;
        for (var key in DEFAULTS) {
            if (!DEFAULTS.hasOwnProperty(key)) continue;
            if (typeof saved[key] === typeof DEFAULTS[key]) state[key] = saved[key];
        }
        if (!presetById(state.preset)) state.preset = DEFAULTS.preset;
        if (["aura", "color", "image"].indexOf(state.mode) < 0) state.mode = DEFAULTS.mode;
    }

    var saveTimer = null;
    function saveState() {
        if (saveTimer) clearTimeout(saveTimer);
        saveTimer = setTimeout(function () {
            saveTimer = null;
            try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); }
            catch (e) { /* quota — most likely a big data-URL image; nothing to do */ }
        }, 300);
    }

    function presetById(id) {
        for (var i = 0; i < PRESETS.length; i++) if (PRESETS[i].id === id) return PRESETS[i];
        return null;
    }
    function activePreset() { return presetById(state.preset) || PRESETS[0]; }

    // ---------------------------------------------------------------------
    // Small helpers
    // ---------------------------------------------------------------------
    function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

    function hexToRgb(hex) {
        var h = String(hex).replace("#", "");
        if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
        var n = parseInt(h, 16);
        if (!isFinite(n)) return { r: 0, g: 0, b: 0 };
        return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
    }
    function rgba(hex, a) {
        var c = hexToRgb(hex);
        return "rgba(" + c.r + "," + c.g + "," + c.b + "," + a + ")";
    }

    // Turn what the user typed into something CSS can actually fetch.
    //   - already a URL (data:, http:, file:)        -> untouched
    //   - absolute disk path (C:\a b\x.png, /home/…) -> file:// URL, encoded
    //   - anything else                              -> untouched, so the
    //     browser resolves it against the document like any relative src
    // That last case matters: prefixing a relative path with "/" would produce
    // file:///icons/x.png, which resolves to the drive root and never loads.
    function toCssUrl(src) {
        if (!src) return "";
        var s = String(src).trim();
        if (/^(data:|https?:|file:)/i.test(s)) return s;

        var isWinAbs = /^[A-Za-z]:[\\/]/.test(s);
        var isUnc = /^\\\\/.test(s);
        var isPosixAbs = /^\//.test(s);
        if (!isWinAbs && !isUnc && !isPosixAbs) return encodeURI(s.replace(/\\/g, "/"));

        var p = s.replace(/\\/g, "/");
        if (isUnc) return "file:" + encodeURI(p);      // \\server\share -> file://server/share
        if (!isPosixAbs) p = "/" + p;                  // C:/… -> /C:/…
        return "file://" + encodeURI(p);
    }

    // ---------------------------------------------------------------------
    // DOM
    // ---------------------------------------------------------------------
    var root = document.documentElement;
    var elBase = document.getElementById("bdBase");
    var elCanvas = document.getElementById("bdCanvas");
    var elCustom = document.getElementById("bdCustom");
    var elGrain = document.getElementById("bdGrain");
    var ctx = elCanvas ? elCanvas.getContext("2d") : null;

    /* Los tres paneles, no dos. QuickIt llego despues y se quedo fuera de esta
       lista: sin el, no recibia el velo —se quedaba con el .62 de respaldo de
       su hoja mientras los otros dos iban al valor real— y su ventana se veia
       de otro color que las de al lado. Tampoco movia el aura al pasar el
       mouse por encima. */
    var frames = [
        document.getElementById("frameEaseIt"),
        document.getElementById("frameQuickIt"),
        document.getElementById("frameAlignIt")
    ];

    // ---------------------------------------------------------------------
    // Sprites
    // ---------------------------------------------------------------------
    // Each lobe is one pre-rendered soft blob drawn additively, not a fresh
    // createRadialGradient() every frame. Building ~24 gradient objects per
    // frame is the kind of steady allocation churn that shows up as jitter in
    // a host app; drawing 24 cached bitmaps doesn't.
    var SPRITE_SIZE = 96;
    var sprites = [];

    function buildSprites() {
        var colors = activePreset().colors;
        sprites = colors.map(function (color) {
            var c = document.createElement("canvas");
            c.width = c.height = SPRITE_SIZE;
            var g = c.getContext("2d");
            var half = SPRITE_SIZE / 2;
            var grd = g.createRadialGradient(half, half, 0, half, half, half);
            // A deliberately non-linear falloff: a plain linear ramp reads as a
            // billiard ball, this reads as smoke.
            grd.addColorStop(0.00, rgba(color, 0.95));
            grd.addColorStop(0.18, rgba(color, 0.58));
            grd.addColorStop(0.42, rgba(color, 0.24));
            grd.addColorStop(0.70, rgba(color, 0.07));
            grd.addColorStop(1.00, rgba(color, 0));
            g.fillStyle = grd;
            g.fillRect(0, 0, SPRITE_SIZE, SPRITE_SIZE);
            return c;
        });
    }

    // ---------------------------------------------------------------------
    // Blobs
    // ---------------------------------------------------------------------
    // Positions come from a slow Lissajous orbit around a fixed home point
    // rather than from velocity integration. Velocities drift, clump in a
    // corner and need bounce handling; an orbit is bounded by construction and
    // never needs correcting, which matters when this thing may be left
    // running for a whole editing session.
    var blobs = [];

    function buildBlobs() {
        var n = 7;
        blobs = [];
        for (var i = 0; i < n; i++) {
            var lobes = [];
            for (var j = 0; j < 3; j++) {
                lobes.push({
                    ox: (Math.random() - 0.5) * 0.10,
                    oy: (Math.random() - 0.5) * 0.10,
                    f: 0.10 + Math.random() * 0.22,
                    p: Math.random() * TAU,
                    s: 0.55 + Math.random() * 0.5
                });
            }
            blobs.push({
                hx: 0.12 + Math.random() * 0.76,
                hy: 0.10 + Math.random() * 0.80,
                ax: 0.10 + Math.random() * 0.20,
                ay: 0.08 + Math.random() * 0.18,
                fx: 0.045 + Math.random() * 0.075,
                fy: 0.038 + Math.random() * 0.065,
                px: Math.random() * TAU,
                py: Math.random() * TAU,
                r: 0.34 + Math.random() * 0.34,
                alpha: 0.34 + Math.random() * 0.26,
                sprite: i % 4,
                lobes: lobes,
                // live position, filled in by step()
                x: 0.5, y: 0.5
            });
        }
    }

    // ---------------------------------------------------------------------
    // Pointer + clicks
    // ---------------------------------------------------------------------
    // Normalized 0..1 across the whole panel, eased toward the raw position so
    // the smoke lags the cursor slightly instead of snapping to it.
    var ptr = { x: 0.5, y: 0.5, ex: 0.5, ey: 0.5, active: false, lastMove: 0 };
    var ripples = [];
    var RIPPLE_MS = 1100;

    function setPointer(nx, ny) {
        ptr.x = clamp(nx, -0.2, 1.2);
        ptr.y = clamp(ny, -0.2, 1.2);
        ptr.active = true;
        ptr.lastMove = Date.now();
        wake();
    }

    function pulse(nx, ny) {
        ripples.push({ x: clamp(nx, 0, 1), y: clamp(ny, 0, 1), t0: (window.performance ? performance.now() : Date.now()) });
        if (ripples.length > 5) ripples.shift();
        ptr.lastMove = Date.now();
        wake();
    }

    // Local (shell chrome) events. The panes send theirs over postMessage.
    function localMove(e) {
        setPointer(e.clientX / Math.max(1, window.innerWidth), e.clientY / Math.max(1, window.innerHeight));
    }
    window.addEventListener("mousemove", localMove, true);
    window.addEventListener("mousedown", function (e) {
        pulse(e.clientX / Math.max(1, window.innerWidth), e.clientY / Math.max(1, window.innerHeight));
    }, true);
    window.addEventListener("mouseout", function (e) {
        if (!e.relatedTarget) ptr.active = false;
    });

    // Pointer coming out of a pane arrives in that pane's own coordinate
    // space, so it has to be offset by where that iframe sits on screen
    // before it means anything to the canvas.
    window.addEventListener("message", function (e) {
        var d = e.data;
        if (!d || d.__editkit !== "bd") return;

        if (d.type === "ready") { pushToPanes(); return; }

        var frame = null;
        for (var i = 0; i < frames.length; i++) {
            if (frames[i] && frames[i].contentWindow === e.source) { frame = frames[i]; break; }
        }
        if (!frame) return;

        if (d.type === "leave") { ptr.active = false; return; }

        var rect = frame.getBoundingClientRect();
        var gx = (rect.left + d.x) / Math.max(1, window.innerWidth);
        var gy = (rect.top + d.y) / Math.max(1, window.innerHeight);

        if (d.type === "pointer") setPointer(gx, gy);
        else if (d.type === "click") pulse(gx, gy);
    });

    /* The veil exists to keep labels readable over a MOVING gradient. A flat
       colour has nothing to veil, and veiling it would mean the colour the
       user picked is never the colour they actually see — the panes would
       blend their own --bg over it. So solid-colour mode reports no veil, and
       the picked hex renders exactly. Aura and image modes keep the user's
       stored strength. */
    function effectiveScrim() {
        return state.mode === "color" ? 0 : state.scrim / 100;
    }

    function pushToPanes() {
        var msg = { __editkit: "bd-style", scrim: effectiveScrim() };
        for (var i = 0; i < frames.length; i++) {
            var f = frames[i];
            if (!f || !f.contentWindow) continue;
            try { f.contentWindow.postMessage(msg, "*"); } catch (err) {}
        }
    }

    // ---------------------------------------------------------------------
    // Render loop
    // ---------------------------------------------------------------------
    var BUF_LONG = 240;   // longest side of the render buffer, in px
    var bufW = BUF_LONG, bufH = BUF_LONG;
    var raf = null;
    var lastFrame = 0;
    var simTime = 0;
    var reduceMotion = false;
    try { reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) {}

    function resize() {
        if (!elCanvas) return;
        var w = Math.max(1, window.innerWidth + 160);
        var h = Math.max(1, window.innerHeight + 160);
        var scale = BUF_LONG / Math.max(w, h);
        bufW = Math.max(40, Math.round(w * scale));
        bufH = Math.max(40, Math.round(h * scale));
        elCanvas.width = bufW;
        elCanvas.height = bufH;
        draw();
    }

    // Idle throttling: full rate while the cursor is live, a slower drift once
    // it's been still for a few seconds. The animation never stops (a frozen
    // background looks broken), it just costs less.
    function effectiveFps() {
        var base = clamp(state.fps, 10, 60);
        var idle = Date.now() - ptr.lastMove > 4000 && ripples.length === 0;
        return idle ? Math.min(base, 20) : base;
    }

    function step(dt, now) {
        var motion = state.intensity / 100;
        simTime += dt * (0.25 + motion * 0.85);

        // ease the pointer
        var k = 1 - Math.pow(0.0015, dt);
        ptr.ex += (ptr.x - ptr.ex) * k;
        ptr.ey += (ptr.y - ptr.ey) * k;

        // retire finished ripples
        for (var i = ripples.length - 1; i >= 0; i--) {
            if (now - ripples[i].t0 > RIPPLE_MS) ripples.splice(i, 1);
        }

        var react = (state.reactivity / 100) * (ptr.active ? 1 : 0);

        for (var b = 0; b < blobs.length; b++) {
            var o = blobs[b];
            var x = o.hx + o.ax * Math.sin(simTime * o.fx * TAU + o.px);
            var y = o.hy + o.ay * Math.cos(simTime * o.fy * TAU + o.py);

            // pull toward the cursor, strongest when already close to it
            if (react > 0) {
                var dx = ptr.ex - x, dy = ptr.ey - y;
                var pull = react * 0.42 * Math.exp(-(dx * dx + dy * dy) * 5.0);
                x += dx * pull;
                y += dy * pull;
            }

            // and get shoved outward by the expanding ring of each click
            for (var r = 0; r < ripples.length; r++) {
                var rp = ripples[r];
                var age = (now - rp.t0) / RIPPLE_MS;
                if (age < 0 || age > 1) continue;
                var radius = (1 - Math.pow(1 - age, 3)) * 0.85;
                var vx = x - rp.x, vy = y - rp.y;
                var dist = Math.sqrt(vx * vx + vy * vy) || 0.0001;
                var band = Math.exp(-Math.pow((dist - radius) * 4.5, 2));
                // Ramp the shove in over the first ~120ms. The ring starts at
                // radius 0, so without this a blob sitting on the click point
                // is already inside the band on the very first frame and gets
                // displaced by the full 0.20 in one step — which reads as the
                // whole backdrop snapping, not as a wave passing through it.
                var attack = Math.min(1, age / 0.12);
                attack = attack * attack * (3 - 2 * attack);
                var force = band * attack * (1 - age) * 0.20;
                x += (vx / dist) * force;
                y += (vy / dist) * force;
            }

            o.x = x;
            o.y = y;
        }
    }

    function draw() {
        if (!ctx) return;
        var w = bufW, h = bufH;
        var preset = activePreset();
        var unit = Math.min(w, h);

        ctx.globalCompositeOperation = "source-over";
        ctx.globalAlpha = 1;
        ctx.fillStyle = preset.base;
        ctx.fillRect(0, 0, w, h);

        if (!sprites.length) return;

        // Additive blending is what turns overlapping soft blobs into
        // something that reads as light diffusing through smoke rather than
        // as stacked translucent circles.
        ctx.globalCompositeOperation = "lighter";

        var bright = 0.45 + (state.intensity / 100) * 0.75;

        for (var b = 0; b < blobs.length; b++) {
            var o = blobs[b];
            var sprite = sprites[o.sprite % sprites.length];
            for (var l = 0; l < o.lobes.length; l++) {
                var lb = o.lobes[l];
                var wob = Math.sin(simTime * lb.f * TAU + lb.p);
                var lx = (o.x + lb.ox + wob * 0.045) * w;
                var ly = (o.y + lb.oy + Math.cos(simTime * lb.f * TAU + lb.p) * 0.045) * h;
                var rad = o.r * lb.s * unit * (0.86 + wob * 0.14);
                ctx.globalAlpha = clamp(o.alpha * bright * (0.7 + lb.s * 0.3), 0, 1);
                ctx.drawImage(sprite, lx - rad, ly - rad, rad * 2, rad * 2);
            }
        }

        // a soft glow riding the cursor — the most legible part of the
        // interaction, since it tracks 1:1 with what the user is doing
        if (ptr.active && state.reactivity > 0) {
            var gs = sprites[1 % sprites.length];
            var gr = unit * 0.30;
            ctx.globalAlpha = clamp((state.reactivity / 100) * 0.34, 0, 1);
            ctx.drawImage(gs, ptr.ex * w - gr, ptr.ey * h - gr, gr * 2, gr * 2);
        }

        // and the bloom each click leaves behind as its ring travels out
        var nowMs = window.performance ? performance.now() : Date.now();
        for (var i = 0; i < ripples.length; i++) {
            var rp = ripples[i];
            var age = (nowMs - rp.t0) / RIPPLE_MS;
            if (age < 0 || age > 1) continue;
            var rr = ((1 - Math.pow(1 - age, 3)) * 0.85 + 0.06) * unit;
            var sp = sprites[3 % sprites.length];
            ctx.globalAlpha = clamp((1 - age) * 0.5, 0, 1);
            ctx.drawImage(sp, rp.x * w - rr, rp.y * h - rr, rr * 2, rr * 2);
        }

        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = "source-over";
    }

    function loop(now) {
        raf = requestAnimationFrame(loop);
        var interval = 1000 / effectiveFps();
        var elapsed = now - lastFrame;
        if (elapsed < interval - 0.75) return;
        var dt = Math.min(0.12, elapsed / 1000);
        lastFrame = now;
        step(dt, now);
        draw();
    }

    function running() { return raf !== null; }

    function start() {
        var awake = window.EditKitAwake;
        if (running() || state.mode !== "aura" || reduceMotion ||
            (awake && (awake.idle() || awake.performance()))) return;
        lastFrame = window.performance ? performance.now() : 0;
        raf = requestAnimationFrame(loop);
    }
    function stop() {
        if (raf !== null) { cancelAnimationFrame(raf); raf = null; }
    }
    function wake() { if (state.mode === "aura" && !reduceMotion) start(); }

    // Pause whenever the panel isn't on screen. A CEP panel that's been
    // tabbed away or collapsed is still a live document, and an unattended
    // rAF loop there is pure waste of the host's frame budget.
    document.addEventListener("visibilitychange", function () {
        if (document.hidden) stop(); else wake();
    });
    window.addEventListener("editkit-runtimechange", function () {
        var awake = window.EditKitAwake;
        if (awake && (awake.idle() || awake.performance())) {
            stop();
            draw();
        } else {
            wake();
        }
    });
    try {
        var csv = new CSInterface();
        csv.addEventListener("com.adobe.csxs.events.WindowVisibilityChanged", function (ev) {
            var visible = !ev || !ev.data || ev.data === "true" || ev.data === true;
            if (visible) wake(); else stop();
        });
    } catch (e) {}

    window.addEventListener("resize", resize);

    // ---------------------------------------------------------------------
    // Grain tile
    // ---------------------------------------------------------------------
    // Generated once instead of shipped as a binary: it's 64x64 of noise, and
    // building it in code keeps the extension one file lighter.
    function buildGrain() {
        if (!elGrain) return;
        var size = 64;
        var c = document.createElement("canvas");
        c.width = c.height = size;
        var g = c.getContext("2d");
        var img = g.createImageData(size, size);
        for (var i = 0; i < img.data.length; i += 4) {
            var v = 110 + Math.random() * 36;
            img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
            img.data[i + 3] = 255;
        }
        g.putImageData(img, 0, 0);
        try { elGrain.style.backgroundImage = "url(" + c.toDataURL("image/png") + ")"; } catch (e) {}
    }

    // ---------------------------------------------------------------------
    // Applying state to the DOM
    // ---------------------------------------------------------------------
    function applyLayers() {
        var isAura = state.mode === "aura";
        var isImage = state.mode === "image";
        var isColor = state.mode === "color";

        if (elBase) elBase.style.background = isAura ? activePreset().base : "#0c0c0c";
        if (elCustom) elCustom.style.display = isAura ? "none" : "";

        // Opacity is offered as an "all modes" control, so it has to actually
        // do something in all three. On the aura it fades the smoke toward the
        // preset's own base color (which #bdBase is already painted with), so
        // the result is the same backdrop turned down rather than a hole
        // punched through to black.
        if (elCanvas) {
            elCanvas.style.display = isAura ? "" : "none";
            elCanvas.style.opacity = String(state.opacity / 100);
        }

        root.style.setProperty("--bd-soft", state.softness + "px");
        root.style.setProperty("--bd-grain", String(state.grain / 100));

        if (elCustom) {
            if (isColor) {
                elCustom.style.backgroundImage = "none";
                elCustom.style.backgroundColor = state.color;
                elCustom.style.filter = "none";
            } else if (isImage) {
                var url = toCssUrl(state.image);
                elCustom.style.backgroundColor = "transparent";
                elCustom.style.backgroundImage = url ? 'url("' + url.replace(/"/g, '\\"') + '")' : "none";
                elCustom.style.filter = state.blur > 0 ? "blur(" + state.blur + "px)" : "none";
                if (state.imageFit === "tile") {
                    elCustom.style.backgroundSize = "auto";
                    elCustom.style.backgroundRepeat = "repeat";
                } else if (state.imageFit === "center") {
                    elCustom.style.backgroundSize = "auto";
                    elCustom.style.backgroundRepeat = "no-repeat";
                } else {
                    elCustom.style.backgroundSize = state.imageFit; // cover | contain
                    elCustom.style.backgroundRepeat = "no-repeat";
                }
            }
            // Solid colour renders at full strength for the same reason it
            // gets no veil: the point of picking a hex is seeing that hex.
            // Opacity stays a live control for the aura and for images.
            elCustom.style.opacity = isColor ? "1" : String(state.opacity / 100);
        }

        if (isAura) { buildSprites(); wake(); draw(); }
        else stop();

        if (isImage) probeImage();
        pushToPanes();
    }

    // A background-image that 404s (or that the host refuses to read off disk)
    // fails silently — CSS just paints nothing and the user is left staring at
    // a black panel wondering what they did wrong. Load the same URL through an
    // Image() so we can actually say so.
    var probeToken = 0;
    function probeImage() {
        var warn = $("bdLoadWarn");
        if (!warn) return;
        var url = toCssUrl(state.image);
        if (!url) { warn.hidden = true; return; }
        var token = ++probeToken;
        var img = new Image();
        img.onload = function () { if (token === probeToken) warn.hidden = true; };
        img.onerror = function () { if (token === probeToken) warn.hidden = false; };
        img.src = url;
    }

    // ---------------------------------------------------------------------
    // Settings UI
    // ---------------------------------------------------------------------
    var overlay = document.getElementById("bdOverlay");
    var openBtn = document.getElementById("backdropToggle");

    function $(id) { return document.getElementById(id); }

    function openSheet() {
        if (!overlay) return;
        overlay.hidden = false;
        if (openBtn) openBtn.classList.add("active");
        syncUI();
    }
    function closeSheet() {
        if (!overlay) return;
        overlay.hidden = true;
        if (openBtn) openBtn.classList.remove("active");
    }

    if (openBtn) openBtn.addEventListener("click", function (e) { e.stopPropagation(); overlay && overlay.hidden ? openSheet() : closeSheet(); });
    if ($("bdClose")) $("bdClose").addEventListener("click", closeSheet);
    if (overlay) overlay.addEventListener("mousedown", function (e) { if (e.target === overlay) closeSheet(); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeSheet(); });

    // --- preset chips, with a real miniature of each preset as its swatch ---
    // Returns the <canvas> itself rather than a toDataURL() string painted as a
    // CSS background. The old route had two ways to come out blank — a
    // toDataURL that the host webview refuses, and a <span> with no intrinsic
    // size to fall back on, which collapsed to just its 1px border. A canvas
    // element carries its own dimensions and needs no serialisation step.
    function presetSwatch(preset) {
        var W = 90, H = 50;
        var dpr = Math.max(1, Math.min(3, window.devicePixelRatio || 1));
        var c = document.createElement("canvas");
        c.width = Math.round(W * dpr);
        c.height = Math.round(H * dpr);
        var g = c.getContext("2d");
        if (!g) return c;
        g.scale(dpr, dpr);
        g.fillStyle = preset.base;
        g.fillRect(0, 0, W, H);
        g.globalCompositeOperation = "lighter";
        var spots = [[0.24, 0.62, 0.62], [0.62, 0.32, 0.52], [0.82, 0.74, 0.42]];
        for (var i = 0; i < spots.length; i++) {
            var s = spots[i];
            var rad = s[2] * H;
            var grd = g.createRadialGradient(s[0] * W, s[1] * H, 0, s[0] * W, s[1] * H, rad);
            var col = preset.colors[i % preset.colors.length];
            grd.addColorStop(0, rgba(col, 0.85));
            grd.addColorStop(0.45, rgba(col, 0.22));
            grd.addColorStop(1, rgba(col, 0));
            g.fillStyle = grd;
            g.fillRect(0, 0, W, H);
        }
        return c;
    }

    function buildPresetChips() {
        var host = $("bdPresets");
        if (!host) return;
        host.innerHTML = "";
        PRESETS.forEach(function (p) {
            var btn = document.createElement("button");
            btn.type = "button";
            btn.className = "bd-preset" + (p.id === state.preset ? " active" : "");
            btn.setAttribute("data-preset", p.id);

            var sw = presetSwatch(p);
            sw.className = "bd-swatch";

            var label = document.createElement("span");
            label.textContent = p.name[lang] || p.name.es;

            btn.appendChild(sw);
            btn.appendChild(label);
            btn.addEventListener("click", function () {
                state.preset = p.id;
                buildSprites();
                applyLayers();
                saveState();
                syncUI();
            });
            host.appendChild(btn);
        });
    }

    function buildColorChips() {
        var host = $("bdChips");
        if (!host) return;
        host.innerHTML = "";
        COLOR_CHIPS.forEach(function (hex) {
            var btn = document.createElement("button");
            btn.type = "button";
            btn.className = "bd-chip" + (hex.toLowerCase() === String(state.color).toLowerCase() ? " active" : "");
            btn.style.background = hex;
            btn.title = hex;
            btn.addEventListener("click", function () {
                state.color = hex;
                applyLayers(); saveState(); syncUI();
            });
            host.appendChild(btn);
        });
    }

    // --- sliders ---
    function wireRange(inputId, valId, key, suffix, onChange) {
        var input = $(inputId), out = $(valId);
        if (!input) return;
        input.addEventListener("input", function () {
            var v = parseFloat(input.value);
            if (!isFinite(v)) return;
            state[key] = v;
            if (out) out.textContent = v + (suffix || "");
            if (onChange) onChange();
            else applyLayers();
            saveState();
        });
    }

    wireRange("bdIntensity", "bdIntensityVal", "intensity", "%", function () { wake(); });
    wireRange("bdReactivity", "bdReactivityVal", "reactivity", "%", function () { wake(); });
    wireRange("bdSoftness", "bdSoftnessVal", "softness", "px");
    /* SECRETO: SIN VELO. El velo a cero deja los paneles transparentes sobre el
       fondo animado, y eso no es un error: es el aspecto mas bonito que tiene
       el plugin y el mas incomodo para trabajar. Quien llega ahi bajando el
       deslizador hasta el fondo se merece que se le note. */
    wireRange("bdScrim", "bdScrimVal", "scrim", "%", function () {
        pushToPanes();
        if (state.scrim === 0 && state.mode !== "color") {
            try { if (window.EditKitLog) window.EditKitLog.found("p4"); } catch (e) {}
        }
    });
    wireRange("bdGrainRange", "bdGrainVal", "grain", "%");
    wireRange("bdBlur", "bdBlurVal", "blur", "px");
    wireRange("bdOpacity", "bdOpacityVal", "opacity", "%");
    wireRange("bdFps", "bdFpsVal", "fps", " fps", function () { wake(); });

    // --- mode tabs ---
    Array.prototype.forEach.call(document.querySelectorAll(".bd-tab"), function (tab) {
        tab.addEventListener("click", function () {
            state.mode = tab.getAttribute("data-mode");
            applyLayers();
            saveState();
            syncUI();
        });
    });

    // --- color + image inputs ---
    if ($("bdColorInput")) {
        $("bdColorInput").addEventListener("input", function () {
            state.color = $("bdColorInput").value;
            applyLayers(); saveState();
            buildColorChips();
        });
    }

    if ($("bdFit")) {
        $("bdFit").addEventListener("change", function () {
            state.imageFit = $("bdFit").value;
            applyLayers(); saveState();
        });
    }

    if ($("bdPathInput")) {
        $("bdPathInput").addEventListener("change", function () {
            state.image = $("bdPathInput").value.trim();
            applyLayers(); saveState(); syncUI();
        });
    }

    if ($("bdClear")) {
        $("bdClear").addEventListener("click", function () {
            state.image = "";
            applyLayers(); saveState(); syncUI();
        });
    }

    // Two ways in, because neither is reliable everywhere: CEP's own file
    // input is missing or silently inert in some host versions, while
    // ExtendScript's File.openDialog is always there but only exists when we
    // really are inside AE/Premiere. Try the host first, fall back to the
    // browser input.
    var fileInput = $("bdFileInput");

    function readFile(file) {
        if (!file) return;
        var reader = new FileReader();
        reader.onload = function () {
            state.image = String(reader.result || "");
            applyLayers();
            saveState();
            syncUI();
            // ~3.5MB of base64 is around where localStorage starts refusing
            // to keep it between sessions.
            var big = state.image.length > 3500000;
            var warn = $("bdSizeWarn");
            if (warn) warn.hidden = !big;
        };
        reader.readAsDataURL(file);
    }

    if (fileInput) fileInput.addEventListener("change", function () { readFile(fileInput.files && fileInput.files[0]); });

    if ($("bdPick")) {
        $("bdPick").addEventListener("click", function () {
            var handled = false;
            try {
                var cs = new CSInterface();
                if (cs && cs.hostEnvironment) {
                    handled = true;
                    cs.evalScript("editkit_pickBackdropImage()", function (res) {
                        var out = null;
                        try { out = JSON.parse(res); } catch (e) {}
                        if (out && out.success && out.path) {
                            state.image = out.path;
                            applyLayers(); saveState(); syncUI();
                        } else if (!out || (!out.canceled && !out.success)) {
                            // host said no — let the browser input try instead
                            if (fileInput) fileInput.click();
                        }
                    });
                }
            } catch (e) { handled = false; }
            if (!handled && fileInput) fileInput.click();
        });
    }

    if ($("bdReset")) {
        $("bdReset").addEventListener("click", function () {
            for (var key in DEFAULTS) if (DEFAULTS.hasOwnProperty(key)) state[key] = DEFAULTS[key];
            buildSprites();
            applyLayers();
            saveState();
            syncUI();
        });
    }

    // --- keep every control showing the truth ---
    function setRange(id, valId, value, suffix) {
        var input = $(id), out = $(valId);
        if (input) input.value = value;
        if (out) out.textContent = value + (suffix || "");
    }

    function syncUI() {
        Array.prototype.forEach.call(document.querySelectorAll(".bd-tab"), function (tab) {
            tab.classList.toggle("active", tab.getAttribute("data-mode") === state.mode);
        });
        Array.prototype.forEach.call(document.querySelectorAll(".bd-pane"), function (pane) {
            pane.hidden = pane.getAttribute("data-pane") !== state.mode;
        });

        Array.prototype.forEach.call(document.querySelectorAll(".bd-preset"), function (chip) {
            chip.classList.toggle("active", chip.getAttribute("data-preset") === state.preset);
        });

        setRange("bdIntensity", "bdIntensityVal", state.intensity, "%");
        setRange("bdReactivity", "bdReactivityVal", state.reactivity, "%");
        setRange("bdSoftness", "bdSoftnessVal", state.softness, "px");
        setRange("bdScrim", "bdScrimVal", state.scrim, "%");
        setRange("bdGrainRange", "bdGrainVal", state.grain, "%");
        setRange("bdBlur", "bdBlurVal", state.blur, "px");
        setRange("bdOpacity", "bdOpacityVal", state.opacity, "%");
        setRange("bdFps", "bdFpsVal", state.fps, " fps");

        // Frame rate only governs the aura's own render loop — a still image or
        // a flat color has no frames to pace, and a GIF runs on its own clock.
        // Grey it out there rather than leave a slider that does nothing.
        var fpsInput = $("bdFps");
        if (fpsInput) {
            var live = state.mode === "aura";
            fpsInput.disabled = !live;
            if ($("bdLabelFps")) $("bdLabelFps").style.opacity = live ? "" : ".45";
            if ($("bdFpsVal")) $("bdFpsVal").style.opacity = live ? "" : ".45";
        }

        if ($("bdColorInput")) $("bdColorInput").value = /^#[0-9a-f]{6}$/i.test(state.color) ? state.color : "#1d1d1d";
        if ($("bdFit")) $("bdFit").value = state.imageFit;
        if ($("bdPathInput")) $("bdPathInput").value = /^data:/i.test(state.image) ? "" : state.image;

        var prev = $("bdPreview");
        if (prev) {
            var url = toCssUrl(state.image);
            prev.style.backgroundImage = url ? 'url("' + url.replace(/"/g, '\\"') + '")' : "none";
        }
        if ($("bdNoImage")) $("bdNoImage").hidden = !!state.image;
        if ($("bdClear")) $("bdClear").disabled = !state.image;

        applyLanguage();
    }

    function applyLanguage() {
        var map = {
            bdSheetTitle: "title",
            setNavHint: "navHint",
            setTabCustomLabel: "tabCustom", setTabCommunityLabel: "tabCommunity", setTabAboutLabel: "tabAbout",
            setSectionCommunity: "communitySection", setCommunityIntro: "communityIntro",
            communityDiscordNote: "communityDiscordNote", communityDiscordFixedBadge: "communityDiscordFixed",
            communityTelegramNote: "communityTelegramNote",
            setCommunitySuggestionNote: "communitySuggestionNote", setAboutSuggestions: "aboutSuggestions",
            setAboutVersionLabel: "aboutVersionLabel", setAboutDocsLabel: "aboutDocs",
            setAboutCheckUpdate: "aboutCheck",
            setAboutAutoUpdateLabel: "aboutAuto", setAboutAutoUpdateNote: "aboutAutoNote",
            setAboutUpdatePreserveNote: "aboutPreserve",
            setSectionBackdrop: "secBackdrop", setSectionPanel: "secPanel", setLangNote: "noteLang",
            setLabelLang: "labelLang", setLangHint: "hintLang",
            setLabelToolView: "labelToolView", setToolViewHint: "hintToolView",
            setLabelLayout: "labelLayout", setLayoutHint: "hintLayout",
            setLabelQuickIt: "labelQuickIt", setQuickItNote: "hintQuickIt",
            setLabelEaseIt: "labelEaseIt", setEaseItNote: "hintEaseIt",
            setLabelAlignIt: "labelAlignIt", setAlignItNote: "hintAlignIt",
            setLabelPerformance: "labelPerformance", setPerformanceNote: "hintPerformance",
            setTipsNote: "hintTips",
            setLabelContextHints: "labelContextHints", setContextHintsNote: "hintContextHints",
            contextHintsReset: "resetContextHints",
            bdTabAura: "tabAura", bdTabColor: "tabColor", bdTabImage: "tabImage",
            bdLabelVariation: "variation",
            bdLabelIntensity: "intensity",
            bdLabelReactivity: "reactivity",
            bdLabelSoftness: "softness",
            bdAuraHint: "auraHint",
            bdLabelColor: "colorLabel",
            bdPick: "imageFile",
            bdClear: "imageClear",
            bdLabelFit: "fit",
            bdLabelBlur: "blur",
            bdLabelOpacity: "opacity",
            bdGifHint: "gifHint",
            bdSizeWarn: "sizeWarn",
            bdLoadWarn: "loadFail",
            bdLabelCommon: "common",
            bdLabelScrim: "veil",
            bdScrimHint: "veilHint",
            bdLabelGrain: "grain",
            bdLabelFps: "perf",
            bdFpsHint: "perfHint",
            bdReset: "reset",
            bdNoImage: "imageNone"
        };
        for (var id in map) {
            if (!map.hasOwnProperty(id)) continue;
            var el = $(id);
            if (el) el.textContent = t(map[id]);
        }
        var outerTabs = ["Custom", "Profiles", "Community", "About"];
        for (var ti = 0; ti < outerTabs.length; ti++) {
            var tab = $("setTab" + outerTabs[ti]);
            var label = $("setTab" + outerTabs[ti] + "Label");
            if (tab && label) {
                tab.title = label.textContent;
                tab.setAttribute("aria-label", label.textContent);
            }
        }
        /* The About copy is the one place with inline markup (a few <b>), so it
           cannot ride the textContent loop above without showing the tags. */
        var richText = {
            setAboutLead: "aboutLead", setAboutWhat: "aboutWhat",
            setAboutFree: "aboutFree", setAboutCredit: "aboutCredit",
            setAboutThird: "aboutThird"
        };
        for (var rid in richText) {
            if (!richText.hasOwnProperty(rid)) continue;
            var rel = $(rid);
            if (rel) rel.innerHTML = t(richText[rid]);
        }

        // La cifra de verdad viene de shell/js/version.js; el "1.0.0" del HTML
        // es solo lo que se ve si por lo que sea ese script no llegara a cargar.
        var verVal = $("setAboutVersionValue");
        if (verVal && window.EditKitVersion) verVal.textContent = window.EditKitVersion;

        /* Aviso transitorio de una sola version. Al cambiar el manifiesto a
           1.0.18 se oculta por si solo, aunque el marcado siga presente. */
        var discordFixedBadge = $("communityDiscordFixedBadge");
        if (discordFixedBadge) discordFixedBadge.hidden = window.EditKitVersion !== "1.0.17";

        if ($("bdPathInput")) $("bdPathInput").placeholder = t("imagePath");
        if ($("bdClose")) $("bdClose").setAttribute("aria-label", t("close"));
        if (openBtn) openBtn.title = t("btnTip");

        /* La etiqueta de un campo no lleva id propio en el HTML: se busca por
           el `for`, que es lo que la ata a su control. */
        var tl = document.querySelector('label[for="tipsSelect"]');
        if (tl) tl.textContent = t("labelTips");
        var tips = $("tipsSelect");
        if (tips) {
            var tmap = { off: "tipsOff", "200": "tipsFast", "450": "tipsNormal", "900": "tipsSlow" };
            Array.prototype.forEach.call(tips.options, function (o) {
                if (tmap[o.value]) o.textContent = t(tmap[o.value]);
            });
        }

        var fit = $("bdFit");
        if (fit) {
            var opts = { cover: "fitCover", contain: "fitContain", tile: "fitTile", center: "fitCenter" };
            Array.prototype.forEach.call(fit.options, function (o) {
                if (opts[o.value]) o.textContent = t(opts[o.value]);
            });
        }
    }

    // ---------------------------------------------------------------------
    // Boot
    // ---------------------------------------------------------------------
    loadState();
    buildGrain();
    buildSprites();
    buildBlobs();
    buildPresetChips();
    buildColorChips();
    resize();
    applyLayers();
    syncUI();

    // Panes may finish loading after this runs; push the veil again then, and
    // they also announce themselves with a "ready" message on their own.
    for (var fi = 0; fi < frames.length; fi++) {
        if (frames[fi]) frames[fi].addEventListener("load", pushToPanes);
    }

    if (reduceMotion) draw(); else start();

    window.EditKitBackdrop = {
        setLanguage: function (l) {
            lang = DICT[l] ? l : "es";
            buildPresetChips();
            syncUI();
        },
        /* Volver a leer lo guardado y repintar. La usan los temas, que escriben
           el ajuste del fondo por su cuenta y necesitan que esto se entere sin
           recargar el panel entero.

           El bucle se apaga y se vuelve a encender a proposito: si el tema pasa
           de aura a color plano, el bucle se quedaria dibujando humo sobre algo
           que ya no es un aura, y al contrario no arrancaria nunca. `start` y
           `stop` ya saben cual de los dos toca segun el modo. */
        reload: function () {
            loadState();
            resize();
            applyLayers();
            syncUI();
            stop();
            if (reduceMotion) draw(); else start();
        },
        open: openSheet,
        close: closeSheet,
        /* Una copia de lo que hay puesto ahora. La pide el diagnostico del menu
           del panel: leer la clave del almacenamiento a mano no vale, porque
           antes de que el usuario toque nada no hay clave que leer y los
           valores de fabrica viven aqui. Copia y no el objeto: quien pregunta
           no tiene por que poder cambiarlo. */
        state: function () {
            var out = {}, k;
            for (k in state) { if (state.hasOwnProperty(k)) out[k] = state[k]; }
            return out;
        }
    };
})();
