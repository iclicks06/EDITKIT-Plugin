/* ============================================================================
   EDITKIT — EL DESPLEGABLE, SIN EL SISTEMA DE POR MEDIO

   Un `<select>` se puede vestir por fuera: quitarle la apariencia nativa,
   ponerle nuestro borde, nuestra letra y nuestra flecha. Lo que NO se puede
   vestir es la LISTA que sale al pulsarlo. Esa la dibuja el sistema operativo,
   fuera de la pagina, con su tipografia, su fondo, su borde y su color de
   seleccion — y no hay CSS que llegue ahi. En Windows sale una lista blanca con
   el azul de Windows. En un panel negro, eso es lo mas llamativo que hay en
   pantalla, y pasa ochenta veces: hay ochenta desplegables en el plugin.

   Asi que aqui se dibuja uno propio.

   ── LO QUE NO SE TOCA ──────────────────────────────────────────────────────
   El `<select>` SE QUEDA. Sigue en el documento, con sus `<option>`, su `id` y
   su `value`; solo deja de verse. Eso es lo que hace viable el cambio:

     · los ochenta sitios que hacen `el.value`, `el.value = x` o escuchan
       `change` siguen funcionando sin tocar una linea;
     · el diccionario reescribe los `<option>` al cambiar de idioma, como
       siempre, y la lista propia se entera y se rehace;
     · si este archivo no llega a cargarse, el panel sigue teniendo ochenta
       desplegables que funcionan. Se pierde el aspecto, no la funcion.

   El `<select>` es la fuente de la verdad; esto es una piel.

   ── DETALLES QUE SE PAGAN SI NO SE MIRAN ───────────────────────────────────
   · La lista se cuelga del <body>, no del campo: dentro de un contenedor con
     desplazamiento, una lista colgada del campo se recorta por abajo y no se
     puede elegir la ultima opcion.
   · Y se coloca midiendo: si no cabe debajo, sale encima; si es mas alta que
     la ventana, se limita y se desplaza ella. Un panel de CEP mide a veces
     190 px de ancho y 300 de alto.
   · Con el teclado funciona como el de verdad: arriba, abajo, Inicio, Fin,
     Enter, Escape, y escribir una letra salta a la opcion que empieza por ahi.
     Un desplegable propio que solo entiende el raton es un retroceso.
   ============================================================================ */
(function () {
    "use strict";

    var GAP = 4;        // lo que se separa del campo
    var EDGE = 6;       // lo que se separa del borde de la ventana
    var MINW = 90;

    var openOne = null;     // el desplegable abierto, si hay alguno

    function el(tag, cls) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        return n;
    }

    // ---------------------------------------------------------------------
    // La lista, una sola para todo el documento
    // ---------------------------------------------------------------------
    var list = null;

    function listBox() {
        if (list && list.parentNode) return list;
        list = el("div", "ek-sel-list");
        list.setAttribute("role", "listbox");
        document.body.appendChild(list);
        return list;
    }

    function closeList() {
        if (list) {
            list.classList.remove("show");
            list.style.left = "-9999px";
            list.style.top = "-9999px";
            list.innerHTML = "";
        }
        if (openOne) {
            openOne.btn.classList.remove("open");
            openOne.btn.setAttribute("aria-expanded", "false");
            openOne = null;
        }
    }

    /* Las opciones utiles de un select. Se salta las deshabilitadas y respeta
       los grupos, que en este plugin no se usan hoy pero costaba lo mismo. */
    function options(sel) {
        var out = [], i;
        for (i = 0; i < sel.options.length; i++) {
            var o = sel.options[i];
            if (o.disabled) continue;
            out.push(o);
        }
        return out;
    }

    function place(box, anchor) {
        box.style.left = "-9999px";
        box.style.top = "-9999px";
        box.style.maxHeight = "";
        box.classList.add("show");

        var r = anchor.getBoundingClientRect();
        var vw = window.innerWidth, vh = window.innerHeight;

        // Nunca mas estrecha que el campo, y nunca mas ancha que la ventana.
        var w = Math.max(r.width, MINW);
        if (w > vw - EDGE * 2) w = vw - EDGE * 2;
        box.style.width = Math.round(w) + "px";

        var h = box.offsetHeight;
        var below = vh - r.bottom - GAP - EDGE;
        var above = r.top - GAP - EDGE;

        var top;
        if (h <= below || below >= above) {
            top = r.bottom + GAP;
            if (h > below) box.style.maxHeight = Math.max(80, below) + "px";
        } else {
            box.style.maxHeight = Math.max(80, above) + "px";
            top = r.top - Math.min(h, above) - GAP;
        }

        var left = r.left;
        if (left + w > vw - EDGE) left = vw - w - EDGE;
        if (left < EDGE) left = EDGE;

        box.style.left = Math.round(left) + "px";
        box.style.top = Math.round(Math.max(EDGE, top)) + "px";
    }

    function openFor(item) {
        closeList();
        var sel = item.sel, box = listBox();
        box.innerHTML = "";

        var opts = options(sel), i, active = null;
        for (i = 0; i < opts.length; i++) {
            (function (o) {
                var row = el("div", "ek-sel-opt");
                row.setAttribute("role", "option");
                row.textContent = o.textContent;
                /* Algunas listas optan por enseñar el texto entero al dejar el
                   cursor encima. El atributo vive en el <select> fuente para
                   que la piel siga siendo generica y el tooltip compartido se
                   encargue del idioma, el retardo y la colocacion. */
                if (sel.hasAttribute("data-option-tips")) {
                    row.setAttribute("data-tip", o.textContent);
                }
                if (o.value === sel.value) {
                    row.classList.add("on");
                    row.setAttribute("aria-selected", "true");
                    active = row;
                }
                row.addEventListener("mousedown", function (e) {
                    // mousedown y no click: el click llega despues del blur, y
                    // con el blur ya se habria cerrado la lista.
                    e.preventDefault();
                    e.stopPropagation();
                    pick(item, o.value);
                });
                row.addEventListener("mouseenter", function () { mark(row); });
                box.appendChild(row);
            })(opts[i]);
        }

        openOne = item;
        item.btn.classList.add("open");
        item.btn.setAttribute("aria-expanded", "true");
        place(box, item.btn);
        if (active) {
            mark(active);
            try { active.scrollIntoView({ block: "nearest" }); } catch (e) {}
        }
    }

    function mark(row) {
        if (!list) return;
        var all = list.querySelectorAll(".ek-sel-opt"), i;
        for (i = 0; i < all.length; i++) all[i].classList.remove("hot");
        if (row) row.classList.add("hot");
    }

    function hot() {
        return list ? list.querySelector(".ek-sel-opt.hot") : null;
    }

    function move(step) {
        if (!list) return;
        var all = list.querySelectorAll(".ek-sel-opt");
        if (!all.length) return;
        var cur = hot(), at = -1, i;
        for (i = 0; i < all.length; i++) if (all[i] === cur) at = i;
        var next = at + step;
        if (next < 0) next = 0;
        if (next > all.length - 1) next = all.length - 1;
        mark(all[next]);
        try { all[next].scrollIntoView({ block: "nearest" }); } catch (e) {}
    }

    /* Elegir es escribirlo en el `<select>` y avisar. El `change` se lanza a
       mano porque escribir `.value` por codigo no lo dispara, y de ese evento
       cuelga todo lo que el plugin hace con un desplegable. */
    function pick(item, value) {
        var sel = item.sel;
        if (sel.value !== value) {
            sel.value = value;
            try {
                var ev;
                if (typeof Event === "function") {
                    ev = new Event("change", { bubbles: true });
                } else {
                    ev = document.createEvent("HTMLEvents");
                    ev.initEvent("change", true, false);
                }
                sel.dispatchEvent(ev);
            } catch (e) {}
        }
        sync(item);
        closeList();
        try { item.btn.focus(); } catch (e2) {}
    }

    // El texto del boton: lo que diga la opcion elegida, y nada mas.
    function sync(item) {
        var sel = item.sel, txt = "";
        var i = sel.selectedIndex;
        if (i >= 0 && sel.options[i]) txt = sel.options[i].textContent;
        item.label.textContent = txt;
        item.btn.setAttribute("aria-label", txt);
    }

    // ---------------------------------------------------------------------
    // Vestir un select
    // ---------------------------------------------------------------------
    function dress(sel) {
        if (!sel || sel.getAttribute("data-ek-sel") === "1") return;
        if (sel.multiple || sel.size > 1) return;      // no es un desplegable
        sel.setAttribute("data-ek-sel", "1");

        var wrap = el("span", "ek-sel");
        var btn = el("button", "ek-sel-btn");
        btn.type = "button";
        btn.setAttribute("aria-haspopup", "listbox");
        btn.setAttribute("aria-expanded", "false");

        var label = el("span", "ek-sel-label");
        var chev = el("span", "ek-sel-chev");
        chev.setAttribute("aria-hidden", "true");
        btn.appendChild(label);
        btn.appendChild(chev);

        /* El campo original se queda donde estaba, dentro del envoltorio: asi
           hereda la misma maquetacion —el `flex` de su fila, su `grid-area`—
           que tenia antes, y ninguna hoja de estilos se entera del cambio. */
        sel.parentNode.insertBefore(wrap, sel);
        wrap.appendChild(btn);
        wrap.appendChild(sel);

        /* Se esconde SIN `display:none` y sin `hidden`: un select apartado asi
           deja de contar para los lectores de pantalla y para los atajos, y su
           `value` sigue siendo el que manda. Queda de un pixel, transparente y
           sin poder senalarse. */
        sel.classList.add("ek-sel-real");

        var item = { sel: sel, btn: btn, label: label, wrap: wrap };
        sync(item);

        btn.addEventListener("mousedown", function (e) {
            e.preventDefault();
            if (openOne && openOne.sel === sel) { closeList(); return; }
            openFor(item);
        });

        btn.addEventListener("keydown", function (e) {
            var k = e.key;
            if (!openOne || openOne.sel !== sel) {
                if (k === "Enter" || k === " " || k === "ArrowDown" || k === "ArrowUp") {
                    e.preventDefault();
                    openFor(item);
                }
                return;
            }
            if (k === "Escape") { e.preventDefault(); closeList(); return; }
            if (k === "Enter" || k === " ") {
                e.preventDefault();
                var h = hot();
                if (!h) { closeList(); return; }
                // El valor se recupera por posicion: la lista y las opciones
                // utiles van en el mismo orden.
                var all = list.querySelectorAll(".ek-sel-opt"), opts = options(sel), i;
                for (i = 0; i < all.length; i++) if (all[i] === h) pick(item, opts[i].value);
                return;
            }
            if (k === "ArrowDown") { e.preventDefault(); move(1); return; }
            if (k === "ArrowUp") { e.preventDefault(); move(-1); return; }
            if (k === "Home") { e.preventDefault(); move(-999); return; }
            if (k === "End") { e.preventDefault(); move(999); return; }

            // Escribir una letra salta a la primera opcion que empiece por ella.
            if (k && k.length === 1) {
                var want = k.toLowerCase();
                var rows = list.querySelectorAll(".ek-sel-opt");
                for (i = 0; i < rows.length; i++) {
                    if (rows[i].textContent.toLowerCase().indexOf(want) === 0) {
                        mark(rows[i]);
                        try { rows[i].scrollIntoView({ block: "nearest" }); } catch (e2) {}
                        break;
                    }
                }
            }
        });

        /* Quien cambie el select por su cuenta —el propio panel al restaurar
           ajustes, o el diccionario al reescribir las opciones— tiene que verse
           reflejado en el boton. `change` cubre lo primero; el observador, lo
           segundo. */
        sel.addEventListener("change", function () { sync(item); });
        if (window.MutationObserver) {
            var obs = new MutationObserver(function () {
                sync(item);
                if (openOne && openOne.sel === sel) openFor(item);
            });
            obs.observe(sel, { childList: true, subtree: true, characterData: true,
                               attributes: true, attributeFilter: ["value"] });
        }

        return item;
    }

    // ---------------------------------------------------------------------
    // Cerrar, y vestir lo que vaya apareciendo
    // ---------------------------------------------------------------------
    document.addEventListener("mousedown", function (e) {
        if (!openOne) return;
        var n = e.target;
        while (n && n !== document.body) {
            if (n === list || n === openOne.btn) return;
            n = n.parentNode;
        }
        closeList();
    }, true);

    window.addEventListener("resize", closeList);
    window.addEventListener("blur", closeList);
    /* El scroll exterior invalida la posicion fija de la lista y por eso la
       cierra. El scroll de la lista NO: con muchas acciones de QuickIt es la
       unica forma de llegar a las opciones de abajo. Como `scroll` se escucha
       en captura, el movimiento interno llegaba tambien hasta este oyente y
       cerraba el desplegable en el primer paso de la rueda. */
    document.addEventListener("scroll", function (e) {
        if (!openOne) return;
        var target = e.target;
        if (list && (target === list || (list.contains && list.contains(target)))) return;
        closeList();
    }, true);

    function dressAll(root) {
        var all = (root || document).querySelectorAll("select:not([data-ek-sel])");
        for (var i = 0; i < all.length; i++) dress(all[i]);
    }

    function boot() {
        dressAll(document);
        /* Hay desplegables que nacen despues: el menu de un boton de la
           rejilla, la hoja de ajustes. Se vigila el documento entero, que es
           mas barato que acordarse de llamar a esto en ocho sitios. */
        if (window.MutationObserver) {
            var obs = new MutationObserver(function (recs) {
                for (var i = 0; i < recs.length; i++) {
                    var added = recs[i].addedNodes;
                    for (var j = 0; j < added.length; j++) {
                        var n = added[j];
                        if (n.nodeType !== 1) continue;
                        if (n.tagName === "SELECT") dress(n);
                        else if (n.querySelectorAll) dressAll(n);
                    }
                }
            });
            obs.observe(document.documentElement, { childList: true, subtree: true });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }

})();
