(function () {
  "use strict";

  var config = window.EditKitFeedbackConfig || {};
  var form = document.getElementById("feedbackForm");
  if (!form) return;

  var typeSelect = document.getElementById("feedbackType");
  var messageInput = document.getElementById("feedbackMessage");
  var contactInput = document.getElementById("feedbackContact");
  var websiteInput = document.getElementById("feedbackWebsite");
  var counter = document.getElementById("feedbackCounter");
  var submitButton = document.getElementById("feedbackSubmit");
  var status = document.getElementById("feedbackStatus");
  var minChars = Number(config.minMessageChars) || 10;
  var maxChars = Number(config.maxMessageChars) || 1200;
  var sending = false;
  var statusKey = "";
  var statusReference = "";

  var DICT = {
    es: {
      title: "Enviar una sugerencia",
      intro: "Cuéntame qué mejorarías o qué no funcionó como esperabas.",
      type: "Tipo",
      idea: "Idea o mejora",
      bug: "Problema",
      comment: "Comentario",
      message: "Mensaje",
      messagePlaceholder: "Describe tu idea o problema con el mayor detalle posible…",
      contact: "Contacto (opcional)",
      contactPlaceholder: "Correo, Discord o Telegram",
      privacy: "Se enviarán este mensaje, el tipo, tu contacto si lo escribes, la versión de EditKit, el programa de Adobe y el idioma. Nunca se envían proyectos, presets ni configuraciones.",
      submit: "Enviar sugerencia",
      sending: "Enviando…",
      tooShort: "Escribe al menos {min} caracteres para poder enviarlo.",
      success: "Sugerencia enviada. Gracias por ayudar a mejorar EditKit.",
      reference: "Referencia: {id}.",
      invalid: "Revisa el mensaje e inténtalo de nuevo.",
      rateLimited: "Has enviado varios mensajes seguidos. Espera un minuto e inténtalo de nuevo.",
      unavailable: "No se pudo entregar el mensaje en este momento. Inténtalo más tarde.",
      network: "No se pudo conectar. Revisa tu conexión a internet e inténtalo de nuevo."
    },
    en: {
      title: "Send a suggestion",
      intro: "Tell me what you would improve or what did not work as expected.",
      type: "Type",
      idea: "Idea or improvement",
      bug: "Problem",
      comment: "Comment",
      message: "Message",
      messagePlaceholder: "Describe your idea or problem in as much detail as possible…",
      contact: "Contact (optional)",
      contactPlaceholder: "Email, Discord, or Telegram",
      privacy: "This message, its type, your contact if provided, the EditKit version, the Adobe app, and the language will be sent. Projects, presets, and settings are never sent.",
      submit: "Send suggestion",
      sending: "Sending…",
      tooShort: "Write at least {min} characters before sending.",
      success: "Suggestion sent. Thank you for helping improve EditKit.",
      reference: "Reference: {id}.",
      invalid: "Check the message and try again.",
      rateLimited: "Several messages were sent in a short time. Wait a minute and try again.",
      unavailable: "The message could not be delivered right now. Please try again later.",
      network: "Could not connect. Check your internet connection and try again."
    }
  };

  var lang = "es";
  try { lang = localStorage.getItem("editkit_lang") || "es"; } catch (e) {}
  if (!DICT[lang]) lang = "es";

  function t(key) {
    return (DICT[lang] && DICT[lang][key]) || DICT.es[key] || key;
  }

  function setText(id, value) {
    var el = document.getElementById(id);
    if (el) el.textContent = value;
  }

  function replaceToken(value, token, replacement) {
    return String(value).replace("{" + token + "}", replacement);
  }

  function renderStatus() {
    if (!statusKey) {
      status.hidden = true;
      status.textContent = "";
      status.className = "feedback-status";
      return;
    }
    var text = t(statusKey);
    if (statusKey === "tooShort") text = replaceToken(text, "min", minChars);
    if (statusReference) text += " " + replaceToken(t("reference"), "id", statusReference);
    status.textContent = text;
    status.hidden = false;
    status.className = "feedback-status " + (statusKey === "success" ? "is-success" : "is-error");
  }

  function setStatus(key, reference) {
    statusKey = key || "";
    statusReference = reference || "";
    renderStatus();
  }

  function messageLength() {
    return String(messageInput.value || "").replace(/^\s+|\s+$/g, "").length;
  }

  function syncForm() {
    var length = String(messageInput.value || "").length;
    counter.textContent = length + " / " + maxChars;
    submitButton.disabled = sending || messageLength() < minChars || messageLength() > maxChars;
    submitButton.textContent = sending ? t("sending") : t("submit");
  }

  function applyLanguage(nextLanguage) {
    lang = DICT[nextLanguage] ? nextLanguage : "es";
    setText("feedbackTitle", t("title"));
    setText("feedbackIntro", t("intro"));
    setText("feedbackTypeLabel", t("type"));
    setText("feedbackMessageLabel", t("message"));
    setText("feedbackContactLabel", t("contact"));
    setText("feedbackPrivacy", t("privacy"));
    messageInput.placeholder = t("messagePlaceholder");
    contactInput.placeholder = t("contactPlaceholder");
    var optionKeys = { idea: "idea", bug: "bug", comment: "comment" };
    Array.prototype.forEach.call(typeSelect.options, function (option) {
      if (optionKeys[option.value]) option.textContent = t(optionKeys[option.value]);
    });
    syncForm();
    renderStatus();
  }

  function hostName() {
    var app = "";
    try { app = String(new CSInterface().getHostEnvironment().appName || ""); } catch (e) {}
    if (app === "AEFT") return "After Effects";
    if (app === "PPRO") return "Premiere Pro";
    return app || "Unknown Adobe app";
  }

  function finishRequest(key, reference) {
    sending = false;
    setStatus(key, reference);
    syncForm();
  }

  function sendFeedback() {
    var message = String(messageInput.value || "").replace(/^\s+|\s+$/g, "");
    if (message.length < minChars || message.length > maxChars) {
      setStatus("tooShort");
      syncForm();
      messageInput.focus();
      return;
    }
    if (!config.endpoint || !/^https:\/\//i.test(config.endpoint)) {
      finishRequest("unavailable");
      return;
    }

    sending = true;
    setStatus("");
    syncForm();

    var xhr = new XMLHttpRequest();
    xhr.open("POST", config.endpoint, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.timeout = Number(config.timeoutMs) || 20000;
    xhr.onload = function () {
      var response = {};
      try { response = JSON.parse(xhr.responseText || "{}"); } catch (e) {}
      if (xhr.status === 202 && response.ok) {
        messageInput.value = "";
        finishRequest("success", response.id || "");
      } else if (xhr.status === 429) {
        finishRequest("rateLimited");
      } else if (xhr.status >= 500 || xhr.status === 0) {
        finishRequest("unavailable");
      } else {
        finishRequest("invalid");
      }
    };
    xhr.onerror = function () { finishRequest("network"); };
    xhr.ontimeout = function () { finishRequest("network"); };
    xhr.send(JSON.stringify({
      type: typeSelect.value,
      message: message,
      contact: String(contactInput.value || "").replace(/^\s+|\s+$/g, ""),
      website: String(websiteInput.value || ""),
      pluginVersion: String(window.EditKitVersion || ""),
      host: hostName(),
      language: lang
    }));
  }

  messageInput.maxLength = maxChars;
  messageInput.minLength = minChars;
  messageInput.addEventListener("input", function () {
    if (statusKey === "tooShort" || statusKey === "invalid") setStatus("");
    syncForm();
  });
  form.addEventListener("submit", function (event) {
    event.preventDefault();
    if (!sending) sendFeedback();
  });

  applyLanguage(lang);
  window.EditKitFeedback = {
    setLanguage: applyLanguage,
    focusMessage: function () {
      try {
        form.scrollIntoView({ block: "start", behavior: "smooth" });
      } catch (e) {
        form.scrollIntoView(true);
      }
      window.setTimeout(function () { messageInput.focus(); }, 180);
    }
  };
}());
