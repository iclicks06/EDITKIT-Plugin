/*
 * Public configuration for the EditKit feedback form.
 *
 * This endpoint is safe to ship inside the extension. The private Discord
 * webhook remains stored only as a Cloudflare Worker secret.
 */
(function (root) {
  "use strict";

  var config = {
    endpoint: "https://editkit-feedback.editkit-build-tools.workers.dev/v1/feedback",
    minMessageChars: 10,
    maxMessageChars: 1200,
    timeoutMs: 20000
  };

  if (typeof Object.freeze === "function") Object.freeze(config);
  root.EditKitFeedbackConfig = config;
}(window));
