/**
 * ALIGNIT PANEL — Main JavaScript
 * Interfaz minimalista, con pestañas en lugar de acordeones y scroll interno
 * cuando el contenido excede el alto del panel.
 * Todas las llamadas a ExtendScript (executeAlignment, distributeLayersEvenly,
 * copyTransform, quickCenterBoth, quickMatchSize, quickStack, quickFlip)
 * se mantienen sin cambios respecto a la versión anterior.
 *
 * Ajustes: el objeto `settings` ahora cubre comportamiento general,
 * apariencia (acento / tamaño / densidad / badges / etiquetas) y el orden y
 * visibilidad de cada sección del panel (Cuadrícula, Herramientas, Acciones
 * rápidas, Barra de estado), todo persistido en localStorage.
 */

(function () {
    'use strict';

    var csInterface = new CSInterface();
    function T(key) { return (window.EditKitI18n && window.EditKitI18n.t(key)) || key; }
    function TF(key, arg0) { return (window.EditKitI18n && window.EditKitI18n.fmt(key, arg0)) || key; }
    var currentMode = 'align';
    var currentTarget = 'comp';
    var currentLayout = 'normal';
    var lastAction = null;
    var draggedSectionId = null;

    var defaultSectionOrder = ['align', 'tools', 'quick', 'status'];

    var HOST_ERROR_KEYS = {
        'Necesitas al menos 3 capas': 'aa.err.needThreeLayers',
        'Necesitas seleccionar al menos 2 capas': 'aa.err.needTwoLayers',
        'No hay capas seleccionadas': 'aa.err.noLayersSelected',
        'No hay composición activa': 'aa.err.noActiveComp',
        'No hay suficientes capas válidas': 'aa.err.notEnoughValidLayers',
        'No se puede obtener tamaño de la primera capa': 'aa.err.cantGetFirstLayerSize',
        'Tipo de transform no válido': 'aa.err.invalidTransformType'
    };
    // hostscript.jsx always returns errors in Spanish ("Error: ..."); translate
    // the known fixed set client-side so English mode stays fully English too.
    function translateHostResult(result) {
        if (!result || result.indexOf('Error:') !== 0) return result;
        var body = result.slice(6).trim();
        var key = HOST_ERROR_KEYS[body];
        return key ? 'Error: ' + T(key) : result;
    }

    function sectionLabel(id) {
        var keys = {
            align: 'aa.sectionAlignGrid',
            tools: 'aa.sectionTools', quick: 'aa.sectionQuick', status: 'aa.sectionStatus'
        };
        return keys[id] ? T(keys[id]) : id;
    }

    var defaultSettings = {
        // General
        padding: 0,
        stackSpacing: 10,
        createUndo: true,
        animateFeedback: false,
        defaultMode: 'align',
        defaultTarget: 'comp',
        rememberLastMode: false,
        showToasts: true,
        toastDuration: 2000,

        // Apariencia
        accentTheme: 'editkit',
        customAccentColor: '#49c9bd',
        defaultPanelSize: 'auto',
        density: 'normal',
        reticleMax: '330',
        showShortcutBadges: true,
        showTextLabels: true,

        // Atajos
        shortcutsEnabled: true,

        // Secciones
        sectionOrder: defaultSectionOrder.slice(),
        sectionVisibility: { align: true, tools: true, quick: true, status: true }
    };

    var settings = JSON.parse(JSON.stringify(defaultSettings));

    // ============================================================================
    // INIT
    // ============================================================================

    function init() {
        updateThemeWithAppSkinInfo(csInterface.hostEnvironment.appSkinInfo);
        csInterface.addEventListener(CSInterface.THEME_COLOR_CHANGED_EVENT, onAppThemeColorChanged);

        loadSettings();
        applyStartupModeAndTarget();
        applyAccentTheme();
        // Repaint when the shared accent changes in EaseIt or the EditKit header.
        // Only matters while this panel is set to follow it.
        if (window.EditKitAccent) {
            window.EditKitAccent.onChange(function () {
                if (settings.accentTheme === 'editkit') applyAccentTheme();
            });
        }
        applyDensity();
        applyReticleMax();
        applyBadgeVisibility();
        applyLabelVisibility();
        applySectionOrderAndVisibility();

        setupEventListeners();
        setupKeyboardShortcuts();

        applyDefaultPanelSize();
        window.addEventListener('resize', detectPanelSize);
    }

    // ============================================================================
    // THEME
    // ============================================================================

    function onAppThemeColorChanged() {
        var skinInfo = JSON.parse(window.__adobe_cep__.getHostEnvironment()).appSkinInfo;
        updateThemeWithAppSkinInfo(skinInfo);
    }

    function updateThemeWithAppSkinInfo(appSkinInfo) {
        var bgColor = toHex(appSkinInfo.panelBackgroundColor.color);
        document.body.style.backgroundColor = bgColor;
    }

    function toHex(color, delta) {
        delta = delta || 0;
        function computeValue(value, d) {
            var v = Math.round(value + d);
            if (v < 0) v = 0;
            if (v > 255) v = 255;
            var hex = v.toString(16);
            return hex.length === 1 ? '0' + hex : hex;
        }
        return '#' + computeValue(color.red, delta) + computeValue(color.green, delta) + computeValue(color.blue, delta);
    }

    // ============================================================================
    // RESPONSIVE — PANEL SIZE DETECTION
    // ============================================================================

    function detectPanelSize() {
        /* Con los ajustes abiertos, el shell estira este marco hasta cubrir
           EditKit entero. El panel de debajo sigue midiendo lo que medía —está
           clavado en su hueco—, así que medir la ventana aquí lo pondría en
           "expandido" detrás de la hoja y lo devolvería a su tamaño al cerrar. */
        var L = window.EditKitLift;
        if (L && L.isOn()) return;

        var width = window.innerWidth;
        var hasManualSelection = document.querySelector('.size-btn.active[data-manual="true"]');

        if (!hasManualSelection) {
            if (width < 190) {
                setLayout('small', false);
            } else if (width < 250) {
                setLayout('compact', false);
            } else if (width < 340) {
                setLayout('normal', false);
            } else {
                setLayout('expanded', false);
            }
        }
    }

    function setLayout(size, manual) {
        currentLayout = size;
        var app = document.querySelector('.app');
        app.setAttribute('data-layout', size);

        var sizeButtons = document.querySelectorAll('.size-btn');
        sizeButtons.forEach(function (btn) {
            var isActive = btn.getAttribute('data-size') === size;
            btn.classList.toggle('active', isActive);
            if (manual && isActive) {
                btn.setAttribute('data-manual', 'true');
            } else if (manual) {
                btn.removeAttribute('data-manual');
            }
        });

        syncLabelToggleAvailability();
        // Remember a size the user picked by hand, so the panel comes back the
        // way they left it instead of re-guessing from the width every launch.
        if (manual) rememberLayout(size);
    }

    var LAST_LAYOUT_KEY = 'alignAnchorLastLayout';
    function rememberLayout(size) {
        try { localStorage.setItem(LAST_LAYOUT_KEY, size); } catch (e) {}
    }
    function recallLayout() {
        var valid = { small: 1, compact: 1, normal: 1, expanded: 1 };
        try {
            var v = localStorage.getItem(LAST_LAYOUT_KEY);
            return valid[v] ? v : null;
        } catch (e) { return null; }
    }

    function applyDefaultPanelSize() {
        // An explicit "default panel size" in Ajustes still wins — that is a
        // deliberate choice. Below it sits whatever the user last clicked, and
        // only with neither does the width get to decide.
        if (settings.defaultPanelSize && settings.defaultPanelSize !== 'auto') {
            setLayout(settings.defaultPanelSize, true);
            return;
        }
        var last = recallLayout();
        if (last) { setLayout(last, true); return; }
        detectPanelSize();
    }

    // ============================================================================
    // EVENT LISTENERS
    // ============================================================================

    function setupEventListeners() {
        // Manual size controls
        document.querySelectorAll('.size-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                setLayout(this.getAttribute('data-size'), true);
            });
        });

        // Mode toggle (Align / Anchor)
        var modeToggle = document.getElementById('modeToggle');
        var app = document.querySelector('.app');
        var modeOptions = modeToggle.querySelectorAll('.mode-opt');

        modeToggle.addEventListener('click', function () {
            currentMode = currentMode === 'align' ? 'anchor' : 'align';
            this.setAttribute('data-mode', currentMode);
            app.setAttribute('data-mode', currentMode);

            modeOptions.forEach(function (opt) {
                opt.classList.toggle('active', opt.getAttribute('data-value') === currentMode);
            });

            if (settings.rememberLastMode) {
                try { localStorage.setItem('alignAnchorLastMode', currentMode); } catch (e) { /* no disponible */ }
            }

            showToast(TF('aa.toast.modeIs', currentMode === 'align' ? T('aa.align') : T('aa.anchor')));
        });

        // Target switch (Comp / Selection)
        var targetButtons = document.querySelectorAll('.target-opt');
        targetButtons.forEach(function (btn) {
            btn.addEventListener('click', function () {
                currentTarget = this.getAttribute('data-target');
                targetButtons.forEach(function (b) { b.classList.remove('active'); });
                this.classList.add('active');
                showToast(TF('aa.toast.alignTargetIs', currentTarget === 'comp' ? T('aa.composition') : T('aa.selection')));
            });
        });

        // Tabs (Distribuir / Transform / Ajustes)
        var tabs = document.querySelectorAll('.tab');
        var tabContents = document.querySelectorAll('.tab-content');
        tabs.forEach(function (tab) {
            tab.addEventListener('click', function () {
                var target = this.getAttribute('data-tab');

                tabs.forEach(function (t) {
                    t.classList.toggle('active', t === tab);
                    t.setAttribute('aria-selected', t === tab ? 'true' : 'false');
                });
                tabContents.forEach(function (c) {
                    c.classList.toggle('active', c.getAttribute('data-tab-content') === target);
                });
            });
        });

        /* ----------------------------------------------------------------
           Los ajustes: engranaje arriba, hoja encima de todo

           Dejaron de ser una pestana. Como pestana ocupaban un tercio de esa
           barra de forma permanente a cambio de algo que se abre una vez, se
           toca y se cierra, mientras Distribuir y Transform son trabajo de
           todos los dias.

           Y la hoja se abre sobre EditKit entero: se le pide al shell que
           estire este marco mientras dure. Encerrada aqui dentro, con el panel
           estrecho, cada frase salia en cinco lineas mientras al lado sobraba
           sitio. Suelto, sin shell, se abre como siempre.
           ---------------------------------------------------------------- */
        var aaOverlay = document.getElementById('aaOverlay');
        var aaGear = document.getElementById('aaGear');

        function liftSheet(on) {
            var L = window.EditKitLift;
            if (!L || !L.available) return;
            if (on) L.on(); else L.off();
        }

        function openSettings() {
            if (!aaOverlay) return;
            liftSheet(true);
            aaOverlay.hidden = false;
            if (aaGear) aaGear.classList.add('active');
        }

        function closeSettings() {
            if (!aaOverlay) return;
            aaOverlay.hidden = true;
            liftSheet(false);
            if (aaGear) aaGear.classList.remove('active');
        }

        if (aaGear) {
            aaGear.addEventListener('click', function () {
                if (aaOverlay && aaOverlay.hidden) openSettings(); else closeSettings();
            });
        }
        var aaClose = document.getElementById('aaClose');
        if (aaClose) aaClose.addEventListener('click', closeSettings);
        if (aaOverlay) {
            // Fuera de la hoja se cierra; dentro no, o cada clic en un
            // desplegable la cerraria por debajo de la mano.
            aaOverlay.addEventListener('mousedown', function (e) {
                if (e.target === aaOverlay) closeSettings();
            });
        }
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && aaOverlay && !aaOverlay.hidden) closeSettings();
        });

        if (window.EditKitMountToolIcon) window.EditKitMountToolIcon('alignit');

        // Settings sub-navigation (General / Apariencia / Secciones / Atajos)
        var settingsNavButtons = document.querySelectorAll('.settings-nav-btn');
        var settingsPanels = document.querySelectorAll('.settings-panel');
        settingsNavButtons.forEach(function (btn) {
            btn.addEventListener('click', function () {
                var target = this.getAttribute('data-settings-panel');
                settingsNavButtons.forEach(function (b) {
                    b.classList.toggle('active', b === btn);
                    b.setAttribute('aria-selected', b === btn ? 'true' : 'false');
                });
                settingsPanels.forEach(function (p) {
                    p.classList.toggle('active', p.getAttribute('data-settings-content') === target);
                });
                var sheetBody = document.querySelector('.aa-sheet-body');
                if (sheetBody) sheetBody.scrollTop = 0;
            });
        });

        // Alignment grid buttons
        document.querySelectorAll('.btn-align').forEach(function (btn) {
            btn.addEventListener('click', function (e) {
                handleAlignment(this.getAttribute('data-direction'), e.shiftKey, this);
            });
        });

        // Center H / V buttons
        document.querySelectorAll('.btn-mid').forEach(function (btn) {
            btn.addEventListener('click', function (e) {
                handleAlignment(this.getAttribute('data-direction'), e.shiftKey, this);
            });
        });

        // Distribute buttons
        document.querySelectorAll('[data-distribute]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                handleDistribute(this.getAttribute('data-distribute'), this);
            });
        });

        // Transform buttons
        document.querySelectorAll('[data-transform]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                handleTransform(this.getAttribute('data-transform'), this);
            });
        });

        // Quick action buttons
        document.querySelectorAll('.quick-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                handleQuickAction(this.getAttribute('data-action'), this);
            });
        });

        // ---- Ajustes > General ----
        document.getElementById('paddingInput').addEventListener('change', function () {
            settings.padding = parseInt(this.value, 10) || 0;
            saveSettings();
        });

        document.getElementById('stackSpacing').addEventListener('change', function () {
            settings.stackSpacing = parseInt(this.value, 10) || 10;
            saveSettings();
        });

        document.getElementById('defaultModeSelect').addEventListener('change', function () {
            settings.defaultMode = this.value;
            saveSettings();
        });

        document.getElementById('defaultTargetSelect').addEventListener('change', function () {
            settings.defaultTarget = this.value;
            saveSettings();
        });

        document.getElementById('rememberLastModeCheckbox').addEventListener('change', function () {
            settings.rememberLastMode = this.checked;
            saveSettings();
        });

        document.getElementById('createUndoCheckbox').addEventListener('change', function () {
            settings.createUndo = this.checked;
            saveSettings();
        });

        document.getElementById('animateCheckbox').addEventListener('change', function () {
            settings.animateFeedback = this.checked;
            saveSettings();
        });

        document.getElementById('showToastsCheckbox').addEventListener('change', function () {
            settings.showToasts = this.checked;
            saveSettings();
        });

        document.getElementById('toastDurationInput').addEventListener('change', function () {
            settings.toastDuration = parseInt(this.value, 10) || 2000;
            saveSettings();
        });

        // ---- Ajustes > Apariencia ----
        document.getElementById('accentThemeSelect').addEventListener('change', function () {
            settings.accentTheme = this.value;
            applyAccentTheme();
            saveSettings();
        });

        document.getElementById('customAccentInput').addEventListener('input', function () {
            settings.customAccentColor = this.value;
            if (settings.accentTheme === 'custom') applyAccentTheme();
            saveSettings();
        });

        document.getElementById('defaultSizeSelect').addEventListener('change', function () {
            settings.defaultPanelSize = this.value;
            applyDefaultPanelSize();
            saveSettings();
        });

        document.getElementById('reticleMaxSelect').addEventListener('change', function () {
            settings.reticleMax = this.value;
            applyReticleMax();
            saveSettings();
        });

        document.getElementById('densitySelect').addEventListener('change', function () {
            settings.density = this.value;
            applyDensity();
            saveSettings();
        });

        document.getElementById('showBadgesCheckbox').addEventListener('change', function () {
            settings.showShortcutBadges = this.checked;
            applyBadgeVisibility();
            saveSettings();
        });

        document.getElementById('showLabelsCheckbox').addEventListener('change', function () {
            settings.showTextLabels = this.checked;
            applyLabelVisibility();
            saveSettings();
        });

        // ---- Ajustes > restaurar ----
        /* Restaurar se pregunta, y se pregunta DENTRO del panel. Antes lo hacia
           `window.confirm()`, que es un cuadro del sistema operativo: salia en
           el centro de la pantalla con la tipografia de Windows y los botones
           en el idioma del sistema, y ademas congelaba la pagina entera
           mientras estaba abierto.

           Y la pregunta estaba escrita en espanol a pelo dentro del codigo, asi
           que a quien tuviera el plugin en ingles le salia en espanol. */
        document.getElementById('resetSettingsBtn').addEventListener('click', function () {
            window.EditKitAsk.confirm({
                text: T('aa.ask.reset'),
                go: T('aa.ask.resetGo'),
                keep: T('aa.ask.keep'),
                danger: true
            }, function (yes) {
                if (!yes) return;

                settings = JSON.parse(JSON.stringify(defaultSettings));
                syncSettingsUI();
                applyAccentTheme();
                applyDensity();
                applyBadgeVisibility();
                applyLabelVisibility();
                applySectionOrderAndVisibility();
                applyStartupModeAndTarget();
                saveSettings();
                showToast(T('aa.toast.settingsReset'));
            });
        });
    }

    // ============================================================================
    // KEYBOARD SHORTCUTS
    // ============================================================================

    function setupKeyboardShortcuts() {
        /* Con el registro de comandos cargado, los atajos los reparte el
           registro: es el unico sitio donde el usuario puede reasignarlos, y
           dos manejadores compitiendo por la misma tecla harian que cambiarla
           en ajustes no sirviera de nada. */
        if (window.EditKitCommands) return;

        var shortcuts = {
            q: 'topLeft', w: 'top', e: 'topRight',
            a: 'left', s: 'center', d: 'right',
            z: 'bottomLeft', x: 'bottom', c: 'bottomRight',
            h: 'centerH', v: 'centerV'
        };

        document.addEventListener('keydown', function (e) {
            if (!settings.shortcutsEnabled) return;
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;

            if (e.key === 'Tab') {
                e.preventDefault();
                document.getElementById('modeToggle').click();
                return;
            }

            var key = e.key.toLowerCase();
            if (shortcuts[key] && !e.ctrlKey && !e.metaKey && !e.altKey) {
                e.preventDefault();
                handleAlignment(shortcuts[key], e.shiftKey);
            }

            if (key === 'r' && lastAction && !e.ctrlKey && !e.metaKey) {
                e.preventDefault();
                handleAlignment(lastAction.direction, lastAction.doubleDuty);
            }
        });
    }

    // ============================================================================
    // STARTUP MODE / TARGET
    // ============================================================================

    function applyStartupModeAndTarget() {
        var storedMode = null;
        if (settings.rememberLastMode) {
            try { storedMode = localStorage.getItem('alignAnchorLastMode'); } catch (e) { /* no disponible */ }
        }

        currentMode = storedMode || settings.defaultMode || 'align';
        currentTarget = settings.defaultTarget || 'comp';

        var app = document.querySelector('.app');
        var modeToggle = document.getElementById('modeToggle');
        app.setAttribute('data-mode', currentMode);
        modeToggle.setAttribute('data-mode', currentMode);
        modeToggle.querySelectorAll('.mode-opt').forEach(function (opt) {
            opt.classList.toggle('active', opt.getAttribute('data-value') === currentMode);
        });

        document.querySelectorAll('.target-opt').forEach(function (btn) {
            btn.classList.toggle('active', btn.getAttribute('data-target') === currentTarget);
        });
    }

    // ============================================================================
    // APARIENCIA — acento / densidad / badges / etiquetas
    // ============================================================================

    function applyAccentTheme() {
        var root = document.documentElement;

        switch (settings.accentTheme) {
            // Follows the one accent shared with EaseIt and the EditKit header.
            // Align and Anchor deliberately collapse to the same color here —
            // the mode is still called out by the header and the badges.
            case 'editkit':
                var shared = window.EditKitAccent ? window.EditKitAccent.get() : '#49c9bd';
                root.style.setProperty('--accent-align', shared);
                root.style.setProperty('--accent-anchor', shared);
                break;
            case 'teal':
                root.style.setProperty('--accent-align', '#49c9bd');
                root.style.setProperty('--accent-anchor', '#49c9bd');
                break;
            case 'amber':
                root.style.setProperty('--accent-align', '#e2a45c');
                root.style.setProperty('--accent-anchor', '#e2a45c');
                break;
            case 'custom':
                root.style.setProperty('--accent-align', settings.customAccentColor);
                root.style.setProperty('--accent-anchor', settings.customAccentColor);
                break;
            default:
                root.style.removeProperty('--accent-align');
                root.style.removeProperty('--accent-anchor');
        }

        var customRow = document.getElementById('customAccentRow');
        if (customRow) customRow.hidden = settings.accentTheme !== 'custom';

        paintAccentTones();
    }

    /* Los dos tonos que salen de cada acento: el relleno tenue de los estados
       :active y el color de texto y anillo que va encima de ese relleno.

       Los definia el CSS con color-mix(), que llego en Chromium 111 y no existe
       en el Chromium de CEP de ninguna version de After Effects: las variables
       no llegaban a existir y los estados que las usan no pintaban nada. Se
       calculan aqui, con la misma cuenta que hacia color-mix() y en el mismo
       sitio donde ya se decide el acento.

       Se hacen los DOS modos y no solo el activo: el acento cambia con el modo
       sin volver a pasar por aqui —es una clase en el contenedor— y calcular
       solo el de ahora dejaria el otro con el color del anterior. */
    function paintAccentTones() {
        var A = window.EditKitAccent;
        if (!A || !A.tones) return;
        var root = document.documentElement;
        var cs = getComputedStyle(root);

        var pairs = [["align", "--accent-align"], ["anchor", "--accent-anchor"]];
        for (var i = 0; i < pairs.length; i++) {
            var hex = (cs.getPropertyValue(pairs[i][1]) || "").replace(/^\s+|\s+$/g, "");
            if (!hex) continue;
            var t = A.tones(hex);
            root.style.setProperty("--accent-" + pairs[i][0] + "-soft", t.soft);
            root.style.setProperty("--accent-" + pairs[i][0] + "-strong", t.strong);
            root.style.setProperty("--accent-" + pairs[i][0] + "-mid", t.mid);
        }
    }

    function applyDensity() {
        var app = document.querySelector('.app');
        if (app) app.setAttribute('data-density', settings.density || 'normal');
    }

    /* El reticulo es un cuadrado atado al ancho del panel, asi que ensancharlo
       hunde las herramientas de abajo. Este tope lo corta; "none" quita la
       regla entera en lugar de poner un numero grande, para que quien prefiera
       el comportamiento de siempre lo tenga intacto. */
    function applyReticleMax() {
        var v = settings.reticleMax || '330';
        var app = document.querySelector('.app');
        if (!app) return;
        if (v === 'none') {
            app.setAttribute('data-reticle', 'none');
            app.style.removeProperty('--reticle-max');
        } else {
            app.removeAttribute('data-reticle');
            app.style.setProperty('--reticle-max', parseInt(v, 10) + 'px');
        }
    }

    function applyBadgeVisibility() {
        var app = document.querySelector('.app');
        if (app) app.classList.toggle('hide-badges', !settings.showShortcutBadges);
    }

    function applyLabelVisibility() {
        var app = document.querySelector('.app');
        if (app) app.classList.toggle('force-hide-labels', !settings.showTextLabels);
    }

    // Pequeño/Compacto are always too narrow for text labels, regardless of
    // this setting (see the CSS note next to .force-hide-labels). Keep the
    // "Mostrar etiquetas de texto" checkbox honest about that: disable +
    // uncheck it while in either size, and restore it to the user's real
    // saved preference (untouched in settings.showTextLabels) once back to
    // Normal/Expandido — so nothing looks checked-but-doing-nothing, and
    // nothing gets silently lost either.
    function syncLabelToggleAvailability() {
        var checkbox = document.getElementById('showLabelsCheckbox');
        if (!checkbox) return;
        var cramped = currentLayout === 'small' || currentLayout === 'compact';
        checkbox.disabled = cramped;
        checkbox.checked = cramped ? false : settings.showTextLabels;
    }

    // ============================================================================
    // SECCIONES — reordenar / mostrar / ocultar
    // ============================================================================

    function applySectionOrderAndVisibility() {
        var order = settings.sectionOrder;

        /* Los ajustes viven dentro de esta seccion. Ocultarla dejaria el panel
           sin forma de volver a abrirlos, asi que se reordena como las demas
           pero no se apaga. */
        if (settings.sectionVisibility && typeof settings.sectionVisibility.tools !== 'undefined') {
            settings.sectionVisibility.tools = true;
        }

        var lastVisibleId = null;
        for (var i = order.length - 1; i >= 0; i--) {
            if (settings.sectionVisibility[order[i]]) { lastVisibleId = order[i]; break; }
        }

        order.forEach(function (id, index) {
            var el = document.querySelector('[data-section="' + id + '"]');
            if (!el) return;
            el.style.order = index;
            el.style.display = settings.sectionVisibility[id] ? '' : 'none';
            if (id === 'status') {
                el.style.marginTop = (id === lastVisibleId) ? 'auto' : '0';
            }
        });
    }

    function renderSectionList() {
        var list = document.getElementById('sectionList');
        if (!list) return;
        list.innerHTML = '';

        settings.sectionOrder.forEach(function (id, index) {
            var li = document.createElement('li');
            li.className = 'section-item' + (settings.sectionVisibility[id] ? '' : ' hidden-section');
            li.setAttribute('draggable', 'true');
            li.setAttribute('data-section-id', id);

            var handle = document.createElement('span');
            handle.className = 'drag-handle';
            handle.setAttribute('aria-hidden', 'true');
            handle.textContent = '⠿';

            var label = document.createElement('span');
            label.className = 'section-item-label';
            label.textContent = sectionLabel(id);

            var controls = document.createElement('div');
            controls.className = 'section-item-controls';

            var upBtn = document.createElement('button');
            upBtn.type = 'button';
            upBtn.className = 'section-move';
            upBtn.title = T('aa.moveUp');
            upBtn.setAttribute('aria-label', T('aa.moveUpAria'));
            upBtn.textContent = '▲';
            upBtn.disabled = index === 0;
            upBtn.addEventListener('click', function () { moveSection(id, -1); });

            var downBtn = document.createElement('button');
            downBtn.type = 'button';
            downBtn.className = 'section-move';
            downBtn.title = T('aa.moveDown');
            downBtn.setAttribute('aria-label', T('aa.moveDownAria'));
            downBtn.textContent = '▼';
            downBtn.disabled = index === settings.sectionOrder.length - 1;
            downBtn.addEventListener('click', function () { moveSection(id, 1); });

            var toggleLabel = document.createElement('label');
            toggleLabel.className = 'section-visibility-toggle';
            toggleLabel.title = T('aa.toggleVisibility');

            var toggleInput = document.createElement('input');
            toggleInput.type = 'checkbox';
            toggleInput.className = 'toggle-checkbox';
            toggleInput.checked = settings.sectionVisibility[id];
            toggleInput.title = T('aa.toggleVisibility');
            toggleInput.addEventListener('change', function () {
                toggleSectionVisibility(id, this.checked);
            });
            toggleLabel.appendChild(toggleInput);

            controls.appendChild(upBtn);
            controls.appendChild(downBtn);
            controls.appendChild(toggleLabel);

            li.appendChild(handle);
            li.appendChild(label);
            li.appendChild(controls);

            li.addEventListener('dragstart', function (e) {
                draggedSectionId = id;
                li.classList.add('dragging');
                if (e.dataTransfer) e.dataTransfer.effectAllowed = 'move';
            });
            li.addEventListener('dragend', function () {
                li.classList.remove('dragging');
            });
            li.addEventListener('dragover', function (e) {
                e.preventDefault();
                li.classList.add('drag-over');
            });
            li.addEventListener('dragleave', function () {
                li.classList.remove('drag-over');
            });
            li.addEventListener('drop', function (e) {
                e.preventDefault();
                li.classList.remove('drag-over');
                if (draggedSectionId && draggedSectionId !== id) {
                    reorderSection(draggedSectionId, id);
                }
                draggedSectionId = null;
            });

            list.appendChild(li);
        });
    }

    function moveSection(id, delta) {
        var order = settings.sectionOrder;
        var index = order.indexOf(id);
        var newIndex = index + delta;
        if (newIndex < 0 || newIndex >= order.length) return;

        var tmp = order[index];
        order[index] = order[newIndex];
        order[newIndex] = tmp;

        applySectionOrderAndVisibility();
        renderSectionList();
        saveSettings();
    }

    function reorderSection(draggedId, targetId) {
        var order = settings.sectionOrder;
        var fromIndex = order.indexOf(draggedId);
        var toIndex = order.indexOf(targetId);
        if (fromIndex === -1 || toIndex === -1) return;

        order.splice(fromIndex, 1);
        order.splice(toIndex, 0, draggedId);

        applySectionOrderAndVisibility();
        renderSectionList();
        saveSettings();
    }

    function toggleSectionVisibility(id, isVisible) {
        /* La seccion de pestanas ya se puede ocultar. Estaba clavada porque
           dentro vivian los ajustes, y esconderla dejaba al usuario sin la
           puerta para volver a ensenarla. Ahora los ajustes se abren desde el
           engranaje de la cabecera, que no se va a ninguna parte. */
        var visibleCount = Object.keys(settings.sectionVisibility).filter(function (key) {
            return settings.sectionVisibility[key];
        }).length;

        if (!isVisible && visibleCount <= 1) {
            showToast(T('aa.toast.atLeastOneSectionVisible'), true);
            renderSectionList();
            return;
        }

        settings.sectionVisibility[id] = isVisible;
        applySectionOrderAndVisibility();
        renderSectionList();
        saveSettings();
    }

    // ============================================================================
    // QUICK ACTIONS
    // ============================================================================

    function handleQuickAction(action, buttonElement) {
        animateButton(buttonElement);

        var script = '';
        switch (action) {
            case 'centerBoth': script = 'quickCenterBoth()'; break;
            case 'matchSize': script = 'quickMatchSize()'; break;
            case 'stackVertical': script = 'quickStack("vertical", ' + settings.stackSpacing + ')'; break;
            case 'stackHorizontal': script = 'quickStack("horizontal", ' + settings.stackSpacing + ')'; break;
            case 'flipH': script = 'quickFlip("horizontal")'; break;
            case 'flipV': script = 'quickFlip("vertical")'; break;
        }

        if (!script) return;

        csInterface.evalScript(script, function (result) {
            if (result && result.indexOf('Error:') === 0) {
                showToast(translateHostResult(result), true);
            } else {
                showToast('✓ ' + getQuickActionName(action));
            }
        });
    }

    function getQuickActionName(action) {
        var names = {
            centerBoth: T('aa.quickActionCenterBoth'),
            matchSize: T('aa.quickActionMatchSize'),
            stackVertical: T('aa.quickActionStackVertical'),
            stackHorizontal: T('aa.quickActionStackHorizontal'),
            flipH: T('aa.quickActionFlipH'),
            flipV: T('aa.quickActionFlipV')
        };
        return names[action] || action;
    }

    // ============================================================================
    // TRANSFORM
    // ============================================================================

    function handleTransform(transform, buttonElement) {
        animateButton(buttonElement);

        csInterface.evalScript('copyTransform("' + transform + '")', function (result) {
            if (result && result.indexOf('Error:') === 0) {
                showToast(translateHostResult(result), true);
            } else {
                var names = { copyPosition: T('aa.transformPosition'), copyAnchor: T('aa.transformAnchor'), copyScale: T('aa.transformScale') };
                var name = names[transform] || transform;
                showToast('✓ ' + name);
            }
        });
    }

    // ============================================================================
    // ALIGNMENT
    // ============================================================================

    function handleAlignment(direction, shiftPressed, buttonElement) {
        lastAction = {
            direction: direction,
            doubleDuty: shiftPressed,
            mode: currentMode,
            target: currentTarget
        };

        updateLastAction();
        animateButton(buttonElement);

        var script = 'executeAlignment(' +
            '"' + direction + '", ' +
            '"' + currentMode + '", ' +
            shiftPressed + ', ' +
            '"' + currentTarget + '", ' +
            settings.padding +
            ')';

        csInterface.evalScript(script, function (result) {
            if (result && result !== 'undefined') {
                if (result.indexOf('Error:') === 0) {
                    showToast(translateHostResult(result), true);
                } else {
                    showToast('✓ ' + getActionName(direction, currentMode, shiftPressed));
                }
            }
        });
    }

    // ============================================================================
    // DISTRIBUTE
    // ============================================================================

    function handleDistribute(direction, buttonElement) {
        animateButton(buttonElement);

        csInterface.evalScript('distributeLayersEvenly("' + direction + '")', function (result) {
            if (result && result !== 'undefined') {
                if (result.indexOf('Error:') === 0) {
                    showToast(translateHostResult(result), true);
                } else {
                    showToast('✓ ' + T('aa.toast.distributed') + ' ' + (direction === 'horizontal' ? T('aa.horizontal').toLowerCase() : T('aa.vertical').toLowerCase()));
                }
            }
        });
    }

    // ============================================================================
    // UI HELPERS
    // ============================================================================

    function animateButton(buttonElement) {
        if (!settings.animateFeedback || !buttonElement) return;
        buttonElement.classList.add('processing');
        setTimeout(function () {
            buttonElement.classList.remove('processing');
        }, 500);
    }

    function getActionName(direction, mode, doubleDuty) {
        var names = {
            topLeft: T('aa.topLeft'), top: T('aa.top'), topRight: T('aa.topRight'),
            left: T('aa.left'), center: T('aa.center'), right: T('aa.right'),
            bottomLeft: T('aa.bottomLeft'), bottom: T('aa.bottom'), bottomRight: T('aa.bottomRight'),
            centerH: T('aa.centerH'), centerV: T('aa.centerV')
        };
        var action = names[direction] || direction;
        var modeText = doubleDuty ? 'A+A' : (mode === 'align' ? T('aa.align') : T('aa.anchor'));
        return action + ' (' + modeText + ')';
    }

    function updateLastAction() {
        if (!lastAction) return;
        var el = document.getElementById('lastAction');
        var text = document.getElementById('lastActionText');
        text.textContent = '⟲ ' + getActionName(lastAction.direction, lastAction.mode, lastAction.doubleDuty) + ' · R';
        el.hidden = false;
    }

    function showToast(message, isError) {
        /* Apagado es apagado, errores incluidos. Dejar pasar los errores
           convertia el ajuste en media promesa: quien lo apaga quiere el panel
           callado, no callado a medias. Los ajustes avisan de que esto tambien
           silencia los fallos, que es lo que hace que sea una preferencia y no
           una trampa. */
        if (!settings.showToasts) return;

        var toast = document.getElementById('toast');
        var toastMessage = document.getElementById('toastMessage');
        toastMessage.textContent = message;
        toast.classList.toggle('error', !!isError);
        toast.classList.add('show');
        clearTimeout(showToast._t);
        showToast._t = setTimeout(function () {
            toast.classList.remove('show');
        }, settings.toastDuration || 2000);
    }

    // ============================================================================
    // SETTINGS PERSISTENCE
    // ============================================================================

    function saveSettings() {
        try {
            localStorage.setItem('alignAnchorSettings', JSON.stringify(settings));
        } catch (e) {
            /* almacenamiento no disponible */
        }
    }

    function loadSettings() {
        settings = JSON.parse(JSON.stringify(defaultSettings));

        try {
            var saved = localStorage.getItem('alignAnchorSettings');
            if (saved) {
                var parsed = JSON.parse(saved);
                for (var key in parsed) {
                    if (!Object.prototype.hasOwnProperty.call(parsed, key)) continue;

                    if (key === 'sectionVisibility' && parsed[key]) {
                        settings.sectionVisibility = Object.assign({}, settings.sectionVisibility, parsed[key]);
                    } else if (key === 'sectionOrder' && Array.isArray(parsed[key])) {
                        /* Al aparecer una seccion nueva, el orden guardado se
                           queda corto. Descartarlo entero perderia la
                           ordenacion que el usuario habia elegido, asi que se
                           conserva lo que sigue siendo valido y se anaden al
                           final las que falten. */
                        var kept = [];
                        for (var oi = 0; oi < parsed[key].length; oi++) {
                            if (defaultSectionOrder.indexOf(parsed[key][oi]) >= 0 && kept.indexOf(parsed[key][oi]) < 0) {
                                kept.push(parsed[key][oi]);
                            }
                        }
                        for (var di = 0; di < defaultSectionOrder.length; di++) {
                            if (kept.indexOf(defaultSectionOrder[di]) < 0) kept.push(defaultSectionOrder[di]);
                        }
                        settings.sectionOrder = kept;
                    } else if (Object.prototype.hasOwnProperty.call(settings, key)) {
                        settings[key] = parsed[key];
                    }
                }
            }
        } catch (e) {
            /* nada guardado aún o datos corruptos */
        }

        // 'auto' era el valor por defecto anterior, así que un ajuste guardado
        // con ese valor significa "nunca lo toqué" — pasa a seguir el acento
        // compartido de EditKit. Una elección explícita (teal/ámbar/personalizado)
        // se respeta.
        if (settings.accentTheme === 'auto' && !accentMigrationDone()) {
            settings.accentTheme = 'editkit';
            markAccentMigrationDone();
            saveSettings();
        }

        syncSettingsUI();
    }

    var ACCENT_MIGRATION_KEY = 'alignAnchorAccentMigrated';
    function accentMigrationDone() {
        try { return localStorage.getItem(ACCENT_MIGRATION_KEY) === '1'; } catch (e) { return false; }
    }
    function markAccentMigrationDone() {
        try { localStorage.setItem(ACCENT_MIGRATION_KEY, '1'); } catch (e) {}
    }

    function syncSettingsUI() {
        document.getElementById('paddingInput').value = settings.padding;
        document.getElementById('stackSpacing').value = settings.stackSpacing;
        document.getElementById('defaultModeSelect').value = settings.defaultMode;
        document.getElementById('defaultTargetSelect').value = settings.defaultTarget;
        document.getElementById('rememberLastModeCheckbox').checked = settings.rememberLastMode;
        document.getElementById('createUndoCheckbox').checked = settings.createUndo;
        document.getElementById('animateCheckbox').checked = settings.animateFeedback;
        document.getElementById('showToastsCheckbox').checked = settings.showToasts;
        document.getElementById('toastDurationInput').value = settings.toastDuration;

        document.getElementById('accentThemeSelect').value = settings.accentTheme;
        document.getElementById('customAccentInput').value = settings.customAccentColor;
        document.getElementById('defaultSizeSelect').value = settings.defaultPanelSize;
        document.getElementById('densitySelect').value = settings.density;
        document.getElementById('reticleMaxSelect').value = settings.reticleMax;
        document.getElementById('showBadgesCheckbox').checked = settings.showShortcutBadges;
        document.getElementById('showLabelsCheckbox').checked = settings.showTextLabels;

        var customRow = document.getElementById('customAccentRow');
        if (customRow) customRow.hidden = settings.accentTheme !== 'custom';

        renderSectionList();
    }

    document.addEventListener('editkit-lang-changed', function () {
        renderSectionList();
        if (lastAction) updateLastAction();
    });

    /* La puerta que usa la ventana de al lado. Se expone lo minimo: la
       alineacion sigue siendo cosa de este archivo, y lo unico que necesita el
       de al lado es poder dispararla, repetir la ultima y hablar por el mismo
       aviso. */
    window.AlignItApi = {
        toast: showToast,
        align: handleAlignment,
        repeat: function () {
            if (!lastAction) return;
            handleAlignment(lastAction.direction, lastAction.doubleDuty);
        },
        settings: function () { return settings; }
    };

    init();
})();
