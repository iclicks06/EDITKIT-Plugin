/* ============================================================================
   ALIGNIT — SECRETO: EL RETÍCULO INQUIETO

   Cinco toques seguidos sobre el nombre "AlignIt" y las nueve celdas del
   retículo se desordenan un momento y vuelven solas a su sitio, una detrás de
   otra. Es lo que hace el panel, contado en un segundo y medio.

   Se dispara desde el nombre y no desde el retículo a propósito: los botones
   del retículo alinean capas de verdad, y un secreto no puede pedirle al
   usuario que ejecute cinco veces una operación sobre su composición. El
   nombre no hace nada más, así que ahí no estorba.

   Nada de esto toca la composición: es una transformación CSS sobre los
   botones, que se quita sola.

   El archivo también lleva la cuenta de las alineaciones hechas, para la
   bitácora del shell.
   ============================================================================ */
(function () {
    "use strict";

    var log = window.EditKitLog;

    // ------------------------------------------------------------------
    // Contador de alineaciones
    // ------------------------------------------------------------------
    if (log && window.CSInterface && CSInterface.prototype && CSInterface.prototype.evalScript) {
        var MARK = "__editkit_log_wrapped";
        if (!CSInterface.prototype[MARK]) {
            CSInterface.prototype[MARK] = true;
            /* Las que mueven capas. getSelectionInfo y compañía pasan por el
               mismo sitio decenas de veces por minuto y no son trabajo hecho. */
            var COUNTED = /^(executeAlignment|quickCenterBoth|quickMatchSize|quickStack|quickFlip|copyTransform|distributeLayersEvenly|moveAnchorPoint)\(/;
            var orig = CSInterface.prototype.evalScript;
            CSInterface.prototype.evalScript = function (script, cb) {
                try {
                    if (typeof script === "string" && COUNTED.test(script)) log.bump("aligns");
                } catch (e) {}
                return orig.call(this, script, cb);
            };
        }
    }

    // ------------------------------------------------------------------
    // El secreto
    // ------------------------------------------------------------------
    var brand = document.querySelector(".brand-name");
    var cells = document.querySelectorAll(".reticle-grid .btn-align");
    if (!brand || !cells.length) return;

    var running = false;

    function play() {
        if (running) return;
        running = true;
        if (log) log.found("v2");

        var list = Array.prototype.slice.call(cells);
        list.forEach(function (el) {
            /* Desorden reproducible-ish pero distinto cada vez, y siempre
               pequeño: la gracia es que se note que se fueron, no que el panel
               parezca roto. */
            var dx = (Math.random() * 2 - 1) * 26;
            var dy = (Math.random() * 2 - 1) * 22;
            var rot = (Math.random() * 2 - 1) * 12;
            el.classList.add("egg-scatter");
            el.style.transform = "translate(" + dx.toFixed(1) + "px," + dy.toFixed(1) + "px) rotate(" + rot.toFixed(1) + "deg)";
        });

        // Y de vuelta, una a una, con un rebote corto.
        setTimeout(function () {
            list.forEach(function (el, i) {
                setTimeout(function () {
                    el.classList.add("egg-snap");
                    el.style.transform = "";
                }, i * 45);
            });
        }, 620);

        setTimeout(function () {
            list.forEach(function (el) {
                el.classList.remove("egg-scatter", "egg-snap");
                el.style.transform = "";
            });
            running = false;
        }, 620 + list.length * 45 + 700);
    }

    // ------------------------------------------------------------------
    // SECRETO: MARGEN NO ENCONTRADO
    // ------------------------------------------------------------------
    /* El margen admite cualquier numero, y hay uno que casi todo el mundo ha
       escrito alguna vez por curiosidad. No cambia el comportamiento: el 404
       sigue siendo un margen de 404 pixeles, que es lo que el usuario pidio.
       Solo se le contesta. */
    (function () {
        var pad = document.getElementById("paddingInput");
        if (!pad) return;
        pad.addEventListener("change", function () {
            if (parseFloat(pad.value) !== 404) return;
            if (log) log.found("k6");
            var api = window.AlignItApi;
            var lang = "es";
            try { lang = localStorage.getItem("editkit_lang") || "es"; } catch (e) {}
            var msg = (lang === "en") ? "Margin not found" : "Margen no encontrado";
            if (api && api.toast) api.toast(msg);
        });
    })();

    var taps = 0, last = 0;
    brand.addEventListener("click", function () {
        try {
            var sel = window.getSelection();
            if (sel && sel.removeAllRanges) sel.removeAllRanges();
        } catch (e) {}
        var now = Date.now();
        taps = (now - last < 600) ? taps + 1 : 1;
        last = now;
        if (taps < 5) return;
        taps = 0;
        play();
    });
})();
