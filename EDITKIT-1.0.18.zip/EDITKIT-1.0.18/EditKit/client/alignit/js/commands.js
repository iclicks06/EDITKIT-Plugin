/* ============================================================================
   ALIGNIT — LO QUE SABE HACER, EN LA CENTRALITA

   Alinear, anclar, distribuir por el reticulo y las acciones rapidas. Cada
   comando pulsa el boton que ya existia en vez de repetir su logica: main.js
   sigue siendo el dueno de la alineacion, y asi no hay dos sitios donde
   arreglar la misma cosa.

   Antes esto vivia en tools.js, dentro de este mismo panel. tools.js se mudo
   con las herramientas a la ventana del medio, y lo que era de AlignIt se
   quedo aqui. La ventaja no es solo de orden: desde alli se puede llamar a
   cualquiera de estas acciones —la centralita lleva el recado— sin que este
   archivo tenga que saber que existe nadie mas.
   ============================================================================ */
(function () {
    "use strict";

    var C = window.EditKitCommands;
    if (!C) return;

    function T(key) { return (window.EditKitI18n && window.EditKitI18n.t(key)) || key; }

    function clicker(sel) {
        return function () {
            var el = document.querySelector(sel);
            if (el) el.click();
        };
    }

    function reg(id, group, key, run, keys) {
        C.register({
            id: id,
            group: function () { return T(group); },
            label: function () { return T(key); },
            run: run,
            keys: keys || ""
        });
    }

    function api() { return window.AlignItApi || null; }

    function each(sel, fn) {
        var els = document.querySelectorAll(sel);
        for (var i = 0; i < els.length; i++) fn(els[i], i);
    }

    function registerAll() {
        var G_ALIGN = "aa.tabAlign", G_QUICK = "aa.quickActions",
            G_DIST = "aa.distribute", G_TR = "aa.transform";

        var dirs = [
            ["topLeft", "aa.topLeft", "q"], ["top", "aa.top", "w"], ["topRight", "aa.topRight", "e"],
            ["left", "aa.left", "a"], ["center", "aa.center", "s"], ["right", "aa.right", "d"],
            ["bottomLeft", "aa.bottomLeft", "z"], ["bottom", "aa.bottom", "x"], ["bottomRight", "aa.bottomRight", "c"],
            ["centerH", "aa.centerH", "h"], ["centerV", "aa.centerV", "v"]
        ];
        for (var i = 0; i < dirs.length; i++) {
            (function (d) {
                reg("align." + d[0], G_ALIGN, d[1], clicker('[data-direction="' + d[0] + '"]'), d[2]);
            })(dirs[i]);
        }

        reg("align.mode", G_ALIGN, "aa.switchModeShortcut", clicker("#modeToggle"), "Tab");
        reg("align.repeat", G_ALIGN, "aa.repeatAction", function () {
            var a = api();
            if (a && a.repeat) a.repeat();
        }, "r");

        reg("dist.h", G_DIST, "aa.distributeHTip", clicker('[data-distribute="horizontal"]'), "");
        reg("dist.v", G_DIST, "aa.distributeVTip", clicker('[data-distribute="vertical"]'), "");

        reg("tr.copyPosition", G_TR, "aa.copyPositionTip", clicker('[data-transform="copyPosition"]'), "");
        reg("tr.copyAnchor", G_TR, "aa.copyAnchorTip", clicker('[data-transform="copyAnchor"]'), "");
        reg("tr.copyScale", G_TR, "aa.copyScaleTip", clicker('[data-transform="copyScale"]'), "");

        var quick = [
            ["centerBoth", "aa.centerBothTip"], ["matchSize", "aa.matchSizeTip"],
            ["stackVertical", "aa.stackVerticalTip"], ["stackHorizontal", "aa.stackHorizontalTip"],
            ["flipH", "aa.flipHTip"], ["flipV", "aa.flipVTip"]
        ];
        for (i = 0; i < quick.length; i++) {
            (function (q) {
                reg("quick." + q[0], G_QUICK, q[1], clicker('[data-action="' + q[0] + '"]'), "");
            })(quick[i]);
        }
    }

    // ------------------------------------------------------------------
    // El panel ensena sus atajos
    // ------------------------------------------------------------------
    /* Cada boton que tenga comando detras va aprendiendo a contarlo. La
       descripcion sigue diciendo lo mismo; detras, y solo cuando la accion ya
       se ha usado varias veces, aparece el atajo. */
    var COACH = [
        ['[data-direction="topLeft"]', "align.topLeft"], ['[data-direction="top"]', "align.top"],
        ['[data-direction="topRight"]', "align.topRight"], ['[data-direction="left"]', "align.left"],
        ['[data-direction="center"]', "align.center"], ['[data-direction="right"]', "align.right"],
        ['[data-direction="bottomLeft"]', "align.bottomLeft"], ['[data-direction="bottom"]', "align.bottom"],
        ['[data-direction="bottomRight"]', "align.bottomRight"],
        ['[data-direction="centerH"]', "align.centerH"], ['[data-direction="centerV"]', "align.centerV"],
        ['[data-action="centerBoth"]', "quick.centerBoth"], ['[data-action="matchSize"]', "quick.matchSize"],
        ['[data-action="stackVertical"]', "quick.stackVertical"],
        ['[data-action="stackHorizontal"]', "quick.stackHorizontal"],
        ['[data-action="flipH"]', "quick.flipH"], ['[data-action="flipV"]', "quick.flipV"],
        ['[data-distribute="horizontal"]', "dist.h"], ['[data-distribute="vertical"]', "dist.v"],
        ['[data-transform="copyPosition"]', "tr.copyPosition"],
        ['[data-transform="copyAnchor"]', "tr.copyAnchor"],
        ['[data-transform="copyScale"]', "tr.copyScale"]
    ];

    function applyCoaching() {
        for (var i = 0; i < COACH.length; i++) {
            var el = document.querySelector(COACH[i][0]);
            if (!el) continue;
            /* La descripcion base se recalcula, nunca se lee del atributo: al
               cambiar de idioma i18n reescribe el title entero, y guardarlo
               una vez dejaria la pista pegada a un texto que ya no esta. */
            var key = el.getAttribute("data-i18n-title");
            var base = key ? T(key) : (el.getAttribute("data-base-title") || el.title || "");
            if (!key) el.setAttribute("data-base-title", base);
            C.decorate(el, COACH[i][1], base);
        }
    }

    // Solo cuenta lo que sale del raton: quien ya usa el atajo no necesita que
    // se lo ensenen.
    function countMouseUse() {
        for (var i = 0; i < COACH.length; i++) {
            (function (sel, id) {
                var el = document.querySelector(sel);
                if (!el) return;
                el.addEventListener("click", function () {
                    C.bump(id);
                    applyCoaching();
                });
            })(COACH[i][0], COACH[i][1]);
        }
    }


    // ------------------------------------------------------------------
    // Las pestanas, cuando los nombres dejan de caber
    // ------------------------------------------------------------------
    /* Tres pestanas, dos idiomas y cualquier ancho de panel: no hay punto de
       corte que se pueda escribir de antemano sin equivocarse en la mitad de
       los casos. Se quita la clase, se mira si algun nombre se esta cortando y
       se vuelve a poner.

       El vigilante con intervalo no es plan B de ResizeObserver: el Chromium de
       CEP 9 es anterior a el, y donde si existe no dispara mientras el panel no
       se esta dibujando. Y medir una sola vez por cambio de ancho no basta:
       cuando el shell mueve un divisor, la maquetacion del <iframe> puede no
       haber terminado en el instante en que llega el aviso. Se mide ahora y
       otra vez un momento despues, cuando todo esta quieto. */
    function fitTabs() {
        var app = document.querySelector(".app");
        var bar = document.querySelector(".tab-bar");
        if (!app || !bar) return;
        if (bar.offsetParent === null) return;

        app.classList.remove("tabs-icon-only");
        var labels = bar.querySelectorAll(".tab-label");
        for (var i = 0; i < labels.length; i++) {
            /* Una etiqueta de ancho cero no esta apretada: es que todavia no
               esta maquetada. Sin este descarte, la barra se quedaria en iconos
               para siempre aunque sobrara sitio. */
            if (labels[i].clientWidth <= 0) continue;
            /* Sin margen a proposito: la etiqueta es un <span> dentro de un
               flex, y mientras le sobre sitio scrollWidth y clientWidth
               coinciden. Cualquier holgura aqui daria siempre positivo. */
            if (labels[i].scrollWidth > labels[i].clientWidth + 1) {
                app.classList.add("tabs-icon-only");
                return;
            }
        }
    }

    function scheduleFit() {
        fitTabs();
        setTimeout(fitTabs, 220);
    }

    function watchTabs() {
        scheduleFit();
        window.addEventListener("resize", scheduleFit);

        var bar = document.querySelector(".tab-bar");
        if (!bar) return;
        if (window.ResizeObserver) {
            try { new ResizeObserver(scheduleFit).observe(bar); } catch (e) {}
        }
        /* El vigilante solo trabaja mientras se vea el panel. Uno de CEP no se
           descarga al cambiar de pestana: se queda cargado detras, y preguntar
           por el ancho de la barra dos veces por segundo obliga al navegador a
           recalcular la maquetacion cada vez, durante horas, para nadie. Al
           volver a aparecer se mide en el acto. */
        var last = bar.offsetWidth;
        function watch() {
            var w = bar.offsetWidth;
            if (w === last) return;
            last = w;
            scheduleFit();
        }
        setInterval(function () {
            var A = window.EditKitAwake;
            if (A && A.idle()) return;
            watch();
        }, 400);
        if (window.EditKitAwake) window.EditKitAwake.onWake(watch);
    }

    function boot() {
        registerAll();
        applyCoaching();
        countMouseUse();
        watchTabs();
        each(".tab, .size-btn", function (b) {
            b.addEventListener("click", function () { setTimeout(scheduleFit, 0); });
        });

        /* El interruptor de atajos se mudo a los ajustes de la ventana del
           medio, pero gobierna el registro entero y este panel tiene que
           obedecerlo igual. Se lee lo guardado al arrancar y se escucha el
           aviso para cuando cambie mientras el panel esta abierto. */
        try {
            if (localStorage.getItem("editkit_shortcuts_off") === "1") C.setEnabled(false);
        } catch (e) {}

        document.addEventListener("editkit-lang-changed", function () {
            applyCoaching();
            setTimeout(scheduleFit, 0);
        });
        document.addEventListener("editkit-shortcuts-changed", applyCoaching);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
})();
