/*
 * library-io.js — preset library interop and the right-click menu. EXPERIMENTAL.
 *
 * Two things live here.
 *
 * 1. READING OTHER PLUGINS' LIBRARIES. Flow exports a .flow file that is a
 *    plain JSON array of { _id, name, value: [x1, y1, x2, y2] }. That is the de
 *    facto interchange shape for ease libraries, so EaseIt both reads it and
 *    writes it — under .easeit, but byte-compatible, so a library exported here
 *    opens in any plugin that accepts the same array.
 *
 *    The catch worth knowing: four numbers can only describe a two-point
 *    bezier. EaseIt presets built from a formula (Elastic, Bounce) or carrying
 *    extra midpoints have no equivalent in that shape, so they are left out of
 *    an export rather than silently flattened into something that animates
 *    differently — and the user is told how many were skipped.
 *
 * 2. THE RIGHT-CLICK MENU on preset tiles, in the shape Flow uses: edit value,
 *    rename, delete, copy value as, manage library, select library. The panel
 *    suppresses the browser context menu globally (no-context-menu.js), so
 *    "contextmenu" is free to mean this instead.
 *
 * Collections are read and written straight through the "easeit_collections" key,
 * the same store EaseIt uses, and window.EaseItLibrary.refresh() redraws the
 * grid afterwards. Nothing here keeps its own copy of the library.
 */
(function () {
  "use strict";

  var COLLECTIONS_KEY = "easeit_collections";
  var EXT = "easeit";

  function t(key, fallback) {
    var s = window.EditKitI18n && window.EditKitI18n.t ? window.EditKitI18n.t(key) : null;
    return (s && s !== key) ? s : fallback;
  }
  function say(msg, kind, detail) {
    if (window.EaseItCurve && window.EaseItCurve.status) window.EaseItCurve.status(msg, kind, detail);
  }
  function lib() { return window.EaseItLibrary || null; }

  // ---------------------------------------------------------------- storage
  function readCollections() {
    try {
      var c = JSON.parse(localStorage.getItem(COLLECTIONS_KEY));
      if (c && c.items && c.items.length) return c;
    } catch (e) {}
    return null;
  }
  function writeCollections(c) {
    try { localStorage.setItem(COLLECTIONS_KEY, JSON.stringify(c)); return true; } catch (e) { return false; }
  }
  /* The built-ins are not stored anywhere: EaseIt generates them and hides the
     ones a collection has "removed", per collection, under this key. A brand
     new collection therefore starts life showing all of them, which is not what
     a new *library* means to anyone coming from Flow. Listing every built-in
     name in its hidden set is what makes it start empty — and because it is the
     same mechanism the "Quitar presets" mode uses, the user can bring any of
     them back. */
  var HIDDEN_BASE = "easeit_preset_hidden";
  function hiddenKey(id) { return HIDDEN_BASE + ":" + (id || "default"); }
  function readHidden(id) {
    try { return JSON.parse(localStorage.getItem(hiddenKey(id))) || []; } catch (e) { return []; }
  }
  function writeHidden(id, arr) {
    try { localStorage.setItem(hiddenKey(id), JSON.stringify(arr)); } catch (e) {}
  }

  /* Every built-in name there is: the ones the grid is showing right now, plus
     the ones the active collection has hidden. Read off the DOM because a
     built-in tile carries its own name as data-key (custom ones carry "c:<id>"),
     so no list has to be kept in step with EaseIt's own. */
  function allBuiltinNames(activeId) {
    var seen = {}, out = [];
    var tiles = document.querySelectorAll('#presetGrid [data-type="builtin"]');
    for (var i = 0; i < tiles.length; i++) {
      var k = tiles[i].getAttribute("data-key");
      if (k && !seen[k]) { seen[k] = 1; out.push(k); }
    }
    var hid = readHidden(activeId);
    for (var j = 0; j < hid.length; j++) {
      if (hid[j] && !seen[hid[j]]) { seen[hid[j]] = 1; out.push(hid[j]); }
    }
    return out;
  }

  function activePresets(c) {
    if (!c) return [];
    return (c.libs && c.libs[c.active]) || [];
  }

  // ------------------------------------------------------------- conversion
  function isFiniteNum(n) { return typeof n === "number" && isFinite(n); }

  /* Flow's array -> EaseIt presets. Anything without four usable numbers is
     dropped: a preset that can't describe a curve is worse than no preset. */
  function fromInterchange(arr) {
    var out = [];
    for (var i = 0; i < arr.length; i++) {
      var p = arr[i];
      if (!p || !p.name) continue;
      var v = p.value || p.v;
      if (!v || v.length !== 4) continue;
      var nums = [Number(v[0]), Number(v[1]), Number(v[2]), Number(v[3])];
      if (!nums.every(isFiniteNum)) continue;
      out.push({ name: String(p.name), v: nums });
    }
    return out;
  }

  function uuidish() {
    function part(n) {
      var s = "";
      for (var i = 0; i < n; i++) s += Math.floor(Math.random() * 16).toString(16);
      return s;
    }
    return part(8) + "-" + part(4) + "-4" + part(3) + "-a" + part(3) + "-" + part(12);
  }

  /* EaseIt presets -> the interchange array. Returns the skipped ones too so
     the caller can say what didn't make it. */
  function toInterchange(presets) {
    var out = [], skipped = [];
    for (var i = 0; i < presets.length; i++) {
      var p = presets[i];
      if (!p || !p.name) continue;
      if (p.v && p.v.length === 4 && p.v.every(isFiniteNum)) {
        out.push({ _id: uuidish(), name: String(p.name), value: [p.v[0], p.v[1], p.v[2], p.v[3]] });
      } else {
        skipped.push(String(p.name));
      }
    }
    return { list: out, skipped: skipped };
  }

  /* Accepts a .flow / .easeit array, and also EaseIt's own older export object
     so nothing that used to import stops importing. */
  function parseLibraryFile(text) {
    var data;
    try { data = JSON.parse(text); } catch (e) { return null; }
    if (Object.prototype.toString.call(data) === "[object Array]") return fromInterchange(data);
    if (data && Object.prototype.toString.call(data.presets) === "[object Array]") {
      // the native shape already carries fn / nodes presets; keep them whole
      return data.presets.filter(function (p) { return p && p.name && (p.v || p.nodes || p.fn); });
    }
    return null;
  }

  // ------------------------------------------------------------------- host
  function cs() {
    try { return new CSInterface(); } catch (e) { return null; }
  }

  function importLibrary() {
    var iface = cs();
    if (!iface) { say(t("lib.noHost", "Sin conexión con la aplicación"), "error"); return; }
    iface.evalScript("easeit_importPresets()", function (raw) {
      var res;
      try { res = JSON.parse(raw); } catch (e) { say(t("lib.importFailed", "Falló la importación"), "error", raw); return; }
      if (!res.success) {
        if (!res.canceled) say(res.error || t("lib.importFailed", "Falló la importación"), "error", raw);
        return;
      }
      var presets = parseLibraryFile(res.data);
      if (!presets || !presets.length) {
        say(t("lib.noPresets", "No se encontraron presets en ese archivo"), "error");
        return;
      }
      askDestination(presets, nextCollectionName());
    });
  }

  /* A new library is named the way the app names things, not the way the file
     on disk happened to be named: "Nueva colección 3" reads as part of the
     panel, "zick.films" reads as somebody else's filename. The number is the
     first one not already taken, so a rename can never collide with it. */
  function nextCollectionName() {
    var base = t("lib.newCollection", "Nueva colección");
    var c = readCollections();
    var taken = {};
    if (c && c.items) {
      for (var i = 0; i < c.items.length; i++) taken[String(c.items[i].name || "")] = 1;
    }
    var n = 1;
    while (taken[base + " " + n]) n++;
    return base + " " + n;
  }

  /* Flow lists a library oldest-first, and so does the file. EaseIt's grid
     shows the newest custom preset first, so a batch written in file order
     comes out backwards. Storing it reversed is what makes it READ in file
     order — the compensation lives here, at the one place that knows the file
     had an order worth keeping. */
  function inFileOrder(presets) { return presets.slice().reverse(); }

  function askDestination(presets, suggestedName) {
    var L = lib();
    if (!L || !L.modal) { importInto(null, presets, null); return; }
    var c = readCollections();
    var here = c ? collectionName(c, c.active) : "";
    L.modal({
      title: t("lib.importTitle", "Importar librería"),
      wide: true,
      bodyHTML: "<p>" + presets.length + " " +
        t("lib.importFound", "presets encontrados.") + " " +
        t("lib.importWhere", "¿Dónde quieres agregarlos?") + "</p>" +
        "<p class='tip'>" + t("lib.importIntoHint", "Añadir los suma a la librería abierta") +
        (here ? " (<b>" + escapeHTML(here) + "</b>)" : "") + ". " +
        t("lib.importNewHint", "Crear una nueva los deja aparte, sin los presets de fábrica.") +
        "</p>",
      okText: t("lib.importNew", "Nueva librería"),
      cancelText: t("lib.importHere", "Añadir aquí"),
      onOk: function () { importInto(suggestedName, presets, null); },
      onCancel: function () { importInto(null, presets, null); }
    });
  }

  function collectionName(c, id) {
    if (!c || !c.items) return "";
    for (var i = 0; i < c.items.length; i++) if (c.items[i].id === id) return c.items[i].name || "";
    return "";
  }
  function escapeHTML(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  function newId() {
    return "k" + Date.now().toString(36) + Math.floor(Math.random() * 1000000).toString(36);
  }

  /* newName === null -> append to whatever library is open.
     newName === a string -> create it, switch to it, and start it empty. */
  function importInto(newName, presets) {
    var c = readCollections();
    if (!c) { say(t("lib.importFailed", "Falló la importación"), "error"); return; }
    if (!c.libs) c.libs = {};

    if (newName) {
      var builtins = allBuiltinNames(c.active);   // read BEFORE switching away
      var id = newId();
      c.items.push({ id: id, name: newName });
      c.libs[id] = inFileOrder(presets);
      c.active = id;
      writeCollections(c);
      writeHidden(id, builtins);                  // a new library starts empty
    } else {
      c.libs[c.active] = activePresets(c).slice().concat(inFileOrder(presets));
      writeCollections(c);
    }

    if (lib()) lib().refresh();
    say(t("lib.imported", "Importados") + " " + presets.length +
        (newName ? " \u00b7 " + newName : ""), "success");
  }

  function exportLibrary() {
    var iface = cs();
    if (!iface) { say(t("lib.noHost", "Sin conexión con la aplicación"), "error"); return; }
    var c = readCollections();
    var conv = toInterchange(activePresets(c));
    if (!conv.list.length) {
      say(t("lib.nothingToExport", "No hay presets bezier para exportar en esta colección"), "error");
      return;
    }
    var json = JSON.stringify(conv.list, null, 4);
    iface.evalScript("easeit_exportLibrary(" + JSON.stringify(json) + ", " + JSON.stringify(EXT) + ")", function (raw) {
      var res;
      try { res = JSON.parse(raw); } catch (e) { say(t("lib.exportFailed", "Falló la exportación"), "error", raw); return; }
      if (!res.success) {
        if (!res.canceled) say(res.error || t("lib.exportFailed", "Falló la exportación"), "error", raw);
        return;
      }
      var msg = t("lib.exported", "Librería exportada") + " (" + conv.list.length + ")";
      if (conv.skipped.length) {
        msg += " · " + conv.skipped.length + " " + t("lib.skipped", "sin equivalente bezier, omitidos");
      }
      say(msg, "success");
      showInteropNote(conv.list.length, conv.skipped);
    });
  }

  /* Said once, after an export, because the whole point of the format is that
     it travels — and nobody would guess that from a file extension. */
  function showInteropNote(count, skipped) {
    if (!lib() || !lib().modal) return;
    var body = "<p>" + t("lib.noteBody",
      "El archivo <b>.easeit</b> usa el mismo formato que las librerías <b>.flow</b>, así que se puede importar en otros plugins de easing que acepten ese formato — y este panel también lee archivos <b>.flow</b> directamente.") + "</p>";
    if (skipped && skipped.length) {
      body += "<p class='tip'>" + t("lib.noteSkipped",
        "Quedaron afuera porque el formato sólo describe curvas bezier de dos puntos:") +
        " <b>" + skipped.join(", ") + "</b></p>";
    }
    lib().modal({ title: t("lib.noteTitle", "Librería exportada"), wide: true, okOnly: true, bodyHTML: body });
  }

  // ------------------------------------------------------------ preset edits
  function findPreset(name) {
    var c = readCollections();
    var list = activePresets(c);
    for (var i = 0; i < list.length; i++) if (String(list[i].name) === String(name)) return { c: c, list: list, i: i, p: list[i] };
    return null;
  }

  function renamePreset(name) {
    var hit = findPreset(name);
    if (!hit || !lib() || !lib().modal) return;
    lib().modal({
      title: t("lib.rename", "Renombrar preset"), input: true, defaultValue: name,
      okText: t("settings.done", "Listo"),
      onOk: function (value) {
        value = String(value || "").replace(/^\s+|\s+$/g, "");
        if (!value) return;
        hit.list[hit.i].name = value;
        hit.c.libs[hit.c.active] = hit.list;
        writeCollections(hit.c);
        lib().refresh();
        say(t("lib.renamed", "Renombrado") + " “" + value + "”", "success");
      }
    });
  }

  function deletePreset(name) {
    var hit = findPreset(name);
    if (!hit) return;
    hit.list.splice(hit.i, 1);
    hit.c.libs[hit.c.active] = hit.list;
    writeCollections(hit.c);
    if (lib()) lib().refresh();
    say(t("lib.deleted", "Eliminado") + " “" + name + "”", "success");
  }

  function copyText(text) {
    var ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed"; ta.style.top = "-9999px";
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
    if (ta.parentNode) ta.parentNode.removeChild(ta);
    return ok;
  }

  function copyPresetValue(name, asCss) {
    var hit = findPreset(name);
    var v = hit && hit.p && hit.p.v;
    if (!v || v.length !== 4) {
      // built-in presets aren't in the collection store; fall back to the tile
      say(t("lib.noValue", "Ese preset no es una curva bezier de dos puntos"), "error");
      return;
    }
    var nums = v.map(function (n) { return (Math.round(n * 100) / 100).toFixed(2); });
    var text = asCss ? "cubic-bezier(" + nums.join(", ") + ")" : nums.join(", ");
    if (copyText(text)) say(t("quick.copied", "Copiado") + ": " + text, "success");
    else say(t("quick.copyFailed", "No se pudo copiar al portapapeles"), "error");
  }

  function editPresetValue(name) {
    var hit = findPreset(name);
    if (!hit || !hit.p.v || !lib()) { say(t("lib.noValue", "Ese preset no es una curva bezier de dos puntos"), "error"); return; }
    lib().setCurve(hit.p.v.slice());
    // the readout is EaseIt's own point editor
    var ro = document.getElementById("curveReadout");
    setTimeout(function () { if (ro) ro.click(); }, 260);
  }

  // -------------------------------------------------------------- the menu
  var openMenu = null;

  function closeMenu() {
    if (openMenu && openMenu.parentNode) openMenu.parentNode.removeChild(openMenu);
    openMenu = null;
  }

  function buildMenu(items) {
    var menu = document.createElement("div");
    menu.className = "ctx-menu";
    items.forEach(function (item) {
      if (item.sep) { menu.appendChild(document.createElement("hr")); return; }
      var row = document.createElement("div");
      row.className = "ctx-item" + (item.sub ? " has-sub" : "") + (item.checked ? " checked" : "");
      var label = document.createElement("span");
      label.textContent = item.label;
      row.appendChild(label);
      if (item.sub) {
        var arrow = document.createElement("i");
        arrow.className = "ctx-arrow";
        row.appendChild(arrow);
        var sub = buildMenu(item.sub);
        sub.className = "ctx-menu ctx-sub";
        row.appendChild(sub);
      } else {
        row.addEventListener("click", function (e) {
          e.stopPropagation();
          closeMenu();
          setTimeout(item.run, 0);
        });
      }
      menu.appendChild(row);
    });
    return menu;
  }

  function collectionItems() {
    var c = readCollections();
    if (!c) return [];
    return c.items.map(function (it) {
      return {
        label: it.name, checked: it.id === c.active,
        run: function () { if (lib()) lib().selectCollection(it.id); }
      };
    });
  }

  function showMenu(x, y, presetName, isBuiltin) {
    closeMenu();
    var items = [];

    if (!isBuiltin) {
      items.push({ label: t("lib.editValue", "Editar valor"), run: function () { editPresetValue(presetName); } });
      items.push({ label: t("lib.rename", "Renombrar"), run: function () { renamePreset(presetName); } });
      items.push({ label: t("lib.delete", "Eliminar"), run: function () { deletePreset(presetName); } });
      items.push({ sep: true });
      items.push({ label: t("lib.copyAs", "Copiar valor como"), sub: [
        { label: "Bezier", run: function () { copyPresetValue(presetName, false); } },
        { label: "CSS", run: function () { copyPresetValue(presetName, true); } }
      ] });
      items.push({ sep: true });
    }

    items.push({ label: t("lib.manage", "Gestionar librería"), sub: [
      { label: t("lib.new", "Nueva"), run: function () { if (lib()) lib().newCollection(); } },
      { label: t("lib.import", "Importar"), run: importLibrary },
      { label: t("lib.export", "Exportar"), run: exportLibrary },
      { label: t("lib.renameLib", "Renombrar"), run: function () { if (lib()) lib().renameCollection(); } },
      { label: t("lib.deleteLib", "Eliminar"), run: function () { if (lib()) lib().deleteCollection(); } }
    ] });
    items.push({ label: t("lib.select", "Seleccionar librería"), sub: collectionItems() });

    var menu = buildMenu(items);
    menu.style.visibility = "hidden";
    document.body.appendChild(menu);
    openMenu = menu;

    // Keep it on screen. "On screen" here means inside this iframe: a panel
    // cannot draw over its neighbour, so anything past the pane's edge is not
    // clipped-but-reachable, it is simply gone.
    var w = menu.offsetWidth, h = menu.offsetHeight;
    var left = Math.min(x, window.innerWidth - w - 6);
    var top = Math.min(y, window.innerHeight - h - 6);
    left = Math.max(4, left);
    menu.style.left = left + "px";
    menu.style.top = Math.max(4, top) + "px";

    // Submenus open rightward by default and were the part that fell off the
    // edge — into AlignIt, where nothing of ours can render. Measure the widest
    // one and flip the whole menu leftward when it would not fit.
    var widestSub = 0;
    Array.prototype.forEach.call(menu.querySelectorAll(".ctx-sub"), function (sub) {
      sub.style.display = "block";
      sub.style.visibility = "hidden";
      if (sub.offsetWidth > widestSub) widestSub = sub.offsetWidth;
      sub.style.display = "";
      sub.style.visibility = "";
    });
    if (left + w + widestSub > window.innerWidth - 4) menu.classList.add("flip-sub");

    menu.style.visibility = "";
  }

  document.addEventListener("contextmenu", function (e) {
    var tile = e.target && e.target.closest ? e.target.closest(".preset-tile") : null;
    if (!tile) return;
    e.preventDefault();
    e.stopPropagation();
    showMenu(e.clientX, e.clientY, tile.getAttribute("data-name"),
             tile.getAttribute("data-type") === "builtin");
  }, true);

  document.addEventListener("mousedown", function (e) {
    if (openMenu && !openMenu.contains(e.target)) closeMenu();
  }, true);
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeMenu(); });
  window.addEventListener("blur", closeMenu);

  /* The toolbar's Import button belongs to the core, which only knows EaseIt's
     own {presets:[…]} shape — hand it a Flow library and it answers "No presets
     found in that file", which is exactly what happened. The reader here takes
     both shapes, so the button gets pointed at it instead.

     Taking the element away from the core is the only way in: its listener was
     bound at boot and there is no handle on it. cloneNode(true) copies the
     icon and the data-tip attributes but no listeners, so the clone arrives
     clean and the original goes away with the core's handler still attached.

     Export is deliberately NOT taken over. The core writes the native format,
     which keeps formula and multi-point presets whole; the .easeit interchange
     can only describe two-point beziers, so it stays where it is labelled as
     such — the right-click menu, under "Gestionar librería". */
  /* EaseIt's own "+" (new collection) has the same problem: the collection it
     creates has no custom presets but every built-in on show. The button belongs
     to the core and there is no hook on it, so instead the store is watched —
     any collection id that appears and has never been seen before gets its
     built-ins hidden once. That covers the "+" button, the context menu, and
     anything else that might create one later. */
  var SEEN_KEY = "editkit_easeit_seen_collections";
  function seenIds() {
    try { return JSON.parse(localStorage.getItem(SEEN_KEY)) || null; } catch (e) { return null; }
  }
  function rememberIds(ids) {
    try { localStorage.setItem(SEEN_KEY, JSON.stringify(ids)); } catch (e) {}
  }
  function currentIds(c) {
    var out = [];
    if (c && c.items) for (var i = 0; i < c.items.length; i++) out.push(c.items[i].id);
    return out;
  }
  var lastRaw = null;
  function emptyNewCollections() {
    // cheap guard: parse only when the store actually changed
    var raw = null;
    try { raw = localStorage.getItem(COLLECTIONS_KEY); } catch (e) { return; }
    if (raw === lastRaw) return;
    lastRaw = raw;
    var c = readCollections();
    if (!c) return;
    var now = currentIds(c);
    var before = seenIds();
    if (before === null) { rememberIds(now); return; }   // first run: adopt as-is
    var known = {};
    for (var i = 0; i < before.length; i++) known[before[i]] = 1;
    var fresh = [];
    for (var j = 0; j < now.length; j++) if (!known[now[j]]) fresh.push(now[j]);
    if (fresh.length) {
      var builtins = allBuiltinNames(c.active);
      for (var k = 0; k < fresh.length; k++) {
        // only if nothing has been said about this collection yet
        if (!localStorage.getItem(hiddenKey(fresh[k]))) writeHidden(fresh[k], builtins);
      }
      if (lib()) lib().refresh();
    }
    rememberIds(now);
  }
  /* Cada 700 ms, pero solo mientras el panel se este viendo: uno de CEP sigue
     cargado detras del que el usuario ponga delante, y leer el almacenamiento
     cada 700 ms durante una tarde entera para nadie es gasto puro. Quien sabe
     si se esta viendo es repaint-guard.js, que no se cree un "oculto" que nunca
     dijo "visible"; si no esta cargado, se mira como siempre. Al volver a
     aparecer, una pasada en el acto. */
  setInterval(function () {
    var A = window.EditKitAwake;
    if (A && A.idle()) return;
    emptyNewCollections();
  }, 700);
  if (window.EditKitAwake) window.EditKitAwake.onWake(emptyNewCollections);
  emptyNewCollections();

  /* The core's "+" opens its own dialog prefilled with "Collection" (translated
     to "Colección"), so every library made that way is called the same thing
     until somebody renames it. The dialog belongs to the core, so the default is
     replaced where it becomes visible: the input, the moment it appears. Only
     an untouched default is replaced — anything the user typed is left alone. */
  var DEFAULT_NAMES = ["collection", "colección", "coleccion"];
  function renameDefaultCollectionInput() {
    var inputs = document.querySelectorAll(".modal input");
    for (var i = 0; i < inputs.length; i++) {
      var el = inputs[i];
      if (el.type && el.type !== "text") continue;
      if (el.getAttribute("data-ek-named")) continue;
      var v = String(el.value || "").toLowerCase();
      var isDefault = false;
      for (var j = 0; j < DEFAULT_NAMES.length; j++) if (v === DEFAULT_NAMES[j]) isDefault = true;
      if (!isDefault) continue;
      el.setAttribute("data-ek-named", "1");
      el.value = nextCollectionName();
      try { el.select(); } catch (e) {}
    }
  }
  if (window.MutationObserver) {
    new MutationObserver(renameDefaultCollectionInput)
      .observe(document.body || document.documentElement, { childList: true, subtree: true });
  }

  function takeOverImportButton() {
    var btn = document.getElementById("importBtn");
    if (!btn || btn.getAttribute("data-ek-io")) return;
    var fresh = btn.cloneNode(true);
    fresh.setAttribute("data-ek-io", "1");
    fresh.addEventListener("click", importLibrary);
    if (btn.parentNode) btn.parentNode.replaceChild(fresh, btn);
  }
  takeOverImportButton();

})();
