/* ============================================================================
   EASEIT — PUT THE SELECTION BACK AFTER A TRUE HANDLES REOPEN

   True Handles cannot be done through Premiere's API: nothing there writes real
   bezier handles, so EaseIt saves the project, closes it, edits the file on
   disk, and opens it again. That part is unavoidable. What is avoidable is what
   it costs the user afterwards — the timeline comes back with nothing selected,
   so the clip they were working on has to be found and clicked again before
   they can do anything else.

   The core already refocuses the sequence after the reopen (easeit_th_focusSeq).
   This chains one more call onto that moment to reselect the clip, which the
   host remembered by position in easeit_th_prep.

   Why patch the prototype: the core builds its own CSInterface and calls
   evalScript straight on it, and that object is closed over inside its bundle —
   there is no handle on it from out here. Wrapping the prototype reaches it
   anyway, provided this file loads BEFORE the core builds its instance, which
   is why the <script> tag sits above index.js.
   ============================================================================ */
(function () {
    "use strict";

    if (typeof CSInterface !== "function" || !CSInterface.prototype) return;
    if (CSInterface.prototype.__ekReselectWrapped) return;
    CSInterface.prototype.__ekReselectWrapped = true;

    var original = CSInterface.prototype.evalScript;

    CSInterface.prototype.evalScript = function (script, callback) {
        var self = this;
        var isRefocus = typeof script === "string" && script.indexOf("easeit_th_focusSeq(") === 0;

        if (!isRefocus) return original.call(self, script, callback);

        return original.call(self, script, function (result) {
            // the core's own handling first — the reselect is an extra, never a
            // reason for the sequence refocus to behave differently
            try { if (typeof callback === "function") callback(result); } catch (e) {}
            try {
                original.call(self, "easeit_th_reselect()", function () {
                    /* Deliberately silent. If the clip cannot be found the user
                       is no worse off than before, and a failure notice here
                       would land right after the "your project is safe" message
                       and read as if something had gone wrong with the apply. */
                });
            } catch (e2) {}
        });
    };
})();
