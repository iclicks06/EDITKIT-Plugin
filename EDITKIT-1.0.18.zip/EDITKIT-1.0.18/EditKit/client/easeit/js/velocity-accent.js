/* ============================================================================
   EASEIT — LA CURVA DE VELOCIDAD, DEL COLOR QUE TOQUE

   La superposicion de velocidad venia en verde fijo. El verde estaba escrito
   dos veces y en dos sitios que no se hablan: `--velocity: #34C759` en la hoja
   de estilos, que pinta el boton cuando esta encendido, y la misma cifra
   dentro de index.js, que pinta la curva sobre el lienzo. Ni uno ni otro
   miraban el color de acento, asi que se podia poner EditKit entero en naranja
   y esa curva seguia verde.

   Aqui se arregla en un solo sitio. El color se deriva del acento cada vez que
   el acento cambia, se escribe en `--velocity`, y de ahi lo leen los dos: el
   boton por CSS y el lienzo por `window.EaseItVelocityColor()`, que index.js
   consulta justo antes de trazar.

   POR QUE NO ES EL ACENTO TAL CUAL. Las dos curvas se dibujan en el mismo
   cuadro, una encima de la otra. Si la de velocidad fuera exactamente el
   acento, serian la misma linea de dos formas y no habria manera de saber cual
   es cual. Asi que se gira el tono 40 grados: sigue al acento —se mueve con
   el, viene de el— pero nunca se confunde con el.

   El giro es hacia atras porque con el acento de fabrica —el verde azulado—
   cae justo en el verde de siempre, y quien ya conocia el panel no nota que
   algo cambio. La unica excepcion es el rojo: un acento anaranjado girado
   hacia atras aterriza en rojo, y en este panel el rojo es el color de los
   errores. Cuando eso pasa, se gira hacia el otro lado.
   ============================================================================ */
(function () {
    "use strict";

    var FALLBACK = "#34C759";
    var TURN = 40;          // cuanto se aparta del acento, en grados
    var RED_FROM = 340;     // la franja que se reserva para los errores
    var RED_TO = 25;

    function hexToRgb(hex) {
        if (!hex) return null;
        hex = String(hex).replace("#", "");
        if (hex.length === 3) hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
        if (hex.length !== 6) return null;
        var r = parseInt(hex.substr(0, 2), 16);
        var g = parseInt(hex.substr(2, 2), 16);
        var b = parseInt(hex.substr(4, 2), 16);
        if (isNaN(r) || isNaN(g) || isNaN(b)) return null;
        return { r: r, g: g, b: b };
    }

    function rgbToHsl(c) {
        var r = c.r / 255, g = c.g / 255, b = c.b / 255;
        var max = Math.max(r, g, b), min = Math.min(r, g, b);
        var l = (max + min) / 2;
        var d = max - min;
        if (d === 0) return { h: 0, s: 0, l: l };
        var s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        var h;
        if (max === r) h = ((g - b) / d) % 6;
        else if (max === g) h = (b - r) / d + 2;
        else h = (r - g) / d + 4;
        h *= 60;
        if (h < 0) h += 360;
        return { h: h, s: s, l: l };
    }

    function hslToHex(h, s, l) {
        h = ((h % 360) + 360) % 360;
        var c = (1 - Math.abs(2 * l - 1)) * s;
        var x = c * (1 - Math.abs(((h / 60) % 2) - 1));
        var m = l - c / 2;
        var r = 0, g = 0, b = 0;
        if (h < 60) { r = c; g = x; }
        else if (h < 120) { r = x; g = c; }
        else if (h < 180) { g = c; b = x; }
        else if (h < 240) { g = x; b = c; }
        else if (h < 300) { r = x; b = c; }
        else { r = c; b = x; }
        function hx(v) {
            var n = Math.round((v + m) * 255);
            if (n < 0) n = 0;
            if (n > 255) n = 255;
            var t = n.toString(16);
            return t.length === 1 ? "0" + t : t;
        }
        return "#" + hx(r) + hx(g) + hx(b);
    }

    function inRedBand(h) {
        h = ((h % 360) + 360) % 360;
        return h >= RED_FROM || h < RED_TO;
    }

    function derive(accentHex) {
        var rgb = hexToRgb(accentHex);
        if (!rgb) return FALLBACK;
        var hsl = rgbToHsl(rgb);

        var h = hsl.h - TURN;
        if (inRedBand(h)) h = hsl.h + TURN;

        /* Un acento casi blanco o casi negro daria una linea que no se ve
           sobre el cuadro. Se le pide un minimo de color y de luz sin cambiar
           el que ya los tenga. */
        var s = Math.max(0.45, Math.min(0.92, hsl.s));
        var l = Math.max(0.45, Math.min(0.68, hsl.l));

        return hslToHex(h, s, l);
    }

    function apply(accentHex) {
        var v = derive(accentHex);
        try { document.documentElement.style.setProperty("--velocity", v); } catch (e) {}
    }

    /* Lo que consulta index.js antes de trazar la curva. Se lee el valor
       calculado y no el que guardamos nosotros: asi, si alguien cambia
       `--velocity` a mano —una hoja de usuario, una prueba—, la curva le hace
       caso igual. */
    window.EaseItVelocityColor = function () {
        var v = "";
        try {
            v = getComputedStyle(document.documentElement).getPropertyValue("--velocity");
        } catch (e) { v = ""; }
        v = String(v).replace(/^\s+|\s+$/g, "");
        return v || FALLBACK;
    };

    if (window.EditKitAccent && window.EditKitAccent.onChange) {
        // onChange lo llama una vez con el color en vigor, asi que esto
        // tambien deja `--velocity` puesto al arrancar.
        window.EditKitAccent.onChange(apply);
    } else {
        apply(FALLBACK);
    }
})();
