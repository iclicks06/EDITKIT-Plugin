/*
 * i18n.js — translation layer for everything in EaseIt that lives in plain
 * HTML (labels, tooltips, and the custom Settings panel this fork adds).
 *
 * IMPORTANT / HONEST LIMITATION: index.js is a large minified/obfuscated
 * file with no public API and hundreds of user-facing strings baked
 * directly into its internal string table (toast messages, the "How to
 * use EaseIt" and Preferences dialogs, dropdown option lists like
 * Position/Rotation/Scale, error messages, etc). None of that is reachable
 * from outside without unpicking the obfuscation string-by-string, which
 * would be extremely risky to do safely. Those stay in English regardless
 * of the language picked here. Everything else — every label and tooltip
 * in the actual HTML, plus this whole Settings panel — is fully bilingual.
 */
(function () {
  "use strict";

  var LANG_KEY = "editkit_lang";

  var DICT = {
    es: {
      "easeit.settingsTip": "Ajustes del panel",
      "easeit.helpTip": "Cómo usar EaseIt",
      "easeit.invertTip": "Invertir la curva (Ease In ⇄ Ease Out)",
      "easeit.inverted": "Curva invertida",
      "easeit.invertSymmetric": "Esta curva ya es simétrica — invertirla la deja igual",
      "easeit.invertFailed": "No se pudo invertir la curva",
      "easeit.velocityOverlay": "Superponer velocidad",
      "easeit.zoomOut": "Alejar (Control + rueda)",
      "easeit.zoomIn": "Acercar (Control + rueda)",
      "easeit.fitView": "Ajustar a la vista",
      "easeit.readTip": "Leer el easing de los keyframes seleccionados",
      "easeit.readoutTip": "Clic para editar los puntos",
      "easeit.saveTip": "Guardar como preset",
      "easeit.revertTip": "Revertir: restaura los fotogramas originales y elimina los creados por EaseIt",
      "easeit.applyTip": "Aplicar el easing",
      "easeit.apply": "Aplicar",
      "easeit.recommended": "Recomendado",
      "easeit.eachPair": "Cada par",
      "easeit.eachPairTip": "Aplica la curva entre cada par de seleccionados adyacentes",
      "easeit.applyTo": "Aplicar a",
      "easeit.reverse": "Invertir",
      "easeit.trueHandles": "True Handles",
      "easeit.trueHandlesTip": "Escribe manejadores bezier reales (2 keyframes, sin \"horneado\"). Guarda, cierra y reabre el proyecto.",
      "easeit.experimental": "(experimental)",
      "easeit.dragResize": "Arrastrar para ajustar",
      "easeit.presets": "Presets",
      "easeit.saveCurve": "＋ Guardar curva",
      "easeit.importTip": "Importar presets: .json de EaseIt, o librerías .flow / .easeit",
      "easeit.exportTip": "Exportar tus presets a un archivo .json",
      "easeit.newCollection": "Nueva colección",
      "easeit.renameCollection": "Renombrar colección",
      "easeit.deleteCollection": "Eliminar colección",
      "easeit.removePresets": "Quitar presets",
      "easeit.ready": "Listo",

      "easecopy.copy": "Copiar",
      "easecopy.ease": "Curva",
      "easecopy.value": "Valor",
      "easecopy.captureTip": "Captura la curva y el valor de los keyframes seleccionados. Úsalo en la animación que quieres tomar como referencia.",
      "easecopy.pasteEaseTip": "Pega solo el easing y conserva los valores del destino. Úsalo para dar el mismo ritmo a otra animación sin cambiar su posición, escala, opacidad u otros valores.",
      "easecopy.pasteValueTip": "Pega solo los valores y conserva el easing del destino. Úsalo para repetir posiciones, escalas u otros valores manteniendo el ritmo actual.",
      "easecopy.passTip": "Iguala la velocidad de entrada y salida. Actívalo con 3 o más keyframes cuando el movimiento deba atravesar los intermedios sin frenarse.",
      "easecopy.captured": "Keyframes capturados",
      "easecopy.easeDone": "Easing aplicado",
      "easecopy.valueDone": "Valores aplicados",
      "easecopy.skipped": "omitidos",
      "easecopy.error.needComp": "Abre una composición de After Effects",
      "easecopy.error.needKeys": "Selecciona uno o más keyframes",
      "easecopy.error.clipboardEmpty": "Primero captura los keyframes de origen",
      "easecopy.error.countMismatch": "Selecciona la misma cantidad de keyframes o un múltiplo de la captura",
      "easecopy.error.valueMismatch": "Los valores no son compatibles con las propiedades de destino",
      "easecopy.error.captureFailed": "No se pudo capturar la selección",
      "easecopy.error.pasteFailed": "No se pudo aplicar la captura",
      "easecopy.error.noHost": "Sin conexión con After Effects",
      "easecopy.error.badResponse": "After Effects devolvió una respuesta no válida",

      "lib.editValue": "Editar valor",
      "lib.importTitle": "Importar librería",
      "lib.newCollection": "Nueva colección",
      "lib.importFound": "presets encontrados.",
      "lib.importWhere": "¿Dónde quieres agregarlos?",
      "lib.importIntoHint": "Añadir los suma a la librería abierta",
      "lib.importNewHint": "Crear una nueva los deja aparte, sin los presets de fábrica.",
      "lib.importNew": "Nueva librería",
      "lib.importHere": "Añadir aquí",
      "lib.rename": "Renombrar",
      "lib.delete": "Eliminar",
      "lib.copyAs": "Copiar valor como",
      "lib.manage": "Gestionar librería",
      "lib.select": "Seleccionar librería",
      "lib.new": "Nueva",
      "lib.import": "Importar",
      "lib.export": "Exportar",
      "lib.renameLib": "Renombrar",
      "lib.deleteLib": "Eliminar",
      "lib.imported": "Importados",
      "lib.exported": "Librería exportada",
      "lib.skipped": "sin equivalente bezier, omitidos",
      "lib.renamed": "Renombrado",
      "lib.deleted": "Eliminado",
      "lib.noPresets": "No se encontraron presets en ese archivo",
      "lib.importFailed": "Falló la importación",
      "lib.exportFailed": "Falló la exportación",
      "lib.nothingToExport": "No hay presets bezier para exportar en esta colección",
      "lib.noValue": "Ese preset no es una curva bezier de dos puntos",
      "lib.noHost": "Sin conexión con la aplicación",
      "lib.noteTitle": "Librería exportada",
      "lib.noteBody": "El archivo <b>.easeit</b> usa el mismo formato que las librerías <b>.flow</b>, así que se puede importar en otros plugins de easing que acepten ese formato — y este panel también lee archivos <b>.flow</b> directamente.",
      "lib.noteSkipped": "Quedaron fuera porque el formato solo describe curvas bezier de dos puntos:",

      "quick.title": "Atajos de teclado",
      "quick.apply": "Aplicar el easing",
      "quick.read": "Leer el easing de los keyframes",
      "quick.invert": "Invertir la curva",
      "quick.edit": "Editar los puntos",
      "quick.save": "Guardar como preset",
      "quick.revert": "Revertir",
      "quick.velocity": "Superponer velocidad",
      "quick.fit": "Ajustar a la vista",
      "quick.copyCss": "Copiar como cubic-bezier() de CSS",
      "quick.copyRaw": "Copiar los cuatro números",
      "quick.presets": "Aplicar el preset 1 al 9",
      "quick.help": "Ver esta lista",
      "quick.hint": "Solo mientras el panel tiene el foco y no estás escribiendo. Se puede desactivar en Ajustes.",
      "quick.copied": "Copiado",
      "quick.copyUnavailable": "Solo se puede copiar una curva bezier de 2 puntos",
      "quick.copyFailed": "No se pudo copiar al portapapeles",
      "settings.shortcuts": "Atajos de teclado",
      "settings.shortcutsOn": "Activar atajos de teclado",
      "settings.shortcutsSee": "Ver la lista de atajos",

      "settings.title": "Ajustes de EaseIt",
      "settings.close": "Cerrar",
      "settings.tabGeneral": "General",
      "settings.tabAppearance": "Apariencia",
      "settings.tabSections": "Secciones",
      "settings.tabShortcuts": "Atajos",
      "settings.accentColor": "Color de acento",
      "settings.presetSize": "Tamaño de los presets",
      "settings.sectionOrder": "Orden de las secciones",
      "settings.sectionOrderHint": "Arrastra una sección para cambiarla de sitio, o desmárcala para quitarla del panel. Se aplica al instante.",
      "settings.sectionVisible": "Mostrar u ocultar esta sección",
      "settings.showPresets": "Mostrar la biblioteca de presets",
      "settings.showPresetsHint": "Al ocultarla, el editor de curvas se queda con todo el ancho. Los presets, guardar, importar y las colecciones siguen a mano con Ctrl+K.",
      "settings.presetsBottom": "Poner los presets abajo",
      "settings.presetsBottomHint": "Debajo de los botones de aplicar y encima de «Cada par», con todo el ancho del panel en vez de media columna.",
      "settings.presetsTitle": "Mostrar el rótulo «Presets»",
      "settings.onion": "Papel cebolla",
      "settings.onionAlpha": "Opacidad",
      "settings.onionHint": "La última curva aplicada se queda de fondo, tenue, mientras editas la siguiente. Así ves cuánto la has cambiado sin tener que deshacer para comparar.",
      "settings.showStatus": "Mostrar mensajes de estado, confirmación y error",
      "settings.showStatusHint": "Con esto apagado desaparece la línea de abajo, y con ella también los errores: lo que falle, fallará en silencio.",
      "settings.done": "Listo",
      "settings.previewSection": "Vista previa",
      "settings.autoApply": "Aplicar automáticamente al elegir una curva",
      "settings.autoApplyHint": "Si lo desactivas, en la vista completa seleccionar o editar una curva solo la prepara; los fotogramas cambian cuando pulsas Aplicar. La vista compacta conserva su uso de un toque.",
      "settings.curveSection": "Curva",
      "settings.applySection": "Aplicar a (Premiere)"
    },
    en: {
      "easeit.settingsTip": "Panel settings",
      "easeit.helpTip": "How to use EaseIt",
      "easeit.invertTip": "Invert the curve (Ease In ⇄ Ease Out)",
      "easeit.inverted": "Curve inverted",
      "easeit.invertSymmetric": "This curve is already symmetric — inverting leaves it unchanged",
      "easeit.invertFailed": "Couldn't invert the curve",
      "easeit.velocityOverlay": "Velocity overlay",
      "easeit.zoomOut": "Zoom out (Ctrl + wheel)",
      "easeit.zoomIn": "Zoom in (Ctrl + wheel)",
      "easeit.fitView": "Fit to view",
      "easeit.readTip": "Read easing from selected keyframes",
      "easeit.readoutTip": "Click to edit points",
      "easeit.saveTip": "Save as preset",
      "easeit.revertTip": "Revert: restore the original keyframes and remove those created by EaseIt",
      "easeit.applyTip": "Apply easing",
      "easeit.apply": "Apply",
      "easeit.recommended": "Recommended",
      "easeit.eachPair": "Each pair",
      "easeit.eachPairTip": "Apply the curve between each adjacent selected pair",
      "easeit.applyTo": "Apply to",
      "easeit.reverse": "Reverse",
      "easeit.trueHandles": "True Handles",
      "easeit.trueHandlesTip": "Write real bezier handles (2 keyframes, no baking). Saves, closes & reopens the project.",
      "easeit.experimental": "(experimental)",
      "easeit.dragResize": "Drag to resize",
      "easeit.presets": "Presets",
      "easeit.saveCurve": "＋ Save curve",
      "easeit.importTip": "Import presets: EaseIt .json, or .flow / .easeit libraries",
      "easeit.exportTip": "Export your presets to a .json file",
      "easeit.newCollection": "New collection",
      "easeit.renameCollection": "Rename collection",
      "easeit.deleteCollection": "Delete collection",
      "easeit.removePresets": "Remove presets",
      "easeit.ready": "Ready",

      "easecopy.copy": "Copy",
      "easecopy.ease": "Ease",
      "easecopy.value": "Value",
      "easecopy.captureTip": "Capture the curve and value of the selected keyframes. Use it on the animation you want to use as a reference.",
      "easecopy.pasteEaseTip": "Paste easing only and keep destination values. Use it to give another animation the same timing without changing position, scale, opacity, or other values.",
      "easecopy.pasteValueTip": "Paste values only and keep destination easing. Use it to repeat positions, scales, or other values while preserving the current timing.",
      "easecopy.passTip": "Match incoming and outgoing velocity. Enable it with 3 or more keyframes when motion should pass through intermediate keys without slowing down.",
      "easecopy.captured": "Keyframes captured",
      "easecopy.easeDone": "Easing applied",
      "easecopy.valueDone": "Values applied",
      "easecopy.skipped": "skipped",
      "easecopy.error.needComp": "Open an After Effects composition",
      "easecopy.error.needKeys": "Select one or more keyframes",
      "easecopy.error.clipboardEmpty": "Capture the source keyframes first",
      "easecopy.error.countMismatch": "Select the same number of keyframes, or a multiple of the capture",
      "easecopy.error.valueMismatch": "The values are not compatible with the destination properties",
      "easecopy.error.captureFailed": "The selection could not be captured",
      "easecopy.error.pasteFailed": "The capture could not be applied",
      "easecopy.error.noHost": "No connection to After Effects",
      "easecopy.error.badResponse": "After Effects returned an invalid response",

      "lib.editValue": "Edit value",
      "lib.importTitle": "Import library",
      "lib.newCollection": "New collection",
      "lib.importFound": "presets found.",
      "lib.importWhere": "Where do you want them?",
      "lib.importIntoHint": "Adding them puts them in the library you have open",
      "lib.importNewHint": "Creating a new one keeps them apart, without the factory presets.",
      "lib.importNew": "New library",
      "lib.importHere": "Add here",
      "lib.rename": "Rename",
      "lib.delete": "Delete",
      "lib.copyAs": "Copy value as",
      "lib.manage": "Manage library",
      "lib.select": "Select library",
      "lib.new": "New",
      "lib.import": "Import",
      "lib.export": "Export",
      "lib.renameLib": "Rename",
      "lib.deleteLib": "Delete",
      "lib.imported": "Imported",
      "lib.exported": "Library exported",
      "lib.skipped": "with no bezier equivalent, left out",
      "lib.renamed": "Renamed",
      "lib.deleted": "Deleted",
      "lib.noPresets": "No presets found in that file",
      "lib.importFailed": "Import failed",
      "lib.exportFailed": "Export failed",
      "lib.nothingToExport": "No bezier presets to export in this collection",
      "lib.noValue": "That preset is not a two-point bezier curve",
      "lib.noHost": "No connection to the host application",
      "lib.noteTitle": "Library exported",
      "lib.noteBody": "The <b>.easeit</b> file uses the same format as <b>.flow</b> libraries, so it can be imported into other easing plugins that accept it — and this panel reads <b>.flow</b> files directly too.",
      "lib.noteSkipped": "Left out because the format only describes two-point bezier curves:",

      "quick.title": "Keyboard shortcuts",
      "quick.apply": "Apply the easing",
      "quick.read": "Read easing from the keyframes",
      "quick.invert": "Invert the curve",
      "quick.edit": "Edit the points",
      "quick.save": "Save as preset",
      "quick.revert": "Revert",
      "quick.velocity": "Velocity overlay",
      "quick.fit": "Fit to view",
      "quick.copyCss": "Copy as CSS cubic-bezier()",
      "quick.copyRaw": "Copy the four numbers",
      "quick.presets": "Apply preset 1 to 9",
      "quick.help": "Show this list",
      "quick.hint": "Only while the panel has focus and you are not typing. Can be switched off in Settings.",
      "quick.copied": "Copied",
      "quick.copyUnavailable": "Only a 2-point bezier curve can be copied",
      "quick.copyFailed": "Couldn't copy to the clipboard",
      "settings.shortcuts": "Keyboard shortcuts",
      "settings.shortcutsOn": "Enable keyboard shortcuts",
      "settings.shortcutsSee": "See the shortcut list",

      "settings.title": "EaseIt settings",
      "settings.close": "Close",
      "settings.tabGeneral": "General",
      "settings.tabAppearance": "Appearance",
      "settings.tabSections": "Sections",
      "settings.tabShortcuts": "Shortcuts",
      "settings.accentColor": "Accent color",
      "settings.presetSize": "Preset size",
      "settings.sectionOrder": "Section order",
      "settings.sectionOrderHint": "Drag a section to move it, or uncheck it to take it out of the panel. Applies instantly.",
      "settings.sectionVisible": "Show or hide this section",
      "settings.showPresets": "Show the preset library",
      "settings.showPresetsHint": "Hide it and the curve editor takes the full width. Presets, save, import and collections stay one Ctrl+K away.",
      "settings.presetsBottom": "Put the presets at the bottom",
      "settings.presetsBottomHint": "Below the apply buttons and above \u201cEach pair\u201d, with the panel's full width instead of half a column.",
      "settings.presetsTitle": "Show the \u201cPresets\u201d label",
      "settings.onion": "Onion skin",
      "settings.onionAlpha": "Opacity",
      "settings.onionHint": "The last curve you applied stays faintly in the background while you edit the next one, so you can see how far it moved without undoing to compare.",
      "settings.showStatus": "Show status, confirmation and error messages",
      "settings.showStatusHint": "With this off the bottom line goes, and the errors with it: whatever fails, fails in silence.",
      "settings.done": "Done",
      "settings.previewSection": "Preview",
      "settings.autoApply": "Apply automatically when choosing a curve",
      "settings.autoApplyHint": "When disabled, choosing or editing a curve in the full view only prepares it; keyframes change after you press Apply. Compact view keeps its one-click behavior.",
      "settings.curveSection": "Curve",
      "settings.applySection": "Apply to (Premiere)"
    }
  };

  var lang = "es";
  try { lang = localStorage.getItem(LANG_KEY) || "es"; } catch (e) {}
  if (!DICT[lang]) lang = "es";

  function t(key) {
    return (DICT[lang] && DICT[lang][key]) || (DICT.es[key]) || key;
  }

  function applyDom() {
    var nodes = document.querySelectorAll("[data-i18n]");
    for (var i = 0; i < nodes.length; i++) {
      nodes[i].textContent = t(nodes[i].getAttribute("data-i18n"));
    }
    var tipNodes = document.querySelectorAll("[data-i18n-tip]");
    for (var j = 0; j < tipNodes.length; j++) {
      tipNodes[j].setAttribute("data-tip", t(tipNodes[j].getAttribute("data-i18n-tip")));
    }
    document.documentElement.lang = lang;
  }

  function setLanguage(newLang) {
    if (!DICT[newLang]) return;
    lang = newLang;
    try { localStorage.setItem(LANG_KEY, lang); } catch (e) {}
    applyDom();
  }

  applyDom();

  window.EditKitI18n = {
    t: t,
    setLanguage: setLanguage,
    getLanguage: function () { return lang; }
  };
})();
