/*
 * quick-actions.js — keyboard layer for EaseIt. EXPERIMENTAL.
 *
 * Why this exists: applying a curve took a trip to the mouse every time,
 * even though the action underneath it is a single, well-defined button.
 * A key binding removes that trip without changing what happens when it
 * fires.
 *
 * Everything here drives the existing buttons — it clicks them. No new path
 * into index.js, so a shortcut can never do something the UI cannot.
 *
 * Deliberately conservative about when it listens: never while a text field has
 * focus, never while a modal is open, never with Ctrl/Alt/Cmd held (those
 * belong to the host app). It can be switched off entirely in Ajustes.
 */
(function () {
  "use strict";

  var ENABLED_KEY = "editkit_easeit_shortcuts";

  function t(key, fallback) {
    var s = window.EditKitI18n && window.EditKitI18n.t ? window.EditKitI18n.t(key) : null;
    return (s && s !== key) ? s : fallback;
  }

  function say(msg, kind) {
    if (window.EaseItCurve && window.EaseItCurve.status) window.EaseItCurve.status(msg, kind);
  }

  function enabled() {
    try { return localStorage.getItem(ENABLED_KEY) !== "0"; } catch (e) { return true; }
  }

  // ---------- the bindings ----------
  // Each one is just "press the button the user would have pressed".
  function click(id) {
    var el = document.getElementById(id);
    if (!el) return false;
    el.click();
    return true;
  }

  function applyNthPreset(n) {
    var tiles = document.querySelectorAll("#presetGrid .preset-tile");
    if (!tiles[n - 1]) return false;
    tiles[n - 1].click();
    return true;
  }

  /* Reads the four numbers straight off the readout. That is the same string
     index.js keeps up to date on every curve change, so there is no second
     source of truth to drift — and when the curve is a formula or carries extra
     points the readout says so instead of numbers, which is exactly when there
     is no cubic-bezier to hand out. */
  function currentBezier() {
    var el = document.getElementById("curveReadout");
    if (!el) return null;
    var m = String(el.textContent).match(/(-?[\d.]+)\s*,\s*(-?[\d.]+)\s*,\s*(-?[\d.]+)\s*,\s*(-?[\d.]+)/);
    return m ? [m[1], m[2], m[3], m[4]] : null;
  }

  function toClipboard(text) {
    var ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.top = "-9999px";
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
    if (ta.parentNode) ta.parentNode.removeChild(ta);
    return ok;
  }

  function copyCurve(asCss) {
    var v = currentBezier();
    if (!v) {
      say(t("quick.copyUnavailable", "Sólo se puede copiar una curva bezier de 2 puntos"), "error");
      return false;
    }
    var text = asCss ? "cubic-bezier(" + v.join(", ") + ")" : v.join(", ");
    if (toClipboard(text)) { say(t("quick.copied", "Copiado") + ": " + text, "success"); return true; }
    say(t("quick.copyFailed", "No se pudo copiar al portapapeles"), "error");
    return false;
  }

  var ACTIONS = {
    a: function () { return click("applyBtn"); },
    r: function () { return click("readBtn"); },
    i: function () { return click("invertBtn"); },
    s: function () { return click("saveStar"); },
    z: function () { return click("revertBtn"); },
    e: function () { return click("curveReadout"); },
    v: function () { return click("tbVel"); },
    f: function () { return click("tbFit"); }
  };

  // ---------- when to stay out of the way ----------
  function typing(el) {
    while (el && el.nodeType === 1) {
      var tag = el.tagName;
      if (tag === "TEXTAREA" || tag === "SELECT" || el.isContentEditable) return true;
      if (tag === "INPUT") {
        var type = (el.getAttribute("type") || "text").toLowerCase();
        return type !== "checkbox" && type !== "radio" && type !== "button";
      }
      el = el.parentNode;
    }
    return false;
  }

  function modalOpen() {
    return !!document.querySelector(".modal-overlay:not(.closing)");
  }

  document.addEventListener("keydown", function (e) {
    if (!enabled()) return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;   // the host app owns those
    if (typing(e.target)) return;
    if (modalOpen()) return;                          // Enter/Esc belong to the dialog

    var k = e.key;
    if (!k) return;

    if (k === "?") { showHelp(); e.preventDefault(); return; }

    if (k >= "1" && k <= "9") {
      if (applyNthPreset(parseInt(k, 10))) e.preventDefault();
      return;
    }

    var lower = String(k).toLowerCase();

    if (lower === "c") { copyCurve(!e.shiftKey); e.preventDefault(); return; }

    var run = ACTIONS[lower];
    if (run && run()) e.preventDefault();
  });

  // ---------- the reference card ----------
  var LIST = [
    ["A", "quick.apply", "Aplicar el easing"],
    ["R", "quick.read", "Leer el easing de los keyframes"],
    ["I", "quick.invert", "Invertir la curva"],
    ["E", "quick.edit", "Editar los puntos"],
    ["S", "quick.save", "Guardar como preset"],
    ["Z", "quick.revert", "Revertir"],
    ["V", "quick.velocity", "Superponer velocidad"],
    ["F", "quick.fit", "Ajustar a la vista"],
    ["C", "quick.copyCss", "Copiar como cubic-bezier() de CSS"],
    ["⇧C", "quick.copyRaw", "Copiar los cuatro números"],
    ["1–9", "quick.presets", "Aplicar el preset 1 al 9"],
    ["?", "quick.help", "Ver esta lista"]
  ];

  function showHelp() {
    if (modalOpen()) return;
    var overlay = document.createElement("div");
    overlay.className = "modal-overlay";
    var modal = document.createElement("div");
    modal.className = "modal wide";

    var h3 = document.createElement("h3");
    h3.textContent = t("quick.title", "Atajos de teclado");
    modal.appendChild(h3);

    var body = document.createElement("div");
    body.className = "modal-body";
    var list = document.createElement("div");
    list.className = "quick-keys";
    LIST.forEach(function (row) {
      var line = document.createElement("div");
      line.className = "quick-key-row";
      var kbd = document.createElement("kbd");
      kbd.textContent = row[0];
      var label = document.createElement("span");
      label.textContent = t(row[1], row[2]);
      line.appendChild(kbd);
      line.appendChild(label);
      list.appendChild(line);
    });
    body.appendChild(list);

    var hint = document.createElement("p");
    hint.className = "hint quick-hint";
    hint.textContent = t("quick.hint", "Sólo mientras el panel tiene el foco y no estás escribiendo. Se puede desactivar en Ajustes.");
    body.appendChild(hint);
    modal.appendChild(body);

    var actions = document.createElement("div");
    actions.className = "modal-actions";
    var close = document.createElement("div");
    close.className = "modal-btn primary";
    close.textContent = t("settings.done", "Listo");
    function dismiss() {
      overlay.classList.remove("show");
      setTimeout(function () { if (overlay.parentNode) overlay.parentNode.removeChild(overlay); }, 180);
    }
    close.addEventListener("click", dismiss);
    actions.appendChild(close);
    modal.appendChild(actions);

    overlay.appendChild(modal);
    overlay.addEventListener("click", function (e) { if (e.target === overlay) dismiss(); });
    document.body.appendChild(overlay);
    requestAnimationFrame(function () { overlay.classList.add("show"); });
  }

  window.EaseItQuick = {
    isEnabled: enabled,
    setEnabled: function (on) {
      try { localStorage.setItem(ENABLED_KEY, on ? "1" : "0"); } catch (e) {}
    },
    showHelp: showHelp,
    list: LIST
  };
})();
