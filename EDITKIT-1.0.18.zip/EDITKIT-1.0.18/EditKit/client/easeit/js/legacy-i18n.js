/*
 * legacy-i18n.js — Spanish for the text built into EaseIt's core.
 *
 * index.js carries its own English strings, so they never followed the
 * panel's ES/EN switch: the modals and the status bar stayed English
 * regardless. Rewriting them in place would pin the panel to one language, so
 * instead index.js hands every string it is about to show to the t() below,
 * and this file translates what it recognises.
 *
 * Kept in step with the core: when the core was cleaned of its old licensing,
 * update, support and analytics code, every entry here that translated one of
 * those texts went with it. An entry whose English no longer appears in the
 * core is dead weight, not a safety net.
 *
 * Anything not listed here passes through unchanged, which means the file can
 * be extended one line at a time and a gap only ever shows as English text —
 * never as a broken dialog.
 *
 * Three kinds of string arrive here, and each needs different handling:
 *
 *   "label"   whole-string values: modal titles and button captions. Matched
 *             by exact equality — these are short ("Set", "Save"), and a
 *             substring rule on them would corrupt longer text.
 *   "html"    modal bodies. Often assembled by concatenation with a version
 *             number or a preset name in the middle, so there is no whole
 *             string to match; distinctive sentences are replaced in place,
 *             longest first, leaving the surrounding markup alone.
 *   "status"  the one-line status bar. Mostly built by concatenation too
 *             ("✓ Imported " + n + " presets"), so it goes through the same
 *             longest-first fragment pass.
 *
 * What is deliberately NOT translated: the names of the built-in presets
 * (Linear, Ease In, Quad Out…). They are stored as keys inside
 * easeit_order:<collection> and easeit_preset_hidden:<collection>, so translating
 * them would orphan every saved ordering and hidden-preset list.
 */
(function () {
  "use strict";

  /* ---------- whole-string values: titles and buttons ---------- */
  var LABELS = {
    // titles
    "Separate dimensions?": "¿Separar dimensiones?",
    "Edit points · x1, y1, x2, y2": "Editar puntos · x1, y1, x2, y2",
    "Handle  X, Y": "Manija  X, Y",
    "Name this curve": "Ponle un nombre a esta curva",
    "New collection": "Nueva colección",
    "Rename collection": "Renombrar colección",
    "How to use EaseIt": "Cómo usar EaseIt",
    "How True Handles works": "Cómo funciona True Handles",
    "Restore pre-EaseIt project?": "¿Restaurar el proyecto anterior a EaseIt?",
    "Host error": "Error de la aplicación",

    // buttons
    "Cancel": "Cancelar",
    "Save": "Guardar",
    "Close": "Cerrar",
    "Create": "Crear",
    "Delete": "Eliminar",
    "Set": "Fijar",
    "Got it": "Entendido",
    "Got it, apply": "Entendido, aplicar",
    "Separate & apply": "Separar y aplicar",
    "Restore & reopen": "Restaurar y reabrir",
    "Enter four numbers: x1, y1, x2, y2": "Ingresa cuatro números: x1, y1, x2, y2",
    "My Curve": "Mi curva",
    "Curve": "Curva",
    "Collection": "Colección",
    "My Presets": "Mis presets"
  };

  /* ---------- fragments replaced inside HTML bodies and status lines ----------
     Order does not matter here — the table is sorted longest-first at load, so
     a long sentence is always consumed before any shorter phrase inside it. */
  var FRAGMENTS = [
    /* --- separate dimensions --- */
    ["<p>After Effects can't <b>overshoot</b> spatial <b>Position</b> keyframes unless its <b>X and Y dimensions are separated</b>.</p>",
     "<p>After Effects no puede hacer <b>overshoot</b> en keyframes espaciales de <b>Posición</b> a menos que sus <b>dimensiones X e Y estén separadas</b>.</p>"],
    ["<p>Separate dimensions now and apply this easing?</p>",
     "<p>¿Separar las dimensiones ahora y aplicar este easing?</p>"],
    ["Overshoot not applied — Position X/Y stay together (click Apply to separate)",
     "Overshoot no aplicado — Posición X/Y siguen juntas (clic en Aplicar para separarlas)"],
    ["Overshoot needs separated dimensions — click Apply to separate",
     "El overshoot necesita dimensiones separadas — clic en Aplicar para separarlas"],
    [" · XY separated", " · XY separadas"],
    /* --- modal "Como usar EaseIt": estaban sueltos en el nucleo --- */
    ["<p><b>1.</b> Pick a preset on the <b>PRESETS</b> tab, or drag the yellow handles to shape the curve.</p>",
     "<p><b>1.</b> Elige un preset en <b>PRESETS</b>, o arrastra las manijas amarillas para dar forma a la curva.</p>"],
    ["<p><b>2.</b> <b>Double-click the curve</b> to add a point (mint), <b>double-click a point</b> to remove it, <b>double-click a handle</b> to type exact values.</p>",
     "<p><b>2.</b> <b>Doble clic en la curva</b> para agregar un punto (verde menta), <b>doble clic en un punto</b> para quitarlo, <b>doble clic en una manija</b> para escribir valores exactos.</p>"],
    ["<p><b>Shift</b>-drag = constrain to one axis · <b>Alt</b>-drag an <b>end handle</b> = mirror the other side (even on both ends) · <b>Alt</b>-drag a <b>point's handle</b> = break its link.</p>",
     "<p><b>Shift</b> + arrastrar = restringir a un solo eje · <b>Alt</b> + arrastrar una <b>manija del extremo</b> = reflejar el otro lado (incluso en ambos extremos) · <b>Alt</b> + arrastrar la <b>manija de un punto</b> = romper su vínculo.</p>"],
    ["<p class='tip'>Make the panel <b>very narrow</b> for a compact one-tap preset list — the editor hides and a preset applies the moment you click it.</p>",
     "<p class='tip'>Deja el panel <b>muy estrecho</b> para tener una lista compacta de presets de un solo clic: el editor se oculta y el preset se aplica en cuanto haces clic.</p>"],

    /* --- help --- */
    ["<p><b>3.</b> Then <b>Apply Easing</b>. <b>Revert</b> undoes it.</p>",
     "<p><b>3.</b> Después <b>Aplicar easing</b>. <b>Revertir</b> lo deshace.</p>"],
    ["<p>On-chart tools: <b>V</b> velocity overlay · <b>+ / −</b> zoom · <b>⊡</b> fit. Tap the <b>★</b> to save the curve as a preset.</p>",
     "<p>Herramientas sobre el gráfico: <b>V</b> capa de velocidad · <b>+ / −</b> zoom · <b>⊡</b> ajustar. Pulsa la <b>★</b> para guardar la curva como preset.</p>"],
    ["<p class='tip'>Multiple keyframes? In <b>After Effects</b>, <b>select</b> the keyframes (2 or more) and EaseIt eases them as <b>one animation</b> — even add midpoints in the graph. <b>Premiere</b> works on a single 2-keyframe animation.</p>",
     "<p class='tip'>¿Varios keyframes? En <b>After Effects</b>, <b>selecciona</b> los keyframes (2 o más) y EaseIt los suaviza como <b>una sola animación</b> — incluso puedes agregar puntos intermedios en el gráfico. <b>Premiere</b> trabaja sobre una animación de 2 keyframes.</p>"],

    /* --- collections --- */
    ["<p>This removes the collection and its saved presets. Built-in presets stay.</p>",
     "<p>Esto elimina la colección y sus presets guardados. Los presets incluidos se mantienen.</p>"],
    ["Can't delete the last collection", "No se puede eliminar la última colección"],
    ["Created collection “", "Colección creada “"],
    ["No presets found in that file", "No se encontraron presets en ese archivo"],
    ["Invalid preset file", "Archivo de presets inválido"],
    ["✓ Presets exported", "✓ Presets exportados"],
    ["Import canceled", "Importación cancelada"],
    ["Export canceled", "Exportación cancelada"],
    ["Import failed", "Falló la importación"],
    ["Export failed", "Falló la exportación"],
    ["✓ Imported ", "✓ Importados "],
    ["Saved “", "Guardado “"],
    ["Loaded “", "Cargado “"],
    ["Deleted “", "Eliminado “"],
    // only ever the delete-collection title, built as: Delete “name”?  — the
    // opening ¿ has to be injected here since the trailing ? comes separately
    ["Delete “", "¿Eliminar “"],
    ["＋ New collection", "＋ Nueva colección"],

    /* --- true handles --- */
    ["<p><b>True Handles</b> writes real bezier handles straight into your project file — no baked keyframes.</p>",
     "<p><b>True Handles</b> escribe manijas bezier reales directo en tu archivo de proyecto — sin keyframes horneados.</p>"],
    ["<p>To load them, EaseIt <b>saves, closes and reopens your project automatically</b>. Please <b>wait and don't reopen the project yourself</b> — the first time after launching Premiere it can take up to a minute.</p>",
     "<p>Para cargarlas, EaseIt <b>guarda, cierra y reabre tu proyecto automáticamente</b>. Por favor <b>espera y no reabras el proyecto manualmente</b> — la primera vez después de abrir Premiere puede tardar hasta un minuto.</p>"],
    ["<p><b>⚠ First time only:</b> after this very first apply you may need to <b>re-open your project (or its timeline) yourself</b>. That's a one-time thing — every apply after this reopens automatically.</p>",
     "<p><b>⚠ Solo la primera vez:</b> después de esta primera aplicación puede que tengas que <b>reabrir el proyecto (o su línea de tiempo) manualmente</b>. Es por única vez — todas las aplicaciones siguientes reabren solas.</p>"],
    ["<p class='tip'>A <b>.easeit-bak</b> backup of your project is saved next to it every time, and <b>Revert</b> restores it.</p>",
     "<p class='tip'>Cada vez se guarda una copia de seguridad <b>.easeit-bak</b> de tu proyecto junto al archivo, y <b>Revertir</b> la restaura.</p>"],
    ["<p>This rolls the whole project file back to the backup taken just before the last <b>True Handles</b> apply (any edits made after it are lost).</p>",
     "<p>Esto devuelve todo el archivo de proyecto a la copia de seguridad tomada justo antes de la última aplicación de <b>True Handles</b> (se pierde cualquier edición posterior).</p>"],
    ["True Handles on — Apply writes real bezier handles", "True Handles activado — Aplicar escribe manijas bezier reales"],
    ["True Handles off — Apply bakes keyframes", "True Handles desactivado — Aplicar hornea keyframes"],
    ["True Handles writes curves & multi-point paths — Elastic/Bounce formulas still bake. Applying baked…",
     "True Handles escribe curvas y trayectos de varios puntos — las fórmulas Elastic/Bounce se siguen horneando. Aplicando horneado…"],
    ["True Handles didn't finish (stale) … nothing changed.", "True Handles no terminó (quedó colgado)… no cambió nada."],
    ["A True Handles operation is still finishing — give it a moment.", "Una operación de True Handles todavía está terminando — espera un momento."],
    ["True Handles supports 1D & 2D parameters — '", "True Handles soporta parámetros 1D y 2D — '"],
    ["' bakes instead. Applying baked…", "' se hornea en su lugar. Aplicando horneado…"],
    ["True Handles needs Node.js — reinstall the panel", "True Handles necesita Node.js — reinstala el panel"],
    ["True Handles unavailable", "True Handles no disponible"],
    ["True Handles failed", "Falló True Handles"],
    ["Tagging keyframes & saving project…", "Etiquetando keyframes y guardando el proyecto…"],
    ["Closing project to write handles…", "Cerrando el proyecto para escribir las manijas…"],
    ["Closing project to restore…", "Cerrando el proyecto para restaurar…"],
    ["Reopening your project automatically — please wait, don't reopen it yourself…",
     "Reabriendo tu proyecto automáticamente — espera, no lo abras manualmente…"],
    ["Handles written & your project is safe. If it didn't reopen, just open it again: ",
     "Manijas escritas y tu proyecto está a salvo. Si no se reabrió, vuelve a abrirlo: "],
    [" — real bezier handles written", " — manijas bezier reales escritas"],
    [" — project reopened unchanged", " — el proyecto se reabrió sin cambios"],
    [" (project will reopen)", " (el proyecto se va a reabrir)"],
    ["reopen did not finish in time", "la reapertura no terminó a tiempo"],
    ["Could not close the project", "No se pudo cerrar el proyecto"],
    ["No open project to revert", "No hay ningún proyecto abierto que revertir"],
    ["No True Handles backup for this project — nothing to restore",
     "No hay copia de seguridad de True Handles para este proyecto — nada que restaurar"],
    ["✓ Project restored to pre-EaseIt backup", "✓ Proyecto restaurado a la copia previa a EaseIt"],
    ["Restore failed", "Falló la restauración"],
    ["Prep failed", "Falló la preparación"],
    [" · backup saved", " · copia de seguridad guardada"],

    /* --- apply / read / revert --- */
    ["Formula easings aren't point-editable — pick a bezier preset first",
     "Los easings por fórmula no se editan por puntos — elige primero un preset bezier"],
    ["Point added — drag it and its handles", "Punto agregado — arrástralo junto con sus manijas"],
    ["Point removed", "Punto eliminado"],
    ["Curve updated", "Curva actualizada"],
    ["Couldn't read easing", "No se pudo leer el easing"],
    ["Reading easing…", "Leyendo easing…"],
    ["Applying easing…", "Aplicando easing…"],
    ["Reverting…", "Revirtiendo…"],
    ["Exporting…", "Exportando…"],
    ["Revert failed", "Falló revertir"],
    ["Nothing to revert on ", "Nada que revertir en "],
    [" easing into the editor", " easing en el editor"],
    ["✓ Reverted ", "✓ Revertido "],
    [" baked keys removed", " keys horneados eliminados"],
    [" baked keys", " keys horneados"],
    [" eased · ", " suavizados · "],
    [" properties eased · ", " propiedades suavizadas · "],
    [" properties", " propiedades"],
    ["' isn't on this clip — property reset to Position", "' no está en este clip — propiedad reiniciada a Posición"],

    /* --- diagnostics --- */
    ["✓ Error copied to clipboard", "✓ Error copiado al portapapeles"],
    ["  (click to copy)", "  (clic para copiar)"],
    ["\n\nDetail: ", "\n\nDetalle: "],
    ["Input: ", "Entrada: "],

    /* --- misc single words that only ever arrive as whole status lines --- */
    ["Custom · ", "Personalizada · "],
    [" points)", " puntos)"],
    [" points", " puntos"],
    [" added", " agregado"],
    [" removed ", " eliminado "]
  ];

  // Longest first, so a long sentence is never broken up by a shorter phrase
  // that happens to sit inside it.
  FRAGMENTS.sort(function (a, b) { return b[0].length - a[0].length; });

  function isSpanish() {
    try {
      if (window.EditKitI18n && window.EditKitI18n.getLanguage) return window.EditKitI18n.getLanguage() === "es";
      return (localStorage.getItem("editkit_lang") || "es") === "es";
    } catch (e) { return true; }
  }

  function applyFragments(s) {
    for (var i = 0; i < FRAGMENTS.length; i++) {
      if (s.indexOf(FRAGMENTS[i][0]) !== -1) s = s.split(FRAGMENTS[i][0]).join(FRAGMENTS[i][1]);
    }
    return s;
  }

  function t(s, kind) {
    if (typeof s !== "string" || !s) return s;
    // En ingles no hay nada que traducir: el nucleo ya habla ingles.
    if (!isSpanish()) return s;
    if (kind === "label") return Object.prototype.hasOwnProperty.call(LABELS, s) ? LABELS[s] : applyFragments(s);
    return applyFragments(s);            // "html" and "status"
  }

  window.EaseItText = {
    t: t,
    /* exposed so the dictionary can be inspected or extended at runtime */
    labels: LABELS,
    fragments: FRAGMENTS
  };
})();
