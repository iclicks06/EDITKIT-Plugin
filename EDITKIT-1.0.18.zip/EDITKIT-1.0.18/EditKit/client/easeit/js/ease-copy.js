/*
 * EaseCopy for EDITKIT.
 *
 * The host keeps a private, in-memory snapshot of the selected keyframes.
 * This UI only chooses which half to apply afterwards: temporal easing or
 * values. Nothing touches the Windows/macOS clipboard, so changing focus
 * between the timeline and the CEP panel cannot invalidate the capture.
 */
(function () {
  "use strict";

  var capture = document.getElementById("easeCopyCapture");
  var pasteEase = document.getElementById("easeCopyPasteEase");
  var pasteValue = document.getElementById("easeCopyPasteValue");
  var pass = document.getElementById("easeCopyPass");
  var count = document.getElementById("easeCopyCount");
  if (!capture || !pasteEase || !pasteValue || !pass || !count) return;

  var cs = null;
  try { cs = new CSInterface(); } catch (e) { cs = null; }

  function paintPass() {
    if (pass.parentNode && pass.parentNode.classList) pass.parentNode.classList.toggle("on", pass.checked);
  }
  pass.addEventListener("change", paintPass);
  paintPass();

  function t(key, fallback) {
    var value = window.EditKitI18n && window.EditKitI18n.t ? window.EditKitI18n.t(key) : null;
    return value && value !== key ? value : fallback;
  }

  function say(message, kind) {
    if (window.EaseItCurve && window.EaseItCurve.status) {
      window.EaseItCurve.status(message, kind || "");
      return;
    }
    var status = document.getElementById("status");
    if (!status) return;
    status.textContent = message;
    status.className = "status " + (kind || "");
  }

  function parse(raw) {
    if (!raw) return { ok: false, code: "noHost" };
    try { return JSON.parse(raw); } catch (e) { return { ok: false, code: "badResponse", detail: raw }; }
  }

  function errorText(result) {
    var code = result && result.code ? result.code : "pasteFailed";
    var key = "easecopy.error." + code;
    var fallback = {
      needComp: "Abre una composición de After Effects",
      needKeys: "Selecciona uno o más keyframes",
      clipboardEmpty: "Primero captura los keyframes de origen",
      countMismatch: "Selecciona la misma cantidad de keyframes o un múltiplo de la captura",
      valueMismatch: "Los valores no son compatibles con las propiedades de destino",
      captureFailed: "No se pudo capturar la selección",
      pasteFailed: "No se pudo aplicar la captura",
      noHost: "Sin conexión con After Effects",
      badResponse: "After Effects devolvió una respuesta no válida"
    }[code] || "No se pudo completar EaseCopy";
    return t(key, fallback);
  }

  function busy(on) {
    capture.disabled = on;
    pasteEase.disabled = on;
    pasteValue.disabled = on;
    document.getElementById("easeCopyRow").classList.toggle("busy", on);
  }

  function run(script, done) {
    if (!cs) { done({ ok: false, code: "noHost" }); return; }
    busy(true);
    cs.evalScript(script, function (raw) {
      busy(false);
      done(parse(raw));
    });
  }

  capture.addEventListener("click", function () {
    run("easeit_easeCopyCapture()", function (result) {
      if (!result.ok) { say(errorText(result), "error"); return; }
      count.textContent = String(result.count || 0);
      count.hidden = false;
      capture.classList.add("ready");
      say(t("easecopy.captured", "Capturados") + ": " + String(result.count || 0), "success");
    });
  });

  pasteEase.addEventListener("click", function () {
    run("easeit_easeCopyPasteEase(" + (pass.checked ? "true" : "false") + ")", function (result) {
      if (!result.ok) { say(errorText(result), "error"); return; }
      var message = t("easecopy.easeDone", "Easing aplicado") + ": " + String(result.count || 0);
      if (result.failed) message += " · " + t("easecopy.skipped", "omitidos") + ": " + result.failed;
      say(message, result.failed ? "error" : "success");
    });
  });

  pasteValue.addEventListener("click", function () {
    run("easeit_easeCopyPasteValue()", function (result) {
      if (!result.ok) { say(errorText(result), "error"); return; }
      var message = t("easecopy.valueDone", "Valores aplicados") + ": " + String(result.count || 0);
      if (result.failed) message += " · " + t("easecopy.skipped", "omitidos") + ": " + result.failed;
      say(message, result.failed ? "error" : "success");
    });
  });
}());
