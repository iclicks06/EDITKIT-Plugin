/* ============================================================================
   EASEIT — LO QUE SABE HACER, EN LA PALETA

   EaseIt no cambia: cada comando de esta lista pulsa el botón que ya existía.
   Es a propósito. El editor de curvas es la parte del plugin que más años
   lleva funcionando, y añadirle una forma de llegar a sus botones no es razón
   para tocar uno solo de ellos.

   Lo que sí aporta de nuevo: los presets guardados entran también en la
   paleta. Con una biblioteca de treinta curvas, escribir tres letras es más
   rápido que buscarla con la vista, y hasta ahora no había otra manera.
   ============================================================================ */
(function () {
    "use strict";

    var C = window.EditKitCommands;
    if (!C) return;

    function T(key, fallback) {
        var s = (window.EditKitI18n && window.EditKitI18n.t) ? window.EditKitI18n.t(key) : key;
        return (s && s !== key) ? s : fallback;
    }

    function G() { return T("easeit.title", "EaseIt"); }
    function GP() { return T("easeit.presets", "Presets"); }

    function press(sel) {
        return function () {
            var el = document.querySelector(sel);
            if (el) el.click();
        };
    }

    function add(id, sel, key, fallback, keys, group) {
        if (!document.querySelector(sel)) return;
        C.register({
            id: "ease." + id,
            group: group || G,
            label: function () { return T(key, fallback); },
            run: press(sel),
            keys: keys || ""
        });
    }

    function registerFixed() {
        add("apply", "#applyBtn", "easeit.apply", "Aplicar curva", "ctrl+Enter");
        add("revert", "#revertBtn", "easeit.revertTip", "Volver a los keyframes originales", "");
        add("read", "#readBtn", "easeit.readTip", "Leer la curva de la selección", "");
        add("invert", "#invertBtn", "easeit.invertTip", "Invertir la curva", "");
        add("save", "#saveStar", "easeit.saveTip", "Guardar como preset", "");
        add("saveCurve", "#saveBtn", "easeit.saveCurve", "Guardar curva", "");
        add("import", "#importBtn", "easeit.importTip", "Importar presets", "");
        add("export", "#exportBtn", "easeit.exportTip", "Exportar presets", "");
        add("fit", "#tbFit", "easeit.fitView", "Encajar la curva en la vista", "");
        add("zoomIn", "#tbZoomIn", "easeit.zoomIn", "Acercar", "");
        add("zoomOut", "#tbZoomOut", "easeit.zoomOut", "Alejar", "");
        add("velocity", "#tbVel", "easeit.velocityOverlay", "Superponer la velocidad", "");
        add("settings", "#settingsBtn", "easeit.settingsTip", "Ajustes del panel", "");
        add("help", "#helpBtn", "easeit.helpTip", "Cómo usar EaseIt", "");
        add("collNew", "#collNew", "easeit.newCollection", "Nueva colección", "");
        add("collRename", "#collRename", "easeit.renameCollection", "Renombrar colección", "");
        add("collDelete", "#collDelete", "easeit.deleteCollection", "Borrar colección", "");
    }

    // ------------------------------------------------------------------
    // Los presets
    // ------------------------------------------------------------------
    /* La rejilla la construye el núcleo del panel, que aquí es una caja
       cerrada: no hay a qué engancharse para saber cuándo cambia. Se observa
       el DOM, que es la única señal fiable, y se vuelve a registrar con un
       respiro por medio para no rehacer la lista treinta veces mientras se
       está pintando. */
    var known = {};

    function presetName(el) {
        var n = el.getAttribute("title") || el.getAttribute("data-name") || el.textContent || "";
        return String(n).replace(/^\s+|\s+$/g, "");
    }

    function scanPresets() {
        var grid = document.getElementById("presetGrid");
        if (!grid) return;
        var kids = grid.children, seen = {};

        for (var i = 0; i < kids.length; i++) {
            var el = kids[i];
            var name = presetName(el);
            if (!name) continue;
            var id = "ease.preset." + name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
            seen[id] = true;
            if (known[id]) continue;
            known[id] = true;
            C.register({
                id: id,
                group: GP,
                label: (function (n) { return function () { return n; }; })(name),
                // Se guarda el nombre y no el nodo: la rejilla se repinta
                // entera al cambiar de colección, y un nodo guardado quedaría
                // huérfano y el comando dejaría de hacer nada.
                run: (function (n) {
                    return function () {
                        var g = document.getElementById("presetGrid");
                        if (!g) return;
                        for (var k = 0; k < g.children.length; k++) {
                            if (presetName(g.children[k]) === n) { g.children[k].click(); return; }
                        }
                    };
                })(name),
                keys: ""
            });
        }
    }

    var timer = null;
    function watchPresets() {
        var grid = document.getElementById("presetGrid");
        if (!grid || !window.MutationObserver) return;
        new MutationObserver(function () {
            if (timer) clearTimeout(timer);
            timer = setTimeout(scanPresets, 200);
        }).observe(grid, { childList: true, subtree: true });
    }

    function boot() {
        registerFixed();
        scanPresets();
        watchPresets();
    }

    // El núcleo pinta la rejilla después de cargar; un solo pase llegaría
    // pronto y encontraría el hueco vacío.
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
    else boot();
    setTimeout(boot, 900);
})();
