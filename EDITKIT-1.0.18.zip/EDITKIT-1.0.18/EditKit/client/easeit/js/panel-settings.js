/*
 * panel-settings.js — external "Ajustes" panel for EaseIt.
 *
 * index.js is a large minified/obfuscated closure, so this file drives the
 * same mechanisms index.js itself uses:
 *   - accent color: handed to EditKitAccent (shell/js/accent-bridge.js),
 *     which persists it under the shared "easeit_accent" key and relays it to
 *     the shell chrome and AlignIt. EaseIt's own repaint runs through
 *     window.EaseItAccentAPI — index.js exposes it so the *canvas* colours
 *     (the curve itself and every preset thumbnail) change with the CSS
 *     variables instead of keeping the old accent until the next reload.
 *     The CSS-only path below stays as a fallback for when this file is
 *     loaded without the bridge or without index.js.
 *   - preset size: same localStorage key ("easeit_preset_size") + the same
 *     --preset-size CSS variable / "compact" class toggle on #presetGrid.
 *   - section order: a new feature (EaseIt has no equivalent), fully owned
 *     by this file: reorders the actual .section elements inside
 *     .col-left and remembers the order for next time.
 */
(function () {
  "use strict";

  var ACCENT_KEY = "easeit_accent";
  var PRESET_SIZE_KEY = "easeit_preset_size";
  var SECTION_ORDER_KEY = "editkit_easeit_section_order";
  var HIDE_STATUS_KEY = "editkit_easeit_hide_status";
  var AUTO_APPLY_KEY = "easeit_autoapply";
  var HIDE_PRESETS_KEY = "editkit_easeit_hide_presets";
  var PRESETS_PLACE_KEY = "editkit_easeit_presets_place";   // "side" | "bottom"
  var PRESETS_TITLE_KEY = "editkit_easeit_presets_title";   // "0" oculta el rotulo
  var SECTION_HIDE_KEY = "editkit_easeit_section_hidden";
  var DEFAULT_ACCENT = "#49c9bd";
  var SWATCHES = ["#49c9bd", "#22D3EE", "#8B5CF6", "#34C759", "#FF9F0A", "#FF375F", "#0A84FF", "#FFB648"];

  function t(key) {
    return (window.EditKitI18n && window.EditKitI18n.t(key)) || key;
  }

  var SECTION_LABEL_KEYS = {
    previewSection: "settings.previewSection",
    curveSection: "settings.curveSection",
    applySection: "settings.applySection"
  };
  var DEFAULT_ORDER = ["previewSection", "curveSection", "applySection"];

  function $(id) { return document.getElementById(id); }

  // ---------- accent (same math as index.js's internal accent picker) ----------
  function hexToRgb(hex) {
    if (!hex) return null;
    hex = String(hex).replace("#", "");
    if (hex.length === 3) hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
    if (hex.length !== 6) return null;
    return {
      r: parseInt(hex.substr(0, 2), 16),
      g: parseInt(hex.substr(2, 2), 16),
      b: parseInt(hex.substr(4, 2), 16)
    };
  }
  function clamp255(v) { return Math.max(0, Math.min(255, Math.round(v))); }
  function shade(rgb, amt) {
    return "rgb(" + clamp255(rgb.r + amt) + "," + clamp255(rgb.g + amt) + "," + clamp255(rgb.b + amt) + ")";
  }
  /* CSS-only repaint. Correct for every styled element, but blind to the two
     <canvas> surfaces — hence paintEaseIt() below, which prefers index.js's own
     accent path when it is available. */
  function applyAccentCss(hex) {
    var rgb = hexToRgb(hex);
    if (!rgb) return;
    var style = document.documentElement.style;
    style.setProperty("--accent", hex);
    style.setProperty("--accent-2", shade(rgb, -30));
    style.setProperty("--grad", "linear-gradient(135deg, " + shade(rgb, 22) + ", " + shade(rgb, -28) + ")");
    style.setProperty("--accent-dim", "rgba(" + rgb.r + "," + rgb.g + "," + rgb.b + ",0.16)");
    style.setProperty("--accent-border", "rgba(" + rgb.r + "," + rgb.g + "," + rgb.b + ",0.5)");
  }
  function paintEaseIt(hex) {
    if (window.EaseItAccentAPI && window.EaseItAccentAPI.apply) {
      // Sets the same CSS variables *and* the curve/thumbnail stroke colours,
      // then redraws the graph and rebuilds the preset grid.
      window.EaseItAccentAPI.apply(hex);
    } else {
      applyAccentCss(hex);
    }
  }
  /* The one entry point the UI below uses. With the bridge loaded this also
     reaches the shell header and AlignIt; without it, EaseIt still
     recolors itself. */
  function setAccent(hex) {
    if (window.EditKitAccent) {
      window.EditKitAccent.set(hex);
    } else {
      paintEaseIt(hex);
      saveAccent(hex);
    }
  }
  function saveAccent(hex) {
    try { localStorage.setItem(ACCENT_KEY, hex); } catch (e) {}
  }
  function getSavedAccent() {
    if (window.EditKitAccent) return window.EditKitAccent.get();
    try { return localStorage.getItem(ACCENT_KEY) || DEFAULT_ACCENT; } catch (e) { return DEFAULT_ACCENT; }
  }

  // ---------- preset size (same key/behavior as index.js's own slider) ----------
  var COMPACT_THRESHOLD = 48;
  function applyPresetSize(px) {
    px = Math.max(30, Math.min(140, Math.round(px)));
    document.documentElement.style.setProperty("--preset-size", px + "px");
    var grid = $("presetGrid");
    if (grid) grid.classList.toggle("compact", px < COMPACT_THRESHOLD);
    return px;
  }
  function savePresetSize(px) {
    try { localStorage.setItem(PRESET_SIZE_KEY, String(px)); } catch (e) {}
  }
  function getSavedPresetSize() {
    var v = null;
    try { v = Number(localStorage.getItem(PRESET_SIZE_KEY)); } catch (e) {}
    return isFinite(v) && v > 0 ? v : 48;
  }

  // ---------- hide status/confirmations (new) ----------
  function getHideStatus() {
    try { return localStorage.getItem(HIDE_STATUS_KEY) === "1"; } catch (e) { return false; }
  }
  function applyHideStatus(hide) {
    document.body.classList.toggle("easeit-hide-status", !!hide);
  }
  function saveHideStatus(hide) {
    try { localStorage.setItem(HIDE_STATUS_KEY, hide ? "1" : "0"); } catch (e) {}
  }

  function getAutoApply() {
    try {
      var saved = localStorage.getItem(AUTO_APPLY_KEY);
      return saved === null ? true : saved === "1";
    } catch (e) { return true; }
  }
  function setAutoApply(on) {
    try { localStorage.setItem(AUTO_APPLY_KEY, on ? "1" : "0"); } catch (e) {}
    try {
      window.dispatchEvent(new CustomEvent("easeit:autoapply-change", {
        detail: { enabled: !!on }
      }));
    } catch (e2) {}
  }

  /* ---------- ocultar la columna de presets (nuevo) ----------
     La biblioteca cuesta unos 150 px de ancho de forma permanente, y hay mucha
     gente que trabaja desde el editor de curvas y la visita de vez en cuando.
     Ocultarla no quita nada: la columna sigue en el documento, solo deja de
     verse, y todo lo que vivia dentro —presets guardados, guardar, importar,
     exportar, colecciones— sigue a un Ctrl+K de distancia desde la paleta de
     comandos. Por eso se puede esconder sin dejar al usuario sin salida. */
  function getHidePresets() {
    try { return localStorage.getItem(HIDE_PRESETS_KEY) === "1"; } catch (e) { return false; }
  }
  function applyHidePresets(hide) {
    document.body.classList.toggle("easeit-hide-presets", !!hide);
    // El nucleo mide la rejilla al repintar; sin avisarle, las miniaturas se
    // quedan con el tamano que tenian cuando la columna era visible.
    try { window.dispatchEvent(new Event("resize")); } catch (e) {}
  }
  function saveHidePresets(hide) {
    try { localStorage.setItem(HIDE_PRESETS_KEY, hide ? "1" : "0"); } catch (e) {}
  }

  // ---------- donde vive la biblioteca de presets ----------
  /* De lado, que es como nacio, o al pie de la columna: justo encima de "Cada
     par" y justo debajo de los botones de aplicar. La diferencia no es de
     gusto. De lado, la curva y los presets se reparten el ancho y en un panel
     estrecho no queda sitio para ninguno de los dos; abajo, la curva se lleva
     el ancho entero y los presets se leen en una rejilla mas ancha.

     Se mueve el nodo de verdad y no se dibuja dos veces: la rejilla la construye
     el nucleo de EaseIt, que no sabe nada de esto, y tener dos copias seria
     tener una desactualizada. appendChild sobre un nodo que ya existe lo MUEVE,
     que es exactamente lo que hace falta. */
  function getPresetsPlace() {
    try { return localStorage.getItem(PRESETS_PLACE_KEY) === "bottom" ? "bottom" : "side"; }
    catch (e) { return "side"; }
  }
  function savePresetsPlace(place) {
    try { localStorage.setItem(PRESETS_PLACE_KEY, place); } catch (e) {}
  }
  function applyPresetsPlace(place) {
    var sec = $("presetsSection");
    var eachPairSec = $("eachPairSection");
    var applySec = $("applySection");
    var left = document.querySelector(".col-left");
    var right = document.querySelector(".col-right");
    var curve = $("curveSection");
    if (!sec || !right) return;
    var premiere = document.body.classList.contains("host-ppro");

    if (place === "bottom" && curve && left) {
      // En Premiere Aplicar a acompana siempre a la biblioteca: justo debajo
      // de los controles de curva y justo encima del primer preset.
      if (premiere && applySec) left.insertBefore(applySec, curve.nextSibling);
      left.insertBefore(sec, premiere && applySec ? applySec.nextSibling : curve.nextSibling);
    } else {
      if (premiere && applySec) right.appendChild(applySec);
      right.appendChild(sec);
    }
    /* En After Effects "Cada par" es el cierre de la herramienta, no un
       control que se consulte durante cada aplicación. Como la biblioteca se
       puede mudar entre columnas, esta fila debe acompañarla y quedar siempre
       inmediatamente después de ella. */
    if (!premiere && eachPairSec && sec.parentNode) {
      sec.parentNode.insertBefore(eachPairSec, sec.nextSibling);
    }
    document.body.classList.toggle("easeit-presets-bottom", place === "bottom");

    // El nucleo mide la rejilla al repintar; sin avisarle, las miniaturas se
    // quedan con el ancho que tenian en la columna de antes.
    try { window.dispatchEvent(new Event("resize")); } catch (e) {}
  }

  function getPresetsTitle() {
    try { return localStorage.getItem(PRESETS_TITLE_KEY) !== "0"; } catch (e) { return true; }
  }
  function savePresetsTitle(on) {
    try { localStorage.setItem(PRESETS_TITLE_KEY, on ? "1" : "0"); } catch (e) {}
  }
  function applyPresetsTitle(on) {
    var el = $("presetsLabel");
    if (el) el.hidden = !on;
  }

  // ---------- section order (new) ----------
  function getSavedOrder() {
    try {
      var arr = JSON.parse(localStorage.getItem(SECTION_ORDER_KEY));
      if (Array.isArray(arr) && arr.length === DEFAULT_ORDER.length) return arr;
    } catch (e) {}
    return DEFAULT_ORDER.slice();
  }
  function saveOrder(order) {
    try { localStorage.setItem(SECTION_ORDER_KEY, JSON.stringify(order)); } catch (e) {}
  }
  function applyOrder(order) {
    var colLeft = document.querySelector(".col-left");
    if (!colLeft) return;
    order.forEach(function (id) {
      // En Premiere Aplicar a pertenece a la barra fija sobre los presets;
      // reordenarlo aqui lo devolveria al fondo de la columna de la curva.
      if (id === "applySection" && document.body.classList.contains("host-ppro")) return;
      var el = $(id);
      if (el) colLeft.appendChild(el); // appendChild on an existing node MOVES it — order is preserved
    });
    applyHidden();
  }

  /* Que secciones estan apagadas. Se guarda lo apagado y no lo encendido a
     proposito: asi una seccion nueva aparece por defecto, en lugar de nacer
     oculta para todo el que ya tenia el panel instalado. */
  function getHidden() {
    try {
      var o = JSON.parse(localStorage.getItem(SECTION_HIDE_KEY));
      return (o && typeof o === "object") ? o : {};
    } catch (e) { return {}; }
  }
  function saveHidden(map) {
    try { localStorage.setItem(SECTION_HIDE_KEY, JSON.stringify(map)); } catch (e) {}
  }
  function applyHidden() {
    var map = getHidden();
    var firstVisible = true;
    DEFAULT_ORDER.forEach(function (id) {
      var el = $(id);
      if (!el) return;
      el.hidden = (id === "applySection" && document.body.classList.contains("host-ppro")) ? false : !!map[id];
      el.classList.remove("easeit-first-visible");
    });
    /* :first-child no significa "primera sección visible": una sección con
       [hidden] sigue ocupando su lugar en el árbol. Marcamos la primera que
       realmente se ve para que la curva no herede el aire reservado a la
       vista previa cuando esta está apagada. También respeta cualquier orden
       personalizado por el usuario. */
    Array.prototype.forEach.call(document.querySelectorAll(".col-left > .section"), function (el) {
      if (!el.hidden && firstVisible) {
        el.classList.add("easeit-first-visible");
        firstVisible = false;
      }
    });
  }

  // ---------- boot: apply whatever was already saved ----------
  applyOrder(getSavedOrder());
  applyHideStatus(getHideStatus());
  applyHidePresets(getHidePresets());
  applyPresetsPlace(getPresetsPlace());
  applyPresetsTitle(getPresetsTitle());
  // Preset size is already applied by index.js's own boot logic (it reads the
  // very same localStorage key) — nothing to do here.

  // ---------- build the settings modal (reuses EaseIt's own .modal styles) ----------
  var overlay = null;
  var accentInput = null; // live <input type=color> while the modal is open

  // Repaint EaseIt whenever the accent changes anywhere in EditKit — this modal,
  // EaseIt's flyout picker, or AlignIt's Appearance tab. One painter for
  // the lifetime of the pane; the modal is built and torn down many times.
  if (window.EditKitAccent) {
    window.EditKitAccent.onChange(function (hex) {
      paintEaseIt(hex);
      /* Never write into the picker while it has focus: in CEP the native
         colour chooser stays bound to the element, so assigning .value pushes
         the colour back into the open chooser, which reports it as a change,
         which lands right back here. See accent-picker-fix.js for the same
         problem in EaseIt's own accent modal. */
      if (accentInput && accentInput.value !== hex && document.activeElement !== accentInput) {
        accentInput.value = hex;
      }
    });
  }

  function closeModal() {
    if (!overlay) return;
    accentInput = null;
    overlay.classList.remove("show");
    setTimeout(function () {
      if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
      overlay = null;
    }, 180);
  }

  /* La lista de secciones. Antes se reordenaba con una flecha arriba y otra
     abajo; ahora se arrastra la fila entera, que es el gesto que ya usa AlignIt
     para lo mismo y el que espera cualquiera delante de una lista de tres
     cosas. Las flechas obligaban a contar pasos: para bajar la primera al final
     habia dos clics y ninguna forma de verlo venir.

     La casilla apaga la seccion sin sacarla de la lista: sigue teniendo un
     sitio en el orden, y volver a encenderla la devuelve donde estaba. */
  var dragId = null;

  function renderOrderList(listEl) {
    var order = getSavedOrder();
    var hidden = getHidden();
    listEl.innerHTML = "";

    order.forEach(function (id) {
      if (id === "applySection" && document.body.classList.contains("host-ppro")) return;
      var row = document.createElement("div");
      row.className = "easeit-order-row";
      row.setAttribute("draggable", "true");
      row.setAttribute("data-id", id);
      if (hidden[id]) row.classList.add("is-hidden");

      var grip = document.createElement("span");
      grip.className = "easeit-order-grip";
      grip.innerHTML = '<svg class="ms" viewBox="0 -960 960 960" width="13" height="13" fill="currentColor" aria-hidden="true"><path d="M360-160q-33 0-56.5-23.5T280-240q0-33 23.5-56.5T360-320q33 0 56.5 23.5T440-240q0 33-23.5 56.5T360-160Zm240 0q-33 0-56.5-23.5T520-240q0-33 23.5-56.5T600-320q33 0 56.5 23.5T680-240q0 33-23.5 56.5T600-160ZM360-400q-33 0-56.5-23.5T280-480q0-33 23.5-56.5T360-560q33 0 56.5 23.5T440-480q0 33-23.5 56.5T360-400Zm240 0q-33 0-56.5-23.5T520-480q0-33 23.5-56.5T600-560q33 0 56.5 23.5T680-480q0 33-23.5 56.5T600-400ZM360-640q-33 0-56.5-23.5T280-720q0-33 23.5-56.5T360-800q33 0 56.5 23.5T440-720q0 33-23.5 56.5T360-640Zm240 0q-33 0-56.5-23.5T520-720q0-33 23.5-56.5T600-800q33 0 56.5 23.5T680-720q0 33-23.5 56.5T600-640Z"/></svg>';
      row.appendChild(grip);

      var chk = document.createElement("input");
      chk.type = "checkbox";
      chk.className = "easeit-order-check";
      chk.checked = !hidden[id];
      chk.title = t("settings.sectionVisible");
      chk.addEventListener("change", function () {
        var map = getHidden();
        map[id] = !chk.checked;
        // Sin ninguna seccion el panel es un rectangulo vacio, y el interruptor
        // para recuperarla esta dentro de esta misma ventana.
        var live = 0;
        DEFAULT_ORDER.forEach(function (x) { if (!map[x]) live++; });
        if (!live) { map[id] = false; chk.checked = true; }
        saveHidden(map);
        applyHidden();
        renderOrderList(listEl);
      });
      row.appendChild(chk);

      var label = document.createElement("span");
      label.className = "easeit-order-label";
      label.textContent = t(SECTION_LABEL_KEYS[id]) || id;
      row.appendChild(label);

      row.addEventListener("dragstart", function (e) {
        dragId = id;
        row.classList.add("dragging");
        try {
          e.dataTransfer.effectAllowed = "move";
          e.dataTransfer.setData("text/plain", id);
        } catch (err) {}
      });
      row.addEventListener("dragend", function () {
        dragId = null;
        row.classList.remove("dragging");
        Array.prototype.forEach.call(listEl.children, function (c) { c.classList.remove("drag-over"); });
      });
      row.addEventListener("dragover", function (e) {
        if (!dragId || dragId === id) return;
        e.preventDefault();
        try { e.dataTransfer.dropEffect = "move"; } catch (err) {}
        row.classList.add("drag-over");
      });
      row.addEventListener("dragleave", function () { row.classList.remove("drag-over"); });
      row.addEventListener("drop", function (e) {
        e.preventDefault();
        row.classList.remove("drag-over");
        if (!dragId || dragId === id) return;
        var o = getSavedOrder();
        var from = o.indexOf(dragId);
        var to = o.indexOf(id);
        if (from < 0 || to < 0) return;
        o.splice(to, 0, o.splice(from, 1)[0]);
        dragId = null;
        saveOrder(o);
        applyOrder(o);
        renderOrderList(listEl);
      });

      listEl.appendChild(row);
    });
  }

  function openModal() {
    if (overlay) return;
    overlay = document.createElement("div");
    // ek-overlay le da el mismo aire a los lados que tienen las hojas de los
    // otros dos. El .modal-overlay de EaseIt no llevaba ninguno, asi que su
    // hoja llegaba a tocar los cuatro bordes de la ventana.
    overlay.className = "modal-overlay ek-overlay";

    var modal = document.createElement("div");
    /* ek-sheet es la marca que hace que esta ventana se vea como las de QuickIt
       y AlignIt: shell/css/sheet.css es el unico sitio donde se decide como es
       una ventana de ajustes de EditKit. Solo la lleva esta: la bienvenida y la
       ayuda siguen con el molde de siempre. */
    modal.className = "modal wide ek-sheet";

    /* Una barra arriba con el nombre y la cruz, igual que los otros dos. Antes
       era un h3 suelto y un boton "Listo" al fondo: para cerrarla habia que
       desplazarse hasta abajo, y con tres paneles abiertos y la hoja tapandolo
       todo, un titulo que dijera "Ajustes del panel" no decia de que panel. */
    var head = document.createElement("div");
    head.className = "ek-sheet-head";

    var title = document.createElement("span");
    title.className = "ek-sheet-title";
    title.textContent = t("settings.title");
    head.appendChild(title);

    var x = document.createElement("button");
    x.type = "button";
    x.className = "ek-close";
    x.title = t("settings.close");
    x.setAttribute("aria-label", t("settings.close"));
    x.innerHTML = '<svg viewBox="0 -960 960 960" width="13" height="13" fill="currentColor" aria-hidden="true"><path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg>';
    x.addEventListener("click", closeModal);
    head.appendChild(x);

    modal.appendChild(head);

    /* Las mismas pestañas, con los mismos nombres, que AlignIt: General y
       Apariencia, y Atajos al final porque AlignIt no tiene y los otros dos
       si. Sin Secciones aparte: aqui el orden de tres secciones no pesa lo
       bastante como para ganarse su propia pestaña, y vive dentro de
       Apariencia, una mas entre el color y el papel cebolla. */
    var TABS = [
      { id: "general", key: "settings.tabGeneral",
        icon: '<svg class="ms" viewBox="0 -960 960 960" width="13" height="13" fill="currentColor" aria-hidden="true"><path d="M440-120v-240h80v80h320v80H520v80h-80Zm-320-80v-80h240v80H120Zm160-160v-80H120v-80h160v-80h80v240h-80Zm160-80v-80h400v80H440Zm160-160v-240h80v80h160v80H680v80h-80Zm-480-80v-80h400v80H120Z"/></svg>' },
      { id: "appearance", key: "settings.tabAppearance",
        icon: '<svg class="ms" viewBox="0 -960 960 960" width="13" height="13" fill="currentColor" aria-hidden="true"><path d="M480-80q-82 0-155-31.5t-127.5-86Q143-252 111.5-325T80-480q0-83 32.5-156t88-127Q256-817 330-848.5T488-880q80 0 151 27.5t124.5 76q53.5 48.5 85 115T880-518q0 115-70 176.5T640-280h-74q-9 0-12.5 5t-3.5 11q0 12 15 34.5t15 51.5q0 50-27.5 74T480-80Zm0-400Zm-177 23q17-17 17-43t-17-43q-17-17-43-17t-43 17q-17 17-17 43t17 43q17 17 43 17t43-17Zm120-160q17-17 17-43t-17-43q-17-17-43-17t-43 17q-17 17-17 43t17 43q17 17 43 17t43-17Zm200 0q17-17 17-43t-17-43q-17-17-43-17t-43 17q-17 17-17 43t17 43q17 17 43 17t43-17Zm120 160q17-17 17-43t-17-43q-17-17-43-17t-43 17q-17 17-17 43t17 43q17 17 43 17t43-17ZM480-160q9 0 14.5-5t5.5-13q0-14-15-33t-15-57q0-42 29-67t71-25h70q66 0 113-38.5T800-518q0-121-92.5-201.5T488-800q-136 0-232 93t-96 227q0 133 93.5 226.5T480-160Z"/></svg>' }
    ];
    if (window.EaseItQuick) {
      TABS.push({ id: "shortcuts", key: "settings.tabShortcuts",
        icon: '<svg class="ms" viewBox="0 -960 960 960" width="13" height="13" fill="currentColor" aria-hidden="true"><rect x="120" y="-640" width="720" height="480" rx="40" fill="none" stroke="currentColor" stroke-width="60"/><rect x="220" y="-540" width="80" height="80" fill="currentColor"/><rect x="340" y="-540" width="80" height="80" fill="currentColor"/><rect x="460" y="-540" width="80" height="80" fill="currentColor"/><rect x="580" y="-540" width="80" height="80" fill="currentColor"/><rect x="220" y="-400" width="520" height="70" fill="currentColor"/></svg>' });
    }

    var nav = document.createElement("div");
    nav.className = "settings-nav";
    nav.setAttribute("role", "tablist");
    nav.setAttribute("data-tabs", String(TABS.length));

    var body = document.createElement("div");
    body.className = "modal-body easeit-settings-body ek-sheet-body";
    // Para que la barra de desplazamiento fina lo reconozca sin que haya que
    // enumerarlo por selector como el resto de modales del nucleo.
    body.setAttribute("data-ek-scroll", "");

    var navButtons = {}, panels = {};
    TABS.forEach(function (tab, i) {
      var on = i === 0;
      var navBtn = document.createElement("button");
      navBtn.type = "button";
      navBtn.className = "settings-nav-btn" + (on ? " active" : "");
      navBtn.setAttribute("data-settings-panel", tab.id);
      navBtn.setAttribute("role", "tab");
      navBtn.setAttribute("aria-selected", on ? "true" : "false");
      navBtn.innerHTML = tab.icon;
      var navLabel = document.createElement("span");
      navLabel.className = "settings-nav-label";
      navLabel.textContent = t(tab.key);
      navBtn.appendChild(navLabel);
      navBtn.addEventListener("click", function () {
        TABS.forEach(function (t2) {
          var hit = t2.id === tab.id;
          navButtons[t2.id].classList.toggle("active", hit);
          navButtons[t2.id].setAttribute("aria-selected", hit ? "true" : "false");
          panels[t2.id].classList.toggle("active", hit);
          panels[t2.id].hidden = !hit;
        });
        // Cada pestaña empieza por su principio. Antes el cuerpo conservaba
        // el scroll de Apariencia y Atajos aparecía desplazada hacia arriba,
        // como si faltara su primera parte.
        body.scrollTop = 0;
      });
      nav.appendChild(navBtn);
      navButtons[tab.id] = navBtn;

      var pane = document.createElement("div");
      pane.className = "settings-panel" + (on ? " active" : "");
      pane.setAttribute("data-settings-content", tab.id);
      pane.hidden = !on;
      body.appendChild(pane);
      panels[tab.id] = pane;
    });

    modal.appendChild(nav);

    // ==================== APARIENCIA ====================
    var appearance = panels.appearance;

    // --- accent ---
    var accentLabel = document.createElement("div");
    accentLabel.className = "micro-label";
    accentLabel.textContent = t("settings.accentColor");
    appearance.appendChild(accentLabel);

    /* El selector y las ocho muestras son un solo control: las muestras
       viven DENTRO de la fila del selector, no como un hermano suelto, para
       que el espacio entre ellos sea el de la fila y no el de la seccion. */
    var accentRow = document.createElement("div");
    accentRow.className = "accent-row";
    var colorInput = document.createElement("input");
    colorInput.type = "color";
    colorInput.value = getSavedAccent();
    colorInput.addEventListener("input", function () {
      setAccent(colorInput.value);
    });
    accentInput = colorInput;
    accentRow.appendChild(colorInput);

    var swatchWrap = document.createElement("div");
    swatchWrap.className = "swatches";
    SWATCHES.forEach(function (hex) {
      var sw = document.createElement("span");
      sw.className = "sw";
      sw.style.background = hex;
      /* EaseIt's own accent modal binds its click handler to every
         ".swatches .sw" in the *document*, these included, and reads the colour
         off data-c. Without the attribute that handler fires with null, which
         ends up stored in the shared accent key as the string "null" and stops
         the core repainting at all. Carrying data-c makes a stray binding
         harmless: it applies the colour the swatch actually shows. */
      sw.setAttribute("data-c", hex);
      sw.addEventListener("click", function () {
        setAccent(hex); colorInput.value = hex;
      });
      swatchWrap.appendChild(sw);
    });
    accentRow.appendChild(swatchWrap);
    appearance.appendChild(accentRow);

    // El recuadro pertenece únicamente a EaseIt. El componente compartido
    // conserva la misma lógica que AlignIt, pero se monta dentro de la ventana
    // de este panel cuando se abre, nunca en los ajustes generales de EditKit.
    var surfaceMediaMount = document.createElement("div");
    surfaceMediaMount.className = "surface-media-mount";
    surfaceMediaMount.setAttribute("data-surface-media-mount", "ease");
    appearance.appendChild(surfaceMediaMount);

    // --- preset size ---
    var sizeLabel = document.createElement("div");
    sizeLabel.className = "micro-label easeit-settings-spacer";
    sizeLabel.textContent = t("settings.presetSize");
    appearance.appendChild(sizeLabel);

    var sizeRow = document.createElement("div");
    sizeRow.className = "psize";
    var sizeSlider = document.createElement("input");
    sizeSlider.type = "range";
    sizeSlider.min = "30";
    sizeSlider.max = "140";
    sizeSlider.step = "2";
    sizeSlider.value = String(getSavedPresetSize());
    sizeSlider.addEventListener("input", function () {
      var px = applyPresetSize(sizeSlider.value);
      savePresetSize(px);
    });
    sizeRow.appendChild(sizeSlider);
    appearance.appendChild(sizeRow);

    // --- papel cebolla ---
    // Si onion-skin.js no llego a cargar, la casilla no se pone — una casilla
    // que no hace nada es peor que no tenerla.
    if (window.EaseItOnionSettings) {
      var onionRow = document.createElement("label");
      onionRow.className = "toggle easeit-settings-spacer";
      var onionChk = document.createElement("input");
      onionChk.type = "checkbox";
      onionChk.checked = window.EaseItOnionSettings.isOn();
      var onionSpan = document.createElement("span");
      onionSpan.textContent = t("settings.onion");
      onionRow.appendChild(onionChk);
      onionRow.appendChild(onionSpan);
      appearance.appendChild(onionRow);

      /* Opacidad: solo si la version cargada de onion-skin.js la sabe guardar.
         Con el papel cebolla apagado el deslizador se queda, pero atenuado. */
      if (window.EaseItOnionSettings.setAlpha) {
        var onionAlphaRow = document.createElement("div");
        onionAlphaRow.className = "psize easeit-onion-alpha";
        var onionAlphaName = document.createElement("span");
        onionAlphaName.textContent = t("settings.onionAlpha");
        var onionAlpha = document.createElement("input");
        onionAlpha.type = "range";
        onionAlpha.min = String(window.EaseItOnionSettings.min);
        onionAlpha.max = String(window.EaseItOnionSettings.max);
        onionAlpha.step = "1";
        onionAlpha.value = String(window.EaseItOnionSettings.alpha());
        onionAlpha.setAttribute("aria-label", t("settings.onionAlpha"));
        var onionAlphaVal = document.createElement("span");
        onionAlphaVal.className = "easeit-onion-alpha-val";
        onionAlphaVal.textContent = onionAlpha.value + " %";
        onionAlpha.addEventListener("input", function () {
          onionAlphaVal.textContent = onionAlpha.value + " %";
          window.EaseItOnionSettings.setAlpha(onionAlpha.value);
        });
        onionAlphaRow.appendChild(onionAlphaName);
        onionAlphaRow.appendChild(onionAlpha);
        onionAlphaRow.appendChild(onionAlphaVal);
        appearance.appendChild(onionAlphaRow);
      }
      var syncOnionAlpha = function () {
        if (!onionAlphaRow) return;
        onionAlphaRow.classList.toggle("off", !onionChk.checked);
        onionAlpha.disabled = !onionChk.checked;
      };
      syncOnionAlpha();
      onionChk.addEventListener("change", function () {
        window.EaseItOnionSettings.set(onionChk.checked);
        syncOnionAlpha();
      });

      var onionHint = document.createElement("p");
      onionHint.className = "hint easeit-settings-hint";
      onionHint.textContent = t("settings.onionHint");
      appearance.appendChild(onionHint);
    }

    // --- section order --- (sin pestaña propia: una sección más de Apariencia)
    var orderLabel = document.createElement("div");
    orderLabel.className = "micro-label easeit-settings-spacer";
    orderLabel.textContent = t("settings.sectionOrder");
    appearance.appendChild(orderLabel);

    var orderHint = document.createElement("p");
    orderHint.className = "hint easeit-settings-hint";
    orderHint.textContent = t("settings.sectionOrderHint");
    appearance.appendChild(orderHint);

    var orderList = document.createElement("div");
    orderList.className = "easeit-order-list";
    renderOrderList(orderList);
    appearance.appendChild(orderList);

    // ==================== GENERAL ====================
    var general = panels.general;

    // --- aplicar al escoger una curva o esperar al boton Aplicar ---
    var autoApplyRow = document.createElement("label");
    autoApplyRow.className = "toggle";
    var autoApplyChk = document.createElement("input");
    autoApplyChk.type = "checkbox";
    autoApplyChk.checked = getAutoApply();
    autoApplyChk.addEventListener("change", function () {
      setAutoApply(autoApplyChk.checked);
    });
    var autoApplySpan = document.createElement("span");
    autoApplySpan.textContent = t("settings.autoApply");
    autoApplyRow.appendChild(autoApplyChk);
    autoApplyRow.appendChild(autoApplySpan);
    general.appendChild(autoApplyRow);

    var autoApplyHint = document.createElement("p");
    autoApplyHint.className = "hint easeit-settings-hint";
    autoApplyHint.textContent = t("settings.autoApplyHint");
    general.appendChild(autoApplyHint);

    // --- mostrar u ocultar la biblioteca de presets ---
    var presetsRow = document.createElement("label");
    presetsRow.className = "toggle";
    var presetsChk = document.createElement("input");
    presetsChk.type = "checkbox";
    presetsChk.checked = !getHidePresets();
    presetsChk.addEventListener("change", function () {
      applyHidePresets(!presetsChk.checked);
      saveHidePresets(!presetsChk.checked);
    });
    var presetsSpan = document.createElement("span");
    presetsSpan.textContent = t("settings.showPresets");
    presetsRow.appendChild(presetsChk);
    presetsRow.appendChild(presetsSpan);
    general.appendChild(presetsRow);

    var presetsHint = document.createElement("p");
    presetsHint.className = "hint easeit-settings-hint";
    presetsHint.textContent = t("settings.showPresetsHint");
    general.appendChild(presetsHint);

    // --- donde va la biblioteca ---
    var placeRow = document.createElement("label");
    placeRow.className = "toggle";
    var placeChk = document.createElement("input");
    placeChk.type = "checkbox";
    placeChk.checked = getPresetsPlace() === "bottom";
    placeChk.addEventListener("change", function () {
      var place = placeChk.checked ? "bottom" : "side";
      savePresetsPlace(place);
      applyPresetsPlace(place);
    });
    var placeSpan = document.createElement("span");
    placeSpan.textContent = t("settings.presetsBottom");
    placeRow.appendChild(placeChk);
    placeRow.appendChild(placeSpan);
    general.appendChild(placeRow);

    var placeHint = document.createElement("p");
    placeHint.className = "hint easeit-settings-hint";
    placeHint.textContent = t("settings.presetsBottomHint");
    general.appendChild(placeHint);

    // --- el rotulo "Presets" ---
    var titleRow = document.createElement("label");
    titleRow.className = "toggle";
    var titleChk = document.createElement("input");
    titleChk.type = "checkbox";
    titleChk.checked = getPresetsTitle();
    titleChk.addEventListener("change", function () {
      savePresetsTitle(titleChk.checked);
      applyPresetsTitle(titleChk.checked);
    });
    var titleSpan = document.createElement("span");
    titleSpan.textContent = t("settings.presetsTitle");
    titleRow.appendChild(titleChk);
    titleRow.appendChild(titleSpan);
    general.appendChild(titleRow);

    // --- show/hide status & confirmations ---
    var statusRow = document.createElement("label");
    statusRow.className = "toggle easeit-settings-spacer";
    var statusChk = document.createElement("input");
    statusChk.type = "checkbox";
    statusChk.checked = !getHideStatus();
    statusChk.addEventListener("change", function () {
      applyHideStatus(!statusChk.checked);
      saveHideStatus(!statusChk.checked);
    });
    var statusSpan = document.createElement("span");
    statusSpan.textContent = t("settings.showStatus");
    statusRow.appendChild(statusChk);
    statusRow.appendChild(statusSpan);
    general.appendChild(statusRow);

    // Que los errores tambien callen hay que decirlo. Un interruptor que
    // silencia mas de lo que su nombre promete es una trampa, no un ajuste.
    var statusHint = document.createElement("p");
    statusHint.className = "hint easeit-settings-hint";
    statusHint.textContent = t("settings.showStatusHint");
    general.appendChild(statusHint);

    // ==================== ATAJOS ====================
    if (window.EaseItQuick && panels.shortcuts) {
      var shortcuts = panels.shortcuts;

      var shRow = document.createElement("label");
      shRow.className = "toggle";
      var shChk = document.createElement("input");
      shChk.type = "checkbox";
      shChk.checked = window.EaseItQuick.isEnabled();
      shChk.addEventListener("change", function () {
        window.EaseItQuick.setEnabled(shChk.checked);
      });
      var shSpan = document.createElement("span");
      shSpan.textContent = t("settings.shortcutsOn");
      shRow.appendChild(shChk);
      shRow.appendChild(shSpan);
      shortcuts.appendChild(shRow);

      var shSee = document.createElement("div");
      shSee.className = "link easeit-settings-spacer";
      shSee.textContent = t("settings.shortcutsSee");
      shSee.addEventListener("click", function () {
        closeModal();
        setTimeout(function () { window.EaseItQuick.showHelp(); }, 220);
      });
      shortcuts.appendChild(shSee);
    }

    modal.appendChild(body);

    overlay.appendChild(modal);
    overlay.addEventListener("click", function (e) {
      if (e.target === overlay) closeModal();
    });
    document.body.appendChild(overlay);
    if (window.EditKitSettingsSearch) window.EditKitSettingsSearch.mount(modal);

    /* Hay que montar el editor DESPUES de insertar la ventana en document.
       El componente busca sus campos por id para traducirlos y enlazar sus
       eventos; dentro de un arbol desconectado los campos existen, pero
       document.getElementById todavía no puede encontrarlos. AlignIt ya nace
       conectado porque su ventana está escrita en el HTML; este orden deja a
       EaseIt exactamente en la misma situación. */
    (function mountSurfaceEditor(attempt) {
      if (window.EditKitSurfaceMedia && window.EditKitSurfaceMedia.mount) {
        window.EditKitSurfaceMedia.mount("ease", surfaceMediaMount);
        if (window.EditKitResponsiveTabs) window.EditKitResponsiveTabs.refresh();
        return;
      }
      if (attempt < 12 && surfaceMediaMount.parentNode) {
        setTimeout(function () { mountSurfaceEditor(attempt + 1); }, 40);
      }
    })(0);

    if (window.EditKitMountToolIcon) window.EditKitMountToolIcon("easeit");
    requestAnimationFrame(function () { overlay.classList.add("show"); });
  }

  /* Esc cierra, que es lo que hacen las hojas de los otros dos y lo que espera
     cualquiera delante de algo que tapa la ventana. Se escucha siempre y se
     mira si hay algo abierto: enganchar y desenganchar el manejador con cada
     apertura deja un rastro de manejadores si algo revienta a mitad. */
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && overlay) closeModal();
  });

  var btn = $("settingsBtn");
  if (btn) btn.addEventListener("click", openModal);
})();
