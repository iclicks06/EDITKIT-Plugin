/* ============================================================================
   EASEIT — EL NUCLEO

   Este archivo venia ofuscado desde el producto anterior de donde salio EaseIt,
   y con el venian sus restos: comprobacion de licencias, un contador semanal
   de usos gratis de True Handles, un actualizador que se descargaba e instalaba
   solo, avisos remotos, formularios de soporte que enviaban a un servidor,
   analitica con su consentimiento y un contador de tiempo de uso. En EDITKIT
   nada de eso hacia nada —un doble lo desactivaba todo—, pero seguia ahi.

   Ahora esta descifrado y limpio: las cadenas en su sitio, los subsistemas
   quitados de verdad (no desactivados) y ninguna referencia a ellos. Los
   nombres de variables siguen siendo los generados; cambiarlos a mano en
   tres mil lineas seria la manera mas segura de romper algo sin verlo.

   Se deja legible a proposito: al empaquetar pasa por la misma ofuscacion que
   el resto del cliente.
   ============================================================================ */
((function() {
  'use strict';
  var _0x1b14ff=new CSInterface(),_0x5e0c9d='#49c9bd',_0x4fb8b1="#b9b9b9",_0x10c201="easeit_curvewidth",_0x2277f0=3.6,_0x362934="#FFD23F",_0x9d521c="rgba(255,210,63,0.5)",_0x32ab7b="#54E6B0",_0x405b17='#34C759',_0x41195c='#484848',_0x59bde6="#3a3a3a",_0x257a2f=![],_0x16de5d=0x1;
  function _0x4a86e6(_0x5bd551) {
    return Math["max"](0x0,Math['min'](0xff,Math["round"](_0x5bd551)));
  }
  function _0x5c032f(_0x2ee66f,_0x27165c) {
    return "rgb("+_0x4a86e6(_0x2ee66f['r']+_0x27165c)+','+_0x4a86e6(_0x2ee66f['g']+_0x27165c)+','+_0x4a86e6(_0x2ee66f['b']+_0x27165c)+')';
  }
  function _0x209f4c() {
    var _0x52e6ad= {
      'r':0x32,'g':0x32,'b':0x32
    };
    try {
      var _0x57d7af=_0x1b14ff["getHostEnvironment"]()["appSkinInfo"]["panelBackgroundColor"]["color"];
      _0x52e6ad= {
        'r':_0x57d7af['red'],'g':_0x57d7af["green"],'b':_0x57d7af["blue"]
      };
    } catch(_0x3ad120) {
    }
    var _0x20f85a=0.299*_0x52e6ad['r']+0.587*_0x52e6ad['g']+0.114*_0x52e6ad['b'],_0x509ca9=_0x20f85a<0x6e,_0x3e5a15=document["documentElement"]['style'];
    _0x3e5a15["setProperty"]("--bg",_0x5c032f(_0x52e6ad,0x0)),_0x3e5a15['setProperty']("--bg-dark",_0x5c032f(_0x52e6ad,_0x509ca9?-0xa:-0x10)),_0x3e5a15["setProperty"]("--raised",_0x5c032f(_0x52e6ad,_0x509ca9?0xc:0x8)),_0x3e5a15['setProperty']("--card",_0x5c032f(_0x52e6ad,_0x509ca9?0x10:0xc)),_0x3e5a15["setProperty"]("--border",_0x5c032f(_0x52e6ad,_0x509ca9?0x1e:-0x1a)),_0x3e5a15["setProperty"]("--border-hover",_0x5c032f(_0x52e6ad,_0x509ca9?0x36:-0x2e)),_0x3e5a15["setProperty"]("--text",_0x509ca9?"#d6d6d6":'#1f1f1f'),_0x3e5a15['setProperty']("--text-bright",_0x509ca9?"#f4f4f4":'#0a0a0a'),_0x3e5a15["setProperty"]("--text-dim",_0x509ca9?"#a6a6a6":"#555555"),_0x3e5a15["setProperty"]('--text-faint',_0x509ca9?"#888888":"#777777"),_0x41195c=_0x5c032f(_0x52e6ad,_0x509ca9?0x1e:-0x1a),_0x59bde6=_0x5c032f(_0x52e6ad,_0x509ca9?0xc:-0xc);
    try {
      _0x30ae02();
    } catch(_0x435344) {
    }
  }
  var _0x13dbc9='easeit_accent',_0x3f6d15="#49c9bd";
  function _0x257e61(_0xf2f97) {
    if(!_0xf2f97)return null;
    _0xf2f97=String(_0xf2f97)["replace"]('#','');
    if(_0xf2f97['length']===0x3)_0xf2f97=_0xf2f97["charAt"](0x0)+_0xf2f97["charAt"](0x0)+_0xf2f97["charAt"](0x1)+_0xf2f97["charAt"](0x1)+_0xf2f97["charAt"](0x2)+_0xf2f97['charAt'](0x2);
    if(_0xf2f97['length']!==0x6)return null;
    return {
      'r':parseInt(_0xf2f97["substr"](0x0,0x2),0x10),'g':parseInt(_0xf2f97['substr'](0x2,0x2),0x10),'b':parseInt(_0xf2f97['substr'](0x4,0x2),0x10)
    };
  }
  function _0x5542ab() {
    try {
      return localStorage["getItem"](_0x13dbc9)||_0x3f6d15;
    } catch(_0x2ef8bd) {
      return _0x3f6d15;
    }
  }
  function _0x3b1cae(_0x15e653) {
    var _0x46ffc7=_0x257e61(_0x15e653);
    if(!_0x46ffc7)return;
    var _0x5b1a48=document["documentElement"]["style"];
    _0x5b1a48['setProperty']("--accent",_0x15e653),_0x5b1a48['setProperty']("--accent-2",_0x5c032f(_0x46ffc7,-0x1e)),_0x5b1a48["setProperty"]("--grad","linear-gradient(135deg, "+_0x5c032f(_0x46ffc7,0x16)+',\x20'+_0x5c032f(_0x46ffc7,-0x1c)+')'),_0x5b1a48["setProperty"]("--accent-dim","rgba("+_0x46ffc7['r']+','+_0x46ffc7['g']+','+_0x46ffc7['b']+",0.16)"),_0x5b1a48['setProperty']("--accent-border",'rgba('+_0x46ffc7['r']+','+_0x46ffc7['g']+','+_0x46ffc7['b']+',0.5)'),_0x5e0c9d=_0x15e653,_0x4fb8b1=_0x5c032f(_0x46ffc7,-0x1e);
    try {
      _0x30ae02();
    } catch(_0x446876) {
    }
  }
  var _0x11c271="1.0.0",_0x2f7987=![],_0xf296ff='Position',_0x5d8560=null,_0x300bd3=0x0,_0x522389=0x1,_0x2009ce='',_0x262b90='',_0x3565ed=[],_0x224f56='bezier',_0x80d606=null,_0x21a197='',_0x252896=_0x2c1e4b([0.25,0.1,0.25,0x1]),_0x1f2297=[ {
    'name':"Linear",'v':[0x0,0x0,0x1,0x1]
  }, {
    'name':'Ease','v':[0.25,0.1,0.25,0x1]
  }, {
    'name':"Ease In",'v':[0.42,0x0,0x1,0x1]
  }, {
    'name':"Ease Out",'v':[0x0,0x0,0.58,0x1]
  }, {
    'name':'Ease\x20InOut','v':[0.42,0x0,0.58,0x1]
  }, {
    'name':"Snappy",'v':[0.7,0x0,0.2,0x1]
  }, {
    'name':"Sine In",'v':[0.12,0x0,0.39,0x0]
  }, {
    'name':"Sine Out",'v':[0.61,0x1,0.88,0x1]
  }, {
    'name':"Sine InOut",'v':[0.37,0x0,0.63,0x1]
  }, {
    'name':'Quad\x20In','v':[0.11,0x0,0.5,0x0]
  }, {
    'name':"Quad Out",'v':[0.5,0x1,0.89,0x1]
  }, {
    'name':"Quad InOut",'v':[0.45,0x0,0.55,0x1]
  }, {
    'name':'Cubic\x20In','v':[0.32,0x0,0.67,0x0]
  }, {
    'name':"Cubic Out",'v':[0.33,0x1,0.68,0x1]
  }, {
    'name':'Cubic\x20InOut','v':[0.65,0x0,0.35,0x1]
  }, {
    'name':"Quart In",'v':[0.5,0x0,0.75,0x0]
  }, {
    'name':"Quart Out",'v':[0.25,0x1,0.5,0x1]
  }, {
    'name':"Quart InOut",'v':[0.76,0x0,0.24,0x1]
  }, {
    'name':"Quint In",'v':[0.64,0x0,0.78,0x0]
  }, {
    'name':"Quint Out",'v':[0.22,0x1,0.36,0x1]
  }, {
    'name':"Quint InOut",'v':[0.83,0x0,0.17,0x1]
  }, {
    'name':"Expo In",'v':[0.7,0x0,0.84,0x0]
  }, {
    'name':"Expo Out",'v':[0.16,0x1,0.3,0x1]
  }, {
    'name':"Expo InOut",'v':[0.87,0x0,0.13,0x1]
  }, {
    'name':"Circ In",'v':[0.55,0x0,0x1,0.45]
  }, {
    'name':"Circ Out",'v':[0x0,0.55,0.45,0x1]
  }, {
    'name':"Circ InOut",'v':[0.85,0x0,0.15,0x1]
  }, {
    'name':"Back In",'v':[0.36,0x0,0.66,-0.56]
  }, {
    'name':"Back Out",'v':[0.34,1.56,0.64,0x1]
  }, {
    'name':'Back\x20InOut','v':[0.68,-0.6,0.32,1.6]
  }, {
    'name':'Elastic\x20In','fn':"elasticIn"
  }, {
    'name':"Elastic Out",'fn':"elasticOut"
  }, {
    'name':"Elastic InOut",'fn':"elasticInOut"
  }, {
    'name':"Bounce In",'fn':"bounceIn"
  }, {
    'name':"Bounce Out",'fn':"bounceOut"
  }, {
    'name':"Bounce InOut",'fn':"bounceInOut"
  }];
  function _0x5242a7(_0x1d8d09) {
    return document["getElementById"](_0x1d8d09);
  }
  function _0xa0e1ab(_0x355f66) {
    return(Math['round'](_0x355f66*0x64)/0x64)["toFixed"](0x2);
  }
  function _0x24b322(_0x12c90a) {
    _0x12c90a=Number(_0x12c90a);
    if(isNaN(_0x12c90a))_0x12c90a=0x0;
    return Math['max'](0x0,Math['min'](0x1,_0x12c90a));
  }
  function _0x208db3(_0x3dad7d) {
    return Math["max"](-0x2,Math["min"](0x2,_0x3dad7d));
  }
  function _0x160c2c(_0x4c58a5,_0x637d92,_0x58a9cf,_0x272ef0,_0x5eb4a2) {
    var _0x23fa41=0x1-_0x4c58a5;
    return _0x23fa41*_0x23fa41*_0x23fa41*_0x637d92+0x3*_0x23fa41*_0x23fa41*_0x4c58a5*_0x58a9cf+0x3*_0x23fa41*_0x4c58a5*_0x4c58a5*_0x272ef0+_0x4c58a5*_0x4c58a5*_0x4c58a5*_0x5eb4a2;
  }
  function _0x5f2464(_0x29ba4f,_0x4a2847,_0x2fac7a,_0x25243a,_0x93162a) {
    if(_0x29ba4f<=_0x4a2847[0x0])return _0x4a2847[0x1];
    if(_0x29ba4f>=_0x93162a[0x0])return _0x93162a[0x1];
    var _0x2f0bc0=0x0,_0x5d3d8b=0x1,_0x1c7863=0.5,_0x5b434b;
    for(var _0x3a8436=0x0;_0x3a8436<0x28;_0x3a8436++) {
      _0x5b434b=_0x160c2c(_0x1c7863,_0x4a2847[0x0],_0x2fac7a[0x0],_0x25243a[0x0],_0x93162a[0x0]);
      if(Math['abs'](_0x5b434b-_0x29ba4f)<0.000005)break;
      if(_0x5b434b<_0x29ba4f)_0x2f0bc0=_0x1c7863;
      else _0x5d3d8b=_0x1c7863;
      _0x1c7863=(_0x2f0bc0+_0x5d3d8b)/0x2;
    }
    return _0x160c2c(_0x1c7863,_0x4a2847[0x1],_0x2fac7a[0x1],_0x25243a[0x1],_0x93162a[0x1]);
  }
  function _0x379fa5(_0x3dbfb0,_0x223fcc) {
    if(_0x223fcc<=0x0)return 0x0;
    if(_0x223fcc>=0x1)return 0x1;
    for(var _0x17c020=0x0;_0x17c020<_0x3dbfb0["length"]-0x1;_0x17c020++) {
      var _0x59b72e=_0x3dbfb0[_0x17c020],_0xcd73b6=_0x3dbfb0[_0x17c020+0x1];
      if(_0x223fcc>=_0x59b72e['x']&&_0x223fcc<=_0xcd73b6['x'])return _0x5f2464(_0x223fcc,[_0x59b72e['x'],_0x59b72e['y']],_0x59b72e['hr'],_0xcd73b6['hl'],[_0xcd73b6['x'],_0xcd73b6['y']]);
    }
    return 0x1;
  }
  function _0x5aa311(_0x1a260c) {
    return _0x379fa5(_0x252896,_0x1a260c);
  }
  function _0x53001a(_0x1101e7) {
    return function(_0x187491) {
      return _0x379fa5(_0x1101e7,_0x187491);
    };
  }
  function _0x2eea7a(_0x34159b) {
    return function(_0x415800) {
      return _0x379fa5(_0x2c1e4b(_0x34159b),_0x415800);
    };
  }
  function _0x2c1e4b(_0x8701c) {
    return[ {
      'x':0x0,'y':0x0,'hl':null,'hr':[_0x8701c[0x0],_0x8701c[0x1]]
    }, {
      'x':0x1,'y':0x1,'hl':[_0x8701c[0x2],_0x8701c[0x3]],'hr':null
    }];
  }
  function _0x642cf1() {
    var _0x236570=_0x252896['length']-0x1;
    return[_0x252896[0x0]['hr'][0x0],_0x252896[0x0]['hr'][0x1],_0x252896[_0x236570]['hl'][0x0],_0x252896[_0x236570]['hl'][0x1]];
  }
  function _0x2c4b4e(_0x1e2a7b) {
    var _0x5ed71a=[];
    for(var _0x6e3589=0x0;_0x6e3589<_0x1e2a7b["length"]-0x1;_0x6e3589++) {
      var _0x73fa78=_0x1e2a7b[_0x6e3589],_0x222705=_0x1e2a7b[_0x6e3589+0x1];
      _0x5ed71a["push"]([_0x73fa78['x'],_0x73fa78['y'],_0x73fa78['hr'][0x0],_0x73fa78['hr'][0x1],_0x222705['hl'][0x0],_0x222705['hl'][0x1],_0x222705['x'],_0x222705['y']]);
    }
    return _0x5ed71a;
  }
  function _0x4a34db(_0x316bc6) {
    var _0x3572c5=[];
    for(var _0x57108d=0x0;_0x57108d<_0x316bc6["length"];_0x57108d++) {
      var _0x1bd25c=_0x316bc6[_0x57108d];
      _0x3572c5["push"]( {
        'x':_0x1bd25c['x'],'y':_0x1bd25c['y'],'hl':_0x1bd25c['hl']?[_0x1bd25c['hl'][0x0],_0x1bd25c['hl'][0x1]]:null,'hr':_0x1bd25c['hr']?[_0x1bd25c['hr'][0x0],_0x1bd25c['hr'][0x1]]:null
      });
    }
    return _0x3572c5;
  }
  var _0x30c8a9=0x2*Math['PI'];
  function _0x1054af(_0x195c3c) {
    var _0x59644a=7.5625,_0xbf21e3=2.75;
    if(_0x195c3c<0x1/_0xbf21e3)return _0x59644a*_0x195c3c*_0x195c3c;
    if(_0x195c3c<0x2/_0xbf21e3)return _0x195c3c-=1.5/_0xbf21e3,_0x59644a*_0x195c3c*_0x195c3c+0.75;
    if(_0x195c3c<2.5/_0xbf21e3)return _0x195c3c-=2.25/_0xbf21e3,_0x59644a*_0x195c3c*_0x195c3c+0.9375;
    return _0x195c3c-=2.625/_0xbf21e3,_0x59644a*_0x195c3c*_0x195c3c+0.984375;
  }
  var _0x2936e2= {
    'elasticOut':function(_0x50b8b1) {
      if(_0x50b8b1<=0x0)return 0x0;
      if(_0x50b8b1>=0x1)return 0x1;
      var _0x165e72=0.3,_0x5d103f=_0x165e72/0x4;
      return Math["pow"](0x2,-0xa*_0x50b8b1)*Math['sin']((_0x50b8b1-_0x5d103f)*_0x30c8a9/_0x165e72)+0x1;
    },'elasticIn':function(_0x13b441) {
      if(_0x13b441<=0x0)return 0x0;
      if(_0x13b441>=0x1)return 0x1;
      var _0x46e0a0=0.3,_0x4a0d2c=_0x46e0a0/0x4;
      return-(Math["pow"](0x2,0xa*(_0x13b441-0x1))*Math["sin"]((_0x13b441-0x1-_0x4a0d2c)*_0x30c8a9/_0x46e0a0));
    },'elasticInOut':function(_0x3e163b) {
      if(_0x3e163b<=0x0)return 0x0;
      if(_0x3e163b>=0x1)return 0x1;
      var _0xe15912=0.45,_0x38eb5f=_0xe15912/0x4;
      _0x3e163b*=0x2;
      if(_0x3e163b<0x1)return-0.5*(Math["pow"](0x2,0xa*(_0x3e163b-0x1))*Math["sin"]((_0x3e163b-0x1-_0x38eb5f)*_0x30c8a9/_0xe15912));
      return Math["pow"](0x2,-0xa*(_0x3e163b-0x1))*Math["sin"]((_0x3e163b-0x1-_0x38eb5f)*_0x30c8a9/_0xe15912)*0.5+0x1;
    },'bounceOut':function(_0x477876) {
      return _0x1054af(_0x477876);
    },'bounceIn':function(_0x4a7aec) {
      return 0x1-_0x1054af(0x1-_0x4a7aec);
    },'bounceInOut':function(_0x4e64a6) {
      return _0x4e64a6<0.5?(0x1-_0x1054af(0x1-0x2*_0x4e64a6))/0x2:(0x1+_0x1054af(0x2*_0x4e64a6-0x1))/0x2;
    }
  };
  function _0x55da23(_0x13ae8d) {
    return _0x224f56==='fn'&&_0x2936e2[_0x80d606]?_0x2936e2[_0x80d606](_0x13ae8d):_0x5aa311(_0x13ae8d);
  }
  function _0x3a075a(_0x16f3de) {
    return _0x16f3de['fn']?_0x2936e2[_0x16f3de['fn']]:_0x2eea7a(_0x16f3de['v']);
  }
  function _0x5ee31b(_0x3b9496,_0x47e51e,_0x549540,_0x58bdef) {
    _0x3b9496['clearRect'](0x0,0x0,_0x47e51e,_0x549540);
    var _0x4b8523=Math["round"](Math["min"](_0x47e51e,_0x549540)*0.14),_0x5d6e1c=_0x4b8523,_0x2b088f=_0x47e51e-_0x4b8523,_0x4b9bd8=_0x549540-_0x4b8523,_0x4e7f73=_0x4b8523;
    function _0x5da6fa(_0x4123d5) {
      return _0x5d6e1c+_0x4123d5*(_0x2b088f-_0x5d6e1c);
    }
    function _0x652bb8(_0x5b7c9) {
      return _0x4b9bd8-_0x5b7c9*(_0x4b9bd8-_0x4e7f73);
    }
    _0x3b9496["strokeStyle"]='#2c2c2c',_0x3b9496["lineWidth"]=0x1,_0x3b9496['strokeRect'](_0x5d6e1c,_0x4e7f73,_0x2b088f-_0x5d6e1c,_0x4b9bd8-_0x4e7f73),_0x3b9496["strokeStyle"]=_0x5e0c9d,_0x3b9496["lineWidth"]=1.6,_0x3b9496["lineJoin"]="round",_0x3b9496['lineCap']="round",_0x3b9496["beginPath"]();
    for(var _0x31818f=0x0;_0x31818f<=0x40;_0x31818f++) {
      var _0x35fec7=_0x31818f/0x40,_0x5c0709=_0x652bb8(_0x58bdef(_0x35fec7));
      if(_0x5c0709<0x1)_0x5c0709=0x1;
      if(_0x5c0709>_0x549540-0x1)_0x5c0709=_0x549540-0x1;
      if(_0x31818f===0x0)_0x3b9496["moveTo"](_0x5da6fa(_0x35fec7),_0x5c0709);
      else _0x3b9496['lineTo'](_0x5da6fa(_0x35fec7),_0x5c0709);
    }
    _0x3b9496["stroke"]();
  }
  var _0x3d648f=_0x5242a7('graph'),_0x2bf5e3=_0x3d648f["getContext"]('2d'),_0x3cf45b=0xbe,_0x45822b=0xbe,_0x120a74=0x1a;
  function _0x44028f() {
    var _0x18ade4=_0x3d648f["closest"]&&_0x3d648f['closest'](".section")||_0x5242a7("content"),_0x16fb72=(_0x18ade4&&_0x18ade4["clientWidth"]||0x12c)-0x20,_0x319544=Math["max"](0x8c,_0x16fb72),_0x16983e=Math["max"](0x2,window['devicePixelRatio']||0x1);
    _0x3cf45b=_0x319544,_0x45822b=_0x319544,_0x120a74=Math["round"](_0x319544*0.14),_0x3d648f["style"]['width']=_0x319544+'px',_0x3d648f["style"]["height"]=_0x319544+'px',_0x3d648f["width"]=Math['round'](_0x319544*_0x16983e),_0x3d648f['height']=Math["round"](_0x319544*_0x16983e),_0x2bf5e3["setTransform"](_0x16983e,0x0,0x0,_0x16983e,0x0,0x0),_0x30ae02();
  }
  function _0x4e3f31() {
    return(_0x3cf45b-0x2*_0x120a74)*_0x16de5d;
  }
  function _0x4df839(_0x3ad9cb) {
    return _0x3cf45b/0x2+(_0x3ad9cb-0.5)*_0x4e3f31();
  }
  function _0x17fa44(_0x678372) {
    return _0x45822b/0x2-(_0x678372-0.5)*_0x4e3f31();
  }
  function _0x530231(_0x12b5bf) {
    return Math['max'](0x0,Math["min"](0x1,0.5+(_0x12b5bf-_0x3cf45b/0x2)/_0x4e3f31()));
  }
  function _0x1c8272(_0x2da745) {
    return 0.5-(_0x2da745-_0x45822b/0x2)/_0x4e3f31();
  }
  function _0x13d692(_0x462608) {
    _0x16de5d=Math["max"](0.35,Math["min"](0x3,_0x462608)),_0x30ae02();
  }
  function _0x1b0398(_0x1ff4fa,_0x269f10) {
    return {
      'x':Math['max'](0x7,Math["min"](_0x3cf45b-0x7,_0x1ff4fa)),'y':Math["max"](0x7,Math["min"](_0x45822b-0x7,_0x269f10))
    };
  }
  function _0x597961(_0x3b2c41,_0xb6d865) {
    _0x2bf5e3["strokeStyle"]=_0xb6d865,_0x2bf5e3["lineWidth"]=0x1,_0x2bf5e3["beginPath"]();
    for(var _0x5096cb=0x0;_0x5096cb<=0x3c;_0x5096cb++) {
      var _0x3a1f6b=_0x5096cb/0x3c,_0x38eb88=_0x379fa5(_0x2c1e4b(_0x3b2c41),_0x3a1f6b);
      if(_0x5096cb===0x0)_0x2bf5e3["moveTo"](_0x4df839(_0x3a1f6b),_0x17fa44(_0x38eb88));
      else _0x2bf5e3["lineTo"](_0x4df839(_0x3a1f6b),_0x17fa44(_0x38eb88));
    }
    _0x2bf5e3["stroke"]();
  }
  function _0x176c5d(_0x3e5b9d,_0x46d1bf,_0x921f2f,_0xd3c90e) {
    _0x2bf5e3['fillStyle']=_0xd3c90e,_0x2bf5e3["beginPath"](),_0x2bf5e3["arc"](_0x3e5b9d,_0x46d1bf,_0x921f2f,0x0,6.2832),_0x2bf5e3["fill"]();
  }
  function _0x4c3b1d(_0x400bdc,_0x40d835) {
    var _0xa01e06=_0x1b0398(_0x4df839(_0x400bdc),_0x17fa44(_0x40d835));
    _0x2bf5e3["fillStyle"]=_0x362934,_0x2bf5e3["beginPath"](),_0x2bf5e3["arc"](_0xa01e06['x'],_0xa01e06['y'],4.5,0x0,6.2832),_0x2bf5e3['fill']();
  }
  function _0xd3d7d8(_0x32bb3d,_0x39721f) {
    var _0x4de8cf=_0x1b0398(_0x4df839(_0x32bb3d),_0x17fa44(_0x39721f));
    _0x2bf5e3['fillStyle']=_0x32ab7b,_0x2bf5e3['beginPath'](),_0x2bf5e3["arc"](_0x4de8cf['x'],_0x4de8cf['y'],5.5,0x0,6.2832),_0x2bf5e3["fill"](),_0x2bf5e3["fillStyle"]="#11101a",_0x2bf5e3['beginPath'](),_0x2bf5e3["arc"](_0x4de8cf['x'],_0x4de8cf['y'],2.2,0x0,6.2832),_0x2bf5e3["fill"]();
  }
  function _0x4d54ff(_0x40adbf,_0x108cdc,_0x270e8,_0x2a8257) {
    var _0x3fd2f1=_0x1b0398(_0x4df839(_0x40adbf),_0x17fa44(_0x108cdc)),_0x382a75=_0x1b0398(_0x4df839(_0x270e8),_0x17fa44(_0x2a8257));
    _0x2bf5e3["beginPath"](),_0x2bf5e3["moveTo"](_0x3fd2f1['x'],_0x3fd2f1['y']),_0x2bf5e3["lineTo"](_0x382a75['x'],_0x382a75['y']),_0x2bf5e3["stroke"]();
  }
  function _0x30ae02() {
    _0x2bf5e3["clearRect"](0x0,0x0,_0x3cf45b,_0x45822b);
    var _0xffa2e4=_0x17fa44(0x1),_0x3a0840=_0x17fa44(0x0),_0x210cdb=_0x4df839(0x0),_0x2303a6=_0x4df839(0x1);
    _0x2bf5e3["strokeStyle"]=_0x59bde6;
    for(var _0x5bae17=0x1;_0x5bae17<0x4;_0x5bae17++) {
      var _0x1da4c0=_0x4df839(_0x5bae17/0x4);
      _0x2bf5e3['beginPath'](),_0x2bf5e3["moveTo"](_0x1da4c0,_0xffa2e4),_0x2bf5e3["lineTo"](_0x1da4c0,_0x3a0840),_0x2bf5e3["stroke"]();
      var _0x234ac3=_0x17fa44(_0x5bae17/0x4);
      _0x2bf5e3["beginPath"](),_0x2bf5e3["moveTo"](_0x210cdb,_0x234ac3),_0x2bf5e3["lineTo"](_0x2303a6,_0x234ac3),_0x2bf5e3["stroke"]();
    }
    _0x2bf5e3["strokeStyle"]=_0x41195c,_0x2bf5e3["lineWidth"]=0x1,_0x2bf5e3["strokeRect"](_0x210cdb,_0xffa2e4,_0x2303a6-_0x210cdb,_0x3a0840-_0xffa2e4),_0x597961([0x0,0x0,0x1,0x1],_0x59bde6);
    if(window.EaseItOnion) {
      try {
        window.EaseItOnion(_0x2bf5e3,_0x4df839,_0x17fa44,_0x55da23);
      } catch(_ekOn) {
      }
    }
    if(_0x257a2f) {
      var _0x3585fb=0x78,_0x5c94de=[],_0x55ec98=0.000001;
      for(var _0x44a9b1=0x0;_0x44a9b1<=_0x3585fb;_0x44a9b1++) {
        var _0x38c8f7=_0x44a9b1/_0x3585fb,_0x109c8a=Math["max"](0x0,_0x38c8f7-0x1/_0x3585fb),_0x3a4fcf=Math["min"](0x1,_0x38c8f7+0x1/_0x3585fb),_0x1040fb=Math["abs"]((_0x55da23(_0x3a4fcf)-_0x55da23(_0x109c8a))/(_0x3a4fcf-_0x109c8a));
        _0x5c94de["push"](_0x1040fb);
        if(_0x1040fb>_0x55ec98)_0x55ec98=_0x1040fb;
      }
      _0x2bf5e3["strokeStyle"]=(window.EaseItVelocityColor?window.EaseItVelocityColor():_0x405b17),_0x2bf5e3['lineWidth']=1.6,_0x2bf5e3["lineJoin"]="round",_0x2bf5e3["lineCap"]='round',_0x2bf5e3["beginPath"]();
      for(var _0x171c2a=0x0;_0x171c2a<=_0x3585fb;_0x171c2a++) {
        var _0x15c162=_0x4df839(_0x171c2a/_0x3585fb),_0x4cc2fa=_0x17fa44(_0x5c94de[_0x171c2a]/_0x55ec98);
        if(_0x171c2a===0x0)_0x2bf5e3['moveTo'](_0x15c162,_0x4cc2fa);
        else _0x2bf5e3["lineTo"](_0x15c162,_0x4cc2fa);
      }
      _0x2bf5e3["stroke"]();
    }
    var _0x35dfa7=_0x2bf5e3['createLinearGradient'](_0x4df839(0x0),0x0,_0x4df839(0x1),0x0);
    _0x35dfa7['addColorStop'](0x0,_0x4fb8b1),_0x35dfa7["addColorStop"](0x1,_0x5e0c9d),_0x2bf5e3['strokeStyle']=_0x35dfa7,_0x2bf5e3["lineWidth"]=_0x2277f0,_0x2bf5e3["lineJoin"]="round",_0x2bf5e3['lineCap']="round",_0x2bf5e3['beginPath']();
    for(var _0x5ce156=0x0;_0x5ce156<=0x78;_0x5ce156++) {
      var _0x2281f3=_0x5ce156/0x78,_0x241a83=_0x55da23(_0x2281f3);
      if(_0x5ce156===0x0)_0x2bf5e3["moveTo"](_0x4df839(_0x2281f3),_0x17fa44(_0x241a83));
      else _0x2bf5e3['lineTo'](_0x4df839(_0x2281f3),_0x17fa44(_0x241a83));
    }
    _0x2bf5e3["stroke"](),_0x176c5d(_0x4df839(0x0),_0x17fa44(0x0),0x3,'#666'),_0x176c5d(_0x4df839(0x1),_0x17fa44(0x1),0x3,"#666");
    if(_0x224f56==="bezier") {
      _0x2bf5e3["strokeStyle"]=_0x9d521c,_0x2bf5e3["lineWidth"]=1.4;
      for(var _0x3f6e93=0x0;_0x3f6e93<_0x252896['length'];_0x3f6e93++) {
        if(_0x252896[_0x3f6e93]['hr'])_0x4d54ff(_0x252896[_0x3f6e93]['x'],_0x252896[_0x3f6e93]['y'],_0x252896[_0x3f6e93]['hr'][0x0],_0x252896[_0x3f6e93]['hr'][0x1]);
        if(_0x252896[_0x3f6e93]['hl'])_0x4d54ff(_0x252896[_0x3f6e93]['x'],_0x252896[_0x3f6e93]['y'],_0x252896[_0x3f6e93]['hl'][0x0],_0x252896[_0x3f6e93]['hl'][0x1]);
      }
      for(var _0x5b4066=0x0;_0x5b4066<_0x252896["length"];_0x5b4066++) {
        if(_0x252896[_0x5b4066]['hl'])_0x4c3b1d(_0x252896[_0x5b4066]['hl'][0x0],_0x252896[_0x5b4066]['hl'][0x1]);
        if(_0x252896[_0x5b4066]['hr'])_0x4c3b1d(_0x252896[_0x5b4066]['hr'][0x0],_0x252896[_0x5b4066]['hr'][0x1]);
      }
      for(var _0x4d899b=0x1;_0x4d899b<_0x252896["length"]-0x1;_0x4d899b++)_0xd3d7d8(_0x252896[_0x4d899b]['x'],_0x252896[_0x4d899b]['y']);
    }
  }
  function _0x1a6195() {
    _0x34c692(),_0x565df2(),_0x30ae02(),_0x31876f(),_0x433917();
  }
  var _0x249bab=null;
  function _0x241c41() {
    _0x249bab&&(cancelAnimationFrame(_0x249bab),_0x249bab=null);
  }
  function _0x40db9f(_0x1fbc64,_0x1b7e70) {
    _0x241c41(),_0x224f56="bezier",_0x80d606=null,_0x252896=_0x2c1e4b([_0x24b322(_0x1fbc64[0x0]),Number(_0x1fbc64[0x1]),_0x24b322(_0x1fbc64[0x2]),Number(_0x1fbc64[0x3])]),_0x1a6195(_0x1b7e70);
  }
  function _0x6040cd(_0x487848) {
    _0x241c41(),_0x224f56='bezier',_0x80d606=null,_0x252896=_0x4a34db(_0x487848),_0x1a6195(!![]);
  }
  function _0x5e3d71(_0x3050ac,_0x3e36cc) {
    _0x241c41(),_0x224f56='fn',_0x80d606=_0x3050ac,_0x21a197=_0x3e36cc,_0x1a6195(!![]);
  }
  function _0x225be0(_0x5da677) {
    var _0x5af3ac=[_0x24b322(_0x5da677[0x0]),Number(_0x5da677[0x1]),_0x24b322(_0x5da677[0x2]),Number(_0x5da677[0x3])];
    if(_0x24386e||_0x224f56!=="bezier"||_0x252896["length"]!==0x2) {
      _0x40db9f(_0x5af3ac,!![]);
      return;
    }
    _0x241c41();
    var _0x39cac5=_0x642cf1(),_0x409d1d=null,_0x3b1a55=0xf0;
    _0x224f56="bezier",_0x80d606=null,_0x5b119e();
    function _0x2b8d1b(_0xea26cc) {
      if(_0x409d1d===null)_0x409d1d=_0xea26cc;
      var _0x5679bb=(_0xea26cc-_0x409d1d)/_0x3b1a55;
      if(_0x5679bb>0x1)_0x5679bb=0x1;
      var _0x45cd5a=_0x5679bb<0.5?0x2*_0x5679bb*_0x5679bb:0x1-Math["pow"](-0x2*_0x5679bb+0x2,0x2)/0x2;
      _0x252896=_0x2c1e4b([_0x39cac5[0x0]+(_0x5af3ac[0x0]-_0x39cac5[0x0])*_0x45cd5a,_0x39cac5[0x1]+(_0x5af3ac[0x1]-_0x39cac5[0x1])*_0x45cd5a,_0x39cac5[0x2]+(_0x5af3ac[0x2]-_0x39cac5[0x2])*_0x45cd5a,_0x39cac5[0x3]+(_0x5af3ac[0x3]-_0x39cac5[0x3])*_0x45cd5a]),_0x34c692(),_0x30ae02();
      if(_0x5679bb<0x1)_0x249bab=requestAnimationFrame(_0x2b8d1b);
      else _0x249bab=null,_0x252896=_0x2c1e4b(_0x5af3ac),_0x1a6195();
    }
    _0x249bab=requestAnimationFrame(_0x2b8d1b);
  }
  function _0x1f3ecf() {
    if(_0x224f56==='fn'||_0x252896["length"]!==0x2)return null;
    var _0x945108=_0x642cf1();
    for(var _0x7a78ed=0x0;_0x7a78ed<_0x1f2297["length"];_0x7a78ed++) {
      var _0x3adc95=_0x1f2297[_0x7a78ed]['v'];
      if(!_0x3adc95)continue;
      if(Math['abs'](_0x3adc95[0x0]-_0x945108[0x0])<0.005&&Math["abs"](_0x3adc95[0x1]-_0x945108[0x1])<0.005&&Math["abs"](_0x3adc95[0x2]-_0x945108[0x2])<0.005&&Math['abs'](_0x3adc95[0x3]-_0x945108[0x3])<0.005)return _0x1f2297[_0x7a78ed]['name'];
    }
    return null;
  }
  
  function _0x565df2() {
    _0x5b119e();
  }
  function _0x5b119e() {
    var _0x1858e0=_0x224f56==='fn'?_0x21a197:_0x252896["length"]===0x2?_0x1f3ecf():null,_0x4c7229=document["querySelectorAll"]('.preset-tile.builtin');
    for(var _0x207c6f=0x0;_0x207c6f<_0x4c7229["length"];_0x207c6f++)_0x4c7229[_0x207c6f]['classList']['toggle']("active",_0x4c7229[_0x207c6f]["getAttribute"]("data-name")===_0x1858e0);
  }
  var _0x2df326="easeit_preset_order",_0x5abcaf="easeit_preset_size",_0x15a5a5="easeit_preset_hidden",_0x4a9860=0x30,_0x2020d9=![];
  function _0x1983cd() {
    try {
      return JSON["parse"](localStorage['getItem'](_0x15a5a5))||[];
    } catch(_0x5ea9dd) {
      return[];
    }
  }
  function _0x38e397(_0x2153c3) {
    try {
      localStorage["setItem"](_0x15a5a5,JSON["stringify"](_0x2153c3));
    } catch(_0x5ecb62) {
    }
  }
  function _0x574667(_0x38a358) {
    var _0x192bbf=_0x1983cd(),_0xc7a7d4=_0x192bbf["indexOf"](_0x38a358);
    if(_0xc7a7d4>=0x0)_0x192bbf["splice"](_0xc7a7d4,0x1);
    else _0x192bbf["push"](_0x38a358);
    _0x38e397(_0x192bbf),_0x5dd9ba();
  }
  function _0xd5950e() {
    try {
      return JSON["parse"](localStorage["getItem"](_0x2df326))||[];
    } catch(_0x1bd651) {
      return[];
    }
  }
  function _0x120494() {
    var _0x563f0a=_0xd5950e(),_0x29f830= {
    },_0x56c3a6=[],_0x476ce4= {
    };
    return _0x1f2297["forEach"](function(_0x40ace2) {
      _0x29f830[_0x40ace2["name"]]=_0x40ace2;
    }),_0x563f0a['forEach'](function(_0x3ee2ee) {
      _0x29f830[_0x3ee2ee]&&!_0x476ce4[_0x3ee2ee]&&(_0x56c3a6["push"](_0x29f830[_0x3ee2ee]),_0x476ce4[_0x3ee2ee]=!![]);
    }),_0x1f2297["forEach"](function(_0x19ca52) {
      if(!_0x476ce4[_0x19ca52['name']])_0x56c3a6["push"](_0x19ca52);
    }),_0x56c3a6;
  }
  var _0x417bb0="easeit_order";
  function _0xEKorderKey() {
    try {
      var _0xEKc=JSON['parse'](localStorage['getItem']('easeit_collections'));
      return _0x417bb0+':'+((_0xEKc&&_0xEKc['active'])||'default');
    } catch(_0xEKe) {
      return _0x417bb0+':default';
    }
  }
  function _0x3b0ca2() {
    try {
      return JSON['parse'](localStorage["getItem"](_0xEKorderKey()))||[];
    } catch(_0x3b2418) {
      return[];
    }
  }
  function _0x203542(_0x36ef66) {
    try {
      localStorage["setItem"](_0xEKorderKey(),JSON["stringify"](_0x36ef66));
    } catch(_0x2e63dc) {
    }
  }
  function _0x2ca6c4(_0x8624e6) {
    var _0x9b42d8=![];
    for(var _0x4b7d3a=0x0;_0x4b7d3a<_0x8624e6["length"];_0x4b7d3a++) {
      !_0x8624e6[_0x4b7d3a]['id']&&(_0x8624e6[_0x4b7d3a]['id']='c'+Date["now"]()['toString'](0x24)+_0x4b7d3a['toString'](0x24)+Math["floor"](Math['random']()*0xf4240)['toString'](0x24),_0x9b42d8=!![]);
    }
    if(_0x9b42d8)_0x5c9031(_0x8624e6);
    return _0x8624e6;
  }
  function _0x5a2c37() {
    var _0x1c944c=[],_0xa58807= {
    };
    return _0x2ca6c4(_0x4c74fa())["forEach"](function(_0xaae4a8) {
      var _0x13e310= {
        'type':'custom','key':'c:'+_0xaae4a8['id'],'item':_0xaae4a8
      };
      _0x1c944c["push"](_0x13e310),_0xa58807[_0x13e310["key"]]=_0x13e310;
    }),_0x120494()["forEach"](function(_0x36e1c6) {
      var _0x4c4ced= {
        'type':"builtin",'key':_0x36e1c6["name"],'p':_0x36e1c6
      };
      _0x1c944c["push"](_0x4c4ced),_0xa58807[_0x4c4ced["key"]]=_0x4c4ced;
    }), {
      'entries':_0x1c944c,'map':_0xa58807
    };
  }
  function _0x539f47() {
    var _0x20ecff=_0x5a2c37(),_0x1a70a5=_0x3b0ca2(),_0x390304=[],_0x2e8182= {
    };
    return _0x1a70a5["forEach"](function(_0x70bb4d) {
      _0x20ecff["map"][_0x70bb4d]&&!_0x2e8182[_0x70bb4d]&&(_0x390304["push"](_0x20ecff["map"][_0x70bb4d]),_0x2e8182[_0x70bb4d]=!![]);
    }),_0x20ecff["entries"]['forEach'](function(_0x1ce1df) {
      !_0x2e8182[_0x1ce1df['key']]&&(_0x390304["push"](_0x1ce1df),_0x2e8182[_0x1ce1df["key"]]=!![]);
    }),_0x390304;
  }
  function _0x3d7394(_0x64d07f,_0xa66bd4) {
    var _0xeed060=_0x539f47()["map"](function(_0x4085e5) {
      return _0x4085e5["key"];
    }),_0x2e1e24=_0xeed060["indexOf"](_0x64d07f);
    if(_0x2e1e24<0x0)return;
    _0xeed060['splice'](_0x2e1e24,0x1);
    var _0x21638f=_0xeed060["indexOf"](_0xa66bd4);
    if(_0x21638f<0x0)_0x21638f=_0xeed060["length"];
    _0xeed060["splice"](_0x21638f,0x0,_0x64d07f),_0x203542(_0xeed060),_0x5dd9ba();
  }
  function _0x42cd01(_0x484965,_0x13f17e) {
    var _0x13718b=document["elementFromPoint"](_0x484965["clientX"],_0x484965['clientY']);
    return _0x13718b=_0x13718b&&_0x13718b["closest"]?_0x13718b['closest'](".preset-tile"):null,_0x13718b&&_0x13718b["parentNode"]===_0x13f17e?_0x13718b:null;
  }
  function _0x38cf8a(_0x34d448) {
    var _0x369958=_0x34d448['querySelectorAll']('.dropTarget');
    for(var _0xf0d00c=0x0;_0xf0d00c<_0x369958["length"];_0xf0d00c++)_0x369958[_0xf0d00c]["classList"]["remove"]("dropTarget");
  }
  function _0x5a074f(_0x48e750,_0x1cb8ff) {
    _0x48e750["addEventListener"]("mousedown",function(_0x357c15) {
      if(_0x357c15["button"]!==0x0)return;
      var _0x31eda1=_0x357c15["clientX"],_0x308611=_0x357c15["clientY"],_0x511f74=![],_0x4cedfc=_0x48e750['parentNode'];
      _0x48e750["_didDrag"]=![];
      function _0x62e345(_0x6d9ed4) {
        if(!_0x511f74) {
          if(Math["abs"](_0x6d9ed4["clientX"]-_0x31eda1)+Math["abs"](_0x6d9ed4["clientY"]-_0x308611)<0x6)return;
          _0x511f74=!![],_0x48e750['_didDrag']=!![],_0x48e750['classList']["add"]('dragging'),document['body']["classList"]["add"]("tileDragging");
        }
        _0x38cf8a(_0x4cedfc);
        var _0x1ed809=_0x42cd01(_0x6d9ed4,_0x4cedfc);
        if(_0x1ed809&&_0x1ed809!==_0x48e750)_0x1ed809["classList"]["add"]("dropTarget");
      }
      function _0x17a771(_0x572e2d) {
        document["removeEventListener"]("mousemove",_0x62e345),document["removeEventListener"]("mouseup",_0x17a771),document["body"]["classList"]["remove"]("tileDragging");
        if(!_0x511f74)return;
        _0x48e750["classList"]["remove"]('dragging'),_0x38cf8a(_0x4cedfc);
        var _0x324d97=_0x42cd01(_0x572e2d,_0x4cedfc);
        if(_0x324d97&&_0x324d97!==_0x48e750)_0x1cb8ff(_0x48e750,_0x324d97);
      }
      document["addEventListener"]("mousemove",_0x62e345),document["addEventListener"]("mouseup",_0x17a771);
    });
  }
  var _0x493f9a=0x30;
  function _0x24282d(_0x5e9bb0) {
    _0x5e9bb0=Math["max"](0x1e,Math["min"](0x8c,Number(_0x5e9bb0)||0x30)),_0x4a9860=_0x5e9bb0,document["documentElement"]["style"]["setProperty"]("--preset-size",_0x5e9bb0+'px');
    var _0x14168c=_0x5242a7("presetGrid");
    if(_0x14168c) {
      if(_0x5e9bb0<_0x493f9a)_0x14168c["classList"]["add"]("compact");
      else _0x14168c['classList']["remove"]("compact");
    }
  }
  function _0x55a3e0(_0x8b4418,_0x13e5da,_0x2d03af,_0x2994a8) {
    var _0x46b513=document["createElement"]('div');
    _0x46b513["className"]='preset-tile',_0x46b513["setAttribute"]("data-name",_0x8b4418);
    var _0x4ee740=document['createElement']("div");
    _0x4ee740["className"]="preset-thumb";
    var _0x3f8192=_0x4a9860,_0x297c36=Math["max"](0x2,window["devicePixelRatio"]||0x1),_0x3418e6=document["createElement"]("canvas");
    _0x3418e6["width"]=Math['round'](_0x3f8192*_0x297c36),_0x3418e6["height"]=Math['round'](_0x3f8192*_0x297c36);
    var _0x342315=_0x3418e6["getContext"]('2d');
    _0x342315["scale"](_0x297c36,_0x297c36),_0x5ee31b(_0x342315,_0x3f8192,_0x3f8192,_0x13e5da),_0x4ee740["appendChild"](_0x3418e6),_0x46b513["appendChild"](_0x4ee740);
    var _0xc7ea22=document["createElement"]("div");
    _0xc7ea22["className"]="preset-name",_0xc7ea22["textContent"]=_0x8b4418,_0x46b513['appendChild'](_0xc7ea22);
    if(_0x2994a8) {
      var _0x3c2886=document["createElement"]("div");
      _0x3c2886["className"]="preset-del",_0x3c2886["textContent"]='×',_0x3c2886["addEventListener"]("click",function(_0x330f67) {
        _0x330f67["stopPropagation"](),_0x2994a8();
      }),_0x46b513["appendChild"](_0x3c2886);
    }
    return _0x46b513["addEventListener"]("click",function(_0xaecddd) {
      if(_0x46b513["_didDrag"]) {
        _0x46b513["_didDrag"]=![];
        return;
      }
      _0x2d03af(_0xaecddd);
    }),_0x46b513;
  }
  function _0x5f3e90(_0x35fb70) {
    if(_0x35fb70['fn'])_0x5e3d71(_0x35fb70['fn'],_0x35fb70["name"]);
    else _0x225be0(_0x35fb70['v']["slice"]());
  }
  function _0x4fdb00(_0x2dfb4e,_0x2c9348,_0xd8a7b4) {
    var _0x4f58fc=document['createElement']("div");
    _0x4f58fc['className']="preset-del"+(_0x2c9348?" restore":''),_0x4f58fc["textContent"]=_0x2c9348?'↺':'×',_0x4f58fc["addEventListener"]('click',function(_0x350166) {
      _0x350166["stopPropagation"](),_0xd8a7b4();
    }),_0x2dfb4e["appendChild"](_0x4f58fc);
  }
  function _0x27a292(_0xea56ce,_0x3f3d3c) {
    var _0x2d9f6d=_0xea56ce['getAttribute']("data-key"),_0x326bcc=_0x3f3d3c["getAttribute"]("data-key");
    if(!_0x2d9f6d||!_0x326bcc||_0x2d9f6d===_0x326bcc)return;
    _0x3d7394(_0x2d9f6d,_0x326bcc);
  }
  function _0x46175e(_0x2e2bdc) {
    var _0x5b85f7=_0x4c74fa();
    for(var _0x566b04=0x0;_0x566b04<_0x5b85f7['length'];_0x566b04++) {
      if(_0x5b85f7[_0x566b04]['id']===_0x2e2bdc) {
        _0x5b85f7["splice"](_0x566b04,0x1);
        break;
      }
    }
    _0x5c9031(_0x5b85f7),_0x5dd9ba();
  }
  function _0x5dd9ba() {
    var _0x43d1ef=_0x5242a7("presetGrid");
    if(!_0x43d1ef)return;
    _0x43d1ef["innerHTML"]='';
    var _0x578ccc=_0x1983cd();
    _0x539f47()["forEach"](function(_0x33f560) {
      var _0x33d34e;
      if(_0x33f560['type']==="builtin") {
        var _0x38af7e=_0x33f560['p'],_0x17586a=_0x578ccc['indexOf'](_0x38af7e["name"])>=0x0;
        if(_0x17586a&&!_0x2020d9)return;
        _0x33d34e=_0x55a3e0(_0x38af7e["name"],_0x3a075a(_0x38af7e),function() {
          if(!_0x17586a)_0x5f3e90(_0x38af7e);
        }),_0x33d34e['classList']["add"]('builtin'),_0x33d34e["setAttribute"]("data-type","builtin");
        if(_0x17586a)_0x33d34e['classList']["add"]("removed");
        if(_0x2020d9)_0x4fdb00(_0x33d34e,_0x17586a,function() {
          _0x574667(_0x38af7e['name']);
        });
      } else {
        var _0x3a9964=_0x33f560["item"];
        _0x33d34e=_0x55a3e0(_0x3a9964["name"],_0x173230(_0x3a9964),function() {
          if(_0x3a9964['fn'])_0x5e3d71(_0x3a9964['fn'],_0x3a9964['name']);
          else {
            if(_0x3a9964["nodes"])_0x6040cd(_0x3a9964['nodes']);
            else _0x225be0(_0x3a9964['v']["slice"]());
          }
          _0x5b20db("Loaded “"+_0x3a9964["name"]+'”',"success");
        }),_0x33d34e["setAttribute"]('data-type','custom');
        if(_0x2020d9)_0x4fdb00(_0x33d34e,![],function() {
          _0x46175e(_0x3a9964['id']);
        });
      }
      _0x33d34e["setAttribute"]('data-key',_0x33f560["key"]),_0x5a074f(_0x33d34e,_0x27a292),_0x43d1ef['appendChild'](_0x33d34e);
    }),_0x5b119e();
  }
  function _0x5b542e() {
    var _0x59c978=0x30;
    try {
      _0x59c978=Number(localStorage['getItem'](_0x5abcaf))||0x30;
    } catch(_0x51c4e4) {
    }
    _0x24282d(_0x59c978);
    var _0x31bae1=_0x5242a7("presetEditTog");
    _0x31bae1&&(_0x31bae1["checked"]=_0x2020d9,_0x31bae1["addEventListener"]('change',function() {
      _0x2020d9=_0x31bae1["checked"],_0x5dd9ba();
    }));
    var _0x3f32c9=_0x5242a7("importBtn");
    if(_0x3f32c9)_0x3f32c9["addEventListener"]("click",_0x4e9708);
    var _0x4563dd=_0x5242a7("exportBtn");
    if(_0x4563dd)_0x4563dd["addEventListener"]("click",_0x52496c);
  }
  var _0x1ae2e5=0xc8,_0x4d0f62=0x48,_0x24386e=![],_0x8005bb=![],_0x33a8bd=![];
  function _0x52cbdd() {
    var _0x5a46f7=_0x5242a7('content')||document["body"],_0x698e44=_0x5a46f7["clientWidth"]||window["innerWidth"]||0x0,_0x33576a=_0x698e44>0x0&&_0x698e44<_0x1ae2e5;
    if(_0x8005bb&&_0x33576a===_0x24386e)return;
    _0x24386e=_0x33576a,_0x8005bb=!![],document["body"]['classList']['toggle']("easeit-mini",_0x33576a);
    if(_0x33576a&&!_0x33a8bd) {
      _0x33a8bd=!![];
      
    }
    _0x5dd9ba();
    if(!_0x33576a)_0x44028f();
  }
  function _0x9f98b1(_0xc5a79) {
    var _0x22f373=_0x252896[_0xc5a79];
    if(_0x22f373['hr'])_0x22f373['hr'][0x0]=Math["max"](_0x22f373['x'],Math['min'](_0x252896[_0xc5a79+0x1]['x'],_0x22f373['hr'][0x0]));
    if(_0x22f373['hl'])_0x22f373['hl'][0x0]=Math["min"](_0x22f373['x'],Math["max"](_0x252896[_0xc5a79-0x1]['x'],_0x22f373['hl'][0x0]));
  }
  function _0x123de2(_0x233ba4,_0x2cbc44) {
    var _0x14877c=_0x252896[_0x233ba4];
    if(!_0x14877c['hl']||!_0x14877c['hr'])return;
    var _0xa3e204=_0x2cbc44==='hr'?_0x14877c['hr']:_0x14877c['hl'],_0x349f5c=_0x2cbc44==='hr'?_0x14877c['hl']:_0x14877c['hr'],_0x1e59b2=_0xa3e204[0x0]-_0x14877c['x'],_0x4772c0=_0xa3e204[0x1]-_0x14877c['y'],_0x10e192=Math["sqrt"](_0x1e59b2*_0x1e59b2+_0x4772c0*_0x4772c0);
    if(_0x10e192<0.000001)return;
    var _0x3ff05f=Math['sqrt'](Math['pow'](_0x349f5c[0x0]-_0x14877c['x'],0x2)+Math["pow"](_0x349f5c[0x1]-_0x14877c['y'],0x2));
    _0x349f5c[0x0]=_0x14877c['x']-_0x1e59b2/_0x10e192*_0x3ff05f,_0x349f5c[0x1]=_0x14877c['y']-_0x4772c0/_0x10e192*_0x3ff05f,_0x9f98b1(_0x233ba4);
  }
  function _0x103d80(_0x24441e,_0x1a3a64) {
    return _0x24441e===0x0&&_0x1a3a64==='hr'||_0x24441e===_0x252896["length"]-0x1&&_0x1a3a64==='hl';
  }
  function _0x32d487(_0x12ebea,_0x3216f3) {
    var _0x4c7e1d=_0x252896[_0x12ebea][_0x3216f3],_0x116220=0x1-_0x4c7e1d[0x0],_0x2a08f7=_0x208db3(0x1-_0x4c7e1d[0x1]);
    if(_0x12ebea===0x0) {
      var _0x54c0e7=_0x252896["length"]-0x1;
      _0x252896[_0x54c0e7]['hl']=[_0x116220,_0x2a08f7],_0x9f98b1(_0x54c0e7);
    } else _0x252896[0x0]['hr']=[_0x116220,_0x2a08f7],_0x9f98b1(0x0);
  }
  function _0x3c2667(_0xabac7c) {
    _0xabac7c=Math["max"](0.04,Math["min"](0.96,_0xabac7c));
    var _0x49c6b8=_0x5aa311(_0xabac7c),_0x33b457=_0x252896["length"]-0x1;
    for(var _0x36028a=0x1;_0x36028a<_0x252896["length"];_0x36028a++) {
      if(_0x252896[_0x36028a]['x']>_0xabac7c) {
        _0x33b457=_0x36028a;
        break;
      }
    }
    var _0x32cb3b=_0x252896[_0x33b457-0x1]['x'],_0x1bffaa=_0x252896[_0x33b457]['x'],_0x412a16=Math['min'](0.08,(_0xabac7c-_0x32cb3b)*0.6,(_0x1bffaa-_0xabac7c)*0.6);
    _0x252896["splice"](_0x33b457,0x0, {
      'x':_0xabac7c,'y':_0x49c6b8,'hl':[_0xabac7c-_0x412a16,_0x49c6b8],'hr':[_0xabac7c+_0x412a16,_0x49c6b8]
    });
  }
  var _0x130ac0=null,_0x3c86ad=null,_0x3b9c9e=![];
  function _0x1b4ae0(_0x73266e) {
    var _0x1a5ba3=_0x3d648f["getBoundingClientRect"]();
    return {
      'x':(_0x73266e["clientX"]-_0x1a5ba3["left"])*(_0x3cf45b/_0x1a5ba3["width"]),'y':(_0x73266e['clientY']-_0x1a5ba3["top"])*(_0x45822b/_0x1a5ba3['height'])
    };
  }
  function _0x157c4c() {
    var _0x13e637=[];
    for(var _0x5415bc=0x0;_0x5415bc<_0x252896["length"];_0x5415bc++) {
      var _0x3ca4dd=_0x252896[_0x5415bc];
      if(_0x3ca4dd['hl'])_0x13e637["push"]( {
        'kind':'h','i':_0x5415bc,'which':'hl','p':_0x1b0398(_0x4df839(_0x3ca4dd['hl'][0x0]),_0x17fa44(_0x3ca4dd['hl'][0x1]))
      });
      if(_0x3ca4dd['hr'])_0x13e637["push"]( {
        'kind':'h','i':_0x5415bc,'which':'hr','p':_0x1b0398(_0x4df839(_0x3ca4dd['hr'][0x0]),_0x17fa44(_0x3ca4dd['hr'][0x1]))
      });
    }
    for(var _0xbc474c=0x1;_0xbc474c<_0x252896["length"]-0x1;_0xbc474c++)_0x13e637['push']( {
      'kind':'a','i':_0xbc474c,'p':_0x1b0398(_0x4df839(_0x252896[_0xbc474c]['x']),_0x17fa44(_0x252896[_0xbc474c]['y']))
    });
    return _0x13e637;
  }
  _0x3d648f["addEventListener"]("mousedown",function(_0x110603) {
    _0x241c41();
    if(_0x224f56!=="bezier")return;
    var _0x58457d=_0x1b4ae0(_0x110603),_0x4ccace=_0x157c4c(),_0x4920de=null,_0x7e50c1=0x14;
    for(var _0x245acd=0x0;_0x245acd<_0x4ccace['length'];_0x245acd++) {
      var _0x34c06c=Math["hypot"](_0x58457d['x']-_0x4ccace[_0x245acd]['p']['x'],_0x58457d['y']-_0x4ccace[_0x245acd]['p']['y']);
      _0x34c06c<_0x7e50c1&&(_0x7e50c1=_0x34c06c,_0x4920de=_0x4ccace[_0x245acd]);
    }
    _0x130ac0=_0x4920de;
    if(_0x130ac0) {
      if(_0x130ac0["kind"]==='h') {
        var _0x5398c1=_0x252896[_0x130ac0['i']];
        _0x3c86ad= {
          'x':_0x5398c1[_0x130ac0['which']][0x0],'y':_0x5398c1[_0x130ac0["which"]][0x1]
        };
      } else _0x3c86ad= {
        'x':_0x252896[_0x130ac0['i']]['x'],'y':_0x252896[_0x130ac0['i']]['y']
      };
      _0x110603["preventDefault"](),_0x20fd4c(_0x110603);
    }
  }),window["addEventListener"]("mousemove",function(_0x79e8c7) {
    if(_0x130ac0)_0x20fd4c(_0x79e8c7);
  }),window["addEventListener"]('mouseup',function() {
    if(_0x3b9c9e) {
      _0x3b9c9e=![];
      
    }
    _0x130ac0=null;
  });
  function _0x20fd4c(_0x47af2d) {
    var _0x133f87=_0x1b4ae0(_0x47af2d),_0x14e706=_0x530231(_0x133f87['x']),_0x1897c9=_0x208db3(_0x1c8272(_0x133f87['y']));
    if(_0x130ac0["kind"]==='h') {
      var _0x2e2a0f=_0x252896[_0x130ac0['i']],_0x4a31e7,_0xc19e48;
      _0x130ac0["which"]==='hr'?(_0x4a31e7=_0x2e2a0f['x'],_0xc19e48=_0x252896[_0x130ac0['i']+0x1]['x']):(_0x4a31e7=_0x252896[_0x130ac0['i']-0x1]['x'],_0xc19e48=_0x2e2a0f['x']);
      _0x14e706=Math["max"](_0x4a31e7,Math["min"](_0xc19e48,_0x14e706));
      if(_0x47af2d['shiftKey']&&_0x3c86ad) {
        if(Math["abs"](_0x14e706-_0x3c86ad['x'])>=Math["abs"](_0x1897c9-_0x3c86ad['y']))_0x1897c9=_0x3c86ad['y'];
        else _0x14e706=_0x3c86ad['x'];
      }
      _0x2e2a0f[_0x130ac0["which"]]=[_0x14e706,_0x1897c9];
      if(_0x2e2a0f['hl']&&_0x2e2a0f['hr']) {
        if(!_0x47af2d["altKey"])_0x123de2(_0x130ac0['i'],_0x130ac0["which"]);
      } else _0x47af2d['altKey']&&_0x103d80(_0x130ac0['i'],_0x130ac0["which"])&&(_0x32d487(_0x130ac0['i'],_0x130ac0["which"]),_0x3b9c9e=!![]);
    } else {
      var _0x15f690=_0x252896[_0x130ac0['i']],_0x5f13de=_0x252896[_0x130ac0['i']-0x1]['x']+0.02,_0x46d75f=_0x252896[_0x130ac0['i']+0x1]['x']-0.02,_0xfb0064=Math["max"](_0x5f13de,Math["min"](_0x46d75f,_0x14e706)),_0x5a97c2=_0xfb0064-_0x15f690['x'],_0x46a96f=_0x1897c9-_0x15f690['y'];
      _0x15f690['x']=_0xfb0064,_0x15f690['y']=_0x1897c9,_0x15f690['hl']&&(_0x15f690['hl'][0x0]+=_0x5a97c2,_0x15f690['hl'][0x1]+=_0x46a96f),_0x15f690['hr']&&(_0x15f690['hr'][0x0]+=_0x5a97c2,_0x15f690['hr'][0x1]+=_0x46a96f),_0x9f98b1(_0x130ac0['i']);
    }
    _0x1a6195(!![]);
  }
  _0x3d648f['addEventListener']("dblclick",function(_0xdadfad) {
    if(_0x224f56!=="bezier") {
      _0x5b20db('Formula\x20easings\x20aren\x27t\x20point-editable\x20—\x20pick\x20a\x20bezier\x20preset\x20first');
      return;
    }
    var _0x1e646d=_0x1b4ae0(_0xdadfad),_0x28b80d=_0x157c4c();
    for(var _0x3654bd=0x0;_0x3654bd<_0x28b80d['length'];_0x3654bd++) {
      if(_0x28b80d[_0x3654bd]["kind"]==='h'&&Math['hypot'](_0x1e646d['x']-_0x28b80d[_0x3654bd]['p']['x'],_0x1e646d['y']-_0x28b80d[_0x3654bd]['p']['y'])<0xc) {
        var _0x316162=_0x28b80d[_0x3654bd]['i'],_0x2ce15f=_0x28b80d[_0x3654bd]["which"],_0x294aef=_0x252896[_0x316162],_0xb0983a=_0x294aef[_0x2ce15f];
        _0x43b2f4( {
          'title':"Handle  X, Y",'input':!![],'defaultValue':_0xa0e1ab(_0xb0983a[0x0])+',\x20'+_0xa0e1ab(_0xb0983a[0x1]),'okText':"Set",'onOk':function(_0x29d86b) {
            if(!_0x29d86b)return;
            var _0x4bc633=_0x29d86b['split'](',');
            if(_0x4bc633["length"]<0x2)return;
            var _0x1dd2ca=parseFloat(_0x4bc633[0x0]),_0x430e08=parseFloat(_0x4bc633[0x1]);
            if(isNaN(_0x1dd2ca)||isNaN(_0x430e08))return;
            var _0x2e72fd,_0x30507f;
            _0x2ce15f==='hr'?(_0x2e72fd=_0x294aef['x'],_0x30507f=_0x252896[_0x316162+0x1]['x']):(_0x2e72fd=_0x252896[_0x316162-0x1]['x'],_0x30507f=_0x294aef['x']);
            _0x294aef[_0x2ce15f]=[Math["max"](_0x2e72fd,Math['min'](_0x30507f,_0x1dd2ca)),_0x430e08];
            if(_0x294aef['hl']&&_0x294aef['hr'])_0x123de2(_0x316162,_0x2ce15f);
            _0x1a6195(!![]);
          }
        });
        return;
      }
    }
    for(var _0x45fedf=0x1;_0x45fedf<_0x252896['length']-0x1;_0x45fedf++) {
      var _0x298526=_0x1b0398(_0x4df839(_0x252896[_0x45fedf]['x']),_0x17fa44(_0x252896[_0x45fedf]['y']));
      if(Math["hypot"](_0x1e646d['x']-_0x298526['x'],_0x1e646d['y']-_0x298526['y'])<0xc) {
        _0x252896["splice"](_0x45fedf,0x1),_0x1a6195(!![]),_0x5b20db('Point\x20removed');
        return;
      }
    }
    var _0x3cadea=_0x530231(_0x1e646d['x']),_0x46ff27=_0x17fa44(_0x5aa311(_0x3cadea));
    Math["abs"](_0x1e646d['y']-_0x46ff27)<0x12&&(_0x3c2667(_0x3cadea),_0x1a6195(!![]),_0x5b20db("Point added — drag it and its handles"));
  });
  function _0x2b7ceb() {
    if(_0x224f56==='fn')return _0x21a197;
    if(_0x252896["length"]!==0x2)return "Custom · "+_0x252896['length']+" points";
    var _0x34b274=_0x642cf1();
    return _0xa0e1ab(_0x34b274[0x0])+',\x20'+_0xa0e1ab(_0x34b274[0x1])+',\x20'+_0xa0e1ab(_0x34b274[0x2])+',\x20'+_0xa0e1ab(_0x34b274[0x3]);
  }
  function _0x34c692() {
    var _0x233b52=_0x5242a7('curveReadout');
    if(_0x233b52)_0x233b52['textContent']=_0x2b7ceb();
  }
  function _0x35eaa0(_0x13c74c) {
    if(!_0x13c74c)return null;
    var _0x178499=String(_0x13c74c)["match"](/(-?[\d.]+)[,\s]+(-?[\d.]+)[,\s]+(-?[\d.]+)[,\s]+(-?[\d.]+)/);
    if(!_0x178499)return null;
    return[parseFloat(_0x178499[0x1]),parseFloat(_0x178499[0x2]),parseFloat(_0x178499[0x3]),parseFloat(_0x178499[0x4])];
  }
  function _0x4e139e() {
    var _0x4025d9=_0x224f56==='bezier'&&_0x252896["length"]===0x2?_0x2b7ceb():"0.25, 0.1, 0.25, 1";
    _0x43b2f4( {
      'title':"Edit points · x1, y1, x2, y2",'input':!![],'defaultValue':_0x4025d9,'okText':'Set','onOk':function(_0x2e6f2e) {
        if(_0x2e6f2e===null)return;
        var _0x58fd33=_0x35eaa0(_0x2e6f2e);
        if(_0x58fd33)_0x40db9f(_0x58fd33,!![]),_0x5b20db('Curve\x20updated',"success");
        else _0x5b20db("Enter four numbers: x1, y1, x2, y2","error","Input: "+_0x2e6f2e);
      }
    });
  }
  _0x5242a7("tbZoomIn")["addEventListener"]("click",function() {
    _0x13d692(_0x16de5d*1.25);
  }),_0x5242a7("tbZoomOut")["addEventListener"]("click",function() {
    _0x13d692(_0x16de5d/1.25);
  }),_0x5242a7("tbFit")["addEventListener"]("click",function() {
    _0x16de5d=0x1,_0x30ae02();
  }),_0x5242a7("tbVel")['addEventListener']("click",function() {
    _0x257a2f=!_0x257a2f,this["classList"]["toggle"]('on',_0x257a2f),_0x30ae02();
  }),_0x5242a7('readBtn')['addEventListener']('click',function() {
    _0x5b20db("Reading easing…"),_0x1b14ff["evalScript"]("easeit_readEasing("+JSON["stringify"](JSON["stringify"]( {
      'prop':_0xf296ff
    }))+')',function(_0x1c3953) {
      var _0x41beed;
      try {
        _0x41beed=JSON["parse"](_0x1c3953);
      } catch(_0x555c94) {
        _0x5b20db('Host\x20error','error',_0x1c3953);
        return;
      }
      if(_0x41beed["success"]&&(_0x41beed["nodes"]&&_0x41beed["nodes"]["length"]>0x2||_0x41beed['curve'])) {
        _0x14a13c=!![];
        if(_0x41beed["nodes"]&&_0x41beed["nodes"]["length"]>0x2)_0x6040cd(_0x41beed["nodes"]);
        else _0x40db9f(_0x41beed["curve"],!![]);
        var _0x6b264e=_0x41beed["nodes"]&&_0x41beed["nodes"]["length"]>0x2?'\x20('+_0x41beed["nodes"]["length"]+" points)":'';
        _0x5b20db("Read "+_0x41beed['prop']+" easing into the editor"+_0x6b264e,"success");
        
      } else _0x5b20db(_0x41beed["error"]||"Couldn't read easing","error",_0x1c3953);
    });
  });
  var _0x1dc239=null;
  function _0x11ef0e() {
    _0x1dc239&&(_0x1dc239["classList"]["remove"]("open"),_0x1dc239=null);
  }
  function _0x3014b7(_0x42b067,_0x2d88b9,_0xba7e53,_0x98eb6d,_0x2cbb66) {
    var _0x1df81c=_0x5242a7(_0x42b067),_0x1cbd27=_0x1df81c["querySelector"](".dd-trigger"),_0x32d4b3=_0x1df81c["querySelector"](".dd-label"),_0x527da4=_0x1df81c["querySelector"](".dd-menu"),_0x4055ef=_0xba7e53;
    function _0x5fea09() {
      _0x527da4['innerHTML']='',_0x2d88b9["forEach"](function(_0x529b0d) {
        if(_0x529b0d["group"]!==undefined) {
          var _0x1ed894=document["createElement"]("div");
          _0x1ed894["className"]="dd-group",_0x1ed894["textContent"]=_0x529b0d['group'],_0x527da4["appendChild"](_0x1ed894);
          return;
        }
        var _0x1fb7a6=document["createElement"]("div");
        _0x1fb7a6["className"]="dd-item"+(_0x529b0d['value']===_0x4055ef?'\x20active':'');
        if(_0x2cbb66) {
          var _0x1eb42f=document["createElement"]("canvas");
          _0x1eb42f["width"]=0x3c,_0x1eb42f["height"]=0x2a,_0x1eb42f["className"]='dd-thumb',_0x5ee31b(_0x1eb42f["getContext"]('2d'),_0x1eb42f['width'],_0x1eb42f['height'],_0x529b0d['eval']),_0x1fb7a6['appendChild'](_0x1eb42f);
        }
        var _0x3c0878=document["createElement"]("span");
        _0x3c0878["textContent"]=_0x529b0d["label"],_0x1fb7a6["appendChild"](_0x3c0878);
        if(_0x529b0d['hint']) {
          var _0x263fb7=document["createElement"]("span");
          _0x263fb7['className']='dd-hint',_0x263fb7['textContent']=_0x529b0d["hint"],_0x1fb7a6["appendChild"](_0x263fb7);
        }
        _0x1fb7a6["addEventListener"]("click",function(_0x6ded49) {
          _0x6ded49['stopPropagation'](),_0x4055ef=_0x529b0d["value"],_0x32d4b3["textContent"]=_0x529b0d["triggerLabel"]||_0x529b0d["label"],_0x11ef0e();
          if(_0x98eb6d)_0x98eb6d(_0x529b0d["value"],_0x529b0d);
        }),_0x527da4["appendChild"](_0x1fb7a6);
      });
    }
    function _0x457f1a() {
      _0x11ef0e(),_0x5fea09(),_0x1df81c['classList']['add']("open"),_0x1dc239=_0x1df81c;
      var _0x48c5bf=_0x1cbd27["getBoundingClientRect"]();
      var _0xspaceBelow=window["innerHeight"]-_0x48c5bf["bottom"]-0x8;
      var _0xspaceAbove=_0x48c5bf["top"]-0x8;
      var _0xopenAbove=_0xspaceAbove>_0xspaceBelow;
      var _0xavailable=Math["max"](0x30,_0xopenAbove?_0xspaceAbove:_0xspaceBelow);
      _0x527da4["style"]['left']=_0x48c5bf["left"]+'px';
      _0x527da4["style"]['width']=_0x48c5bf["width"]+'px';
      _0x527da4["style"]["maxHeight"]=Math["min"](0xe6,_0xavailable)+'px';
      if(_0xopenAbove) {
        _0x527da4["style"]["top"]='auto';
        _0x527da4["style"]["bottom"]=window["innerHeight"]-_0x48c5bf["top"]+0x4+'px';
      } else {
        _0x527da4["style"]["bottom"]='auto';
        _0x527da4["style"]["top"]=_0x48c5bf["bottom"]+0x4+'px';
      }
      _0x527da4["scrollTop"]=0x0;
    }
    return _0x1cbd27["addEventListener"]("click",function(_0x4b8b17) {
      _0x4b8b17["stopPropagation"]();
      if(_0x1df81c["classList"]['contains']('open'))_0x11ef0e();
      else _0x457f1a();
    }),_0x5fea09(), {
      'set':function(_0x11f566,_0x489744) {
        _0x4055ef=_0x11f566,_0x32d4b3['textContent']=_0x489744;
      },'setOptions':function(_0x4ef964) {
        _0x2d88b9=_0x4ef964;
        if(_0x1df81c['classList']["contains"]("open"))_0x5fea09();
      }
    };
  }
  document["addEventListener"]('click',_0x11ef0e),_0x5242a7("content")["addEventListener"]('scroll',_0x11ef0e),window["addEventListener"]("resize",_0x11ef0e);
  var _0x4cb856=['Position',"Scale","Rotation",'Anchor\x20Point',"Opacity"]['map'](function(_0x63b994) {
    return {
      'value':_0x63b994,'label':_0x63b994
    };
  }),_0x1a6d0d=[],_0x732212='';
  function _0x260566(_0x647d6a) {
    return _0x647d6a['comp']+(_0x647d6a["compIdx"]?'\x20('+(_0x647d6a["compIdx"]+0x1)+')':'')+" › "+_0x647d6a['param'];
  }
  function _0x4a4dd6(_0x38a982) {
    return "fx|"+_0x38a982["comp"]+'|'+_0x38a982['compIdx']+'|'+_0x38a982['param'];
  }
  function _0xa79380() {
    var _0x21bdbb=_0x4cb856["slice"](),_0xe42f35=null;
    return _0x1a6d0d["forEach"](function(_0x40ece9) {
      var _0xeb2f2a=_0x40ece9["comp"]+(_0x40ece9["compIdx"]?'\x20('+(_0x40ece9["compIdx"]+0x1)+')':'');
      _0xeb2f2a!==_0xe42f35&&(_0x21bdbb["push"]( {
        'group':_0xeb2f2a
      }),_0xe42f35=_0xeb2f2a),_0x21bdbb["push"]( {
        'value':_0x4a4dd6(_0x40ece9),'label':_0x40ece9["param"],'hint':_0x40ece9['keys']+(_0x40ece9["keys"]===0x1?" key":" keys"),'ref': {
          'comp':_0x40ece9["comp"],'compIdx':_0x40ece9["compIdx"],'param':_0x40ece9['param']
        },'dims':_0x40ece9["dims"]||0x1
      });
    }),_0x21bdbb;
  }
  var _0x9acaa4=_0x3014b7("propDD",_0xa79380(),"Position",function(_0xb583a1,_0x36a969) {
    _0x36a969&&_0x36a969["ref"]?(_0x5d8560=_0x36a969['ref'],_0x300bd3=_0x36a969["dims"]||0x1,_0xf296ff=_0x260566(_0x36a969["ref"])):(_0x5d8560=null,_0x300bd3=0x0,_0xf296ff=_0xb583a1),_0x433917();
  },![]);
  function _0x36e990(_0x274942) {
    if(_0x2f7987)return;
    _0x274942=_0x274942||[];
    var _0x44546c=JSON["stringify"](_0x274942);
    if(_0x44546c===_0x732212)return;
    _0x732212=_0x44546c,_0x1a6d0d=_0x274942,_0x9acaa4['setOptions'](_0xa79380());
    if(_0x5d8560) {
      var _0x4f6f92=_0x4a4dd6(_0x5d8560),_0x4a7f5b=![];
      for(var _0x1b36fe=0x0;_0x1b36fe<_0x274942["length"];_0x1b36fe++) {
        if(_0x4a4dd6(_0x274942[_0x1b36fe])===_0x4f6f92) {
          _0x4a7f5b=!![],_0x300bd3=_0x274942[_0x1b36fe]["dims"]||0x1;
          break;
        }
      }
      if(!_0x4a7f5b) {
        var _0x3f3885=_0xf296ff;
        _0x5d8560=null,_0x300bd3=0x0,_0xf296ff="Position",_0x9acaa4["set"]("Position",'Position'),_0x5b20db('\x27'+_0x3f3885+"' isn't on this clip — property reset to Position");
      }
    }
  }
  _0x3014b7("qualityDD",[ {
    'value':0x1,'label':'Every\x20frame'
  }, {
    'value':0x2,'label':'Every\x202nd\x20frame'
  }, {
    'value':0x3,'label':"Every 3rd frame"
  }],0x1,function(_0xcf9cbd) {
    _0x522389=Number(_0xcf9cbd);
  },![]);
  var _0x732471="easeit_preview",_0x4c9d57=!![],_0x196a9f=null,_0x2961f5=null;
  function _0x31876f() {
    _0x196a9f=null;
  }
  function _0x5516f1(_0x3965e6) {
    _0x4c9d57=_0x3965e6;
    var _0x3d8548=_0x5242a7('previewSection');
    if(_0x3d8548)_0x3d8548['style']["display"]=_0x3965e6?'':'none';
  }
  /* El punto de la vista previa. Antes pedía un cuadro detrás de otro para
     siempre: con la vista previa apagada y con el panel oculto seguía pidiendo
     sesenta por segundo para no hacer nada. Ahora se para en esos dos casos y
     vuelve a arrancar cuando el panel se ve otra vez (foco, visibilidad o el
     resize que manda repaint-guard). Y se mueve con transform en vez de left:
     así no obliga a recalcular la maquetación en cada cuadro. */
  function _0x14d81b(_0x4f1b31) {
    if(!_0x4c9d57||(window.EditKitAwake&&(window.EditKitAwake.idle()||window.EditKitAwake.performance()))) {
      _0x2961f5=null;
      return;
    }
    var _0x38a9c2=_0x5242a7("previewDot");
    if(!_0x38a9c2) {
      _0x2961f5=requestAnimationFrame(_0x14d81b);
      return;
    }
    var _0x1575cc=_0x38a9c2['parentElement'],_0x29e3ac=_0x1575cc["clientWidth"]-_0x38a9c2["offsetWidth"]-0x8,_0x7561b5=0x44c,_0x5cdbca=0x15e,_0x29b687=_0x7561b5+_0x5cdbca;
    if(_0x196a9f===null)_0x196a9f=_0x4f1b31;
    var _0x897c65=(_0x4f1b31-_0x196a9f)%_0x29b687,_0x27354f=_0x897c65<_0x7561b5?_0x55da23(_0x897c65/_0x7561b5):0x1;
    if(_0x38a9c2["style"]["left"]!=='4px')_0x38a9c2["style"]["left"]='4px';
    _0x38a9c2["style"]["transform"]='translateX('+_0x27354f*_0x29e3ac+'px)',_0x2961f5=requestAnimationFrame(_0x14d81b);
  }
  function _ekPreviewWake() {
    if(_0x2961f5===null&&_0x4c9d57&&!(window.EditKitAwake&&window.EditKitAwake.performance()))_0x2961f5=requestAnimationFrame(_0x14d81b);
  }
  window["addEventListener"]("focus",_ekPreviewWake);
  window["addEventListener"]("resize",_ekPreviewWake);
  document["addEventListener"]("visibilitychange",_ekPreviewWake);
  function _0x5b20db(_0xd0ccb8,_0x545452,_0x4bef49) {
    var _0x3dd954=_0x5242a7("status");
    _0x3dd954['className']="status"+(_0x545452?'\x20'+_0x545452:''),_0x3dd954["textContent"]=(_0x545452==="error"?'⚠\x20':'')+_0xd0ccb8+(_0x545452==="error"?"  (click to copy)":''),_0x2009ce=_0x545452==='error'?_0xd0ccb8+(_0x4bef49?"\n\nDetail: "+_0x4bef49:''):'';
    if(_0x545452==="error") {
      _0x262b90=_0xd0ccb8+(_0x4bef49?"\n\nDetail: "+_0x4bef49:'');
      
    }
    _0x3565ed["push"]( {
      'line':(_0x545452==="error"?'⚠\x20':_0x545452==="success"?'✓\x20':'·\x20')+_0xd0ccb8,'type':_0x545452||''
    });
    if(_0x3565ed["length"]>0x14)_0x3565ed["shift"]();
  }
  
  
  function _0x1f60f6(_0x5b4395) {
    var _0x3fa8de=document["createElement"]("textarea");
    _0x3fa8de["value"]=_0x5b4395,document['body']["appendChild"](_0x3fa8de),_0x3fa8de["select"]();
    try {
      document["execCommand"]("copy");
    } catch(_0x4bccdb) {
    }
    document["body"]["removeChild"](_0x3fa8de);
  }
  function _0x43b2f4(_0x1801a3) {
    var _0x53ff49=document['querySelector']('.modal-overlay:not(.closing)');
    if(_0x53ff49) {
      var _0x3018a9='';
      try {
        _0x3018a9=_0x53ff49['querySelector']('h3')['textContent'];
      } catch(_0x29b302) {
      }
      if(_0x3018a9===(_0x1801a3["title"]||''))return;
    }
    var _0x25b846=document["createElement"]("div");
    _0x25b846["className"]="modal-overlay";
    var _0x23f566=document["createElement"]('div');
    _0x23f566['className']="modal"+(_0x1801a3["wide"]?'\x20wide':'');
    var _0x5e072c=document['createElement']('h3');
    _0x5e072c["textContent"]=_0x1801a3["title"]||'',_0x23f566["appendChild"](_0x5e072c);
    if(_0x1801a3['bodyHTML']) {
      var _0x574430=document["createElement"]('div');
      _0x574430["className"]='modal-body',_0x574430['innerHTML']=_0x1801a3["bodyHTML"],_0x23f566["appendChild"](_0x574430);
    }
    var _0x521ddd=null;
    _0x1801a3["input"]&&(_0x521ddd=document['createElement']("input"),_0x521ddd["type"]="text",_0x521ddd["className"]="modal-input",_0x521ddd["value"]=_0x1801a3['defaultValue']||'',_0x23f566['appendChild'](_0x521ddd));
    var _0x50f7ee=document['createElement']("div");
    _0x50f7ee["className"]="modal-actions";
    var _0xa0b0fa=![];
    function _0x244d0d() {
      if(_0xa0b0fa)return;
      _0xa0b0fa=!![],document['removeEventListener']("keydown",_0x74650b),_0x25b846["classList"]['add']("closing"),_0x25b846["classList"]["remove"]("show"),setTimeout(function() {
        if(_0x25b846["parentNode"])_0x25b846['parentNode']["removeChild"](_0x25b846);
      },0xf0);
      if(_0x1801a3["onClose"])try {
        _0x1801a3["onClose"]();
      } catch(_0x3b2feb) {
      }
    }
    function _0x465bd8() {
      var _0x44eff1=_0x521ddd?_0x521ddd["value"]:null;
      _0x244d0d();
      if(_0x1801a3["onOk"])_0x1801a3["onOk"](_0x44eff1);
    }
    var _0x51f415=null;
    if(!_0x1801a3["noButtons"]) {
      if(!_0x1801a3["okOnly"]) {
        var _0x2bf9fb=document["createElement"]("div");
        _0x2bf9fb["className"]="modal-btn",_0x2bf9fb['textContent']=_0x1801a3["cancelText"]||'Cancel',_0x2bf9fb["addEventListener"]("click",function() {
          _0x244d0d();
          if(_0x1801a3["onCancel"])_0x1801a3["onCancel"]();
        }),_0x50f7ee['appendChild'](_0x2bf9fb);
      }
      _0x51f415=document["createElement"]("div"),_0x51f415["className"]='modal-btn\x20primary',_0x51f415['textContent']=_0x1801a3["okText"]||'OK',_0x51f415['addEventListener']('click',_0x465bd8),_0x50f7ee["appendChild"](_0x51f415);
    }
    _0x23f566["appendChild"](_0x50f7ee),_0x25b846['appendChild'](_0x23f566),document["body"]["appendChild"](_0x25b846);
    if(_0x1801a3["dismissable"]!==![])_0x25b846["addEventListener"]("click",function(_0x251c22) {
      if(_0x251c22["target"]===_0x25b846)_0x244d0d();
    });
    function _0x74650b(_0x53f570) {
      if(_0x53f570["key"]==='Escape') {
        if(_0x1801a3["dismissable"]!==![])_0x244d0d();
      } else _0x53f570["key"]==='Enter'&&_0x51f415&&(_0x53f570["preventDefault"](),_0x465bd8());
    }
    document['addEventListener']('keydown',_0x74650b),requestAnimationFrame(function() {
      _0x25b846["classList"]["add"]("show");
      if(_0x521ddd)_0x521ddd["focus"](),_0x521ddd["select"]();
      else {
        if(_0x51f415)_0x51f415["focus"]();
      }
    });
    if(_0x1801a3["afterRender"])try {
      _0x1801a3["afterRender"](_0x23f566,_0x244d0d);
    } catch(_0x5a7c1d) {
    }
  }
  function _0x428ebf() {
    _0x43b2f4( {
      'title':"How to use EaseIt",'wide':!![],'okOnly':!![],'okText':"Got it",'bodyHTML':'<p><b>1.</b>\x20Pick\x20a\x20preset\x20on\x20the\x20<b>PRESETS</b>\x20tab,\x20or\x20drag\x20the\x20yellow\x20handles\x20to\x20shape\x20the\x20curve.</p>'+'<p><b>2.</b>\x20<b>Double-click\x20the\x20curve</b>\x20to\x20add\x20a\x20point\x20(mint),\x20<b>double-click\x20a\x20point</b>\x20to\x20remove\x20it,\x20<b>double-click\x20a\x20handle</b>\x20to\x20type\x20exact\x20values.</p>'+'<p><b>Shift</b>-drag\x20=\x20constrain\x20to\x20one\x20axis\x20·\x20<b>Alt</b>-drag\x20an\x20<b>end\x20handle</b>\x20=\x20mirror\x20the\x20other\x20side\x20(even\x20on\x20both\x20ends)\x20·\x20<b>Alt</b>-drag\x20a\x20<b>point\x27s\x20handle</b>\x20=\x20break\x20its\x20link.</p>'+"<p>On-chart tools: <b>V</b> velocity overlay · <b>+ / −</b> zoom · <b>⊡</b> fit. Tap the <b>★</b> to save the curve as a preset.</p>"+'<p\x20class=\x27tip\x27>Make\x20the\x20panel\x20<b>very\x20narrow</b>\x20for\x20a\x20compact\x20one-tap\x20preset\x20list\x20—\x20the\x20editor\x20hides\x20and\x20a\x20preset\x20applies\x20the\x20moment\x20you\x20click\x20it.</p>'+"<p><b>3.</b> Then <b>Apply Easing</b>. <b>Revert</b> undoes it.</p>"+"<p class='tip'>Multiple keyframes? In <b>After Effects</b>, <b>select</b> the keyframes (2 or more) and EaseIt eases them as <b>one animation</b> — even add midpoints in the graph. <b>Premiere</b> works on a single 2-keyframe animation.</p>"
    });
  }
  _0x5242a7("status")["addEventListener"]("click",function() {
    if(!_0x2009ce)return;
    _0x1f60f6("EaseIt "+_0x11c271+" · "+(_0x2f7987?'AE':'PR')+'\x0a'+_0x2009ce);
    var _0x31b563=_0x5242a7("status"),_0x389bba=_0x31b563["textContent"];
    _0x31b563["textContent"]="✓ Error copied to clipboard",_0x31b563["className"]="status success",setTimeout(function() {
      _0x31b563["textContent"]=_0x389bba,_0x31b563["className"]="status error";
    },0x578);
  });
  function _0x115d7b(_0x7a05e,_0x4e0d23) {
    _0x1b14ff["evalScript"](_0x7a05e,function(_0x157fe0) {
      _0x4e0d23(_0x157fe0);
    });
  }
  var _0x240688=null;
  function _0x58c0e6() {
    _0x115d7b("easeit_getClipInfo()",function(_0x14c4ff) {
      var _0x215bcc;
      try {
        _0x215bcc=JSON["parse"](_0x14c4ff);
      } catch(_0x554f73) {
        return;
      }
      _0x240688=_0x215bcc&&_0x215bcc["success"]?_0x215bcc:null;
      if(_0x240688&&!_0x2f7987)_0x36e990(_0x240688["custom"]);
    });
  }
  var _0x390a16="easeit_anchors";
  function _0x46b8ee() {
    try {
      return JSON['parse'](localStorage["getItem"](_0x390a16))|| {
      };
    } catch(_0x41f7d0) {
      return {
      };
    }
  }
  function _0x407bd6(_0xb7e28f) {
    try {
      localStorage['setItem'](_0x390a16,JSON["stringify"](_0xb7e28f));
    } catch(_0x29ecb5) {
    }
  }
  function _0x1c8abb() {
    var _0x43471b=_0x240688;
    return(_0x43471b&&_0x43471b["clip"]?_0x43471b["clip"]:'?')+'|'+_0xf296ff;
  }
  var _0x4e3b14="easeit_truehandles";
  function _0x58e056(_0x4c9912,_0x500d8a) {
    try {
      if(window['EaseItTH'])EaseItTH["log"](_0x4c9912,_0x500d8a);
    } catch(_0x15c709) {
    }
  }
  function _0x2496ba() {
    var _0x33b635=_0x5242a7("thTog");
    return!!(!_0x2f7987&&_0x33b635&&_0x33b635['checked']);
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  function _0x39f798() {
    if(_0x2f7987)return;
    var _0x564bed=_0x5242a7("thRow"),_0x1bed8a=_0x5242a7("thTog");
    if(!_0x564bed||!_0x1bed8a)return;
    _0x564bed["style"]['display']='';
    try {
      _0x1bed8a["checked"]=localStorage['getItem'](_0x4e3b14)==='1';
    } catch(_0x2f12b7) {
    }
    _0x1bed8a['addEventListener']('change',function() {
      try {
        localStorage["setItem"](_0x4e3b14,_0x1bed8a["checked"]?'1':'0');
      } catch(_0x523ec7) {
      }
      if(!_0x1bed8a['checked']) {
        _0x5b20db("True Handles off — Apply bakes keyframes");
        return;
      }
      if(!window["EaseItTH"]||!EaseItTH["available"]()) {
        _0x1bed8a['checked']=![],_0x5b20db("True Handles needs Node.js — reinstall the panel (manifest must have --enable-nodejs)","error");
        return;
      }
      
      _0x115d7b("easeit_th_support()",function(_0x5a0a0a) {
        _0x58e056('support',_0x5a0a0a);
        var _0x4c7b57;
        try {
          _0x4c7b57=JSON['parse'](_0x5a0a0a);
        } catch(_0x59ca72) {
          _0x4c7b57=null;
        }
        if(_0x4c7b57&&_0x4c7b57['supported'])_0x5b20db('True\x20Handles\x20on\x20—\x20Apply\x20writes\x20real\x20bezier\x20handles'+" (project will reopen)");
        else {
          _0x1bed8a["checked"]=![];
          try {
            localStorage["setItem"](_0x4e3b14,'0');
          } catch(_0x1b8267) {
          }
          _0x5b20db(_0x4c7b57&&_0x4c7b57["error"]||"True Handles unavailable","error",_0x5a0a0a);
        }
      });
    });
  }
  function _0x2de7d4(_0x3153af) {
    if(_0x224f56==='fn')return null;
    var _0x1a7e9a=_0x252896;
    if(_0x3153af) {
      var _0x5d5367=[];
      for(var _0x4c6b33=_0x1a7e9a["length"]-0x1;_0x4c6b33>=0x0;_0x4c6b33--) {
        var _0x3819c1=_0x1a7e9a[_0x4c6b33];
        _0x5d5367["push"]( {
          'x':0x1-_0x3819c1['x'],'y':0x1-_0x3819c1['y'],'hl':_0x3819c1['hr']?[0x1-_0x3819c1['hr'][0x0],0x1-_0x3819c1['hr'][0x1]]:null,'hr':_0x3819c1['hl']?[0x1-_0x3819c1['hl'][0x0],0x1-_0x3819c1['hl'][0x1]]:null
        });
      }
      _0x1a7e9a=_0x5d5367;
    }
    var _0x35f7c5=_0x2c4b4e(_0x1a7e9a);
    if(_0x35f7c5["length"]===0x1) {
      var _0x213400=_0x35f7c5[0x0];
      return {
        'x1':_0x213400[0x2],'y1':_0x213400[0x3],'x2':_0x213400[0x4],'y2':_0x213400[0x5]
      };
    }
    return {
      'segs':_0x35f7c5
    };
  }
  var _0x10de31='easeit_th_explained';
  function _0x17ee67(_0x4461ab) {
    var _0x1317b9=_0x5242a7("applyBtn");
    if(_0x5d8560&&_0x300bd3>0x2)return _0x5b20db('True\x20Handles\x20supports\x201D\x20&\x202D\x20parameters\x20—\x20\x27'+_0xf296ff+'\x27\x20bakes\x20instead.\x20Applying\x20baked…'),![];
    var _0x3f6171=_0x2de7d4(_0x4461ab["reverse"]);
    if(!_0x3f6171)return _0x5b20db("True Handles writes curves & multi-point paths — Elastic/Bounce formulas still bake. Applying baked…"),![];
    if(!window["EaseItTH"]||!EaseItTH["available"]())return _0x5b20db('True\x20Handles\x20needs\x20Node.js\x20—\x20reinstall\x20the\x20panel',"error"),!![];
    
    if(EaseItTH['peekState']&&EaseItTH["peekState"]('pending'))return _0x5b20db('A\x20True\x20Handles\x20operation\x20is\x20still\x20finishing\x20—\x20give\x20it\x20a\x20moment.',"error"),!![];
    var _0x46b2cb=![];
    try {
      _0x46b2cb=localStorage['getItem'](_0x10de31)==='1';
    } catch(_0xce6d60) {
    }
    if(!_0x46b2cb)return _0x43b2f4( {
      'title':"How True Handles works",'wide':!![],'okText':"Got it, apply",'cancelText':'Cancel','bodyHTML':"<p><b>True Handles</b> writes real bezier handles straight into your project file — no baked keyframes.</p>"+"<p>To load them, EaseIt <b>saves, closes and reopens your project automatically</b>. Please <b>wait and don't reopen the project yourself</b> — the first time after launching Premiere it can take up to a minute.</p>"+"<p><b>⚠ First time only:</b> after this very first apply you may need to <b>re-open your project (or its timeline) yourself</b>. That's a one-time thing — every apply after this reopens automatically.</p>"+"<p class='tip'>A <b>.easeit-bak</b> backup of your project is saved next to it every time, and <b>Revert</b> restores it.</p>",'onOk':function() {
        try {
          localStorage['setItem'](_0x10de31,'1');
        } catch(_0x2673ba) {
        }
        _0x17ee67(_0x4461ab);
      }
    }),!![];
    return _0x1317b9["classList"]["add"]("busy"),_0x58e056('start', {
      'version':_0x11c271,'prop':_0xf296ff,'curve':_0x3f6171
    }),_0x5b20db("Tagging keyframes & saving project…"),_0x1b14ff['evalScript']("easeit_th_prep("+JSON["stringify"](JSON["stringify"]( {
      'prop':_0xf296ff,'propRef':_0x5d8560||undefined
    }))+')',function(_0xb50e5e) {
      _0x58e056("prep",_0xb50e5e);
      var _0x36d713;
      try {
        _0x36d713=JSON['parse'](_0xb50e5e);
      } catch(_0x36ae29) {
        _0x36d713=null;
      }
      if(!_0x36d713||!_0x36d713["success"]) {
        _0x1317b9["classList"]["remove"]("busy"),_0x5b20db(_0x36d713&&_0x36d713['error']||"Prep failed","error",_0xb50e5e);
        return;
      }
      EaseItTH["setState"]("pending", {
        'action':"surgery",'info':_0x36d713,'curve':_0x3f6171,'real':_0x36d713['projPath'],'ts':Date['now']()
      }),_0x3da855=!![],_0x5b20db("Closing project to write handles…"),_0x1b14ff["evalScript"]("easeit_th_close()",function(_0x4772d2) {
        _0x58e056("close",_0x4772d2);
        var _0x4cea2a=null;
        try {
          _0x4cea2a=JSON['parse'](_0x4772d2);
        } catch(_0x8648a2) {
        }
        if(_0x4cea2a&&_0x4cea2a['success']===![]) {
          EaseItTH["takeState"]("pending"),_0x3da855=![],_0x1a490f(),_0x5b20db(_0x4cea2a["error"]||"Could not close the project",'error',_0x4772d2);
          return;
        }
        _0x3da855=![],setTimeout(function() {
          _0x287933(!![]);
        },0x258);
      }),setTimeout(function() {
        _0x3da855=![],_0x287933(!![]);
      },0x1770);
    }),!![];
  }
  var _0x921818=![],_0x3da855=![];
  function _0x1a490f() {
    var _0x5bdb5c=_0x5242a7("applyBtn");
    if(_0x5bdb5c)_0x5bdb5c['classList']['remove']("busy");
    var _0x52e406=_0x5242a7("revertBtn");
    if(_0x52e406)_0x52e406["classList"]["remove"]("busy");
  }
  function _0x287933(_0x4189ef) {
    if(_0x921818)return;
    if(!window["EaseItTH"]||!EaseItTH["available"]())return;
    var _0x16359b=EaseItTH["peekState"]("pending");
    if(!_0x16359b) {
      _0x12e536();
      return;
    }
    if(_0x3da855)return;
    if(Date["now"]()-_0x16359b['ts']>0x493e0) {
      EaseItTH["takeState"]("pending");
      if(_0x16359b["action"]==="surgery"&&_0x16359b["info"])try {
        _0x58e056("marker-cleanup",EaseItTH["removeMarkerFromFile"](_0x16359b['info']));
      } catch(_0x5c21ac) {
      }
      _0x1a490f(),_0x5b20db("True Handles didn't finish (stale) … nothing changed.","error");
      return;
    }
    _0x921818=!![],EaseItTH['takeState']("pending"),_0x58e056('resume', {
      'action':_0x16359b['action'],'ageMs':Date["now"]()-_0x16359b['ts'],'warm':!!_0x4189ef
    });
    var _0x1cab72=_0x4189ef?0xfa:0x9c4,_0x271760=_0x4189ef?0x12c:0x4b0,_0x2f6d9f=0x0;
    function _0x1aeae() {
      var _0x334f2c;
      if(_0x16359b['action']==="restore")_0x334f2c=EaseItTH["restore"](_0x16359b["real"]),_0x58e056("restore",_0x334f2c);
      else {
        try {
          _0x334f2c=EaseItTH['surgery'](_0x16359b["info"],_0x16359b["curve"]);
        } catch(_0x3dedd9) {
          _0x334f2c= {
            'success':![],'error':String(_0x3dedd9&&_0x3dedd9["message"]||_0x3dedd9)
          };
        }
        _0x58e056("surgery",_0x334f2c);
      }
      if(!_0x334f2c["success"]&&_0x334f2c["retry"]&&_0x2f6d9f<0xf) {
        _0x2f6d9f++,setTimeout(_0x1aeae,0x15e);
        return;
      }
      if(!_0x334f2c["success"]&&_0x16359b['action']==="surgery")try {
        _0x58e056("marker-cleanup",EaseItTH["removeMarkerFromFile"](_0x16359b["info"]));
      } catch(_0x299c6d) {
      }
      _0x3b30cd(_0x334f2c);
    }
    function _0x3b30cd(_0x2ba46d) {
      var _0x2fed30=_0x2ba46d["success"],_0x1d53ef;
      if(_0x16359b["action"]==="restore")_0x1d53ef=_0x2fed30?"✓ Project restored to pre-EaseIt backup":_0x2ba46d["error"]||"Restore failed";
      else {
        var _0xcff8c6=_0x2fed30?_0x2ba46d['droppedInterior']-0x1:0x0,_0x1c1e27=_0x2fed30&&_0x2ba46d["insertedInterior"]?_0x2ba46d["insertedInterior"]:0x0;
        _0x1d53ef=_0x2fed30?'✓\x20'+_0x16359b["info"]['paramName']+" — real bezier handles written"+(_0x1c1e27>0x0?" · "+_0x1c1e27+" path point"+(_0x1c1e27===0x1?'':'s')+" added":'')+(_0xcff8c6>0x0?" · "+_0xcff8c6+" baked keys removed":'')+" · backup saved":(_0x2ba46d["error"]||"True Handles failed")+" — project reopened unchanged";
        
        
      }
      EaseItTH["setState"]("done", {
        'ok':_0x2fed30,'msg':_0x1d53ef
      });
      try {
        _0x58e056('verify-disk',EaseItTH["verifyDisk"](_0x16359b["info"]|| {
          'projPath':_0x16359b["real"],'tickA':'0','tickMarker':'0'
        }));
      } catch(_0x577da9) {
      }
      var _0x20803d=JSON["stringify"](JSON["stringify"]( {
        'path':_0x16359b['real']
      })),_0x30f1c5=_0x16359b["info"]&&_0x16359b["info"]["tickMarker"]?_0x16359b["info"]["tickMarker"]:null;
      _0x921818=![];
      var _0x5cf9b6=![];
      function _0x44ba26() {
        _0x5cf9b6=!![];
      }
      setTimeout(function() {
        if(_0x5cf9b6)return;
        _0x5cf9b6=!![],_0x58e056("detour-watchdog","reopen did not finish in time");
        try {
          EaseItTH['finishReload'](_0x16359b["real"]);
        } catch(_0x82ea9e) {
        }
        EaseItTH["takeState"]("done"),_0x1a490f(),_0x5b20db("Handles written & your project is safe. If it didn't reopen, just open it again: "+_0x16359b["real"],"success");
      },0x7530);
      function _0x37cdb0() {
        _0x44ba26();
        var _0x44d7a5=JSON["stringify"](JSON['stringify']( {
          'seqId':_0x16359b["info"]&&_0x16359b["info"]["seqId"]||'','seqName':_0x16359b["info"]&&_0x16359b["info"]["seqName"]||''
        }));
        _0x1b14ff["evalScript"]("easeit_th_focusSeq("+_0x44d7a5+')',function(_0x51c8df) {
          _0x58e056("focus-seq",_0x51c8df);
          if(!_0x30f1c5) {
            _0x12e536();
            return;
          }
          _0x1b14ff["evalScript"]('easeit_th_verify('+JSON["stringify"](JSON['stringify']( {
            'tickMarker':_0x30f1c5
          }))+')',function(_0x23d279) {
            _0x58e056('verify-open',_0x23d279);
            var _0x3ce6d0=null;
            try {
              _0x3ce6d0=JSON["parse"](_0x23d279);
            } catch(_0x471adc) {
            }
            _0x3ce6d0&&_0x3ce6d0['success']&&_0x3ce6d0["markerPresent"]?(EaseItTH["takeState"]("done"),_0x1a490f(),_0x5b20db('Handles\x20written\x20to\x20the\x20file\x20✓\x20but\x20Premiere\x20still\x20showed\x20a\x20cached\x20copy\x20—\x20close\x20&\x20reopen\x20the\x20project\x20once.','error')):_0x12e536();
          });
        });
      }
      _0x5b20db('Reopening\x20your\x20project\x20automatically\x20—\x20please\x20wait,\x20don\x27t\x20reopen\x20it\x20yourself…');
      var _0x294ed3=EaseItTH['stashForFreshOpen'](_0x16359b["real"]);
      _0x58e056("stash",_0x294ed3);
      if(!_0x294ed3['ok']) {
        setTimeout(function() {
          _0x1b14ff["evalScript"]("easeit_th_open("+_0x20803d+')',function(_0x490b7b) {
            _0x58e056("open-real",_0x490b7b),setTimeout(_0x37cdb0,_0x1cab72);
          });
        },_0x1cab72);
        return;
      }
      var _0x7939a=JSON["stringify"](JSON["stringify"]( {
        'path':_0x294ed3['temp']
      }));
      setTimeout(function() {
        _0x1b14ff["evalScript"]("easeit_th_open("+_0x7939a+')',function(_0x5431ff) {
          _0x58e056("open-fresh",_0x5431ff),setTimeout(function() {
            _0x1b14ff["evalScript"]("easeit_th_saveAs("+_0x20803d+')',function(_0x3a8551) {
              _0x58e056("saveas",_0x3a8551);
              var _0x4b3cb2=null;
              try {
                _0x4b3cb2=JSON["parse"](_0x3a8551);
              } catch(_0x55beb9) {
              }
              if(_0x4b3cb2&&_0x4b3cb2["success"]) {
                try {
                  EaseItTH["finishReload"](_0x16359b["real"]);
                } catch(_0x9cb13) {
                }
                setTimeout(_0x37cdb0,_0x271760);
              } else _0x44ba26(),EaseItTH["takeState"]("done"),_0x1a490f(),_0x5b20db("Handles written & your work is safe — but Premiere couldn't rename the project back. Use File ▸ Save As and pick your original .prproj name.","error",_0x3a8551);
            });
          },_0x271760);
        });
      },_0x1cab72);
    }
    _0x1aeae();
  }
  function _0x12e536() {
    if(!window['EaseItTH'])return;
    var _0x47fb71=EaseItTH["takeState"]("done");
    if(!_0x47fb71)return;
    _0x1a490f(),_0x5b20db(_0x47fb71["msg"],_0x47fb71['ok']?"success":"error"),_0x58c0e6();
  }
  function _0x4f1610() {
    if(_0x2f7987||!window["EaseItTH"]||!EaseItTH["available"]())return;
    try {
      EaseItTH["recoverReload"]();
    } catch(_0x225214) {
    }
    _0x287933();
  }
  function _0x9eb789() {
    var _0x2e0fec=_0x5242a7("revertBtn");
    _0x115d7b("easeit_th_support()",function(_0x2d92e0) {
      var _0x2d585b;
      try {
        _0x2d585b=JSON["parse"](_0x2d92e0);
      } catch(_0x2c4603) {
        _0x2d585b=null;
      }
      if(!_0x2d585b||!_0x2d585b["path"]) {
        _0x5b20db("No open project to revert","error");
        return;
      }
      if(!window['EaseItTH']||!EaseItTH['hasBackup'](_0x2d585b["path"])) {
        _0x5b20db("No True Handles backup for this project — nothing to restore","error");
        return;
      }
      _0x43b2f4( {
        'title':"Restore pre-EaseIt project?",'okText':'Restore\x20&\x20reopen','cancelText':"Cancel",'bodyHTML':"<p>This rolls the whole project file back to the backup taken just before the last <b>True Handles</b> apply (any edits made after it are lost).</p>",'onOk':function() {
          _0x2e0fec["classList"]["add"]("busy"),EaseItTH['setState']("pending", {
            'action':"restore",'real':_0x2d585b["path"],'ts':Date['now']()
          }),_0x3da855=!![],_0x5b20db("Closing project to restore…"),_0x1b14ff["evalScript"]("easeit_th_close()",function(_0x7b9410) {
            _0x58e056("close",_0x7b9410);
            var _0xa31c8b=null;
            try {
              _0xa31c8b=JSON["parse"](_0x7b9410);
            } catch(_0x52edfa) {
            }
            if(_0xa31c8b&&_0xa31c8b["success"]===![]) {
              EaseItTH["takeState"]("pending"),_0x3da855=![],_0x1a490f(),_0x5b20db(_0xa31c8b["error"]||"Could not close the project","error",_0x7b9410);
              return;
            }
            _0x3da855=![],setTimeout(function() {
              _0x287933(!![]);
            },0x258);
          }),setTimeout(function() {
            _0x3da855=![],_0x287933(!![]);
          },0x1770);
        }
      });
    });
  }
  function _0x1d1dae(_0x1b0dfb) {
    _0x956647(_0x1b0dfb,![]);
  }
  var _0x5a6620=![];
  function _0x956647(_0x419ac1,_0x56a425) {
    var _0x134634=_0x5242a7("applyBtn");
    if(_0x134634["classList"]["contains"]("busy"))return;
    if(!_0x419ac1&&_0x2496ba()) {
      var _0xe05dcf=_0x17ee67( {
        'prop':_0xf296ff,'reverse':_0x5242a7("reverse")["checked"]
      });
      if(_0xe05dcf)return;
    }
    var _0x1036aa=_0x46b8ee(),_0x4411b2=_0x1c8abb(),_0x3a6f99= {
      'prop':_0xf296ff,'density':_0x522389,'reverse':_0x5242a7("reverse")['checked']
    };
    if(_0x5d8560)_0x3a6f99["propRef"]=_0x5d8560;
    _0x224f56==='fn'?(_0x3a6f99["kind"]='fn',_0x3a6f99['fn']=_0x80d606):(_0x3a6f99['kind']="path",_0x3a6f99["segs"]=_0x2c4b4e(_0x252896));
    if(_0x25354f())_0x3a6f99["eachPair"]=!![];
    if(_0x56a425)_0x3a6f99["confirmSeparate"]=!![];
    if(_0x1036aa[_0x4411b2]&&_0x1036aa[_0x4411b2]["length"]>=0x2)_0x3a6f99["anchors"]=_0x1036aa[_0x4411b2];
    if(!_0x419ac1)_0x134634["classList"]['add']("busy");
    if(!_0x419ac1)_0x5b20db("Applying easing…");
    _0x1b14ff["evalScript"]('easeit_applyEasing('+JSON["stringify"](JSON["stringify"](_0x3a6f99))+')',function(_0x43f4c1) {
      if(!_0x419ac1)_0x134634['classList']["remove"]("busy");
      var _0x54293a;
      try {
        _0x54293a=JSON["parse"](_0x43f4c1);
      } catch(_0x5aa697) {
        if(!_0x419ac1)_0x5b20db('Host\x20error',"error",_0x43f4c1);
        return;
      }
      if(_0x54293a["needSeparate"]) {
        if(_0x419ac1&&_0x5a6620) {
          _0x5b20db('Overshoot\x20needs\x20separated\x20dimensions\x20—\x20click\x20Apply\x20to\x20separate','error');
          return;
        }
        _0x5a6620=!![],_0x43b2f4( {
          'title':"Separate dimensions?",'wide':!![],'okText':'Separate\x20&\x20apply','cancelText':"Cancel",'bodyHTML':'<p>After\x20Effects\x20can\x27t\x20<b>overshoot</b>\x20spatial\x20<b>Position</b>\x20keyframes\x20unless\x20its\x20<b>X\x20and\x20Y\x20dimensions\x20are\x20separated</b>.</p>'+"<p>Separate dimensions now and apply this easing?</p>",'onOk':function() {
            _0x956647(![],!![]);
          },'onCancel':function() {
            _0x5b20db("Overshoot not applied — Position X/Y stay together (click Apply to separate)");
          }
        });
        return;
      }
      if(_0x54293a["success"]) {
        _0x5a6620=![];
        _0x54293a["anchorsUsed"]&&_0x54293a['anchorsUsed']["length"]>=0x2&&(_0x1036aa[_0x4411b2]=_0x54293a['anchorsUsed'],_0x407bd6(_0x1036aa));
        var _0x201189;
        if(_0x54293a['mode']==="native"||_0x54293a["mode"]==="native-multi"||_0x54293a["mode"]==="formula") {
          var _0x1ae52d=_0x54293a["keyframes"]||_0x54293a["segments"]+0x1;
          _0x201189='✓\x20'+_0x54293a["prop"]+" eased · "+_0x1ae52d+" keyframe"+(_0x1ae52d===0x1?'':'s')+(_0x54293a['separated']?'\x20·\x20XY\x20separated':'');
        } else _0x201189='✓\x20'+_0x54293a['prop']+':\x20'+_0x54293a['keysAdded']+" keys "+(_0x54293a["reBake"]?"re-baked":"baked")+" · "+_0x54293a['segments']+'\x20segment'+(_0x54293a["segments"]===0x1?'':'s');
        _0x5b20db((_0x419ac1?'⚡\x20':'')+_0x201189,'success');
        
        _0x58c0e6();
      } else!_0x419ac1&&_0x5b20db(_0x54293a["error"]||'Failed',"error",_0x43f4c1);
    });
  }
  _0x5242a7("applyBtn")["addEventListener"]("click",function() {
    _0x1d1dae(![]);
  });
  var _0x267a2d=![],_0x5c2a1b=![],_0x21a704=null,_0x14a13c=![],_0x3f66f2="easeit_autoapply";
  function _0x433917() {
    if(!_0x5c2a1b)return;
    if(_0x14a13c) {
      _0x14a13c=![];
      return;
    }
    if(!(_0x267a2d&&_0x2f7987||_0x24386e))return;
    _0x21a704&&clearTimeout(_0x21a704),_0x21a704=setTimeout(function() {
      _0x21a704=null,_0x1d1dae(!![]);
    },_0x24386e?0x5a:0xdc);
  }
  function _0x431770() {
    try {
      var _0x205544=localStorage["getItem"](_0x3f66f2);
      _0x267a2d=_0x205544===null?!![]:_0x205544==='1';
    } catch(_0x1f6dd9) {
      _0x267a2d=!![];
    }
  }
  window["addEventListener"]("easeit:autoapply-change",function(_0xautoEvent) {
    _0x267a2d=!!(_0xautoEvent&&_0xautoEvent["detail"]&&_0xautoEvent["detail"]["enabled"]);
    if(!_0x267a2d&&_0x21a704) {
      clearTimeout(_0x21a704);
      _0x21a704=null;
    }
  });
  var _0x4771d0="easeit_eachpair";
  function _0x25354f() {
    var _0x47124a=_0x5242a7("eachPairTog");
    return!!(_0x2f7987&&_0x47124a&&_0x47124a["checked"]);
  }
  function _0x3b12c5() {
    var _0x40d992=_0x5242a7("eachPairTog");
    if(!_0x40d992)return;
    var _0x2e49d7=!![];
    try {
      var _0x1f7a2e=localStorage['getItem'](_0x4771d0);
      _0x2e49d7=_0x1f7a2e===null?!![]:_0x1f7a2e==='1';
    } catch(_0x124f22) {
    }
    _0x40d992["checked"]=_0x2e49d7,_0x40d992["addEventListener"]("change",function() {
      try {
        localStorage["setItem"](_0x4771d0,_0x40d992["checked"]?'1':'0');
      } catch(_0xc8c990) {
      }
      if(_0x267a2d)_0x433917();
    });
  }
  _0x5242a7("revertBtn")['addEventListener']('click',function() {
    var _0x21edb5=_0x5242a7("revertBtn");
    if(_0x21edb5["classList"]["contains"]("busy"))return;
    if(_0x2496ba()) {
      _0x9eb789();
      return;
    }
    var _0x17fe99=_0x46b8ee(),_0x53d1d9=_0x1c8abb(),_0x531a21= {
      'prop':_0xf296ff
    };
    if(_0x5d8560)_0x531a21["propRef"]=_0x5d8560;
    if(_0x17fe99[_0x53d1d9]&&_0x17fe99[_0x53d1d9]["length"]>=0x2)_0x531a21["anchors"]=_0x17fe99[_0x53d1d9];
    _0x21edb5["classList"]['add']('busy'),_0x5b20db("Reverting…"),_0x1b14ff['evalScript']("easeit_revertEasing("+JSON['stringify'](JSON["stringify"](_0x531a21))+')',function(_0x453765) {
      _0x21edb5["classList"]['remove']("busy");
      var _0x205950;
      try {
        _0x205950=JSON['parse'](_0x453765);
      } catch(_0x4e35bf) {
        _0x5b20db('Host\x20error','error',_0x453765);
        return;
      }
      _0x205950["success"]?(_0x5b20db(_0x205950['removed']>0x0?"✓ Reverted "+_0x205950['prop']+" — removed "+_0x205950["removed"]+" baked keys":"Nothing to revert on "+_0x205950['prop'],"success"),_0x58c0e6()):_0x5b20db(_0x205950["error"]||"Revert failed",'error',_0x453765);
    });
  });
  var _0x385b6e="easeit_library",_0x1998c5="easeit_collections";
  function _0x15994f() {
    return'k'+Date["now"]()["toString"](0x24)+Math["floor"](Math["random"]()*0xf4240)['toString'](0x24);
  }
  function _0xb226d0() {
    var _0xd8b37a=null;
    try {
      _0xd8b37a=JSON['parse'](localStorage["getItem"](_0x1998c5));
    } catch(_0x5cbe66) {
    }
    if(!_0xd8b37a||!_0xd8b37a["items"]||!_0xd8b37a["items"]['length']) {
      var _0x2562a4=[];
      try {
        _0x2562a4=JSON['parse'](localStorage["getItem"](_0x385b6e))||[];
      } catch(_0x6b54bd) {
      }
      _0xd8b37a= {
        'active':"default",'items':[ {
          'id':"default",'name':"My Presets"
        }],'libs': {
          'default':_0x2562a4
        }
      },_0x426ba3(_0xd8b37a);
    }
    if(!_0xd8b37a["libs"])_0xd8b37a["libs"]= {
    };
    var _0x2b7fb1=![];
    for(var _0x59de7b=0x0;_0x59de7b<_0xd8b37a['items']['length'];_0x59de7b++) {
      if(_0xd8b37a["items"][_0x59de7b]['id']===_0xd8b37a["active"])_0x2b7fb1=!![];
    }
    if(!_0x2b7fb1)_0xd8b37a["active"]=_0xd8b37a["items"][0x0]['id'];
    return _0xd8b37a;
  }
  function _0x426ba3(_0x1334a2) {
    try {
      localStorage["setItem"](_0x1998c5,JSON["stringify"](_0x1334a2));
    } catch(_0x7040f3) {
    }
  }
  function _0x2a3e7b(_0x4e29ae,_0x4d78d4) {
    for(var _0x5c7ee7=0x0;_0x5c7ee7<_0x4e29ae["items"]['length'];_0x5c7ee7++) {
      if(_0x4e29ae["items"][_0x5c7ee7]['id']===_0x4d78d4)return _0x4e29ae["items"][_0x5c7ee7]['name'];
    }
    return "Presets";
  }
  function _0x4c74fa() {
    var _0x488083=_0xb226d0();
    return _0x488083["libs"][_0x488083["active"]]||[];
  }
  function _0x5c9031(_0x49c37b) {
    var _0xeca59a=_0xb226d0();
    _0xeca59a["libs"][_0xeca59a["active"]]=_0x49c37b,_0x426ba3(_0xeca59a);
  }
  function _0x12c31f() {
    _0x43b2f4( {
      'title':"New collection",'input':!![],'defaultValue':"Collection",'okText':"Create",'onOk':function(_0x2ef266) {
        _0x2ef266=(_0x2ef266||'')['replace'](/^\s+|\s+$/g,'');
        if(!_0x2ef266)return;
        var _0x5b8399=_0xb226d0(),_0x3f4c7c=_0x15994f();
        _0x5b8399["items"]["push"]( {
          'id':_0x3f4c7c,'name':_0x2ef266
        }),_0x5b8399['libs'][_0x3f4c7c]=[],_0x5b8399["active"]=_0x3f4c7c,_0x426ba3(_0x5b8399),_0x563a04(),_0x5dd9ba(),_0x5b20db("Created collection “"+_0x2ef266+'”',"success");
      }
    });
  }
  function _0xd8d1d0() {
    var _0x35a23f=_0xb226d0();
    _0x43b2f4( {
      'title':"Rename collection",'input':!![],'defaultValue':_0x2a3e7b(_0x35a23f,_0x35a23f["active"]),'okText':"Save",'onOk':function(_0x4835b6) {
        _0x4835b6=(_0x4835b6||'')["replace"](/^\s+|\s+$/g,'');
        if(!_0x4835b6)return;
        var _0x5a863a=_0xb226d0();
        for(var _0x4786f4=0x0;_0x4786f4<_0x5a863a["items"]["length"];_0x4786f4++) {
          if(_0x5a863a["items"][_0x4786f4]['id']===_0x5a863a["active"])_0x5a863a['items'][_0x4786f4]['name']=_0x4835b6;
        }
        _0x426ba3(_0x5a863a),_0x563a04();
      }
    });
  }
  function _0x21d371() {
    var _0x2a7e87=_0xb226d0();
    if(_0x2a7e87["items"]['length']<=0x1) {
      _0x5b20db("Can't delete the last collection");
      return;
    }
    var _0x356bee=_0x2a3e7b(_0x2a7e87,_0x2a7e87['active']);
    _0x43b2f4( {
      'title':"Delete “"+_0x356bee+'”?','wide':!![],'okText':'Delete','cancelText':"Cancel",'bodyHTML':"<p>This removes the collection and its saved presets. Built-in presets stay.</p>",'onOk':function() {
        var _0x595a3c=_0xb226d0(),_0x449a4c=_0x595a3c["active"],_0x24b0a4=[];
        for(var _0x4c786e=0x0;_0x4c786e<_0x595a3c["items"]["length"];_0x4c786e++) {
          if(_0x595a3c['items'][_0x4c786e]['id']!==_0x449a4c)_0x24b0a4["push"](_0x595a3c["items"][_0x4c786e]);
        }
        _0x595a3c['items']=_0x24b0a4,delete _0x595a3c["libs"][_0x449a4c],_0x595a3c["active"]=_0x595a3c["items"][0x0]['id'],_0x426ba3(_0x595a3c),_0x563a04(),_0x5dd9ba(),_0x5b20db('Deleted\x20“'+_0x356bee+'”','success');
      }
    });
  }
  function _0x588a84(_0x7dc29b) {
    var _0x40d74c=_0xb226d0();
    _0x40d74c['active']=_0x7dc29b,_0x426ba3(_0x40d74c),_0x563a04(),_0x5dd9ba();
  }
  function _0x563a04() {
    var _0x3cf67e=_0x5242a7("collectionDD");
    if(!_0x3cf67e)return;
    var _0x34e003=_0xb226d0(),_0x166f55=_0x3cf67e["querySelector"](".dd-label");
    if(_0x166f55)_0x166f55["textContent"]=_0x2a3e7b(_0x34e003,_0x34e003["active"]);
    var _0x4145ae=_0x3cf67e["querySelector"](".dd-menu");
    if(!_0x4145ae)return;
    _0x4145ae["innerHTML"]='',_0x34e003["items"]["forEach"](function(_0x5f1843) {
      var _0x33ca8d=document["createElement"]("div");
      _0x33ca8d["className"]="dd-item"+(_0x5f1843['id']===_0x34e003["active"]?'\x20active':'');
      var _0x2d17d2=document['createElement']("span");
      _0x2d17d2["textContent"]=_0x5f1843["name"],_0x33ca8d['appendChild'](_0x2d17d2),_0x33ca8d["addEventListener"]("click",function(_0x2caa6d) {
        _0x2caa6d['stopPropagation'](),_0x11ef0e(),_0x588a84(_0x5f1843['id']);
      }),_0x4145ae["appendChild"](_0x33ca8d);
    });
    var _0x497d57=document["createElement"]("div");
    _0x497d57["className"]='dd-item\x20dd-new',_0x497d57["textContent"]="＋ New collection",_0x497d57["addEventListener"]("click",function(_0x1242ba) {
      _0x1242ba['stopPropagation'](),_0x11ef0e(),_0x12c31f();
    }),_0x4145ae["appendChild"](_0x497d57);
  }
  function _0x3b7174() {
    var _0x4799ed=_0x5242a7('collectionDD');
    if(!_0x4799ed)return;
    _0x11ef0e(),_0x563a04(),_0x4799ed["classList"]["add"]("open"),_0x1dc239=_0x4799ed;
    var _0x1cb724=_0x4799ed["querySelector"](".dd-trigger"),_0x4077c5=_0x4799ed['querySelector'](".dd-menu"),_0x25fad6=_0x1cb724["getBoundingClientRect"]();
    _0x4077c5["style"]["left"]=_0x25fad6["left"]+'px',_0x4077c5["style"]['width']=Math["max"](_0x25fad6["width"],0x96)+'px';
    var _0x5d0d62=window["innerHeight"]-_0x25fad6["bottom"]-0xc,_0xb2a56e=_0x25fad6["top"]-0xc;
    _0xb2a56e>_0x5d0d62?(_0x4077c5['style']["top"]='auto',_0x4077c5["style"]['bottom']=window["innerHeight"]-_0x25fad6["top"]+0x4+'px',_0x4077c5['style']["maxHeight"]=Math["max"](0x6e,Math["min"](0x104,_0xb2a56e))+'px'):(_0x4077c5["style"]['bottom']="auto",_0x4077c5["style"]["top"]=_0x25fad6["bottom"]+0x4+'px',_0x4077c5["style"]["maxHeight"]=Math["max"](0x6e,Math["min"](0x104,_0x5d0d62))+'px');
  }
  function _0x33a44f() {
    var _0x30ad5d=_0x5242a7("collectionDD");
    if(_0x30ad5d) {
      var _0x4b613c=_0x30ad5d['querySelector'](".dd-trigger");
      if(_0x4b613c)_0x4b613c["addEventListener"]('click',function(_0x53d7a0) {
        _0x53d7a0["stopPropagation"]();
        if(_0x30ad5d['classList']['contains']("open"))_0x11ef0e();
        else _0x3b7174();
      });
    }
    var _0x61a167=_0x5242a7('collNew');
    if(_0x61a167)_0x61a167['addEventListener']("click",_0x12c31f);
    var _0x56ee00=_0x5242a7("collRename");
    if(_0x56ee00)_0x56ee00["addEventListener"]("click",_0xd8d1d0);
    var _0x4e3b8d=_0x5242a7("collDelete");
    if(_0x4e3b8d)_0x4e3b8d['addEventListener']("click",_0x21d371);
    _0x563a04();
  }
  function _0x424c40() {
    var _0x589be0=_0x5242a7("colSplitter"),_0x4aa0c5=document["querySelector"]('.col-left'),_0x577b30=document["querySelector"](".page");
    if(!_0x589be0||!_0x4aa0c5||!_0x577b30)return;
    try {
      var _0x57b931=localStorage["getItem"]('easeit_colwidth');
      _0x57b931&&(_0x4aa0c5["style"]['flexBasis']=_0x57b931,_0x4aa0c5["style"]['maxWidth']="none",_0x4aa0c5['style']["minWidth"]='0');
    } catch(_0x832256) {
    }
    _0x589be0["addEventListener"]("mousedown",function(_0x51b643) {
      if(window["innerWidth"]<0x0)return;
      _0x51b643["preventDefault"]();
      var _0x5aaa31=_0x51b643["clientX"],_0x4f3e25=_0x4aa0c5["getBoundingClientRect"]()['width'];
      _0x589be0['classList']["add"]('dragging'),document["body"]["classList"]['add']('col-resizing');
      function _0x1081c1(_0x46b4dc) {
        var _0x1bed84=_0x4f3e25+(_0x46b4dc['clientX']-_0x5aaa31),_0x27e971=_0x577b30["getBoundingClientRect"]()["width"]-0x8c;
        if(_0x1bed84<0x78)_0x1bed84=0x78;
        if(_0x1bed84>_0x27e971)_0x1bed84=_0x27e971;
        _0x4aa0c5["style"]["flexBasis"]=(_0x1bed84/_0x4aa0c5.parentElement.getBoundingClientRect().width*100)+'%',_0x4aa0c5["style"]["maxWidth"]="none",_0x4aa0c5['style']['minWidth']='0';
        try {
          _0x44028f();
        } catch(_0x4e78d2) {
        }
      }
      function _0x574f1e() {
        document["removeEventListener"]("mousemove",_0x1081c1),document["removeEventListener"]("mouseup",_0x574f1e),_0x589be0["classList"]["remove"]("dragging"),document["body"]["classList"]["remove"]('col-resizing');
        try {
          localStorage["setItem"]("easeit_colwidth",_0x4aa0c5['style']["flexBasis"]);
        } catch(_0x3c4934) {
        }
      }
      document['addEventListener']('mousemove',_0x1081c1),document["addEventListener"]("mouseup",_0x574f1e);
    });
  }
  function _0x173230(_0x19c72e) {
    return _0x19c72e['fn']?_0x2936e2[_0x19c72e['fn']]||_0x2eea7a([0x0,0x0,0x1,0x1]):_0x19c72e['nodes']?_0x53001a(_0x19c72e["nodes"]):_0x2eea7a(_0x19c72e['v']||[0x0,0x0,0x1,0x1]);
  }
  function _0x3cd180() {
    var _0x29fcc8=_0x224f56==='fn'?_0x21a197:_0x1f3ecf()||'My\x20Curve';
    _0x43b2f4( {
      'title':"Name this curve",'input':!![],'defaultValue':_0x29fcc8,'okText':'Save','onOk':function(_0x28ca05) {
        if(_0x28ca05===null)return;
        _0x28ca05=(_0x28ca05||'')["replace"](/^\s+|\s+$/g,'')||"Curve";
        var _0x41ba74=_0x224f56==='fn'? {
          'name':_0x28ca05,'fn':_0x80d606
        }
        :_0x252896["length"]!==0x2? {
          'name':_0x28ca05,'nodes':_0x4a34db(_0x252896)
        }
        : {
          'name':_0x28ca05,'v':_0x642cf1()
        },_0x2c0d39=_0x4c74fa();
        _0x2c0d39["push"](_0x41ba74),_0x5c9031(_0x2c0d39),_0x5dd9ba(),_0x5b20db("Saved “"+_0x28ca05+'”',"success");
        
      }
    });
  }
  _0x5242a7('saveBtn')["addEventListener"]("click",_0x3cd180),(function() {
    var _0x52ee0f=_0x5242a7("saveStar");
    if(_0x52ee0f)_0x52ee0f["addEventListener"]("click",_0x3cd180);
  }()),(function() {
    var _0x4b8d49=_0x5242a7("curveReadout");
    if(_0x4b8d49)_0x4b8d49['addEventListener']("click",_0x4e139e);
  }());
  
  
  
  
  
  
  
  
  function _0x52496c() {
    
    var _0x2dce44= {
      'type':"easeit-presets",'version':_0x11c271,'presets':_0x4c74fa(),'order':_0xd5950e(),'hidden':_0x1983cd()
    },_0x3547b3=JSON["stringify"](_0x2dce44,null,0x2);
    _0x5b20db("Exporting…"),_0x1b14ff["evalScript"]("easeit_exportPresets("+JSON['stringify'](_0x3547b3)+')',function(_0x584de8) {
      var _0x2b6f77;
      try {
        _0x2b6f77=JSON["parse"](_0x584de8);
      } catch(_0x3144b2) {
        _0x5b20db("Export failed","error",_0x584de8);
        return;
      }
      if(_0x2b6f77["success"])_0x5b20db("✓ Presets exported","success");
      else {
        if(!_0x2b6f77["canceled"])_0x5b20db(_0x2b6f77['error']||"Export failed","error",_0x584de8);
        else _0x5b20db("Export canceled");
      }
    });
  }
  function _0x4e9708() {
    
    _0x1b14ff["evalScript"]("easeit_importPresets()",function(_0x3739f5) {
      var _0x331a3b;
      try {
        _0x331a3b=JSON['parse'](_0x3739f5);
      } catch(_0x2b5911) {
        _0x5b20db("Import failed","error",_0x3739f5);
        return;
      }
      if(!_0x331a3b["success"]) {
        if(!_0x331a3b['canceled'])_0x5b20db(_0x331a3b['error']||"Import failed","error",_0x3739f5);
        else _0x5b20db("Import canceled");
        return;
      }
      var _0xa6dede;
      try {
        _0xa6dede=JSON["parse"](_0x331a3b["data"]);
      } catch(_0x4212ca) {
        _0x5b20db('Invalid\x20preset\x20file','error',String(_0x331a3b["data"])["slice"](0x0,0xf0));
        return;
      }
      var _0x54a55b=_0xa6dede&&_0xa6dede["presets"]?_0xa6dede["presets"]:Object["prototype"]["toString"]['call'](_0xa6dede)==="[object Array]"?_0xa6dede:[],_0x2bfa86=_0x4c74fa(),_0x4d13c5=0x0;
      for(var _0x276c59=0x0;_0x276c59<_0x54a55b["length"];_0x276c59++) {
        var _0x2a166a=_0x54a55b[_0x276c59];
        _0x2a166a&&_0x2a166a["name"]&&(_0x2a166a['v']||_0x2a166a["nodes"]||_0x2a166a['fn'])&&(_0x2bfa86["push"](_0x2a166a),_0x4d13c5++);
      }
      if(!_0x4d13c5) {
        _0x5b20db("No presets found in that file","error",String(_0x331a3b['data'])["slice"](0x0,0xf0));
        return;
      }
      _0x5c9031(_0x2bfa86),_0x5dd9ba(),_0x5b20db("✓ Imported "+_0x4d13c5+'\x20preset'+(_0x4d13c5===0x1?'':'s'),"success");
      
    });
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  function _0xf41bd9() {
    try {
      _0x5dd9ba();
    } catch(_0x2f826f) {
    }
  }
  (function() {
    try {
      var _ekApply=_0x3b1cae,_ekBusy=false;
      _0x3b1cae=function(_ekHex) {
        _ekApply(_ekHex);
        _ekBusy=true;
        try {
          if(window.EditKitAccent)window.EditKitAccent.set(_ekHex);
        } catch(_ekA) {
        }
        _ekBusy=false;
      };
      window.EaseItAccentAPI= {
        apply:function(_ekHex) {
          if(_ekBusy)return;
          _ekApply(_ekHex);
          try {
            _0xf41bd9();
          } catch(_ekB) {
          }
        },get:_0x5542ab
      };
    } catch(_ekC) {
    }
  })();
  
  (function() {
    try {
      var _ekHidBase="easeit_preset_hidden";
      function _ekHidKey() {
        try {
          var c=JSON.parse(localStorage.getItem("easeit_collections"));
          return _ekHidBase+":"+((c&&c.active)||"default");
        } catch(e) {
          return _ekHidBase+":default";
        }
      }
      try {
        var _ekOld=localStorage.getItem(_ekHidBase);
        if(_ekOld!==null&&localStorage.getItem(_ekHidBase+":migrated")===null) {
          var _ekC=null;
          try {
            _ekC=JSON.parse(localStorage.getItem("easeit_collections"));
          } catch(e1) {
          }
          var _ekA=(_ekC&&_ekC.active)||"default";
          if(localStorage.getItem(_ekHidBase+":"+_ekA)===null)localStorage.setItem(_ekHidBase+":"+_ekA,_ekOld);
          localStorage.setItem(_ekHidBase+":migrated","1");
        }
      } catch(e2) {
      }
      _0x1983cd=function() {
        try {
          return JSON.parse(localStorage.getItem(_ekHidKey()))||[];
        } catch(e3) {
          return [];
        }
      };
      _0x38e397=function(a) {
        try {
          localStorage.setItem(_ekHidKey(),JSON.stringify(a));
        } catch(e4) {
        }
      };
      var _ekEntries=_0x539f47;
      _0x539f47=function() {
        var list=_ekEntries(),placed= {
        },fresh=[],rest=[],i;
        try {
          _0x3b0ca2().forEach(function(k) {
            placed[k]=true;
          });
        } catch(e5) {
        }
        for(i=0;i<list.length;i++) {
          if(list[i]&&list[i].type==="custom"&&!placed[list[i].key])fresh.push(list[i]);
          else rest.push(list[i]);
        }
        fresh.reverse();
        return fresh.concat(rest);
      };
    } catch(_ekQ) {
    }
  })();
  
  (function() {
    try {
      window.EaseItCurve= {
        status:function(m,k,d) {
          try {
            _0x5b20db(m,k,d);
          } catch(e) {
          }
        },invert:function() {
          try {
            if(_0x224f56==="fn") {
              var f= {
                elasticIn:"elasticOut",elasticOut:"elasticIn",bounceIn:"bounceOut",bounceOut:"bounceIn"
              };
              var to=f[_0x80d606];
              if(!to)return "symmetric";
              var lb=String(_0x21a197||"");
              if(/(^|\s)In(\s|$)/.test(lb))lb=lb.replace(/(^|\s)In(\s|$)/,"$1Out$2");
              else if(/(^|\s)Out(\s|$)/.test(lb))lb=lb.replace(/(^|\s)Out(\s|$)/,"$1In$2");
              _0x5e3d71(to,lb);
              return "ok";
            }
            var src=_0x4a34db(_0x252896),out=[],i,n;
            if(!src||src.length<2)return "error";
            for(i=src.length-1;i>=0;i--) {
              n=src[i];
              out.push( {
                x:1-n.x,y:1-n.y,hl:n.hr?[1-n.hr[0],1-n.hr[1]]:null,hr:n.hl?[1-n.hl[0],1-n.hl[1]]:null
              });
            }
            _0x6040cd(out);
            return "ok";
          } catch(e2) {
            return "error";
          }
        }
      };
    } catch(_ekR) {
    }
  })();
  
  (function() {
    try {
      function _ekT(s,k) {
        try {
          return (window.EaseItText&&window.EaseItText.t)?window.EaseItText.t(s,k):s;
        } catch(e) {
          return s;
        }
      }
      var _ekModal=_0x43b2f4;
      _0x43b2f4=function(o) {
        try {
          if(o) {
            if(typeof o.title==="string")o.title=_ekT(o.title,"label");
            o.okText=_ekT(typeof o.okText==="string"?o.okText:"OK","label");
            o.cancelText=_ekT(typeof o.cancelText==="string"?o.cancelText:"Cancel","label");
            if(typeof o.bodyHTML==="string")o.bodyHTML=_ekT(o.bodyHTML,"html");
            if(typeof o.defaultValue==="string")o.defaultValue=_ekT(o.defaultValue,"label");
          }
        } catch(e1) {
        }
        return _ekModal(o);
      };
      var _ekStat=_0x5b20db;
      _0x5b20db=function(m,k,d) {
        return _ekStat(typeof m==="string"?_ekT(m,"status"):m,k,d);
      };
      
    } catch(_ekS) {
    }
  })();
  
  (function() {
    try {
      window.EaseItLibrary= {
        refresh:function() {
          try {
            _0xf41bd9();
          } catch(e1) {
          }
          try {
            _0x563a04();
          } catch(e2) {
          }
        },selectCollection:function(id) {
          try {
            _0x588a84(id);
          } catch(e3) {
          }
        },newCollection:function() {
          try {
            _0x12c31f();
          } catch(e4) {
          }
        },renameCollection:function() {
          try {
            _0xd8d1d0();
          } catch(e5) {
          }
        },deleteCollection:function() {
          try {
            _0x21d371();
          } catch(e6) {
          }
        },setCurve:function(v) {
          try {
            _0x225be0(v);
          } catch(e7) {
          }
        },modal:function(o) {
          try {
            _0x43b2f4(o);
          } catch(e8) {
          }
        }
      };
    } catch(_ekT) {
    }
  })();
  
  (function() {
    try {
      var _ekNearestWins=true;
      document.addEventListener("dblclick",function(ev) {
        try {
          if(!_ekNearestWins)return;
          if(ev.target!==_0x3d648f)return;
          if(_0x224f56!=="bezier")return;
          var pt=_0x1b4ae0(ev),list=_0x157c4c();
          var bestA=-1,dA=1e9,dH=1e9,i,d;
          for(i=0;i<list.length;i++) {
            d=Math.sqrt(Math.pow(pt.x-list[i].p.x,2)+Math.pow(pt.y-list[i].p.y,2));
            if(list[i].kind==="a") {
              if(d<dA) {
                dA=d;
                bestA=list[i].i;
              }
            } else if(d<dH)dH=d;
          }
          if(bestA<0||dA>=12)return;
          if(dH<dA)return;
          _0x252896.splice(bestA,1);
          _0x1a6195(true);
          try {
            _0x5b20db("Point removed");
          } catch(e1) {
          }
          ev.stopPropagation();
          ev.preventDefault();
        } catch(e2) {
        }
      },true);
    } catch(_ekU) {
    }
  })();
  
  
  
  
  
  
  
  
  function _0x1bc952() {
    window["onerror"]=function(_0x1a3b98,_0x20510c,_0x58b5af,_0x84485f,_0x243d0f) {
      var _0x1edd0b=_0x1a3b98+"  @"+(_0x58b5af||'?')+':'+(_0x84485f||'?')+(_0x243d0f&&_0x243d0f['stack']?'\x0a'+_0x243d0f["stack"]:'');
      try {
        _0x5b20db(String(_0x1a3b98),'error',_0x1edd0b);
      } catch(_0x382790) {
      }
      return![];
    },_0x209f4c(),_0x3b1cae(_0x5542ab());
    try {
      var _0x3e4fd5=Number(localStorage['getItem'](_0x10c201));
      if(_0x3e4fd5>=0x1&&_0x3e4fd5<=0x6)_0x2277f0=_0x3e4fd5;
    } catch(_0x37fd76) {
    }
    try {
      _0x1b14ff["addEventListener"]("com.adobe.csxs.events.ThemeColorChanged",_0x209f4c);
    } catch(_0xef0224) {
    }
    var _0x1ac82a='';
    try {
      _0x1ac82a=_0x1b14ff["getHostEnvironment"]()["appName"];
    } catch(_0x1c82ec) {
    }
    _0x2f7987=_0x1ac82a==="AEFT";
    if(_0x2f7987) {
      var _0x2609f6=_0x5242a7("applySection");
      if(_0x2609f6)_0x2609f6['style']["display"]='none';
      var _0x519f63=_0x5242a7("revertBtn");
      if(_0x519f63)_0x519f63["style"]["display"]="none";
    } else {
      document["body"]["classList"]["add"]("host-ppro");
      /* En Premiere este bloque se consulta todo el tiempo. Se muda delante
         de los presets para que ambos vivan en el mismo desplazamiento y el
         CSS lo mantiene visible mientras se recorre la biblioteca. */
      var _0xapplyPanel=_0x5242a7("applySection");
      var _0xpresetsPanel=_0x5242a7("presetsSection");
      var _0xrightColumn=document["querySelector"](".col-right");
      /* panel-settings puede haber movido ya la biblioteca debajo de la curva.
         insertBefore exige que el segundo nodo siga siendo hijo de esta
         columna; si no, lanza y corta todo el arranque de EaseIt. */
      if(_0xapplyPanel&&_0xpresetsPanel&&_0xrightColumn&&_0xpresetsPanel["parentNode"]===_0xrightColumn) {
        _0xrightColumn["insertBefore"](_0xapplyPanel,_0xpresetsPanel);
      } else if(_0xapplyPanel&&_0xpresetsPanel&&_0xpresetsPanel["parentNode"]) {
        /* En la disposición inferior ambos pertenecen a la columna izquierda.
           Aplicar a va inmediatamente antes de la biblioteca. */
        _0xpresetsPanel["parentNode"]["insertBefore"](_0xapplyPanel,_0xpresetsPanel);
      }
      var _0x3d762e=_0x5242a7("eachPairRow");
      if(_0x3d762e)_0x3d762e["style"]["display"]="none";
    }
    _0x431770(),_0x3b12c5(),_0x39f798(),_0x58e056('boot', {
      'version':_0x11c271,'host':_0x1ac82a
    }),_0x4f1610();
    
    _0x44028f(),_0x424c40(),_0x5b542e(),_0x33a44f(),_0x52cbdd(),_0x34c692(),_0x565df2();
    try {
      _0x4c9d57=localStorage["getItem"](_0x732471)!=='0';
    } catch(_0x26ea3a) {
    }
    _0x5516f1(_0x4c9d57),cancelAnimationFrame(_0x2961f5),_0x2961f5=requestAnimationFrame(_0x14d81b),_0x58c0e6();
    var _0x597bb2=_0x5242a7('helpBtn');
    if(_0x597bb2)_0x597bb2["addEventListener"]("click",_0x428ebf);
    
    
    window["addEventListener"]("focus",function() {
      _0x58c0e6();
    }),document['addEventListener']("visibilitychange",function() {
      if(!document["hidden"])_0x58c0e6();
    }),window['addEventListener']('resize',_0x44028f),window["addEventListener"]("resize",_0x52cbdd);
    try {
      new ResizeObserver(_0x52cbdd)["observe"](_0x5242a7('content')||document["body"]);
    } catch(_0x4c334b) {
    }
    _0x5c2a1b=!![];
    
    
  }
  _0x1bc952();
}()));
