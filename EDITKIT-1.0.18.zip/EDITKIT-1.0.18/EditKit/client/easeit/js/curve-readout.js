/*
 * curve-readout.js — swaps the bezier readout ("0.25, 0.10, 0.25, 1.00") for a
 * pencil icon when the control pill gets too narrow to show it.
 *
 * Why measure instead of a media query: the readout sits in .col-left, whose
 * width is set by EaseIt's own internal splitter, not by the panel width — so
 * a viewport breakpoint would fire at the wrong moments. Instead the text is
 * measured in its normal state (.compact off) and the icon is used only when
 * the text really would be clipped. Measuring always happens with .compact
 * removed, so the two states can't oscillate.
 *
 * The readout element itself is never replaced or re-parented: index.js keeps
 * its click handler ("edit points") and keeps writing the numbers into it. In
 * icon mode the numbers move into the tooltip so they stay reachable.
 */
(function () {
  "use strict";

  var readout = document.getElementById("curveReadout");
  if (!readout) return;
  var pill = readout.parentNode;
  if (!pill || !pill.classList || !pill.classList.contains("control-pill")) return;

  var row = pill.parentNode;
  var settingTip = false;
  var queued = null;

  function baseTip() {
    var key = readout.getAttribute("data-i18n-tip");
    if (key && window.EditKitI18n && window.EditKitI18n.t) return window.EditKitI18n.t(key);
    return readout.getAttribute("data-tip") || "";
  }

  function syncTip(compact) {
    var base = baseTip();
    var values = (readout.textContent || "").replace(/^\s+|\s+$/g, "");
    var text = compact && values ? values + " · " + base : base;
    if (readout.getAttribute("data-tip") === text) return;
    settingTip = true;
    readout.setAttribute("data-tip", text);
    settingTip = false;
  }

  function refresh() {
    queued = null;
    // Always decide from the roomiest state, never from an already-shrunk one,
    // so the two decisions below can't feed on their own output and oscillate.
    pill.classList.remove("compact");
    if (row && row.classList) row.classList.remove("tight");

    // 1. the four bezier numbers give way to the pencil icon
    var clipped = readout.scrollWidth > readout.clientWidth + 1;
    if (clipped) pill.classList.add("compact");
    syncTip(clipped);

    // 2. and if even then the pill can't hold its buttons, APPLY drops its
    //    word and keeps just the tick. The row stays on one line either way —
    //    this is what buys the pill the ~60px it needs at the narrowest column
    //    the splitter allows, instead of letting the icons spill or clip.
    if (row && row.classList && pill.scrollWidth > pill.clientWidth + 1) {
      row.classList.add("tight");
    }
  }

  /* Trailing debounce, deliberately not a "first one wins" guard. A splitter
     drag fires a burst of width changes and the guard version dropped every
     event after the first — so the measurement came from a half-way-through
     width and the readout stayed one drag behind, visibly stuck on the icon
     while the column was already wide. Resetting the timer on every event means
     the width that gets measured is always the one the drag ended on. */
  function schedule() {
    if (queued) clearTimeout(queued);
    queued = setTimeout(refresh, 60);
  }

  // The pill changes width from three directions: the panel resizing, the user
  // dragging EaseIt's internal column splitter (which writes an inline
  // flex-basis on .col-left), and index.js rewriting the numbers themselves.
  //
  // ResizeObserver would be the obvious hook for the first two, but it never
  // fires inside the CEP webview this panel runs in — the splitter drag was
  // measured going 289px -> 139px without a single callback. So the splitter is
  // tracked by watching the inline style it writes, which does fire, and a
  // document-level mouseup catches any drag that ends somewhere unexpected.
  // ResizeObserver is still attached when present, as a bonus, never as the
  // only signal. Observers are kept on a list so they can't be collected.
  var observers = [];

  window.addEventListener("resize", schedule);
  document.addEventListener("mouseup", schedule, true);

  var colLeft = document.querySelector(".col-left");
  if (colLeft && window.MutationObserver) {
    var colObs = new MutationObserver(schedule);
    colObs.observe(colLeft, { attributes: true, attributeFilter: ["style", "class"] });
    observers.push(colObs);
  }

  if (window.ResizeObserver) {
    var ro = new ResizeObserver(schedule);
    ro.observe(pill);
    observers.push(ro);
  }

  if (window.MutationObserver) {
    var textObs = new MutationObserver(function (records) {
      for (var i = 0; i < records.length; i++) {
        // ignore the data-tip write we just made ourselves
        if (records[i].type === "attributes" && settingTip) continue;
        schedule();
        return;
      }
    });
    textObs.observe(readout, { childList: true, characterData: true, subtree: true, attributes: true, attributeFilter: ["data-tip"] });
    observers.push(textObs);
  }

  schedule();
  window.addEventListener("load", schedule);
})();
