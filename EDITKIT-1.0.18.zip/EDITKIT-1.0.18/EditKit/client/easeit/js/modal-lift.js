/* ============================================================================
   EASEIT — LOS MODALES, SOBRE EDITKIT ENTERO

   EaseIt abre sus ventanas —ajustes, ayuda, guardar un preset, avisos— con
   posicion fija dentro de su propio <iframe>. "Fija" ahi dentro es fija dentro
   de EaseIt, no dentro del plugin: en un panel estrecho el modal salia
   aplastado, con cada frase en cinco lineas, mientras a su lado sobraba sitio.

   La solucion es la de shell/js/sheet-lift.js: mientras haya un modal abierto,
   el shell estira este marco hasta cubrir EditKit entero, cabecera incluida.

   Se hace mirando el documento y no llamando desde cada sitio a proposito. La
   mayoria de estos modales los construye el nucleo de EaseIt, que es codigo
   compilado y no se toca; y los que no, son cuatro archivos distintos que
   tendrian que acordarse de pedirlo y de devolverlo. Una sola regla —hay
   .modal-overlay en el documento o no lo hay— los cubre a todos, incluidos los
   que se anadan despues.

   Solo observa. No abre, no cierra y no cambia una sola linea de lo que hacen.
   ============================================================================ */
(function () {
    "use strict";

    var L = window.EditKitLift;
    if (!L || !L.available) return;     // suelto: no hay a quien pedirselo

    if (!window.MutationObserver) return;

    function anyOpen() {
        return !!document.querySelector(".modal-overlay");
    }

    /* El modal se va con un fundido de 180 ms y se quita del documento al
       terminar, asi que "ya no hay ninguno" llega cuando de verdad no queda
       nada que ensenar. No hace falta esperar mas. */
    function sync() {
        if (anyOpen()) L.on();
        else L.off();
    }

    var mo = new MutationObserver(function () { sync(); });
    mo.observe(document.body, { childList: true, subtree: false });

    /* Algun modal cuelga de #wrapper y no del body. Mirar el arbol entero por
       cada nodo que se mueve seria caro en un panel que repinta la curva a 60
       por segundo, asi que se observan los dos sitios donde de verdad se
       cuelgan, sin subarbol. */
    var wrap = document.getElementById("wrapper");
    if (wrap) mo.observe(wrap, { childList: true, subtree: false });

    sync();
})();
