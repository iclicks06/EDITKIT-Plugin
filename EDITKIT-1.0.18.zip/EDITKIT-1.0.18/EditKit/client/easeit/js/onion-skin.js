/* ============================================================================
   EASEIT — PAPEL CEBOLLA

   La última curva aplicada queda dibujada detrás, tenue, mientras se edita la
   siguiente. Es lo que hace un animador con el papel de calcar: ver la versión
   anterior debajo para saber cuánto se ha movido la nueva. Sin esto, afinar una
   curva es aplicar, deshacer, comparar de memoria y volver a empezar.

   ── COMO SE DIBUJA ─────────────────────────────────────────────────────────
   El gráfico lo pinta el núcleo de EaseIt, que viene compilado, y lo pinta con
   sus propias cuentas: el margen, el zoom, hacia dónde crece el eje. Repetir
   esas cuentas aquí sería tener dos versiones de la misma regla esperando a
   separarse — la primera vez que alguien tocara el zoom, la curva de fondo
   dejaría de coincidir con la de delante.

   Así que no se repiten. El núcleo llama a `window.EaseItOnion` en mitad de su
   dibujo, justo después de la diagonal de referencia y antes de la curva de
   velocidad y la curva principal, y le presta sus tres herramientas: el
   lienzo, la función que pasa un tiempo a píxeles horizontales y la que pasa un
   valor a píxeles verticales. La curva de fondo sale con las mismas cuentas que
   la de delante, zoom incluido, y queda por debajo de ella.

   ── COMO SE GUARDA ─────────────────────────────────────────────────────────
   El núcleo también presta la función que evalúa la curva de ahora, sea de
   puntos o de fórmula. Al aplicar se muestrea en 121 puntos —los mismos que usa
   el núcleo para dibujar la suya— y eso es lo que se guarda. Muestras y no
   puntos de control: así da igual que la curva fuera un bézier, un camino de
   varios tramos o una fórmula como un rebote, que no tiene puntos que guardar.

   Se guarda SOLO si After Effects contesta que la aplicó. Si no había
   keyframes seleccionados, la curva de fondo no cambia: el papel cebolla es la
   última curva aplicada, no la última que se intentó aplicar.

   Y se queda en el almacenamiento, así que sigue ahí al volver a abrir el panel
   mañana.
   ============================================================================ */
(function () {
    "use strict";

    var KEY = "easeit_onion";       // las muestras de la última curva aplicada
    var OFF = "easeit_onion_off";   // "1" si el usuario lo apagó
    var ALPHA = "easeit_onion_alpha"; // opacidad elegida, de 5 a 80 (por ciento)
    var ALPHA_DEF = 30, ALPHA_MIN = 5, ALPHA_MAX = 80;
    var N = 120;                    // 121 muestras, como la curva del núcleo

    var live = null;                // la función de la curva de ahora
    var shown = load();

    function load() {
        try {
            var a = JSON.parse(localStorage.getItem(KEY) || "null");
            return (a && a.length === N + 1) ? a : null;
        } catch (e) { return null; }
    }

    function clampAlpha(v) {
        v = Math.round(Number(v));
        if (!isFinite(v)) return ALPHA_DEF;
        return Math.max(ALPHA_MIN, Math.min(ALPHA_MAX, v));
    }
    function alpha() {
        try {
            var v = localStorage.getItem(ALPHA);
            return v === null ? ALPHA_DEF : clampAlpha(v);
        } catch (e) { return ALPHA_DEF; }
    }

    function enabled() {
        try { return localStorage.getItem(OFF) !== "1"; } catch (e) { return true; }
    }

    /* El color del acento, leído en cada dibujo: el acento puede cambiar con el
       panel abierto, y esta curva tiene que cambiar con él. */
    function accent() {
        var v = "";
        try { v = getComputedStyle(document.documentElement).getPropertyValue("--accent"); } catch (e) {}
        v = String(v || "").replace(/^\s+|\s+$/g, "");
        return v || "#49c9bd";
    }

    function sample() {
        if (typeof live !== "function") return null;
        var out = [], i, y;
        for (i = 0; i <= N; i++) {
            y = live(i / N);
            if (typeof y !== "number" || !isFinite(y)) return null;
            // Cuatro decimales: a 300 px de alto, la diferencia no llega a un
            // píxel, y el almacenamiento guarda la tercera parte.
            out.push(Math.round(y * 10000) / 10000);
        }
        return out;
    }

    /* ------------------------------------------------------------------
       Lo llama el núcleo, en mitad de su dibujo
       ------------------------------------------------------------------ */
    window.EaseItOnion = function (ctx, X, Y, F) {
        live = F;
        if (!shown || !enabled() || !ctx || typeof X !== "function" || typeof Y !== "function") return;

        /* save/restore alrededor de todo: el núcleo sigue dibujando detrás de
           esto con el lienzo tal como lo dejó, y un grosor o una opacidad que
           se quedaran puestos se le colarían en la curva principal. */
        ctx.save();
        try {
            ctx.globalAlpha = alpha() / 100;
            ctx.strokeStyle = accent();
            ctx.lineWidth = 2;
            ctx.lineJoin = "round";
            ctx.lineCap = "round";
            if (ctx.setLineDash) ctx.setLineDash([]);
            ctx.beginPath();
            for (var i = 0; i <= N; i++) {
                var px = X(i / N), py = Y(shown[i]);
                if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
            }
            ctx.stroke();
        } catch (e) {}
        ctx.restore();
    };

    /* ------------------------------------------------------------------
       Al aplicar
       ------------------------------------------------------------------ */
    /* Se engancha en la única puerta por la que el panel habla con el
       programa. Se toma la muestra ANTES de llamar —es la curva que se está
       aplicando— y se guarda en la respuesta, si fue bien. */
    if (window.CSInterface && CSInterface.prototype && CSInterface.prototype.evalScript) {
        var MARK = "__easeit_onion_wrapped";
        if (!CSInterface.prototype[MARK]) {
            CSInterface.prototype[MARK] = true;
            var orig = CSInterface.prototype.evalScript;
            CSInterface.prototype.evalScript = function (script, cb) {
                if (typeof script !== "string" || script.indexOf("easeit_applyEasing(") !== 0) {
                    return orig.call(this, script, cb);
                }
                var taken = null;
                try { taken = sample(); } catch (e) { taken = null; }
                return orig.call(this, script, function (res) {
                    try {
                        var r = JSON.parse(res);
                        if (taken && r && r.success === true) {
                            shown = taken;
                            try { localStorage.setItem(KEY, JSON.stringify(taken)); } catch (e2) {}
                        }
                    } catch (e3) {}
                    if (typeof cb === "function") cb(res);
                });
            };
        }
    }

    /* La puerta para el ajuste. Al encenderlo o apagarlo se pide un
       redibujado: el núcleo repinta el gráfico cuando cambia el tamaño de la
       ventana, y es la única señal suya a la que se puede llamar desde fuera. */
    /* El deslizador manda muchos cambios por segundo: se redibuja una vez por
       fotograma como mucho. */
    var redrawQueued = false;
    function redraw() {
        if (redrawQueued) return;
        redrawQueued = true;
        (window.requestAnimationFrame || setTimeout)(function () {
            redrawQueued = false;
            try { window.dispatchEvent(new Event("resize")); } catch (e) {}
        });
    }

    window.EaseItOnionSettings = {
        isOn: enabled,
        alpha: alpha,
        min: ALPHA_MIN,
        max: ALPHA_MAX,
        setAlpha: function (v) {
            try { localStorage.setItem(ALPHA, String(clampAlpha(v))); } catch (e) {}
            redraw();
        },
        set: function (on) {
            try {
                if (on) localStorage.removeItem(OFF);
                else localStorage.setItem(OFF, "1");
            } catch (e) {}
            try { window.dispatchEvent(new Event("resize")); } catch (e2) {}
        }
    };
})();
