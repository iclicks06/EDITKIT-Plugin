/* ============================================================================
   EASEIT — SECRETO: LAS LETRAS QUE REBOTAN

   Cinco toques seguidos sobre el título "EaseIt" y las seis letras se van y
   vuelven, cada una con una curva distinta de las que trae el panel. Debajo
   se va leyendo el nombre de la curva que le toca a cada letra, según
   aterrizan. Es un chiste con fondo: no hay forma más corta de ver, una
   detrás de otra, la diferencia entre un ease out y un back out.

   El título no hace nada más en toda la interfaz, así que el gesto no le quita
   el sitio a ninguna función ni puede dispararse por accidente al trabajar.

   El archivo también lleva la cuenta de las curvas aplicadas, para la bitácora
   del shell. Se cuenta enganchando evalScript en vez de tocar el núcleo: es la
   única puerta por la que el panel habla con la aplicación, así que ahí pasan
   todas, vengan de un preset, del editor o de un atajo.
   ============================================================================ */
(function () {
    "use strict";

    var log = window.EditKitLog;

    // ------------------------------------------------------------------
    // Contador de curvas aplicadas
    // ------------------------------------------------------------------
    if (log && window.CSInterface && CSInterface.prototype && CSInterface.prototype.evalScript) {
        var MARK = "__editkit_log_wrapped";
        if (!CSInterface.prototype[MARK]) {
            CSInterface.prototype[MARK] = true;
            var orig = CSInterface.prototype.evalScript;
            CSInterface.prototype.evalScript = function (script, cb) {
                try {
                    // Solo la llamada que aplica de verdad. revert y read pasan
                    // por aquí también y no son curvas nuevas.
                    if (typeof script === "string" && script.indexOf("easeit_applyEasing(") === 0) {
                        log.bump("curves");
                    }
                } catch (e) {}
                return orig.call(this, script, cb);
            };
        }
    }

    // ------------------------------------------------------------------
    // El secreto
    // ------------------------------------------------------------------
    var h1 = document.querySelector(".title-row h1");
    if (!h1) return;

    /* Curvas reales del panel, con su nombre, y puestas en un orden que las
       contrasta: detrás de una salida suave viene una entrada dura, y el back
       out (el único que se pasa de largo y vuelve) cae pronto, cuando todavía
       se está mirando. */
    var CURVES = [
        ["Ease Out",   "cubic-bezier(.16,1,.3,1)"],
        ["Quint In",   "cubic-bezier(.64,0,.78,0)"],
        ["Back Out",   "cubic-bezier(.34,1.56,.64,1)"],
        ["Expo Out",   "cubic-bezier(.19,1,.22,1)"],
        ["Snappy",     "cubic-bezier(.87,0,.13,1)"],
        ["Circ Out",   "cubic-bezier(0,.55,.45,1)"],
        ["Quart InOut","cubic-bezier(.76,0,.24,1)"],
        ["Ease InOut", "cubic-bezier(.65,0,.35,1)"]
    ];

    var running = false;
    var text = h1.textContent;

    function play() {
        if (running) return;
        running = true;
        if (log) log.found("h8");

        var letters = text.split("");
        h1.textContent = "";
        h1.classList.add("egg-letters");

        /* Un solo rótulo para todas, y no uno por letra: el nombre más corto de
           la lista mide 22px y la letra más ancha del título, 7px, así que seis
           nombres uno al lado del otro se pisan hasta ser ilegibles. Puesto en
           el mismo sitio y cambiando al ritmo de las letras se lee entero y
           además empareja cada nombre con el movimiento que acaba de verse.
           Va en position:absolute para que aparecer no mueva el título. */
        var cap = document.createElement("div");
        cap.className = "egg-caption";
        h1.parentNode.appendChild(cap);

        var STEP = 260;   // separación entre letras: lo justo para leer un nombre

        letters.forEach(function (ch, i) {
            var pick = CURVES[i % CURVES.length];
            var span = document.createElement("span");
            span.className = "egg-letter";
            span.textContent = ch;
            span.style.transitionTimingFunction = pick[1];
            span.style.transitionDelay = (i * STEP) + "ms";
            h1.appendChild(span);

            // Un cuadro después, para que el navegador tenga un estado inicial
            // desde el que animar; sin esto la transición no arranca.
            requestAnimationFrame(function () {
                requestAnimationFrame(function () { span.classList.add("in"); });
            });

            setTimeout(function () {
                cap.textContent = pick[0];
                cap.classList.add("in");
            }, i * STEP + 60);
        });

        var total = STEP * letters.length + 900;
        setTimeout(function () { cap.classList.remove("in"); }, total);
        setTimeout(function () {
            if (cap.parentNode) cap.parentNode.removeChild(cap);
            h1.classList.remove("egg-letters");
            h1.textContent = text;
            running = false;
        }, total + 400);
    }

    // ------------------------------------------------------------------
    // SECRETO: LOS OTROS SUBTITULOS
    // ------------------------------------------------------------------
    /* Tres clics en "curvas de easing" y el subtitulo se pone a decir otras
       cosas, una cada segundo, antes de volver a lo que decia. El subtitulo
       no hace nada mas en todo el panel, y al cambiar de idioma se reescribe
       solo, asi que el secreto no puede dejarlo mal por accidente. */
    (function () {
        var by = document.querySelector("#header .by");
        if (!by) return;

        var lang = "es";
        try { lang = localStorage.getItem("editkit_lang") || "es"; } catch (e) {}

        var LINES = (lang === "en") ? [
            "the shape of the wait",
            "thirty seconds you get back",
            "linear is a decision too",
            "someone drew this by hand"
        ] : [
            "la forma de la espera",
            "treinta segundos que se recuperan",
            "lineal tambien es una decision",
            "esto lo dibujo alguien a mano"
        ];

        var running = false, taps2 = 0, last2 = 0;

        by.addEventListener("click", function () {
            var now = Date.now();
            taps2 = (now - last2 < 600) ? taps2 + 1 : 1;
            last2 = now;
            if (taps2 < 3 || running) return;
            taps2 = 0;
            running = true;
            if (log) log.found("w0");

            var original = by.textContent, i = 0;
            by.style.transition = "opacity .2s ease";

            function step() {
                by.style.opacity = "0";
                setTimeout(function () {
                    by.textContent = (i < LINES.length) ? LINES[i] : original;
                    by.style.opacity = "";
                    i++;
                    if (i <= LINES.length) setTimeout(step, 1100);
                    else { by.style.transition = ""; running = false; }
                }, 200);
            }
            step();
        });
    })();

    var taps = 0, last = 0;
    h1.addEventListener("click", function () {
        try {
            var sel = window.getSelection();
            if (sel && sel.removeAllRanges) sel.removeAllRanges();
        } catch (e) {}
        var now = Date.now();
        taps = (now - last < 600) ? taps + 1 : 1;
        last = now;
        if (taps < 5) return;
        taps = 0;
        play();
    });
})();
