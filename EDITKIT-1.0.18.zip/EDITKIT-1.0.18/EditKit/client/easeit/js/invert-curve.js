/*
 * invert-curve.js — wires the ⇄ button in the control pill to EaseIt's
 * "invert the current curve" operation.
 *
 * The maths lives inside index.js (window.EaseItCurve.invert), because it has
 * to drive EaseIt's own setters so the graph, the readout, the preview and
 * auto-apply all update the way they do when a preset is loaded. This file
 * only owns the button and the message that comes back.
 */
(function () {
  "use strict";

  var btn = document.getElementById("invertBtn");
  if (!btn) return;

  function t(key, fallback) {
    var s = window.EditKitI18n && window.EditKitI18n.t ? window.EditKitI18n.t(key) : null;
    return (s && s !== key) ? s : fallback;
  }

  function say(msg, kind) {
    if (window.EaseItCurve && window.EaseItCurve.status) window.EaseItCurve.status(msg, kind);
  }

  btn.addEventListener("click", function () {
    if (!window.EaseItCurve || !window.EaseItCurve.invert) return;

    switch (window.EaseItCurve.invert()) {
      case "ok":
        say(t("easeit.inverted", "Curva invertida"), "success");
        break;
      case "symmetric":
        // Elastic/Bounce InOut are their own reverse — say so instead of
        // pretending something changed.
        say(t("easeit.invertSymmetric", "Esta curva ya es simétrica — invertirla la deja igual"));
        break;
      default:
        say(t("easeit.invertFailed", "No se pudo invertir la curva"), "error");
    }
  });
})();
