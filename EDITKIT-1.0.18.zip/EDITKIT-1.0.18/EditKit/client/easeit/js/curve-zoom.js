/* ============================================================================
   EASEIT — CONTROL + RUEDA SOBRE LA CURVA

   Acercar y alejar la vista del grafico ya se podia: dos botones en la esquina.
   Lo que no se podia era hacerlo con la mano que ya esta encima del grafico, y
   ahora que esos botones solo aparecen al pasar por encima, hacia falta.

   Lo hace pulsando los mismos dos botones que pulsaria el usuario, no tocando
   el zoom por dentro. Es a proposito: el zoom vive en el nucleo del panel, con
   sus limites y su redibujado, y duplicar esa cuenta aqui seria tener dos
   versiones de la misma regla esperando a separarse. Asi, si el zoom cambia,
   esto sigue funcionando sin enterarse.

   Tres detalles que no son obvios:

     - Sin Control, la rueda no hace nada aqui. El panel entero tiene una barra
       de desplazamiento y quitarsela encima del grafico seria peor que no tener
       zoom: el usuario baja la rueda esperando ver lo que hay debajo y el panel
       se queda clavado.

     - La rueda no da pasos iguales. Un raton suelta 100 o 120 de golpe; un
       trackpad suelta dos o tres por cada milimetro de dedo. Si cada evento
       fuera un clic, el trackpad daria cuarenta saltos de zoom en un gesto. Se
       acumula el recorrido y solo al pasar de un umbral se da un paso.

     - Tambien se atiende a Comando en Mac, que es donde vive ese gesto alli.
   ============================================================================ */
(function () {
    "use strict";

    // Cuanto recorrido de rueda vale un paso de zoom. Con 100 justos, un clic
    // de raton es un paso, que es lo que espera la mano.
    var STEP = 100;
    // Un trackpad puede soltar cientos en un gesto largo; mas de esto de golpe
    // es el usuario pidiendo tres pasos, no treinta.
    var MAX_STEPS = 3;

    var acc = 0;

    function ready(fn) {
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", fn);
        } else {
            fn();
        }
    }

    ready(function () {
        var box = document.querySelector(".graph-box");
        if (!box) return;

        box.addEventListener("wheel", function (e) {
            if (!e.ctrlKey && !e.metaKey) return;

            /* El gesto es nuestro a partir de aqui: sin esto, Chromium se lleva
               Control + rueda para ampliar la pagina entera y deja el panel con
               la letra el doble de grande y sin manera evidente de volver. */
            e.preventDefault();
            e.stopPropagation();

            var d = e.deltaY;
            if (!d) return;
            // deltaMode 1 son lineas y 2 paginas; normalizarlo a pixeles deja
            // el umbral valiendo lo mismo en los tres casos.
            if (e.deltaMode === 1) d *= 16;
            else if (e.deltaMode === 2) d *= 400;

            // Un cambio de sentido empieza de cero: lo que sobraba de bajar no
            // cuenta para subir.
            if ((d > 0) !== (acc > 0)) acc = 0;
            acc += d;

            var steps = Math.floor(Math.abs(acc) / STEP);
            if (!steps) return;
            if (steps > MAX_STEPS) steps = MAX_STEPS;
            acc -= (acc > 0 ? 1 : -1) * steps * STEP;

            // Rueda hacia arriba —delta negativo— acerca, que es el sentido que
            // usan After Effects, el navegador y practicamente todo lo demas.
            var btn = document.getElementById(d < 0 ? "tbZoomIn" : "tbZoomOut");
            if (!btn) return;
            for (var i = 0; i < steps; i++) btn.click();
        }, { passive: false });
    });
})();
