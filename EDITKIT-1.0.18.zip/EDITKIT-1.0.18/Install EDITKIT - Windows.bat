@echo off
setlocal EnableExtensions DisableDelayedExpansion
title EDITKIT Installer

set "SOURCE=%~dp0EditKit"
set "EXTENSIONS=%APPDATA%\Adobe\CEP\extensions"
set "DEST=%EXTENSIONS%\EditKit"
set "WORKROOT=%TEMP%\EditKitInstaller-%RANDOM%-%RANDOM%"
set "STAGE=%WORKROOT%\EditKit"
set "BACKUP=%WORKROOT%\Previous"
set "LOG=%TEMP%\EditKit-install.log"

echo.
echo EDITKIT Installer / Instalador de EDITKIT
echo =========================================
echo.

rem Support both layouts used by common extractors:
rem   1. Install EditKit.bat next to the EditKit folder.
rem   2. Install EditKit.bat one level above an EditKit-X.X.X package folder.
if exist "%SOURCE%\CSXS\manifest.xml" goto source_ready
for /d %%D in ("%~dp0EditKit-*") do (
    if exist "%%~fD\EditKit\CSXS\manifest.xml" (
        set "SOURCE=%%~fD\EditKit"
        goto source_ready
    )
)

:source_ready
if not exist "%SOURCE%\CSXS\manifest.xml" (
    echo ERROR: The EDITKIT files were not found.
    echo ERROR: No se encontraron los archivos de EDITKIT.
    echo.
    echo Extract the entire ZIP before running this installer. Do not move this BAT alone.
    echo Extrae todo el ZIP antes de ejecutar este instalador. No muevas solamente este BAT.
    echo.
    pause
    exit /b 1
)

tasklist /FI "IMAGENAME eq AfterFX.exe" /NH 2>NUL | find /I "AfterFX.exe" >NUL
if not errorlevel 1 goto adobe_running

tasklist /FI "IMAGENAME eq Adobe Premiere Pro.exe" /NH 2>NUL | find /I "Adobe Premiere Pro.exe" >NUL
if not errorlevel 1 goto adobe_running

rem CEPHtmlEngine can remain open briefly after an Adobe application closes and
rem keep extension files locked even when AfterFX.exe is no longer visible.
tasklist /FI "IMAGENAME eq CEPHtmlEngine.exe" /NH 2>NUL | find /I "CEPHtmlEngine.exe" >NUL
if not errorlevel 1 goto adobe_running

echo Preparing Adobe CEP for manually installed extensions...
echo Preparando Adobe CEP para extensiones instaladas manualmente...
echo.

rem EDITKIT does not enable Windows Developer Mode. These per-user registry
rem values only let supported Adobe CEP generations load a manually installed
rem panel. No administrator access, network request, or system-wide setting is
rem used. Adobe documents PlayerDebugMode for this purpose.
set "CEP_SETUP_FAILED="
for %%V in (10 11 12 13) do (
    reg.exe add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >>"%LOG%" 2>&1
    if errorlevel 1 set "CEP_SETUP_FAILED=1"
)
if defined CEP_SETUP_FAILED goto cep_setup_failed

if not exist "%EXTENSIONS%" (
    mkdir "%EXTENSIONS%" >NUL 2>&1
    if errorlevel 1 goto install_failed
)

if exist "%WORKROOT%" rmdir /S /Q "%WORKROOT%" >NUL 2>&1
mkdir "%STAGE%" >NUL 2>&1
if errorlevel 1 goto install_failed

echo Installing EDITKIT for the current Windows user...
echo Instalando EDITKIT para el usuario actual de Windows...
echo.

rem Build and verify a complete temporary copy before touching the active plugin.
robocopy "%SOURCE%" "%STAGE%" /E /R:3 /W:1 /COPY:DAT /DCOPY:DAT /NFL /NDL /NJH /NJS /NP /LOG:"%LOG%" >NUL
if errorlevel 8 goto stage_failed
if not exist "%STAGE%\CSXS\manifest.xml" goto stage_failed

rem Move the current plugin aside so installation is all-or-nothing. The backup
rem stays outside the CEP extensions directory and cannot be loaded by Adobe.
if exist "%DEST%" (
    move "%DEST%" "%BACKUP%" >NUL 2>&1
    if errorlevel 1 goto files_locked
)

move "%STAGE%" "%DEST%" >NUL 2>&1
if errorlevel 1 goto swap_failed

if exist "%BACKUP%" rmdir /S /Q "%BACKUP%" >NUL 2>&1
if exist "%WORKROOT%" rmdir /S /Q "%WORKROOT%" >NUL 2>&1

echo Installation completed successfully.
echo Instalacion completada correctamente.
echo.
echo Open After Effects or Premiere Pro and select:
echo Window ^> Extensions ^(Legacy^) ^> EDITKIT
echo.
echo Abre After Effects o Premiere Pro y selecciona:
echo Ventana ^> Extensiones ^(heredadas^) ^> EDITKIT
echo.
echo Settings, profiles, and presets are stored separately and were not removed.
echo Los ajustes, perfiles y presets se guardan por separado y no se eliminaron.
echo.
pause
exit /b 0

:adobe_running
echo Close After Effects, Premiere Pro, and their remaining CEP windows.
echo Cierra After Effects, Premiere Pro y sus ventanas CEP restantes.
echo.
echo If they are already closed, wait a few seconds and run the installer again.
echo Si ya estan cerrados, espera unos segundos y ejecuta el instalador otra vez.
echo.
pause
exit /b 2

:cep_setup_failed
echo Adobe CEP could not be prepared for the current Windows user.
echo No se pudo preparar Adobe CEP para el usuario actual de Windows.
echo.
echo EDITKIT did not enable Windows Developer Mode or change system-wide settings.
echo EDITKIT no activo el modo desarrollador de Windows ni ajustes globales.
goto install_failed_cleanup

:files_locked
echo The current EDITKIT folder is in use or could not be moved.
echo La carpeta actual de EDITKIT esta en uso o no se pudo mover.
echo.
echo Close all Adobe applications and run the installer again.
echo Cierra todas las aplicaciones de Adobe y ejecuta el instalador otra vez.
goto install_failed_cleanup

:swap_failed
if exist "%BACKUP%" if not exist "%DEST%" move "%BACKUP%" "%DEST%" >NUL 2>&1
goto install_failed_cleanup

:stage_failed
echo The package could not be copied to the temporary installation folder.
echo No se pudo copiar el paquete a la carpeta temporal de instalacion.
goto install_failed_cleanup

:install_failed
echo Installation could not be completed.
echo No se pudo completar la instalacion.
goto install_failed_details

:install_failed_cleanup
if exist "%STAGE%" rmdir /S /Q "%STAGE%" >NUL 2>&1
if exist "%WORKROOT%" rmdir /S /Q "%WORKROOT%" >NUL 2>&1

:install_failed_details
echo.
echo Diagnostic log / Registro de diagnostico:
echo %LOG%
echo.
echo You can install manually by copying the EditKit folder to:
echo Puedes instalar manualmente copiando la carpeta EditKit en:
echo %DEST%
echo.
pause
exit /b 3
