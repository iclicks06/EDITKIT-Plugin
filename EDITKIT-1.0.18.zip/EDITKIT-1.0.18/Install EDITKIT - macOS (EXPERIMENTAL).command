#!/bin/bash

# EDITKIT experimental installer for macOS.
# This readable script performs no downloads, uses no administrator privileges,
# and changes only the current user's Adobe CEP configuration and extension files.

set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE="$SCRIPT_DIR/EditKit"
EXTENSIONS="$HOME/Library/Application Support/Adobe/CEP/extensions"
DEST="$EXTENSIONS/EditKit"
TMP_BASE="${TMPDIR:-/tmp}"
LOG="$TMP_BASE/EDITKIT-install.log"
WORKROOT=""
STAGE=""
BACKUP=""

pause_before_exit() {
    printf '\nPress Return to close / Pulsa Enter para cerrar: '
    read -r _editkit_unused
}

safe_cleanup() {
    if [ -n "$WORKROOT" ]; then
        case "$WORKROOT" in
            "$TMP_BASE"/EDITKIT-installer.*) rm -rf -- "$WORKROOT" ;;
        esac
    fi
}

restore_previous() {
    if [ -n "$BACKUP" ] && [ -d "$BACKUP" ] && [ ! -e "$DEST" ]; then
        mv "$BACKUP" "$DEST" >/dev/null 2>&1 || true
    fi
}

fail_install() {
    printf '\nInstallation could not be completed.\n'
    printf 'No se pudo completar la instalacion.\n'
    restore_previous
    safe_cleanup
    printf '\nDiagnostic log / Registro de diagnostico:\n%s\n' "$LOG"
    pause_before_exit
    exit 1
}

printf '\nEDITKIT Installer for macOS (EXPERIMENTAL)\n'
printf 'Instalador de EDITKIT para macOS (EXPERIMENTAL)\n'
printf '================================================\n\n'

# Support both common extraction layouts: next to EditKit, or one level above
# an EDITKIT-X.X.X package directory.
if [ ! -f "$SOURCE/CSXS/manifest.xml" ]; then
    for PACKAGE_DIR in "$SCRIPT_DIR"/EDITKIT-* "$SCRIPT_DIR"/EditKit-*; do
        if [ -f "$PACKAGE_DIR/EditKit/CSXS/manifest.xml" ]; then
            SOURCE="$PACKAGE_DIR/EditKit"
            break
        fi
    done
fi

if [ ! -f "$SOURCE/CSXS/manifest.xml" ]; then
    printf 'ERROR: The EDITKIT files were not found.\n'
    printf 'ERROR: No se encontraron los archivos de EDITKIT.\n\n'
    printf 'Extract the entire ZIP before running this installer.\n'
    printf 'Extrae todo el ZIP antes de ejecutar este instalador.\n'
    pause_before_exit
    exit 1
fi

if pgrep -f 'Adobe After Effects|Adobe Premiere Pro|CEPHtmlEngine' >/dev/null 2>&1; then
    printf 'Close After Effects, Premiere Pro, and their remaining CEP processes.\n'
    printf 'Cierra After Effects, Premiere Pro y sus procesos CEP restantes.\n'
    pause_before_exit
    exit 2
fi

WORKROOT="$(mktemp -d "$TMP_BASE/EDITKIT-installer.XXXXXX")" || fail_install
STAGE="$WORKROOT/EditKit"
BACKUP="$WORKROOT/Previous"
: > "$LOG" || fail_install

printf 'Preparing a verified temporary copy...\n'
printf 'Preparando una copia temporal verificada...\n'
ditto "$SOURCE" "$STAGE" >>"$LOG" 2>&1 || fail_install
[ -f "$STAGE/CSXS/manifest.xml" ] || fail_install

mkdir -p "$EXTENSIONS" >>"$LOG" 2>&1 || fail_install

printf 'Preparing Adobe CEP for the current macOS user...\n'
printf 'Preparando Adobe CEP para el usuario actual de macOS...\n'
for CEP_VERSION in 10 11 12 13; do
    defaults write "com.adobe.CSXS.$CEP_VERSION" PlayerDebugMode -string "1" >>"$LOG" 2>&1 || fail_install
done

if [ -e "$DEST" ]; then
    mv "$DEST" "$BACKUP" >>"$LOG" 2>&1 || fail_install
fi

if ! mv "$STAGE" "$DEST" >>"$LOG" 2>&1; then
    restore_previous
    fail_install
fi

safe_cleanup

printf '\nInstallation completed successfully.\n'
printf 'Instalacion completada correctamente.\n\n'
printf 'Open After Effects or Premiere Pro and choose:\n'
printf 'Window > Extensions (Legacy) > EDITKIT\n\n'
printf 'Abre After Effects o Premiere Pro y selecciona:\n'
printf 'Ventana > Extensiones (heredadas) > EDITKIT\n\n'
printf 'Settings, profiles, and presets were preserved.\n'
printf 'Los ajustes, perfiles y presets se conservaron.\n'
pause_before_exit
exit 0
