@echo off
setlocal EnableExtensions
title EDITKIT Uninstaller

set "DEST=%APPDATA%\Adobe\CEP\extensions\EditKit"

echo.
echo EDITKIT Uninstaller / Desinstalador de EDITKIT
echo =============================================
echo.

if not exist "%DEST%" (
    echo EDITKIT was not found in the per-user Adobe extensions folder.
    echo No se encontro EDITKIT en la carpeta de extensiones del usuario.
    echo.
    pause
    exit /b 0
)

echo This will remove only the plugin files from:
echo Esto eliminara solamente los archivos del plugin de:
echo %DEST%
echo.
echo Settings, profiles, and presets will be preserved.
echo Las configuraciones, perfiles y presets se conservaran.
echo.
set /p "CONFIRM=Continue / Continuar? (Y/N): "
if /I not "%CONFIRM%"=="Y" if /I not "%CONFIRM%"=="S" (
    echo Cancelled / Cancelado.
    pause
    exit /b 0
)

rmdir /S /Q "%DEST%"
if exist "%DEST%" (
    echo Close After Effects and Premiere Pro, then try again.
    echo Cierra After Effects y Premiere Pro y vuelve a intentarlo.
    echo.
    pause
    exit /b 1
)

echo EDITKIT was uninstalled. Your personal data was preserved.
echo EDITKIT fue desinstalado. Tus datos personales se conservaron.
echo.
pause
exit /b 0
